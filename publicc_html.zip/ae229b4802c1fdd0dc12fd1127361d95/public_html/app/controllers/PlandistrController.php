<?php


namespace app\controllers;

//require ROOT.'/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use vendor\core\base\Controller;

class PlandistrController extends AppController {

    public function indexAction() {
        if ($this->cur_user->access == 4) redirect(BASE_URL . '/kontrdistr/stud');
        $data = $this->data;
        $this->setMeta('Шаблон для распределения');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $this->layout = $this->cur_user->access == 4 ? 'stud' : 'manager';
        $class = isset($_GET['class']) && $_GET['class']!='null' ? $_GET['class'] : '';
        $disc = isset($_GET['disc']) && $_GET['disc']!='null' ? $_GET['disc'] : '';
        $sem = isset($_GET['sem']) && $_GET['sem']!='null' ? $_GET['sem'] : '';
        $course = isset($_GET['course']) && $_GET['course']!='null' ? $_GET['course'] : '';
        $data['class'] = $class;
        $data['disc'] = $disc;
        $data['sem'] = $sem;
        $data['course'] = $course;

        $this->view = 'test';
        if (isset($_GET['test2'])) $this->view = 'test';
        $this->set($data);
    }

    public function studAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);

        $data = $this->data;
        $this->view = 'stud';
        $this->setMeta('Распределение нагрузки');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['uid'] = $id = $this->cur_user['id'];
        $sem2 = $this->cur_user->course * 2;
        $data['plan2'] = \R::getAssoc("SELECT * FROM plan WHERE class=? AND s{$sem2} != '0|0|0|0|0|0|0|0|0' ORDER BY disc", [$this->cur_user->class]);

        foreach ($data['plan2'] as $k => $item) {
            $mark = array_values(\R::getAll("select mark,type from taskwork where disc=? and stud_id = ? and mark is not null", [$item['disc'], $this->cur_user->id]));
            $marks = [];
            foreach ($mark as &$i) {
                if ($i['mark'] == 6) $i['mark'] = 'зач';
                if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
//                    $marks[] = "{$i['type']}:<b>{$i['mark']}</b>";
                $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['type']}:<b>{$i['mark']}</b>".'</span>';
            }
            $t_marks = [];
            $usp = \R::findAll('uspevaemost',"gruppa=? and fam = ? and disciplina = ? and semestr=?",
                [$this->cur_user->class, $this->cur_user->name, $item['disc'], $sem2]);
//                if ($item['disc'] == 'Информационные технологии в управлении') { dump($usp); die; }
//                dd2($usp);
            // and othetnost in ('Экзамен', 'Зачет', 'Дифференцированный зачет', 'Аттестация')
            foreach ($usp as $i) {
                switch ($i['othetnost']) {
                    case 'Экзамен': $i['othetnost']='экз'; break;
                    case 'Зачет': $i['othetnost']='зач'; break;
                    case 'Дифференцированный зачет': $i['othetnost']='диф.з'; break;
                    case 'Аттестация': $i['othetnost']='атт'; break;

                    case 'Домашняя контрольная работа': $i['othetnost']='д.к/р'; break;
                    case 'Аудиторная контрольная работа': $i['othetnost']='ауд.к/р'; break;
                    case 'Курсовая работа': $i['othetnost']='курс/р'; break;
                    case 'Курсовой проект': $i['othetnost']='курс/пр'; break;
                }

                if (!empty( $i['ocenka'])) {
                    if ($i['othetnost']!=='экз'   &&
                        $i['othetnost']!=='зач'   &&
                        $i['othetnost']!=='диф.з' &&
                        $i['othetnost']!=='атт') {
                        $marks[] =   '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['othetnost']}:<b>{$i['ocenka']}</b>".'</span>';
                    } else {
                        $t_marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['othetnost']}:<b>{$i['ocenka']}</b>".'</span>';
                    }
                }
            }
            $data['plan2'][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
            $data['plan2'][$k]['total_marks'] = !empty($t_marks) ? implode(' ', $t_marks) : '';
            $parse = explode('|',$item["s$sem2"]);
            if ($parse[4]==0 && ($parse[5]!=0 || $parse[7]!=0)
                && $parse[0]==0 && $parse[1]==0 && $parse[2]==0
                && $parse[3]==0 && $parse[6]==0 && $parse[8]==0
                && empty($t_marks)) $data['plan2'][$k]['total_marks'] = 'Без оценки';
            if ($this->cur_user->course==1 && $parse[4]==1) $data['plan2'][$k]['total_marks'] = 'Тестирование';
        }

        $this->set($data);
    }

    public function getVkrTasksAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $this->layout = false;
        $class = isset($_GET['class']) ? $_GET['class'] : false;
//        $disc = isset($_GET['disc']) ? $_GET['disc'] : false;
        $sem = isset($_GET['sem']) ? $_GET['sem'] : false;

        $sql = [];
//        if ($class) $sql[] = "class='{$class}'";
//        if ($disc) $sql[] = "disc='{$disc}'";
//        if ($sem) $sql[] = "sem='{$sem}'";
//        $sql = implode(' and ', $sql);

        $html = [];

        $vkr_user = \R::getAssoc("select * from vkruser where sem='{$sem}' and lektor_id is not null order by user_id and status!=2");

        foreach ($vkr_user as $item) {
            $st = \R::findOne('users',"id=?", [$item['user_id']]);
            $pr = \R::findOne('users',"id=?", [$item['lektor_id']]);
            if ($class) if ($st->class != $class) continue;
            $c_class = addcslashes(json_encode( $st['class']),'\\');
            $c_disc = addcslashes(json_encode( $item['disc']),'\\');

            $ua = \R::findOne('vkraccesscurs',"class like ? and disc like ?",["%$c_class%", "%$c_disc%"]);
            $uac = $ua ? \R::findOne('users',"id=?",[$ua['user_id']])['name'] : '';

            $html[] = [$st->name, $st->class, $item['disc'], $uac, $pr->name, 'Лектор'];
        }
        header('Content-Type: application/json');
        die(json_encode(['data' => $html]));
    }

    public function getVkrAccessTableAction() {
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        $this->layout = false;
        $class = isset($_GET['class']) ? $_GET['class'] : false;
        $disc = isset($_GET['disc']) ? $_GET['disc'] : false;


        $sql = [];
//        if ($class) $sql[] = "class='{$class}'";
//        if ($disc) $sql[] = "disc='{$disc}'";
//        $sql = !empty($sql) ? implode(' and ', $sql) : 1;

        $html = [];

        $vkr_user = \R::findAll('vkraccesscurs');

        foreach ($vkr_user as $item) {
            if (($item['class'] == 'null') && ($item['disc'] == 'null')) continue;
            $st = \R::findOne('users',"id=?", [$item['user_id']]);

            $d_class = !is_null($item['class']) ? json_decode($item['class'],1) : null;
            $d_disc = json_decode($item['disc'],1);
//            dd($d_napr == null);
            $class = !is_null($d_class) ? implode(', ', $d_class) : '';
            $disc = !is_null($d_disc) ? implode(', ', $d_disc) : '';
//            $pr = \R::findOne('users',"id=?", [$item['lektor_id']]);
//            if ($class) if ($st->class != $class) continue;
//            $c_class = addcslashes(json_encode( $st['class']),'\\');
//            $c_disc = addcslashes(json_encode( $item['disc']),'\\');

//            $ua = \R::findOne('vkraccess',"class like ? and disc like ?",["%$c_class%", "%$c_disc%"]);
//            $uac = $ua ? \R::findOne('users',"id=?",[$ua['user_id']])['name'] : '';

            $html[] = [$st->name, $class, $disc];
        }
        header('Content-Type: application/json');
        die(json_encode(['data' => $html]));
    }

    public function getTasksCursAction() {
       ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $this->layout = false;
        $class = isset($_GET['class']) && $_GET['class']!='null' ? $_GET['class'] : false;
        $disc = isset($_GET['disc']) && $_GET['disc']!='null' ? $_GET['disc'] : false;
        $sem = isset($_GET['sem']) && $_GET['sem']!='null' ? $_GET['sem'] : false;
        $print = isset($_GET['print']) && $_GET['print']!='null' ? $_GET['print'] : false;
        $getfile = isset($_GET['getfile']) && $_GET['getfile']!='null' ? $_GET['getfile'] : false;

        $html = [];
        $sql = [];
        if (!$class || !$disc) die(json_encode(['data' => []]));

        if ($class) $sql[] = "class = '{$class}'";
        if ($disc) $sql[] = "disc = '{$disc}'";
        $sql = implode(' and ', $sql);
        $i = 0;

        $class_ = $class;
        $disc_ = $disc;
        $studs = \R::findAll('users',"class=? and kodstatusa=240 order by name",[$class_]);
        $plan = \R::findOne('plan', "class=? and disc=? and s{$sem}!='0|0|0|0|0|0|0|0|0' and user_id is not null",[$class, $disc]);
        $prep_ = $plan ? \R::findOne('users','id=?', [$plan->user_id])->name : '';
        foreach ($studs as $stud) {
            $button = '';
            $html[] = [$stud->id.'|'.$disc_, ++$i, $stud->name, $class_, $disc_, $prep_, $button];
        }

        if ($print) {
            $table = "<table border='1' style='border-collapse:collapse;width: 100%;font-size: 0.75em;'>";
            $table .= "<tr>";
                $table .= "<th align='center'>№</th>";
                $table .= "<th align='left'>ФИО Студента</th>";
                $table .= "<th>Группа</th>";
                $table .= "<th>Предмет</th>";
                $table .= "<th>ФИО Преподавателя</th>";
            $table .= "</tr>";
            foreach ($html as $item) {
            $table .= "<tr>";
                $table .= "<td>{$item[1]}</td>";
                $table .= "<td>{$item[2]}</td>";
                $table .= "<td>{$item[3]}</td>";
                $table .= "<td>{$item[4]}</td>";
                $table .= "<td>{$item[5]}</td>";
            $table .= "</tr>";
            }
            $table .= "</table>";
            echo $table;
            die();
        }

        if ($getfile) {
            setlocale(LC_TIME, 'Russian');
            // Create new Spreadsheet object
            $spreadsheet = IOFactory::load(WWW . '/faqres/import.xls');
            $spreadsheet->getActiveSheet();
            $spreadsheet->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
            $spreadsheet->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
            $spreadsheet->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
            $spreadsheet->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
            $spreadsheet->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
            // Группа	Семестр	Дисциплина	Студент	Руководитель
            $i = 1;
            foreach ($html as $item) {
                $i++;
                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue("A{$i}", "{$class}")
                    ->setCellValue("B{$i}", "{$sem}")
                    ->setCellValue("C{$i}", "{$disc}")
                    ->setCellValue("D{$i}", $item[2])
                    ->setCellValue("E{$i}", $item[5]);
            }

            // Set active sheet index to the first sheet, so Excel opens this as the first sheet
            $spreadsheet->setActiveSheetIndex(0);
            // Redirect output to a client’s web browser (Xls)
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="'.$class.'-'.$disc.'-'.$sem.' семестр'.'.xls"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');

            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0

            $writer = IOFactory::createWriter($spreadsheet, 'Xls');
            $writer->save('php://output');
            die();
        }
        die(json_encode(['data' => $html]));
    }

    public function getClassAction()
    {
        $class = ($_POST['class']) ?: null;
        if (!$class) die(0);
        $vkr = array_values(\R::getAssoc("select disc from vkrclasscurs where class=?",[$class]));
        $res = '';
        foreach ($vkr as $item) {
            $res .= "<option>{$item}</option>";
        }
        die($res);
    }

    public function saveClassAction()
    {
        $discs = ($_POST['discs']) ?: null;
        $class = ($_POST['class']) ?: null;

        if (!$discs || !$class) {
            echo 0;
            die;
        };
        $discs = json_decode($discs);
        $list = [];
        foreach ($discs as $disc) $list[] = "'" . $disc . "'";
        $beans = \R::findAll('vkrclasscurs', "class='{$class}' and disc not in (" . \R::genSlots($list) . ")", $list);
        \R::trashAll($beans);
        $res = '';
        date_default_timezone_set('Asia/Yekaterinburg');
        foreach ($discs as $disc) {
            $res .= "<option>{$disc}</option>";
            $vkr = \R::dispense('vkrclasscurs');
            $vkr->class = $class;
            $vkr->disc = $disc;
            $vkr->created = \R::isoDateTime();
            \R::store($vkr);
        }

//        header('Content-Type: application/json');
        die(1);
    }

    public function saveAccessAction()
    {
        die();
        $user_id = $this->cur_user->id;
        $discs = ($_POST['discs']) ?: null;
        $class = ($_POST['class']) ?: null;

        if (!$user_id) die(0);

        $user = \R::findOne('vkraccesscurs',"user_id=?", [$user_id]);
        if (!$user) $user = \R::dispense('vkraccesscurs');

        $user->user_id = $user_id;
        $user->disc = json_encode($discs);
        $user->class = json_encode($class);
        \R::store($user);
        die(1);
    }

    public function saveAccesssAction() {
        $class = ($_POST['class']) ?: null;
        $sem = ($_POST['sem']) ?: null;
        $disc = ($_POST['disc']) ?: null;

        if (!$class || !$sem || !$disc) die(0);
        $v = \R::dispense('vkruserkontr');
        $v->class = $class;
        $v->sem = $sem;
        $v->disc = $disc;
        \R::store($v);
        die(1);
    }

    public function getListDiscsAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $this->layout = false;
        $class = ($_POST['class']) ?: null;
        $sem = ($_POST['sem']) ?: null;
        $html4 = '';
        $vkr = \R::getAssoc("select disc from vkruserkontr where class=? and sem=?",[$class, $sem]);
        $vkr = array_values($vkr);

        $plan = \R::getAssoc("select disc from plan where s{$sem}!='0|0|0|0|0|0|0|0|0' and class='{$class}'");
        foreach ($plan as $item) {
            if (count($vkr)) {
                if (in_array($item, $vkr)) continue;
            }
//            $html4 .= '<li class="list-group-item" data-value="'.$item.'" >' . $item . '</li>';
            $html4 .= '<option>' . $item . '</option>';
        }
        die($html4);
    }

    public function delPrepodAction() {
        $user_id = $this->cur_user->id;
        $prep_id = ($_POST['prepod']) ?: null;

        if (!$user_id || !$prep_id) die(0);

        $user = \R::findOne('vkraccesscurs',"user_id=?", [$user_id]);
        if (!$user) die(0);

        $users = json_decode($user->users,1);
        unset($users[array_search($prep_id, $users)]);

        $user->users = json_encode($users);

        \R::store($user);
        die(1);
    }

    public function delDiscAction() {
        $disc = ($_POST['disc']) ?: null;
        $sem = ($_POST['sem']) ?: null;
        $class = ($_POST['class']) ?: null;
        if (!$disc || !$sem || !$class) die(0);
        $beans = \R::findAll('vkruserkontr', "class=? and sem=? and disc=?", [$class,$sem,$disc]);
        \R::trashAll($beans);
        die(1);
    }

    public function getVkrInfoAction() {
        $user = $this->cur_user->id;
        if (!$user) die(0);
        $vkr = \R::findOne('vkraccesscurs',"user_id=?",[$user]);
        if (!$vkr) die(0);
        header('Content-Type: application/json');
        die(json_encode([
            'class' => json_decode($vkr->class),
            'disc' => json_decode($vkr->disc),
        ]));
    }

    public function getVkrInfoBAction() {
            $user = $this->cur_user->id;
            if (!$user) die(0);
            $vkr = \R::findOne('vkraccesscurs',"user_id=?",[$user]);
            if (!$vkr) die(0);
            $html = $prep = '';

            $vkr_users = json_decode($vkr->users);

            foreach ($vkr_users as $item) {
                $us = \R::findOne('users',"id=?",[$item]);
                $username = (strpos($us->name, '(')) ? preg_replace( '~ \(.*\) ~' , " ", $us->name ) : $us->name;
                $name = explode(' ', str_replace('  ', ' ', $username));

                $prep .= '<option value="'.$us->id.'">'.$username.'</option>';

                $html .= '<a class="btn-xs list-group-item col-xs-6 col-md-4">
                            <span class="del" data-id="'.$us->id.'" style="cursor:pointer;float:right;"> ×</span>
                            <span>'.$name[0].'</span>
                        </a>';
            }

            $c = $d = '<option disabled selected value="">Не выбрано</option>';

            $class = json_decode($vkr->class);
            $disc = json_decode($vkr->disc);

            foreach ($class as $item) $c .= '<option>'.$item.'</option>';
            foreach ($disc as $item) $d .= '<option>'.$item.'</option>';

//            die($html);
            header('Content-Type: application/json');
            die(json_encode([
                'users' => $html,
                'prep' => $prep,
                'class' => $c,
                'disc' => $d,
            ]));
        }

    public function getVkrDiscAction() {
        $class = ($_GET['class']) ?: null;
        $sem = ($_GET['sem']) ?: null;
        $html = '';
//        $vkr = array_values(\R::getAssoc("select disc from plan where class=? and s{$sem} like '_|_|1%'",[$class]));
        $vkr = array_values(\R::getAssoc("select disc from plan where class=? and s{$sem}!='0|0|0|0|0|0|0|0|0'",[$class]));
        foreach ($vkr as $item) $html .= '<option>' . $item . '</option>';
        $count = count($vkr);
        $sel = current($vkr);
        $res = $html;
        die(json_encode(compact('res','count', $sel)));
    }

    public function getVkrDiscBAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
            $class = ($_GET['class']) ?: null;
            $sem = ($_GET['sem']) ?: null;
            $user = ($_GET['user']) ?: null;

            $user_ = \R::findOne('vkraccesscurs',"user_id=?",[$user]);
            $discs = json_decode($user_->disc,1);
            $class_ = json_decode($user_->class,1);
            if (!$discs || !$sem) die('');
            if (!$class) {
                $vkr = array_values(\R::getAssoc("select disc from vkrclasscurs where and class in (".
                    \R::genSlots($class_).")",$class_));
            } else {
                $vkr = array_values(\R::getAssoc("select disc from vkrclasscurs where and class = ?",[$class]));
            }

            $html = '';
            foreach ($vkr as $item) {
                if (!in_array($item, $discs)) continue;
                $html .= '<option>' . $item . '</option>';
            }
            die($html);
        }

    public function getListDiscAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $this->layout = false;
        if (!empty($_GET['class'])) {
            $class = ($_GET['class'] != '') ? $_GET['class'] : null;
            $sem = ($_GET['sem'] != '') ? $_GET['sem'] : null;
            $html4 = '';
            $vkr = array_values(\R::getAssoc("select disc from vkruserkontr where class=? and sem=?",[$class, $sem]));
            foreach ($vkr as $item) {
                $html4 .= '<a class="list-group-item">
                                <span class="del" data-id="'.$item.'" style="cursor:pointer;float:right;"> ×</span>
                                <span>'.$item.'</span>
                           </a>';
            }


            header('Content-Type: application/json');
            echo json_encode(['res' => $html4]);
        }
        die;
    }

    public function getListDiscCursAction() {
        $this->layout = false;
        if (!empty($_GET['class'])) {
            $class = ($_GET['class'] != '') ? $_GET['class'] : null;
            if (!empty($class)) {
                $class_str = "class = '{$class}'";
                $list = ($this->cur_user->access == 1) ? \R::getAssoc("SELECT disc FROM plan WHERE {$class_str} ORDER BY disc") :
                    \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND kafedra<>'' ORDER BY disc",[$this->cur_user->id]);
            }

            $html4 = '';
            $vkr = array_values(\R::getAssoc("select disc from vkrclasscurs where class=?",[$class]));
            foreach ($list as $item) {
                $vkr_sel = in_array($item,$vkr) ? 'true' : '';
                $html4 .= '<li class="list-group-item" data-value="'. $item.'" data-checked="'.$vkr_sel.'">' . $item . '</li>';
            }

            header('Content-Type: application/json');
            echo json_encode(['res' => $html4]);
        }
        die;
    }

    public function uploadAction() {
        if ($this->cur_user->access == 4) header("Location: " . BASE_URL . 'tests');
        $data = $this->data;
        $this->setMeta('Распределение контр.');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $this->set($data);
    }

    public function uploadsaveAction() {
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        $this->layout = false;
        if (!empty($_FILES['xls']["name"])) {
            $file = $_FILES['xls'];
            $file_path_excel = $file['tmp_name'];
            $ar = readExelFile($file_path_excel);
            unset($ar[0]);
            foreach ($ar as $ar_colls) {
                if (!$ar_colls[0]) break;
                $class = $ar_colls[0];
                $sem = $ar_colls[1];
                $disc = $ar_colls[2];
                $user = $ar_colls[3] ? \R::findOne('users',"access=4 and name=?",[$ar_colls[3]]) : null;
                $lektor = $ar_colls[4] ? \R::findOne('users',"access=3 and name=?",[$ar_colls[4]]) : null;
                $user_id = $user ? $user->id : null;
                $lektor_id = $lektor ? $lektor->id : null;
                $q = \R::findOne('vkruserkontr', "user_id=? and disc=? and sem=?", [$user_id, $disc, $sem]);
                if (!$q) $q = \R::dispense('vkruserkontr');
                $q->class = $class;
                $q->sem = $sem;
                $q->disc = $disc;
                $q->userId = $user_id;
                $q->lektorId = !is_null($lektor_id) ? $lektor_id : $q->lektorId;
                \R::store($q);
            }
            if (file_exists($file_path_excel)) unlink($file_path_excel);
        }
        header("Location: " . BASE_URL . 'kontrdistr');
        die;
    }
}