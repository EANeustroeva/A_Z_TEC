<?php

namespace app\controllers;

use Carbon\Carbon;

class UsersController extends AppController
{

    public function indexAction()
    {
        $data = $this->data;
        $this->setMeta('Контакты');
//        $this->view = 'search';
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['my_id'] = $this->cur_user->id;
        $friends_id = ($this->usr->get_user_friends($this->cur_user->id));
        $data['users'] = $this->usr->get_user($friends_id);
        $data['is_friend'] = true;
        $data['class'] = $this->usr->get_class_list();
        $data['course'] = $this->usr->get_course_list();

        $this->set($data);
    }

    public function createUserAction()
    {
        if ($this->cur_user->access != 1) {
            header("Location: " . BASE_URL);
            die;
        }


    }

    public function userDeleteAction()
    {
        if ($this->cur_user->access != 1) throw error('123');
        if (!empty($_POST['id'])) \R::trash('users', $_POST['id']);
//        if ($this->cur_user->access != 1) redirect();
//        if (!empty($_POST['id'])) \R::trash('users', $_POST['id']);
//        redirect();
        die;
    }

    public function accessuserAction()
    {
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        if ($this->cur_user->access != 1) throw error('123');

        $msg = "Успешно сохранено!";
        $hh = ['id', 'name', 'login', 'username', 'password', 'dolg', 'podr', 'email', 'sendmail'];
        $user = !empty($_POST['id']) ? \R::load('users', $_POST['id']) : \R::dispense('users');
        foreach ($hh as $k => $h) {
            $v = trim($_POST[$k]);
            if ($h == 'login') {
                if (empty($v)) $v = null;
                else if (\R::findOne('users', 'login=?', [$v])) continue;
            }
            $user->$h = $v;
        }
        $user->access = 2;
        \R::store($user);
        die($msg);
    }

    public function contdeleteAction()
    {
        if ($this->cur_user->access != 1) throw error('123');
        if (!empty($_POST['id'])) \R::trash('cont', $_POST['id']);
//        if ($this->cur_user->access != 1) redirect();
//        if (!empty($_POST['id'])) \R::trash('users', $_POST['id']);
//        redirect();
        die;
    }

    public function contuserAction()
    {
        if ($this->cur_user->access != 1) throw error('123');
        $msg = "Успешно сохранено!";
        $hh = ['id', 'fio', 'gruppa', 'status', 'prikazy', 'fromd', 'tod', 'metodist'];
        $user = !empty($_POST[0]) ? \R::findOne('cont', "id=?", [$_POST[0]]) : false;
        if (!$user) $user = \R::dispense('cont');
        foreach ($hh as $k => $h) {
            $v = trim($_POST[$k]);

            if ($h == 'metodist') {
                if ($user[$h] != $v) {
                    $name = explode(" ", $v);
//                     $fi = $name[0] . '&nbsp;' . mb_substr($name[1],0,1,"UTF-8") . '.' . mb_substr($name[2],0,1,"UTF-8") . '.';
                    $this->email('snedz91@gmail.com', 'Вы назначены методистом',
                        "{$name[1]} {$name[2]}!<br> Вас назначили методистом для студента <b>{$user['fio']}</b> группы {$user['gruppa']} находящегося в состоянии {$user['status']}");
                    $msg = "Сообщение отправлено методисту!";
                }
            }

            $user->$h = $v;
        }
        \R::store($user);
        die($msg);
    }

    public function contingent__Action()
    {
        if ($this->cur_user->access != 1) redirect();

        if ($this->isAjax()) {

//            die($html);
        }

        $data = $this->data;
        $this->setMeta('Движение контингента');
        //        $this->view = 'search';
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        //        if (isset($_GET['qwe'])) $this->view = 'contengent2';

        $met = [];
        $metodists = \R::getCol("select distinct name from users where access=2 order by name");
        foreach ($metodists as $metodist) $met[] = '"' . $metodist . '"';
        $data['metodists'] = implode(',', $met);
        $data['statuses'] = '"Академ.отпуск"';

        $data['users'] = \R::findAll('cont');

        if (isset($_GET['qwe'])) {
            ddd(\R::findOne('cont', "id=?", [1]));
        }

        $this->set($data);
    }

    public function contingentAction()
    {
        if ($this->cur_user->access != 1) redirect();

        if ($this->isAjax()) {

//            die($html);
        }

        $data = $this->data;
        $this->setMeta('Движение контингента');
        //        $this->view = 'search';
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;

        $met = [];
        $metodists = \R::getCol("select distinct name from users where access=2 order by name");
        foreach ($metodists as $metodist) $met[] = '"'.$metodist.'"';
        $data['metodists'] = '"",'.implode(',', $met);
        $data['statuses'] = '"Академ.отпуск","Отп.по.бер.и.род"';

        $data['noty'] = json_decode($this->cur_user->noty,1);
        $data['admin_noty'] = json_decode(\R::findOne("users",'id=?',[1])->noty,1);
        $data['list'] = \R::getAssoc("select alias,title from noty where alias like 'metodist%' or alias like 'prakt'");
        $data['noty_list'] = \R::getAssoc("select alias,header,message from noty");
        $data['config'] = \R::findOne('configs',"_key=?",['test_all_msg'])->_value;
        $data['config_metodist_email'] = \R::findOne('configs',"_key=?",['metodist_email'])->_value;

        $this->set($data);
    }

    public function accessAction()
    {
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        if ($this->cur_user->access != 1) throw error('123');

        /* $hh = ['id','name','login','username','password','dolg','podr','email','sendmail'];
         $user = !empty($_POST['id']) ? \R::load('users',$_POST['id']) : \R::dispense('users');
         foreach ($hh as $k=>$h) {
             $v = trim($_POST[$k]);
             if ($h == 'login') {
                 if (empty($v)) $v = null;
                 else if (\R::findOne('users','login=?', [$v])) continue;
             }
             $user->$h = $v;
         }
         $user->access = 2;
         \R::store($user);
         die;*/

//        throw error('123');

        /* if (!empty($_POST['n_name']) && !empty($_POST['n_login']) && !empty($_POST['n_pass'])) {
             $user = (!empty($_POST['n_id'])) ? \R::load('users',$_POST['n_id']) : \R::dispense('users');
             $user->access = 1;
             $user->name = $_POST['n_name'];
             $user->username = $_POST['n_login'];
             $user->password = $_POST['n_pass'];
             \R::store($user);
             $_SESSION['info_msg'][] = "Запись <b>$user->name</b> успешно создана/сохранена!";
             redirect();
         }*/

        if ($this->isAjax()) {
//            dd2($_POST);
            if (!empty($_POST['id'])) {
                $us = \R::load('users', $_POST['id']);
                if ($_POST['rules'] == '') $us->rules = null;
                else $us->rules = implode(',', $_POST['rules']);
                \R::store($us);
            }
            die;
        }
        $data = $this->data;
        $this->setMeta('Доступы');
//        $this->view = 'search';
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['my_id'] = $this->cur_user->id;
        $data['menu_list'] = \R::findAll('menu');

        $data['users'] = \R::findAll('users', 'access=1 AND id!=?', [$data['my_id']]);

        $this->set($data);
    }

    public function metodistsAction()
    {
        if ($this->cur_user->access != 1) redirect();
        if (isset($_GET['qwe'])) $this->view = 'metodists_new';

        if ($this->isAjax()) {
            $users = \R::findAll('users', 'access=2 AND id!=?', [$this->cur_user->id]);
            $out = [];
            foreach ($users as $user) {
                $out[] = [
                    $user['id'],
                    $user['name'],
                    $user['login'],
                    $user['username'],
                    $user['password'],
                    $user['dolg'],
                    $user['podr'],
                    $user['email'],
                    $user['sendmail'],
                ];
            }
            die(json_encode(['data' => $out]));
        }

        if (!empty($_POST['n_name']) && !empty($_POST['n_login']) && !empty($_POST['n_pass'])) {
            $user = (!empty($_POST['n_id'])) ? \R::load('users', $_POST['n_id']) : \R::dispense('users');
            $user->access = 2;
            $user->name = $_POST['n_name'];
            $user->username = $_POST['n_login'];
            $user->password = $_POST['n_pass'];
            \R::store($user);
            $_SESSION['info_msg'][] = "Запись <b>$user->name</b> успешно создана/сохранена!";
            redirect();
        }

        $data = $this->data;
        $this->setMeta('Сотрудники');
//        $this->view = 'search';
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['my_id'] = $this->cur_user->id;
        $data['menu_list'] = \R::findAll('menu');

        $data['users'] = \R::findAll('users', 'access=2 AND id!=?', [$data['my_id']]);

        $this->set($data);
    }

    public function addFriendAction()
    {
        $this->layout = false;
        $cur_user = \R::load('users', $_SESSION['logged_user']['id']);
        $f = \R::dispense('friends');
        $f->user_id = $cur_user['id'];
        $f->friend_id = $_POST['usr_id'];
        \R::store($f);
//        header("Location: " . BASE_URL . '?id=' . $_POST['usr_id']);
        $redicet = $_SERVER['HTTP_REFERER'];
        @header("Location: $redicet");
    }

    public function delFriendAction()
    {
        $this->layout = false;
        $this->usr->del_friend($this->cur_user->id, $_POST['usr_id']);
//        header("Location: " . BASE_URL . '?id=' . $_POST['usr_id']);
        $redicet = $_SERVER['HTTP_REFERER'];
        @header("Location: $redicet");
    }

    public function dialogAction()
    {
        if ($this->isAjax()) {
            dd2($_POST);
            die;
        }
        $this->layout = false;
        $cur_user = $this->cur_user->id;
        $buddy_id = $_POST['usr_id'];
        $name = isset($_POST['name']) ? $_POST['name'] : '';
        $msg = $_POST['msg'];

        if (is_array($buddy_id)) {
            $d_id = $this->msg->create_dialog($cur_user, $msg, $name, 1);
            foreach ($buddy_id as $usr) {
                $this->msg->add_user_to_dialog($usr, $d_id);
            }
        } else {
            $res = $this->usr->get_dialog_with($buddy_id, $cur_user);
            if (!empty($res)) {
                $d_id = $res;
                $this->msg->insert([
                    'user_id' => $cur_user,
                    'dialog_id' => $d_id,
                    'message' => $msg,
                ]);
            } else {
                $d_id = $this->msg->create_dialog($cur_user, $msg, $buddy_id);
//                $this->msg->add_user_to_dialog($buddy_id, $d_id);
            }

            if (!empty($_FILES)) {
                $uploadDir = BASE_PATH . 'upload/im/';
                $tempFile = $_FILES['file']['tmp_name'];

                $title = md5(uniqid());
                while (file_exists(WWW . '/' . $uploadDir . $title)) {
                    $title .= rand(10, 99);
                }

                $targetFile = $uploadDir . $title;
                if (move_uploaded_file($tempFile, $targetFile)) {
                    $this->msg->insert([
                        'user_id' => $this->cur_user->id,
                        'dialog_id' => $d_id,
                        'message' => $_FILES['file']['name'],
                        'file' => $title
                    ]);
                }
            };

        }
        if ($this->isAjax()) {
            echo $data['msg'] = json_decode($this->msg->messages($d_id));
            die;
        }
        if (isset($_GET['widget'])) redirect('/im/dialog?id=' . $d_id . '&widget=1');
        redirect();
        header("Location: " . BASE_URL . 'im/dialog?id=' . $d_id);
    }

    public function dispatchAction()
    {
        $this->layout = false;
        $name = $_POST['name'];

        $fac = !empty($_POST['dfac']) ? $_POST['dfac'] : null;
        $course = !empty($_POST['dcourse']) ? $_POST['dcourse'] : null;
        $class = !empty($_POST['dclass']) ? json_encode($_POST['dclass']) : null;
        $msg = $_POST['msg'];

        $cur_user = $this->cur_user->id;

        $d_id = $this->msg->create_dialog($cur_user, $msg, $name, 2, $fac, $class, $course);
//        $this->msg->add_user_to_dialog($cur_user, $d_id);

        header("Location: " . BASE_URL . 'im/dialog?id=' . $d_id);
    }

    public function searchAction()
    {
        $data = $this->data;
        $limit = 8;
        $course = isset($_GET['course']) ? $_GET['course'] : null;
        $class = isset($_GET['class']) ? $_GET['class'] : null;

        $data['users'] = $this->usr->get_all($limit, 0, $course, $class);

        if ($this->isAjax()) {
            $page = intval($_GET['page']);
            $course = isset($_GET['course']) ? $_GET['course'] : null;
            $class = isset($_GET['class']) ? $_GET['class'] : null;
            $data['users'] = $this->usr->get_all($limit, $page, $course, $class);

        }

        $data['count_users'] = \R::count('users');
        $data['max_pages'] = ceil($this->usr->get_count_users($course, $class) / $limit);
        $this->setMeta('Справочник');
//        $this->view = 'search';
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['my_id'] = $this->cur_user->id;

        foreach ($data['users'] as $k => $user) {
            $data['users'][$k]['is_friend'] = ($this->usr->is_friend($this->cur_user->id, $k)) ? true : false;
        }
        $data['is_friend'] = false;
        $data['class'] = $this->usr->get_class_list($course, $this->cur_user);
        $data['course'] = $this->usr->get_course_list();

        $this->set($data);
    }

    public function changepayAction()
    {
//        if (!isset($_POST['status'])) redirect();
        $this->layout = false;
        switch ($_POST['status']) {
            case '-1':
            case '':
                $stat = null;
                break;
            case '0':
                $stat = 0;
                break;
            case '1':
                $stat = 1;
                break;
        }
        \R::exec("UPDATE users SET master_pay=? WHERE access=4", [$stat]);
        redirect();
    }

    public function search()
    {

    }
}