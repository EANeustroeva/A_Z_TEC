<?php


namespace app\controllers;

// '19 6 54'
use app\models\Doc;

class DocsController extends AppController {

    public function ckeditorAction() {
        $data = $this->data;
        $this->setMeta('Файловый браузер');
        $this->layout = 'ckeditor';
        $data['meta'] = $this->meta;
        $this->set($data);
    }

    public function indexAction() {
        if ($this->cur_user->access != 1) redirect('view');


        $data = $this->data;
        $this->setMeta('Документы 2.0');
        $data['meta'] = $this->meta;



        $this->set($data);
    }

    public function _indexAction() {
        if ($this->cur_user->access == 4)
            redirect('view');
        $data = $this->data;
        $this->setMeta('Документы');

        $arr = [];
        if ($this->cur_user->access == 1 || $this->cur_user->access == 3) {
            $this->view = 'manager';
        }

        switch ($this->cur_user->access) {
            case 1:
                $mfiles = \R::findAll('mfiles');
                foreach ($mfiles as $file) {
                    $course = $file['course'] . ' курс';
                    // $napr = $file['napr'];
                    // $s1 = $file['dop'];
                    $s1 = str_replace('|','; ',$file['class']);
                    $s2 = !empty($file['sem']) ? $file['sem'] . ' семестр' : null;
                    $s3 = $file['disc'];
                    $fname = $file['ftitle'];
                    if (empty($s1) && empty($s2) && empty($s3))    $arr[$course][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && empty($s2) && empty($s3))   $arr[$course][$s1][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && empty($s3))   $arr[$course][$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && empty($s2) && !empty($s3))   $arr[$course][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && !empty($s2) && empty($s3))  $arr[$course][$s1][$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && !empty($s3))  $arr[$course][$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && empty($s2) && !empty($s3))  $arr[$course][$s1][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && !empty($s2) && !empty($s3)) $arr[$course][$s1][$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                }
                // dd($arr);
                break;
            case 3:
//                $gr = \R::getAssoc("SELECT class FROM userclass WHERE user_id=? ORDER BY class",[$this->cur_user->id]);
//                $ds = \R::getAssoc("SELECT disc FROM plan WHERE user_id=? ORDER BY disc",[$this->cur_user->id]);
//                foreach ($gr as &$item) $item = "class LIKE '%$item%'";
//                foreach ($ds as &$item) $item = "disc = '$item'";
//                $dsstr = (!empty($ds)) ? ' ('.implode(' OR ', $ds).' OR disc IS NULL)': 'disc IS NULL';
//                $mfiles = \R::findAll('mfiles', '('.implode(' OR ', $gr).') AND '.$dsstr);
                $mfiles = \R::findAll('mfiles', "user_id=?",[$this->cur_user->id]);
                foreach ($mfiles as $file) {
                    $s1 = str_replace('|','; ',$file['class']);
                    $s2 = !empty($file['sem']) ? $file['sem'] . ' семестр' : null;
                    $s3 = $file['disc'];
                    $fname = $file['ftitle'];
                    if (empty($s1) && empty($s2) && empty($s3)) $arr[$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && empty($s2) && empty($s3)) $arr[$s1][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && empty($s3)) $arr[$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && empty($s2) && !empty($s3)) $arr[$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && !empty($s2) && empty($s3)) $arr[$s1][$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && !empty($s3)) $arr[$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && empty($s2) && !empty($s3)) $arr[$s1][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && !empty($s2) && !empty($s3)) $arr[$s1][$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                }
                break;
            case 4:
                $mfiles = \R::findAll('mfiles', "(course=?  OR course IS NULL) AND class=?",
                    [$this->cur_user->course, $this->cur_user->class]);
                foreach ($mfiles as $file) {
                    // $napr = $file['napr'];
                    // $s1 = $file['dop'];
                    $s2 = !empty($file['sem']) ? $file['sem'] . ' семестр' : null;
                    $s3 = $file['disc'];
                    $fname = $file['ftitle'];

                    if (empty($s1) && empty($s2) && empty($s3)) $arr[$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    // if (!empty($s1) && empty($s2) && empty($s3)) $arr[$s1][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && empty($s3)) $arr[$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && empty($s2) && !empty($s3)) $arr[$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    // if (!empty($s1) && !empty($s2) && empty($s3)) $arr[$s1][$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && !empty($s3)) $arr[$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    // if (!empty($s1) && empty($s2) && !empty($s3)) $arr[$s1][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    // if (!empty($s1) && !empty($s2) && !empty($s3)) $arr[$s1][$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                }
                break;
        }

        $data['meta'] = $this->meta;
        $data['docs'] = $this->doc->getList($this->cur_user->id);
        $data["full_size"] = $data['docs']["full_size"];
        unset($data['docs']["full_size"]);

        function getListFilesAcc($a, &$i = 0, $lvl = -1) {
            $lvl++;
            $html = $st = '';
            switch ($lvl) {
                case 0:
                    $st = 'area';
                    break;
                case 1:
                    $st = 'equipamento';
                    break;
                case 2:
                    $st = 'ponto';
                    break;

            }
            foreach ($a as $k => $item) {
                if (isset($item['file']) && !is_array($item['file']))
                    $html .= '<a data-toggle="tooltip" title="'.$item['descr'].'" class="list-group-item" href="' . BASE_URL . 'download?f=' . base64_encode('../ino/' . $item['file']) . '&c=' . urlencode($k) . '"><i class="glyphicon glyphicon-open-file"></i> ' . $k . '</a>';
                else {
                    $html .= '
                    <div class="panel panel-default">
                        <div class="panel-heading ' . $st . '">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#collapse' . $i . '" href="#collapse' . ++$i . '">' . $k . '</a>
                            </h4>
                        </div>
                        <div id="collapse' . $i . '" class="panel-collapse collapse">
                            <div class="panel-body">';
                    $html .= getListFilesAcc($item, $i, $lvl);
                    $html .= '</div>
                        </div>
                    </div>';
                }
                $i++;
            }
            return $html;
        }

        $html = '<div class="panel-group" id="collapse0">';
        /************************/
        $i=0;
        $courses = 8;
        for ($j = 1; $j<=$courses; $j++) {
            $ii=0;
            $html .= '
                    <div class="panel panel-default">
                        <div class="panel-heading area">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#collapse' . $i . '" href="#collapse' . ++$i . '">' . $j . ' курс</a>
                            </h4>
                        </div>
                        <div id="collapse' . $i . '" class="panel-collapse collapse">
                            <div class="panel-body">';
//
                            $classes = \R::getAssoc("select class from users where course=? and class<>''",[$j]);
                            foreach ($classes as $class_item) {
                                $html .= '
                                    <div class="panel panel-default">
                                        <div class="panel-heading equipamento">
                                            <h4 class="panel-title">';
                                $ii++;
                                $html .= '
                                                <a data-toggle="collapse" data-parent="#collapse' . $i . '_' . ($ii-1) . '" href="#collapse' . $i . '_' .$ii . '">' . $class_item . '</a>
                                            </h4>
                                        </div>
                                        <div id="collapse' . $i . '_' . $ii . '" class="panel-collapse collapse">
                                            <div class="panel-body">';

                                                for ($jj = 1; $jj <= 6; $jj++) {
                                                    $html .= '
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading ponto">
                                                            <h4 class="panel-title">';
                                                    $html .= '
                                                                <a data-toggle="collapse" data-parent="#collapse' . $i . '_' . $ii . '_' . ($jj-1) . '" href="#collapse' . $i . '_' . $ii . '_' . $jj . '">' . $jj . ' семестр</a>
                                                            </h4>
                                                        </div>
                                                        <div id="collapse' . $i . '_' . $ii . '_' . $jj . '" class="panel-collapse collapse">
                                                            <div class="panel-body">';
                                                                $discs = \R::getAssoc("select disc from plan where class=? and s{$jj} != '0|0|0|0|0|0|0|0|0'",[$class_item]);

                                                    $html .=    '<table>
                                                                    <thead>
                                                                        <tr>
                                                                            <th>Название</th>                                                   
                                                                            <th>РПД</th>                                                   
                                                                            <th>ФОС</th>                                                   
                                                                            <th>Доп. файлы</th>                                                   
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>';
                                                                foreach ($discs as $disc_item) {

                                                                $html .= "<tr>
                                                                            <td>{$disc_item}</td>
                                                                            <td></td>
                                                                            <td></td>
                                                                            <td></td>
                                                                          </tr>";

                                                                }
                                                        $html .=   '</tbody>
                                                                </table>';

                                                $html .=    '</div>
                                                        </div>
                                                    </div>';
                                                }

                                    $html .=    '</div>
                                            </div>
                                        </div>';

                            }

                    $html .= '</div>
                        </div>
                    </div>';
        }

        /************************/
//        $html .= getListFilesAcc($arr);
        $html .= '';
        $html .= '</div>';

        $data['mfiles'] = $html;
/*        if (!function_exists('glob_recursive')) {
            // Does not support flag GLOB_BRACE

            function glob_recursive($pattern, $flags = 0) {
                $files = glob($pattern, $flags);*/
               // foreach (glob(dirname($pattern) . '/*', GLOB_ONLYDIR | GLOB_NOSORT) as $dir) {
               /*     $files = array_merge($files, glob_recursive($dir . '/' . basename($pattern), $flags));
                }

                return $files;
            }
        }*/
      //  $plan = glob_recursive(WWW . "/doc/*/" . $this->cur_user->class . "*");
      /*  if (!empty($plan)) {
            $data['sem'] = $this->doc->getListDir($plan[0]);
            $data['plan'] = str_replace(WWW . '/', '', $plan[0]);
        }*/

        $this->set($data);
    }

    public function uploadAction() {
        $this->layout = false;
        require_once LIBS . '/qqfileuploader.php';

        // list of valid extensions, ex. array("jpeg", "xml", "bmp")
        $allowedExtensions = [];//['jpg', 'jpeg', 'png', 'gif', "doc", "docs", "xls", "xlsx", "txt", "pdf", "rar", "zip",];
// max file size in bytes
        $sizeLimit = 50 * 1024 * 1024;
//echo BASE_PATH . 'upload/';
        $uploader = new \qqFileUploader($allowedExtensions, $sizeLimit);
        $result = $uploader->handleUpload(BASE_PATH . 'upload/docs/', FALSE);

// to pass data through iframe you will need to encode all html tags

        if (isset($result['success']) && $result['success']) {
            $file = $result['file'];
//            dd2(round( (filesize($file)/1024) ,2));
            $doc = \R::dispense('files');
            $doc->user_id = $this->cur_user['id'];
            $doc->type = 0;
            $doc->fext = strtolower(substr(strrchr($file, '.'), 1));
            $doc->fname = str_replace('.' . $doc->fext, '', strtolower(substr(strrchr($file, '/'), 1)));
            $doc->ftitle = $result['real'];
            $doc->fsize = round((filesize($file) / 1024), 2);
            $doc->fdata = \R::isoDate();
            \R::store($doc);
            $result['url'] = $this->path_to_url($file);
            unset($result['file']);

            $imgsize = getimagesize($file);
            $result['width'] = $imgsize[0];
            $result['height'] = $imgsize[1];
        }
        echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
        die;
    }

    function path_to_url($path) {
        $path = str_replace('\\', '/', $path);
        return strpos($path, BASE_PATH) === 0 ? BASE_URL . substr($path, strlen(BASE_PATH)) : $path;
    }

    public function deleteAction() {
        $this->layout = false;
        if (isset($_POST['id'])) {
            \R::trash('files', $_POST['id']);
        }
        redirect();
    }

    public function viewAction() {
        if (empty($_POST['disc'])) redirect(BASE_URL);
        $data = $this->data;
        $this->setMeta("Документы");
        $data['meta']['title'] = "Документы";
        $disc = $_POST['disc'];
        if (!empty($disc)) $mfiles = \R::findAll('mfiles', "course=? AND (class=? OR class IS NULL) AND disc=? and archive=0", [$this->cur_user->course, $this->cur_user->class, $disc]);
        $data['docs'] = $mfiles;
        $data['plan'] = \R::getAssocRow("SELECT * FROM plan WHERE class=? AND s".($this->cur_user->course * 2 -1)." != '0|0|0|0|0|0|0|0|0' AND disc=? ORDER BY disc",[$this->cur_user->class,$disc])[0];
//        dd($data['plan']);
        $data['plan']['user_id'] = \R::findOne('users','name=?',[$data['plan']['lektor']])->id;
        $d_id = $this->usr->get_dialog_with($data['plan']['user_id'], $this->cur_user->id);
//        dd($d_id);
        $data['msg'] = json_decode($this->msg->messages($d_id));
//        dd($d_id);
//        dd(json_decode($this->msg->messages(10)));
//        dd($data);
        $this->set($data);
    }

    public function editAction() {
        if ($this->cur_user->access == 4) header("Location: " . BASE_URL . 'docs');
        $data = $this->data;
        $this->setMeta("Документы");
        $data['meta']['title'] = "Документы";

        $napr_list = $classlist = $prof_list = $disc_list = '';

        if ($this->cur_user->access == 2 || $this->cur_user->access == 3) {
            $napr = \R::getAssoc("SELECT napr FROM plan WHERE user_id=? ORDER BY napr", [$this->cur_user->id]);
            $class = \R::getAssoc("SELECT class FROM userclass WHERE user_id=? ORDER BY class", [$this->cur_user->id]);
            $disc = \R::getAssoc("SELECT disc FROM plan WHERE user_id=? ORDER BY disc", [$this->cur_user->id]);
            $dop = \R::getAssoc("SELECT dop FROM plan WHERE user_id=? ORDER BY dop", [$this->cur_user->id]);
        } else {
            $napr = \R::getAssoc("SELECT napr FROM plan ORDER BY napr");
            $class = \R::getAssoc("SELECT class FROM userclass ORDER BY class");
            $disc = \R::getAssoc("SELECT disc FROM plan ORDER BY disc");
            $dop = \R::getAssoc("SELECT dop FROM plan ORDER BY dop");
        }

        foreach ($napr as $k => $item)
            $napr_list .= "<option>$k</option>";
        foreach ($class as $k => $item)
            foreach (explode("|", $k) as $cls)
                if (!empty($cls) && !strpos($classlist, $cls))
                    $classlist .= "<option>$cls</option>";
        foreach ($dop as $k => $item)
            if (!empty($k)) $prof_list .= "<option>$k</option>";
        foreach ($disc as $k => $item)
            if (!empty($k)) $disc_list .= "<option>$k</option>";
        $data['napr_list'] = $napr_list;
        $data['classlist'] = $classlist;
        $data['prof_list'] = $prof_list;
        $data['disc_list'] = $disc_list;
        $this->set($data);
    }

    public function uploaduchAction() {
        if (is_null($_FILES['file'])) {
            die;
        };
        $this->layout = false;
        $file = $_FILES['file'];
//        dd($file);
        $ext = strtolower(substr(strrchr($file['name'], '.'), 1));
        $ftitle = md5(uniqid()) .  '.' . $ext;
//        dd(WWW. '/ino/' . $ftitle);
        while (file_exists(WWW. '/ino/' . $ftitle)) {
            $ftitle .= rand(10, 99);
        }
        $res = move_uploaded_file($file['tmp_name'],WWW .'/ino/'.$ftitle);
//            file_put_contents('C:\OpenServer\domains\eduproj.loc\public\tst\ino\\' . $ftitle.'.'.$ext, get_content($url.$file->attr('href')));
        if (!$res) header("Location: ". BASE_URL . 'docs');
        $f = \R::dispense('mfiles');
        $f->ftitle = $file['name'];
        $f->fname = $ftitle;
        if (!empty($_POST['course'])) $f->course = $_POST['course'];
        if (!empty($_POST['napr'])) $f->napr = $_POST['napr'];
        if (!empty($_POST['disc'])) $f->disc = $_POST['disc'];
        if (!empty($_POST['class'])) $f->class = $_POST['class'];//implode("|", $_POST['class']);
        if (!empty($_POST['dop'])) $f->dop = $_POST['dop'];
        if (!empty($_POST['sem'])) $f->sem =  $_POST['sem'];
        if (!empty($_POST['ftype'])) $f->type =  $_POST['ftype'];
        if (!empty($_POST['descr'])) $f->descr =  $_POST['descr'];
        if ($this->cur_user->access == 3) $f->user_id = $this->cur_user->id;
//            dd($f->export());
        \R::store($f);

         echo json_encode(['success' => '<h4>Успешно загружено</h4>']);
        // echo '<a href="'.BASE_URL.'docs" class="btn btn-success">Вернуться назад</a>';
//        header("Location: ". BASE_URL . 'docs');
        die;
    }

    public function getListDiscAction() {
        ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
        $this->layout = false;
        if (!empty($_GET['class'])) {
            $class = ($_GET['class'] != '') ? $_GET['class'] : null;
            $sem = ($_GET['sem'] != '') ? $_GET['sem'] : 1;
            if (!empty($class)) {
//                foreach ($class as &$item) $item = 'class = "'.$item.'"';
//                $class_str = implode(' OR ', $class);
                $class_str = "class = '{$class}'";
                if ($this->cur_user->access == 1) {
                    if (!empty($sem)) {
                        $list = \R::getAssoc("SELECT disc FROM plan WHERE ($class_str) AND s".$sem." != '0|0|0|0|0|0|0|0|0' ORDER BY disc");
                        $vkr = \R::getAssoc("select disc from vkruserdist where ($class_str) and sem={$sem} ORDER BY disc");
                    } else {
                        $list = \R::getAssoc("SELECT disc FROM plan WHERE {$class_str} ORDER BY disc");
                    }
                    if (!empty($vkr)) {
                        $list = array_merge($list, $vkr);
                    }
                }
                else {
                    if (!empty($_GET['sem'])) $list = \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND s".$_GET['sem']." != '0|0|0|0|0|0|0|0|0' ORDER BY disc",[$this->cur_user->id]);
                    else $list = \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND kafedra<>'' ORDER BY disc",[$this->cur_user->id]);
                }
            }

            $html3 = $html4 = $html5 = '';

            $html5 = '<table class="table table-striped table-hover table-bordered table-responsive">
<thead>
    <tr>
        <th style="width: 40%;">Название предмета</th>
        <th>Доп. файлы</th>
    </tr>                
</thead>
<tbody>';

            $html = '<table class="table table-striped table-hover table-bordered table-responsive">
<thead>
    <tr>
        <th style="width: 40%;">Название предмета</th>
        <th>РПД</th>
        <th>ОС</th>
        <th>Доп. файлы</th>
    </tr>                
</thead>
<tbody>';
            $vkr = array_values(\R::getAssoc("select disc from vkrclass_ where class=? and sem=?",[$class,$sem]));
//            dd2($vkr);
            foreach ($list as $item) {
                $html3 .= '<option>' . $item . '</option>';
                $vkr_sel = in_array($item,$vkr) ? ' selected' : '';
                $html4 .= '<option'.$vkr_sel.'>' . $item . '</option>';
                $files = \R::findAll('mfiles',"class=? and sem=? and disc=? and archive=0",[$class, $sem, $item]);
                $files_str = [];
                $rpd = $fos = '';
                foreach ($files as $file) {
                    if ($file->type == 1) { $rpd = "<span style='cursor: pointer' data-id='{$file->id}' title='{$file->ftitle}' class='label label-success'><i class='glyphicon glyphicon-file'></i></span>"; continue; }
                    if ($file->type == 2) { $fos = "<span style='cursor: pointer' data-id='{$file->id}' title='{$file->ftitle}' class='label label-success'><i class='glyphicon glyphicon-file'></i></span>"; continue; }
                    $label = mb_strimwidth($file->ftitle, 0, 25, '..');
                    $files_str[] = "<span style='cursor: pointer' data-id='{$file->id}' title='{$file->ftitle}' class='label label-success'>{$label}</span>";
                }
                $files = implode(' ', $files_str);
                $rflag = ($rpd!='' && $fos!='') ? '':'danger';
//<a type="button" class="close" data-dismiss="alert" aria-label="Close">
//                    <span aria-hidden="true">&times;</span>
//                </a>

                $files2 = \R::findAll('mfilesnext',"class=? and sem=? and disc=? and archive=0",[$class, $sem, $item]);
                $files_str2 = [];
                foreach ($files2 as $file) {
                    $label = mb_strimwidth($file->ftitle, 0, 25, '..');
                    $files_str2[] = "<span style='cursor: pointer' data-id='{$file->id}' title='{$file->ftitle}' class='label label-success'>{$label}</span>";
                }
                $files2 = implode(' ', $files_str2);
                $html5 .= "<tr class=''>";
                $html5 .=    "<td class='text-left'>{$item}</td>";
                $html5 .=    '<td class="text-left"><button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-plus" data-toggle="modal" data-target="#exampleModal" data-whatever="'.$item.'" data-doctype="файл"></button> '.$files2.'</a></td>';
                $html5 .= '</tr>';

                $html .= "<tr class='{$rflag}'>";
//                $html .=    "<td class='text-left'>{$item}</td>";
                $html .=    "<td class='text-left'><a href='/docs/studs?disc={$item}&sem={$sem}&class={$class}' target='_blank'>{$item}</a></td>";
                $html .= ($rpd=='') ? '<td class="text-left"><button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-plus" data-toggle="modal" data-target="#exampleModal" data-whatever="'.$item.'" data-doctype="РПД"></button></a></td>' : "<td>{$rpd}</td>";
                $html .= ($fos=='') ? '<td class="text-left"><button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-plus" data-toggle="modal" data-target="#exampleModal" data-whatever="'.$item.'" data-doctype="ФОС"></button></a></td>' : "<td>{$fos}</td>";
                $html .=    '<td class="text-left"><button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-plus" data-toggle="modal" data-target="#exampleModal" data-whatever="'.$item.'" data-doctype="файл"></button> '.$files.'</a></td>';
                $html .= '</tr>';
            }
            $html .= '</tbody></table>';
            $html5 .= '</tbody></table>';

            $html2 = '';
            if ($class) {
                $class2 = explode('-',$class);
                $list = \R::getAll("SELECT DISTINCT class FROM users WHERE class like '{$class2[0]}-{$class2[1]}%' ORDER BY class ASC");
                foreach ($list as $item) if (!empty($item['class'])) $html2 .= '<option>' . $item['class'] . '</option>';
            }


            header('Content-Type: application/json');
            echo json_encode(['res' => $html,'res2' => $html2,'res3' => $html3,'res4' => $html4,'res5' => $html5]);
//            echo $html;
        }
        die;
    }

    public function dubAction() {
        $discs = $_POST['discs'];
        $in = $_POST['class'];
        $out = $_POST['class2'];
        $sem = $_POST['sem'];
        if (empty($in) || empty($out)) die;
        $disc = \R::findAll('mfiles',"class=? and sem=? and archive=0",[$in, $sem]);
        foreach ($disc as $item) {
            if (!in_array($item->disc, $discs)) continue;
            $dub = \R::duplicate($item);
            $dub->class = $out;
            $dub->sem = $sem;
            \R::store($dub);
        }
        echo '1';
        die;
    }

    public function getFileByIdAction() {
        $this->layout = false;
        date_default_timezone_set('Asia/Yekaterinburg');

        $arr = ['января','февраля','марта','апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
//    $arr[date('n', strtotime($message['msg_time']))-1] . date(" j, Y, g:i a", strtotime($message['msg_time'])),

        $file = \R::load('mfiles', $_GET['id']);
        $file->link = '<a title="'.$file['descr'].'" class="list-group-item" href="' . BASE_URL . 'download?f=' . base64_encode('../ino/' . $file->fname) . '&c=' . urlencode($file['ftitle']) . '"><i class="glyphicon glyphicon-open-file"></i> ' .$file['ftitle'] . '</a>';

        $file->changed = 'Файл не найден!';
        if (file_exists(WWW. '/ino/' . $file->fname)) {
            $time = filemtime(WWW. '/ino/' . $file->fname);
            $file->changed = 'Файл загружен: ' . date("H:i, j ", $time)  . $arr[date('n', $time)-1] . date(", Yг.", $time);
        }
//        $file->changed = () ..

//        date ("F d Y H:i:s.",filemtime(WWW. '/ino/' . $file->fname)) : '';
        echo json_encode($file);

        die;
    }

    public function savedocAction() {
        $this->layout = false;
        $file = \R::load('mfiles', $_GET['id']);
        $file->descr = $_GET['descr'];
        $file->type = $_GET['type'];
        \R::store($file);

        die;
    }

    public function deletedocAction() {
        $this->layout = false;
        $file = \R::load('mfiles', $_GET['id']);
        $file->archive = 1;
        \R::store($file);

        die;
    }

    public function incdocsAction() {
        if ($this->cur_user->access != 1) redirect();
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        $data = $this->data;
        $this->setMeta('Отчеты');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
//        dd($_POST);
        if (isset($_GET['q'])) {
            $classes = \R::getAssoc("select distinct class from users");
            foreach ($classes as $k => $class) {
                $discs = [];
                $sem = $_GET['q'];
                $list = \R::getAssoc("SELECT disc FROM plan WHERE class='{$class}' and s{$sem}!='0|0|0|0|0|0|0|0|0' ORDER BY disc");
                foreach ($list as $item) {
                    $c = \R::getAll("select id,type from mfiles where class=? and type=0 and disc=? and sem=? and archive=0", [$class,$item,$sem]);
                    $c1 = count(array_filter($c, function ($v) { return $v['type']==0; }));
                    $c2 = count(array_filter($c, function ($v) { return $v['type']==1; }));
                    $c3 = count(array_filter($c, function ($v) { return $v['type']==2; }));
//                    $c1 = \R::count('mfiles', "class=? and type=0 and disc=? and archive=0", [$class,$item]);
//                    $c2 = \R::count('mfiles', "class=? and type=1 and disc=? and archive=0", [$class,$item]);
//                    $c3 = \R::count('mfiles', "class=? and type=2 and disc=? and archive=0", [$class,$item]);
                    if ($c1 == 0 || $c2 == 0 || $c3 == 0) {
//                        dd($c1);
                        if ($c1 == 0) $discs[$item][0] = true;
                        if ($c2 == 0) $discs[$item][1] = true;
                        if ($c3 == 0) $discs[$item][2] = true;
                    }
                }
                if (empty($discs)) unset($classes[$k]);
                else $classes[$k] = $discs;
            }

            $data['docs'] = $classes;
            $this->layout = false;
            $html = '
    <table border="1" class="table table-bordered">
        <thead>
        <tr>
            <th>Группа</th>
            <th>РПД</th>
            <th>ФОС</th>
            <th>Доп. файлы</th>
        </tr>
        </thead>
        <tbody>';
        foreach ($data['docs'] as $k => $item) {
            $html .= '<tr>
                <td>'. $k .'</td>
                <td class="text-left">';
            foreach ($item as $key => $value) { if (isset($value[1])) $html.= "<li>{$key}</li>"; }
            $html .= '</td>
                <td class="text-left">';
            foreach ($item as $key => $value) { if (isset($value[2])) $html.= "<li>{$key}</li>"; }
            $html .= '</td>
                <td class="text-left">';
            foreach ($item as $key => $value) { if (isset($value[0])) $html.= "<li>{$key}</li>"; }
            $html.='</td>
            </tr>';
        }
            $html .= '</tbody>
    </table>';
            echo $html;
            die;
        }
        if (!empty($_POST) && !is_null($_POST['course'])) {
            $course = $_POST['course'];
            $year = 18 - $course;
            $sem = $_POST['sem'];
            $classes = \R::getAssoc("select distinct class from users where class like ?",["%-{$year}%"]);
            foreach ($classes as $k => $class) {
                /*$prof = \R::findOne(" select prof from classprof where class=?",[$class]);
                if ($prof) {
                    $discs = \R::findOne(" select disc from compdisc where prof=?",[$prof->prof]);
                    $discs = explode('|',$item['disc']);
                }*/


                $discs = [];
                $list = \R::getAssoc("SELECT disc FROM plan WHERE class='{$class}' AND s{$sem} != '0|0|0|0|0|0|0|0|0' ORDER BY disc");
                foreach ($list as $item) {
                    $c1 = \R::count('mfiles', "class=? and type=0 and sem=? and disc=? and archive=0", [$class, $sem, $item]);
                    $c2 = \R::count('mfiles', "class=? and type=1 and sem=? and disc=? and archive=0", [$class, $sem, $item]);
                    $c3 = \R::count('mfiles', "class=? and type=2 and sem=? and disc=? and archive=0", [$class, $sem, $item]);
                    if ($c1 == 0 || $c2 == 0 || $c3 == 0) {
//                        dd($c1);
                        if ($c1 == 0) $discs[$item][0] = true;
                        if ($c2 == 0) $discs[$item][1] = true;
                        if ($c3 == 0) $discs[$item][2] = true;
                    }
                }
//                dd($discs);
                if (empty($discs)) unset($classes[$k]);
                else $classes[$k] = $discs;
            }
//            dd($classes);
            $data['docs'] = $classes;
            if (!empty($_POST['print'])) {
                $this->layout = false;
                $html = '';
                if (!empty($data['docs'])) {
                    $html = '
    <table border="1" class="table table-bordered">
        <thead>
        <tr>
            <th>Группа</th>
            <th>РПД</th>
            <th>ФОС</th>
            <th>Задания</th>
        </tr>
        </thead>
        <tbody>';
        foreach ($data['docs'] as $k => $item) {
            $html .= '<tr>
                <td>'. $k .'</td>
                <td class="text-left">';
            foreach ($item as $key => $value) { if (isset($value[1])) $html.= "<li>{$key}</li>"; }
            $html .= '</td>
                <td class="text-left">';
            foreach ($item as $key => $value) { if (isset($value[2])) $html.= "<li>{$key}</li>"; }
            $html .= '</td>
                <td class="text-left">';
            foreach ($item as $key => $value) { if (isset($value[0])) $html.= "<li>{$key}</li>"; }
            $html.='</td>
            </tr>';
        }
        $html .= '</tbody>
    </table>';
                }

                echo $html;
                die;
            }
        }
        $classes = \R::getAssoc("select distinct class from users where class is not null order by class");
        $resultArray = [];
        array_walk($classes, function($item, $key) use (&$resultArray) {
            preg_match("#.*?(\d\d)#si",$item, $match);
            if (isset($match[1]))
                $resultArray['20'.$match[1]][] = $item;
        });
        krsort($resultArray);
        $data['classes'] = $resultArray;
//        $data['docs'] = \R::getAll('select * from classad');
        $this->set($data);
    }

    public function genloginAction() {
//      ini_set('max_execution_time', 9000);
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $class = isset($_POST['class']) ? $_POST['class'] : null;
        $html = '';
        if ($class) {
            $html .= "<div>
                        <div style='float: left;font-size: 1.17em;font-weight: bold;'>Регистрация обучающихся ИНО в КИИС модуль \"Студент ИНО\"*</div>
                        <div style='float: right;'>Форма 144</div></div><div style='clear: both'></div>";

            $html .= "<h3 style='text-align: center; margin: 0;'>Группа {$class}</h3>";
            $users = \R::findAll('users',"access=4 and class=? order by name",[$class]);
            $html .= "<table border='1' style='border-collapse:collapse;width: 100%;'>";
            $html .= "<tr>";
                $html .= "<th align='center'>№</th>";
                $html .= "<th>Фамилия Имя Отчество</th>";
                $html .= "<th>Логин</th>";
                $html .= "<th>Подпись</th>";
                $html .= "</tr>";
            $ct = 0;
            foreach ($users as $user) {
                $ct++;
                $html .= "<tr>";
                $html .= "<td align='center'>{$ct}</td>";
                $html .= "<td>{$user->name}</td>";
                $html .= "<td align='center'>{$user->login}</td>";
                $html .= "<td width='100'>&nbsp</td>";
                $html .= "</tr>";
            }
            $html .= "</table>";
            $html .= "<p style='margin: 0;'>* - пароль задаётся самим студентом непосредственно при первом входе на портал</p>";
        } else $html = "Группа не выбрана!";

        echo $html;
        die;

        require_once LIBS . '/../phpdocx/phpdocx/Classes/Phpdocx/Create/CreateDocx.inc';
        $docx = new \Phpdocx\Create\CreateDocx();
        $options = [
            'parseDivsAsPs'  => true,
            'baseURL'        => 'http://en.wikipedia.org/',
            'downloadImages' => true,
            'parseFloats' => true,
            'marginTop' => '571', 'marginRight' => '571', 'marginBottom' => '571', 'marginLeft' => '571'
        ];
        $docx->modifyPageLayout('A4', ['marginTop' => '571', 'marginRight' => '571', 'marginBottom' => '571', 'marginLeft' => '571',]);
        $docx->embedHTML($html,$options);
        $docx->createDocxAndDownload ('AccessLogins', true);
        die;
    }

    public function genekzAction() {
//      ini_set('max_execution_time', 9000);
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        $class = isset($_POST['class']) ? $_POST['class'] : null;
        $kurs = !empty($_POST['kurs']) ? $_POST['kurs'] : null;
        if (isset($_POST['disc']) && strpos( $_POST['disc'],'|')) {
            list($sem,$disc) = explode('|', $_POST['disc']);
        } else {
            $disc = isset($_POST['disc']) ? $_POST['disc'] : '';
            $sem = isset($_POST['sem']) ? $_POST['sem'] : null;
        }

        $prep = '';
        if (!empty($disc)&&$class) {
            if ($this->cur_user->access == 3) {
                $prep = $this->cur_user->name;
            } else {
                $prep = \R::findOne("plan","disc=? and class=? and lektor is not null",[$disc, $class])->lektor;
            }
        }
        $html = '';
        if ($class) {
            if (is_null($sem)) {
                preg_match("#\d\d#si",$class,$cur_year);
                $d = (integer) 18 - $cur_year[0];
                $sem = (date("n") < 7) ? $d*2 : $d*2 + 1;
            }

            $forma = $kurs ? 'курсовая работа' : '';

            $html .= "<div style='font-size: 0.75em;'>
                        <div style='float: left;text-align: center'>
                            <div>Министерство науки и высшего образования РФ</div>
                            <div>Уральский государственный экономический университет</div>
                            <div>ИНО</div>
                            <div>Экзаменационная ведомость №</div>
                            <div style='text-align: left'>
                                <p style='margin-bottom: 0;'>Дисциплина - <b>{$disc}</b></p>
                                <div>Форма отчётности - {$forma}</div>
                                <p style='margin-top: 0;'>Преподаватель - <b>{$prep}</b></p>
                            </div>
                        </div>
                        <div style='float: right; min-width: 250px'>
                            <div>Семестр {$sem} (зимний) <span style='float: right;'>Форма 12</span></div>
                            <div style='text-align: center'>Учебный год 2018/2019</div>
                            <p> </p>
                            <div style='text-align: center; font-size: 2em;font-weight: bold;margin: 0;'>{$class}</div>
                        </div>
                    </div>
                    <div style='clear: both'></div>";
            $users = \R::findAll('users',"access=4 and class=? and kodstatusa=240 order by name",[$class]);
            $ids = $marks = [];
            foreach ($users as $user) $ids[] = $user->id;
            if (!empty($disc)) {
                if ($this->cur_user->access == 3) {
                    $marks = \R::getAssoc("select stud_id,mark from taskwork where stud_id in (" . \R::genSlots($ids) . ") and sem={$sem} and disc='{$disc}' and type='кр' and prep_id={$this->cur_user->id} order by created", $ids);
                    $marks2 = \R::getAssoc("select stud_id,mark from taskwork where stud_id in (" . \R::genSlots($ids) . ") and sem={$sem} and disc='{$disc}' and type='кп' and prep_id={$this->cur_user->id} order by created", $ids);
                } else {
                    $marks = \R::getAssoc("select stud_id,mark from taskwork where stud_id in (".\R::genSlots($ids).") and sem={$sem} and disc='{$disc}' and type='кр' order by created", $ids);
                    $marks2 = \R::getAssoc("select stud_id,mark from taskwork where stud_id in (".\R::genSlots($ids).") and sem={$sem} and disc='{$disc}' and type='кп' order by created", $ids);

                }
            }
            $html .= "<table border='1' style='border-collapse:collapse;width: 100%;font-size: 0.75em;'>";
            $html .= "<tr>";
                $html .= "<th align='center'>№</th>";
                    $html .= "<th width='300'>Фамилия, имя, отчество</th>";
                    $html .= "<th>Допуск, № бил.</th>";
                    $html .= "<th style='text-align: center'>Контр. работы</th>";
                    $html .= "<th>Аттес-тация</th>";
                    $html .= $kurs ? "<th style='text-align: center'>Курсовая</th>" : "<th>Экзамен / зачёт</th>";
                    $html .= "<th>Подпись преподавателя</th>";
                $html .= "</tr>";
            $ct = 0;
            foreach ($users as $user) {
                $ct++;
                $html .= "<tr>";
                    $html .= "<td align='center'>{$ct}</td>";
                    $html .= "<td>{$user->name}</td>";
                    $html .= "<td>&nbsp;</td>";
                    $mark = '';
                    if (isset($marks[$user->id])) {
                        if ($marks[$user->id] == 6) $mark = 'зач.';
                        elseif ($marks[$user->id] == 7) $mark = 'на дораб.';
                        else $mark = $marks[$user->id];
                    }
                    $html .= "<td align='center'>{$mark}</td>";
                    $html .= "<td>&nbsp;</td>";
                    $mark2 = '';
                    if (isset($marks2[$user->id])) {
                        switch ($marks2[$user->id]) {
                            case $marks2[$user->id] < 3: $mark2 = 'неуд.'; break;
                            case 3: $mark2 = 'удовл.'; break;
                            case 4: $mark2 = 'хор.'; break;
                            case 5: $mark2 = 'отл.'; break;
                            case 6: $mark2 = 'зач.'; break;
                            case 7: $mark2 = '&nbsp;'; break;
//                            case 7: $mark2 = 'на дораб.'; break;
                            default: $mark2 = $marks2[$user->id];
                        }
                    }
                    $html .= $kurs ? "<td>{$mark2}</td>" : "<td>&nbsp;</td>";
                    $html .= "<td>&nbsp;</td>";
                $html .= "</tr>";
            }
            $html .= "</table>";
            $html .= "<div style='font-size: 0.75em;'>";
                $html .= "<div style='width: 280px; float:left;'>";
                    $html .= "<p style='margin-bottom: 0;'>Директор ИНО <span style='text-align: right; position: absolute; right: 290px;'>ИТОГО: {$ct} чел., из них:</span></p>";
                    $html .= "<div style='text-align: right;'>___________________   Е.Н. Ялунина</div>";
                    $html .= "<p>Дата \"____\" ________________ ________ г.</p>";
                    $html .= "<p><b>Подпись экзаменатора</b> __________________</p>";
                $html .= "</div>";
                $html .= "<div style='text-align: right;float: right; width: 340px;'>";
                $html .= "<p> </p>";
                    $html .= "<div style='width: 60%;float:left;'>";
                        $html .= "<div>Отлично ______</div>";
                        $html .= "<div>Хорошо ______</div>";
                        $html .= "<div>Удовлетворительно ______</div>";
                        $html .= "<div>Неудовлетворительно ______</div>";
                    $html .= "</div>";
                    $html .= "<div style='width: 40%;float:left;'>";
                        $html .= "<div>Зачтено ______</div>";
                        $html .= "<div>Не зачтено ______</div>";
                        $html .= "<div>Не явилось ______</div>";
                        $html .= "<div>Не допущено ______</div>";
                    $html .= "</div>";
                $html .= "</div>";
                $html .= "<div style='clear: both;'></div>";
                $html .= "<div>Примечание: деканат составляет ведомость в 1 экземпляре и выдает ее преподавателю или старосте группы в день зачета/экзамена. По окончании зачета/экзамена экзаменатор представляет ведомость в день зачета/экзамена в деканат. <br>Графа \"Допуск\" проставляется в деканате или преподавателем, \"№ билета\" - по желанию экзаменатора.</div>";
            $html .= "</div>";
        } else $html = "Группа не выбрана!";

        echo $html;
        die;

        require_once LIBS . '/../phpdocx/phpdocx/Classes/Phpdocx/Create/CreateDocx.inc';
        $docx = new \Phpdocx\Create\CreateDocx();
        $options = [
            'parseDivsAsPs'  => true,
            'baseURL'        => 'http://en.wikipedia.org/',
            'downloadImages' => true,
            'parseFloats' => true,
            'marginTop' => '571', 'marginRight' => '571', 'marginBottom' => '571', 'marginLeft' => '571'
        ];
        $docx->modifyPageLayout('A4', ['marginTop' => '571', 'marginRight' => '571', 'marginBottom' => '571', 'marginLeft' => '571',]);
        $docx->embedHTML($html,$options);
        $docx->createDocxAndDownload ('AccessLogins', true);
        die;
    }

    public function studsAction() {
        $data = $this->data;
        $this->setMeta('Просмотр');
        $data['meta'] = $this->meta;

        $disc = $_GET['disc'];
        $class = $_GET['class'];
        $sem = $_GET['sem'];
        if (isset($_GET['dd'])) dd($this->sem);


        if (!empty($disc)) $mfiles = \R::findAll('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and type=0 and archive=0", [$sem, $class, $disc]);
        if (!empty($disc)) $data['rpd'] = \R::findOne('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and archive=0 and type=1 order by id desc", [$sem, $class, $disc]);
        if (!empty($disc)) $data['fos'] = \R::findOne('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and archive=0 and type=2 order by id desc", [$sem, $class, $disc]);
        $data['docs'] = $mfiles;
        $data['plan'] = \R::getAssocRow("SELECT * FROM plan WHERE class=? AND disc=? ORDER BY disc", [$class, $disc])[0];
        if (!empty($_GET['dd'])) dd($data['plan']);
        $data['plan']['user_id'] = \R::findOne('users', 'name=?', [$data['plan']['lektor']])->id;

        if (isset($_GET['test'])) $this->view = 'indextest';

        $this->set($data);
    }

    public function getdiscsAction() {
        $this->layout = false;
        $class = isset($_POST['class']) ? $_POST['class'] : null;
        preg_match("#\d\d#si",$class,$cur_year);
        $d = (integer) 18 - $cur_year[0];
        $sem = (date("n") < 7) ? $d*2 : $d*2 + 1;
        $discs = \R::getAssoc("select disc from plan where class=? and s{$sem}!='0|0|0|0|0|0|0|0|0' order by disc",[$class]);
        echo "<option selected value=''>Ничего не выбрано</option>";
        foreach ($discs as $disc) echo "<option>{$disc}</option>";
        die;
    }
}