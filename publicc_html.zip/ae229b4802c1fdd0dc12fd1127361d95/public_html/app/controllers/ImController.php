<?php


namespace app\controllers;


use app\models\Lastmsg;
use app\models\Message;
use Carbon\Carbon;

class ImController extends AppController {

    public $last;

    public function __construct($route) {
        parent::__construct($route);
        $this->last = new Lastmsg();
    }

    public function indexAction() {
        $data = $this->data;
        $this->setMeta('Сообщения');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $id = $this->cur_user['id'];
        $dialogs = $this->msg->getDialogs($this->cur_user);
        $data['avatar'] = $data['cur_user']['avatar'] = $data['cur_user']['photo'] != '' ? BASE_URL .'order/'.$this->cur_user->photo : BASE_URL . 'assets/images/thumbs/no-image.jpg';


        if (!empty($dialogs)) {
            foreach ($dialogs as &$dialog) {
                $dialog['avatar'] = BASE_URL . 'assets/images/thumbs/no-image.jpg';
                if ($dialog['public'] == 0) {
                    $name = $this->usr->get_users_from_dialog($dialog['id'], $id);
//                     dd($name);
//                    $dialog['name'] = explode(' ', $name[0]['name'])[1];
                    $dialog['name'] = $name[0]['name'];
//                    if (!empty($name[0]['class'])) $dialog['name'] .= ' <span class="text-muted">(Группа: ' . $name[0]['class'] . ')</span>';
                    if ($name[0]['access']==4  && !empty($name[0]['class'])) $dialog['name'] .= ' <span class="label label-primary">'. $name[0]['class'] . '</span>';
//                    $dialog['avatar'] = $name[0]['photo'] = $name[0]['photo'] != '' ? BASE_URL .'order/'.$name[0]['photo']: BASE_URL . 'assets/images/thumbs/no-image.jpg';
                    $dialog['avatar'] = $name[0]['photo'] != '' && @getimagesize('https://ino-online.usue.ru/order/'. $name[0]['photo']) ? BASE_URL .'order/'.$name[0]['photo'] : '/img/no_photo/no-image.jpg';
                }
                if ($dialog['public'] == 1) $dialog['name'] = '<span class="glyphicon glyphicon-user text-primary"></span>&nbsp;' . $dialog['name'];
                if ($dialog['public'] == 2) $dialog['name'] = '<span class="glyphicon glyphicon-envelope text-danger"></span>&nbsp;' . $dialog['name'];

                $unread = $this->msg->unread_per_user($id, $dialog['id']);
                $dialog['unread'] = $unread > 0 ? $unread : null;
                $user = $this->usr->get_user($dialog['user_id']);
                $dialog['time'] = data_form_dialog($dialog['updated']);
            }
            $data['dlgs'] = $dialogs;
        }
        // $data['class'] = $this->usr->get_class_list();
        // $data['course'] = $this->usr->get_course_list();
        // dd($data['class']);
        $this->set($data);
    }

    public function dialogAction() {
//        if (isset($_GET['qwe']))
            $this->view = 'dialogtest';
        $data = $this->data;
        if ($this->isAjax()) {
            header('Content-Type: application/json');
            echo $this->messages();
            exit;
        }
        $this->setMeta('Сообщения');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $id = $_SESSION['logged_user']['id'];
        $ids = $this->usr->get_users_from_dialog($_GET['id'], $id);
        $p_id = [];
        foreach ($ids as $k => $i) {
            $p_id[] = $i['id'];
        }
        $contacts = $this->usr->get_user($p_id);//\R::findAll('users');//

        foreach ($contacts as &$contact) {
            //get unread messages from this user
            $unread = $this->msg->unread_per_user($id, $contact->id);
            $contact->unread = $unread > 0 ? $unread : null;
        }
//        if (isset($_GET['qwe'])) dump_debug(json_decode($this->messages()));

        $data['msg'] = json_decode($this->messages());
        $data['users'] = $contacts;
        $data['name'] = '';

        if (isset($_GET['widget'])) $this->layout = 'blank';
        $this->set($data);
    }

    public function dispatchAction() {
        dd($_POST);
        $this->layout = false;
        $name = $_POST['name'];
        $fac = isset($_POST['dfac']) ? $_POST['dfac'] : null;
        $course = isset($_POST['dcourse']) ? $_POST['dcourse'] : null;
        $class = isset($_POST['dclass']) ? $_POST['dclass'] : null;
        $msg = $_POST['msg'];


        die;
        $this->setMeta('Сообщения');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $id = $_SESSION['logged_user']['id'];
        $ids = $this->usr->get_users_from_dialog($_GET['id'], $id);
        $p_id = [];
        foreach ($ids as $k => $i) {
            $p_id[] = $i['id'];
        }
        $contacts = $this->usr->get_user($p_id);//\R::findAll('users');//

        foreach ($contacts as $key => $contact) {
            //get unread messages from this user
            $unread = $this->msg->unread_per_user($id, $contact->id);
            $contacts[$key]->unread = $unread > 0 ? $unread : null;
        }
        $data['msg'] = json_decode($this->messages());
        $data['users'] = $contacts;
        $data['name'] = '';

        $this->set($data);
    }

    public function saveAction() {
        $this->save_message();
        $this->layout = false;
    }

    public function converseAction() {
        if ($this->cur_user->access == 4) redirect('/');
        if (empty($_GET['class'])) redirect('/');
        $this->setMeta('Профиль');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $id = $_SESSION['logged_user']['id'];
        $data['cur_user'] = $this->cur_user;

        $class = $_GET['class'];
        preg_match("#\d\d#si",$class,$cur_year);
        $d = (integer) date('y') - $cur_year[0];
        $sem = (date("n") < 7) ? $d*2 : $d*2 + 1;
        $data['sem'] = $sem;

        $q = \R::findOne('classsem',"class=? and enabled=1",[$this->cur_user->class]);
        if ($q) {
            $sem = 1;
            $q = \R::findOne('classsem',"class=? and enabled=1",[$this->cur_user->class]);
            $ns = explode('|',$q->ns);
            for ($s=0;$s<9;$s++) {
                if (empty($ns[$s])) break;
                if (Carbon::parse($ns[$s])->lte(Carbon::now()))
                    $sem = $s+1;
            }
//            foreach ($ks as $k=>$item) { if (empty($item)) break; if(strtotime(date('d.m.Y')) > strtotime($item)) $sem++; }
            if ($sem>9) $sem = 9;
            $data['sem'] = $sem;
        }
//        $sem = $data['sem'];

//if (isset($_GET['qwe'])) \R::fancyDebug(true);
//        $sems = $sem > 1 ? [$sem=>[],($sem-1)=>[]] : [$sem => []];

//        foreach ($sems as $sem=>$value) {

        for ($sem=$data['sem'];$sem>0;$sem--) {
            $uids = [];
            $users = \R::findAll('users',"class=? order by name",[$class]);
            if (count($users) == 0) continue;
            foreach ($users as $user) $uids[] = $user->id;
            $discs = \R::getAssoc("select disc from plan where user_id=? and class=? and s{$sem}!='0|0|0|0|0|0|0|0|0'",[$id, $class]);
            $discs_kr = \R::getAssoc("select disc from vkruserkontr where lektor_id=? and class=? and sem=?",[$id, $class,$sem]);
            $discs_cr = \R::getAssoc("select disc from vkrusercurs where lektor_id=? and class=? and sem=?",[$id, $class,$sem]);
            $discs = array_merge($discs, $discs_kr);
            $discs = array_merge($discs, $discs_cr);
            $rpd_fos_docs = count($discs) ? \R::getAll("select * from mfiles where sem={$sem} and (class = '{$class}') AND disc 
                in (".\R::genSlots(array_values($discs)).") and archive=0 order by id desc", array_values($discs)) : []; // OR class IS NULL
            foreach ($discs as $k=>$disc) {
                $u = []; $files = [];
//                $rpd   = \R::findOne('mfiles', "sem=? and (class = ? OR class IS NULL) AND disc=? and archive=0 and type=1 order by id desc", [$sem, $class, $disc]);
//                $fos   = \R::findOne('mfiles', "sem=? and (class = ? OR class IS NULL) AND disc=? and archive=0 and type=2 order by id desc", [$sem, $class, $disc]);
//                $docs  = \R::findAll('mfiles', "sem=? and (class = ? OR class IS NULL) AND disc=? and archive=0 and type=0 order by id desc", [$sem, $class, $disc]);

                $rpd   = current(array_filter($rpd_fos_docs, function ($v) use ($disc) { return $v['disc'] == $disc && $v['type'] == 1; }));
                $fos   = current(array_filter($rpd_fos_docs, function ($v) use ($disc) { return $v['disc'] == $disc && $v['type'] == 2; }));
                $docs  = array_filter($rpd_fos_docs, function ($v) use ($disc) { return $v['disc'] == $disc && $v['type'] == 0; });

                foreach ($docs as $doc) { $files[] = $doc['fname']; }
                $marks = \R::getAssoc("select marked,stud_id,mark,type from taskwork where prep_id=? and disc=? and class=? and sem=? and mark is not null order by marked desc", [$this->cur_user->id, $disc, $class, $sem]);

                $d_kontr = !empty($uids) ? \R::getAssoc("select user_id,lektor_id from vkruserkontr where lektor_id is not null and disc='{$disc}' and sem='{$sem}' and user_id in (".\R::genSlots($uids).")",$uids) : [];
                $d_curs = !empty($uids) ? \R::getAssoc("select user_id,lektor_id from vkrusercurs where lektor_id is not null and disc='{$disc}' and sem='{$sem}' and user_id in (".\R::genSlots($uids).")",$uids) : [];
                $lektors = !empty($d_kontr) ? \R::getAssoc("select id,name from users where id in (".\R::genSlots(array_values($d_kontr)).")", array_values($d_kontr)) : [];
                $lektors2 = !empty($d_curs) ? \R::getAssoc("select id,name from users where id in (".\R::genSlots(array_values($d_curs)).")", array_values($d_curs)) : [];
    //            $d_kontr = \R::getAssoc("select user_id,lektor_id from vkrusercurs where disc='{$disc}' and sem='{$sem}' and user_id in (".\R::genSlots($this->vkr_ids).")",$this->vkr_ids);
    //            dd($d_kontr);
    //            dd($docs);

                foreach ($users as $user) {
                    $marks_ = $files2 = [];
                    $rpd_   = !empty($rpd) ? \R::findOne('downloads',"user_id=? and filename=?",[$user->id, $rpd['fname']]) : false;
                    $fos_   = !empty($fos) ? \R::findOne('downloads',"user_id=? and filename=?",[$user->id, $fos['fname']]) : false;
                    $docs_  = !empty($files) ? \R::getAssoc("select filename,created from downloads where user_id={$user->id} and filename in (".\R::genSlots($files).")",$files) : false;
                    if ($docs_) foreach ($docs_ as $doc) { $files2[] = date('d.m.Y H:i',strtotime($doc)); }

                    foreach ($marks as $kk=>$mark) {
                        if ($mark['stud_id']!=$user->id) continue;
                        $type = '';
                        switch ($mark['type']) {
                            case 'кр': $type = 'Контр.раб.'; break;
                            case 'зач': $type = 'Зач.'; break;
                            case 'прр': $type = 'Пров.раб.'; break;
                            case 'экз': $type = 'Экз.раб.'; break;
                            case 'кп': $type = 'Курс.раб.'; break;
                        }
                        if ($mark['mark'] == 6) $mark['mark'] = 'зач';
                        if ($mark['mark'] == 7) $mark['mark'] = 'на дораб.';
                        $marks_[] = '<small>['.date('d.m.Y H:i',strtotime($kk)) . "]</small> {$type}:<b>{$mark['mark']}</b>";
                    }
                    $post = '';
                    if(!empty($d_kontr) && array_key_exists($user->id, $d_kontr)) {
                        $ss = "Распределено (к/р):<br><b>{$lektors[$d_kontr[$user->id]]}</b>";
                        $cc = '#5cb85c';
                        $post = '<span class="pull-right" data-toggle="tooltip" data-html="true"
                                data-placement="right" title="'.$ss.'"><i style="color: '.$cc.'; font-size: 18px; cursor:pointer;" 
                                class="glyphicon glyphicon-info-sign"></i></span>';
                    } elseif (!empty($d_curs) && array_key_exists($user->id, $d_curs)) {
                        $ss = "Распределено (курс/р):<br><b>{$lektors2[$d_curs[$user->id]]}</b>";
                        $cc = '#5cb85c';
                        $post = '<span class="pull-right" data-toggle="tooltip" data-html="true"
                                data-placement="right" title="'.$ss.'"><i style="color: '.$cc.'; font-size: 18px; cursor:pointer;" 
                                class="glyphicon glyphicon-info-sign"></i></span>';
                    }
                    $u[$user->id] = [
                        'name' => $user->name . $post,
                        'rpd'   => $rpd_ ? date('d.m.Y H:i',strtotime($rpd_->created)): false,
                        'fos'   => $fos_ ? date('d.m.Y H:i',strtotime($fos_->created)): false,
                        'docs'  => $docs_ ? $files2 : false,
                        'marks' => implode('<br>',$marks_),
                    ];
                }
                $discs[$k] = [
                    'rpd'   => $rpd,
                    'fos'   => $fos,
                    'docs'  => $docs,
                    'users' => $u,
                    'is_d'  => in_array($k,$discs_kr)
                ];
            }
            $data['discs'][$sem] = $discs;
        }
        $tests = \R::findAll('tests',"user_id=?", [$this->cur_user->id]);
//        $data['discs'] = $discs;
        $data['tests'] = $tests;
        $this->view = 'new';
        $this->set($data);
    }

    public function converceAction() {
        $this->setMeta('Сообщения');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['class'] = $this->usr->get_class_list(null, $this->cur_user);
        $classes = [];
        foreach ($data['class'] as $class) $classes[] = $class['class'];
        $data['users'] = \R::findAll('users',"access=4 and class in (".\R::genSlots($classes).")", $classes);
        $this->set($data);
    }

    public function messages() {
        //get paginated new_messages
        $per_page = 15;
        $user = $this->cur_user->id;
        $dialog_id = isset($_GET['id']) ? $_GET['id'] : 0;//$this->input->post('user');
        $limit = isset($_POST['limit']) ? $_POST['limit'] : $per_page;
        $messages = array_reverse($this->msg->conversation((int)$dialog_id, (int)$limit));

//        $total = $this->msg->thread_len($user, $dialog_id);
        $total = $this->msg->conversation_len((int)$dialog_id);
        $arr = ['Янв','Фев','Мар','Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'];

        $buddy_id = $this->msg->getUserFromDialog($this->cur_user->id, $dialog_id);
        $chatbuddy = \R::load('users', $buddy_id);
        $systems = [];
        if (isset($_GET['qwe'])) {
            if ($this->cur_user->access==3 && $chatbuddy->access==4 || $this->cur_user->access==4 && $chatbuddy->access==3) {
                $stud_id = $this->cur_user->access == 4 ? $this->cur_user->id : $buddy_id;
                $prep_id = $this->cur_user->access == 4 ? $buddy_id : $this->cur_user->id;
                $works = \R::getAll("select * from taskwork where stud_id=? and archive=0 order by created", [$stud_id]); //,current($messages)['msg_time']
                dd($works);
            }
        }

        $thread = [];
        foreach ($messages as $message) {
            if (count($systems)) {
                $system = array_filter($systems, function ($v) use ($message) {
                   return $v['created'] < strtotime($message['msg_time']);
                });
                foreach ($system as $ss) {
                    $thread[] = [
                        'msg' => "работа <b>{$ss['ftitle']}</b> загружена",
                        'time' => data_form_dialog($message['msg_time']),
                        'type' => 'system'
                    ];
                }
            }

            $owner = \R::load('users', $message['user_id']);
            if ($message['user_id'] != $user && $message['is_read'] == '0') $this->msg->mark_read($message['id']);
            $chat = ['msg' => ($message['message']), 'status' => $message['is_read'], 'sender' => $message['user_id'],
                     'recipient' => $message['dialog_id'],
                     'avatar' => $owner->avatar = $owner->photo != '' ? BASE_URL .'order/'.$owner->photo: BASE_URL . 'assets/images/thumbs/no-image.jpg',
                     //                 'body' => parse_smileys($message->message, $this->smiley_url),
                     'body' => ($message['message']),
                     'file' => !empty($message['file']) ? $message['file'] : false,
//                     'time' => date("M j, Y, g:i a", strtotime($message['msg_time'])),
//                     'time' => $arr[date('n', strtotime($message['msg_time']))-1] . date(" j, Y, g:i a", strtotime($message['msg_time'])),
                     'time' => data_form_dialog($message['msg_time']),
                     'type' => $message['user_id'] == $user ? 'out' : 'in',
                     'name' => $owner->name //explode(' ', $owner->name)[1] . ' ' . explode(' ', $owner->name)[2]];
            ];
            array_push($thread, $chat);
        }

        $contact = ['name' => $chatbuddy->name,
                    'class' => $chatbuddy->access == 4 ? ' <span class="label label-primary">' . $chatbuddy['class'] . '</span>' : '',
                    'd_id' => $dialog_id,
                    'status' => $chatbuddy->online, 'id' => $chatbuddy->id, 'limit' => $limit + $per_page,
                    'more' => $total <= $limit ? false : true, 'scroll' => $limit > $per_page ? false : true,
                    'remaining' => $total - $limit];
        $response = ['success' => true, 'errors' => '', 'message' => '', 'buddy' => $contact, 'thread' => $thread];
        //add the header here
        // header('Content-Type: application/json');
        return json_encode($response);
    }

    public function uploadAction() {
        $this->layout = false;
        require_once LIBS . '/qqfileuploader.php';
        $upload_path = BASE_PATH . 'upload/im/';


        $uploader = new \qqFileUploader();
        // Specify the list of valid extensions, ex. array("jpeg", "xml", "bmp")
        $uploader->allowedExtensions = array();
        // Specify max file size in bytes.
        $uploader->sizeLimit = 1000 * 1024 * 1024;
        // Specify the input name set in the javascript.
        $uploader->inputName = 'qqfile';
        // If you want to use resume feature for uploader, specify the folder to save parts.
        $uploader->chunksFolder = 'chunks';
        // Call handleUpload() with the name of the folder, relative to PHP's getcwd()
//        $result = $uploader->handleUpload($upload_path, FALSE);

        $method = $_SERVER["REQUEST_METHOD"];
        if ($method == "POST") {
            header("Content-Type: text/plain");
            // Call handleUpload() with the name of the folder, relative to PHP's getcwd()
            $result = $uploader->handleUpload($upload_path, md5(mt_rand()));
            // To return a name used for uploaded file you can use the following line.
            $result["uploadName"] = $uploader->getUploadName();

            if (!empty($_POST['d_id'])) {
                $this->msg->insert([
                    'user_id' => $this->cur_user->id,
                    'dialog_id' => $_POST['d_id'],
                    'message' => $uploader->getName(),
                    'file' => $result["uploadName"]
                ]);
            }

            echo json_encode($result);
        }
        else {
            header("HTTP/1.0 405 Method Not Allowed");
        }
        die;


        // To save the upload with a specified name, set the second parameter.
         $result = $uploader->handleUpload($upload_path, md5(mt_rand()).'_'.$uploader->getName());
        // To return a name used for uploaded file you can use the following line.
        $result['uploadName'] = $uploader->getUploadName();
        header("Content-Type: text/plain");
        echo json_encode($result);
        die;

        $method = $_SERVER["REQUEST_METHOD"];
        if ($method == "POST") {
            header("Content-Type: text/plain");
            // Call handleUpload() with the name of the folder, relative to PHP's getcwd()
            $result = $uploader->handleUpload("files");
            // To return a name used for uploaded file you can use the following line.
            $result["uploadName"] = $uploader->getUploadName();
            echo json_encode($result);
        }
        else {
            header("HTTP/1.0 405 Method Not Allowed");
        }




        // list of valid extensions, ex. array("jpeg", "xml", "bmp")
        $allowedExtensions = [];//['jpg', 'jpeg', 'png', 'gif', "doc", "docs", "xls", "xlsx", "txt", "pdf", "rar", "zip",];
// max file size in bytes
        $sizeLimit = 50 * 1024 * 1024;
//echo BASE_PATH . 'upload/';
        $uploader = new \qqFileUploader($allowedExtensions, $sizeLimit);
        $result = $uploader->handleUpload(BASE_PATH . 'upload/im/', FALSE);

// to pass data through iframe you will need to encode all html tags
        if (isset($result['success']) && $result['success']) {
            $file = $result['file'];/*
//            dd2(round( (filesize($file)/1024) ,2));
            $doc = \R::dispense('files');
            $doc->user_id = $this->cur_user['id'];
            $doc->type = 0;
            $doc->fext = strtolower(substr(strrchr($file, '.'), 1));
            $doc->fname = str_replace('.' . $doc->fext, '', strtolower(substr(strrchr($file, '/'), 1)));
            $doc->ftitle = $result['real'];
            $doc->fsize = round((filesize($file) / 1024), 2);
            $doc->fdata = \R::isoDate();
            \R::store($doc);*/
            $result['url'] = $this->path_to_url($file);
            unset($result['file']);

//            $imgsize = getimagesize($file);
//            $result['width'] = $imgsize[0];
//            $result['height'] = $imgsize[1];
        }
        echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
        die;
    }

    public function save_message() {
        $logged_user = $_SESSION['logged_user']['id'];
        $dialog_id = isset($_GET['id']) ? $_GET['id'] : 0;
        $message = isset($_POST['message']) ? $_POST['message'] : '';
        $_POST['message'] = '';
        if ($message != '' && $dialog_id != '') {
            $msg_id = $this->msg->insert(['user_id' => $logged_user, 'dialog_id' => $dialog_id,
                                          'message' => $message]);//$this->msg->filter_bazar($message),]);
            $msg = $this->msg->get($msg_id);

            $owner = \R::load('users', $msg['user_id']);
            $chat = array('msg' => $msg['id'], 'sender' => $msg['user_id'], 'recipient' => $msg['dialog_id'],
                          'avatar' => $owner->photo != '' ? $owner->photo : 'no-image.jpg',
                          // 'body' => parse_smileys($msg->message, $this->smiley_url),
                          'time' => date("M j, Y, g:i a", strtotime($msg['msg_time'])),
                          'type' => $msg['user_id'] == $logged_user ? 'out' : 'in',
                          'name' => $msg['user_id'] == $logged_user ? 'Вы' : $owner->name);

            $response = array('success' => true, 'message' => $chat);
        } else {
            $response = array('success' => false, 'message' => 'Empty fields exists');
        }
        //add the header here
        // header('Content-Type: application/json');
//        header('Location: ' . BASE_URL . 'im/dialog?id=' . $dialog_id);
        if (isset($_GET['widget'])) redirect(BASE_URL . 'im/dialog?id=' . $dialog_id. '&widget=1');
        redirect(BASE_URL . 'im/dialog?id=' . $dialog_id);
//        dump($response);
        return json_encode($response);
    }

    public function updates() {
        $new_exists = false;
        $user_id = $_SESSION['logged_user']['id'];
        $last_seen = $this->last->get_by($user_id);
        //dump($last_seen);
        $last_seen = empty($last_seen) ? 0 : $last_seen->message_id;
        $exists = $this->msg->latest_message($user_id, $last_seen);
        if ($exists) {
            $new_exists = true;
        }
        dd($exists);
        // THIS WHOLE SECTION NEED A GOOD OVERHAUL TO CHANGE THE FUNCTIONALITY
        if ($new_exists) {
            $new_messages = $this->msg->unread($this->cur_user);
            $thread = [];
            $senders = [];

            foreach ($new_messages as $message) {
                if (!isset($senders[$message['user_id']])) {
                    $senders[$message['user_id']]['count'] = 1;
                } else {
                    $senders[$message['user_id']]['count'] += 1;
                }
                $owner = \R::load('users', $message['user_id']);
                //$this->user->get($message->msg_from);
                $chat = ['msg' => $message['id'], 'status' => $message['is_read'], 'sender' => $message['user_id'],
                         'dialog' => $message['dialog_id'],
                         'avatar' => $owner->avatar != '' ? $owner->avatar : 'no-image.jpg',
                         // 'body' => parse_smileys($message->message, $this->smiley_url),
                         'time' => date("M j, Y, g:i a", strtotime($message['msg_time'])),
                         'type' => $message['user_id'] == $user_id ? 'out' : 'in',
                         'name' => ucwords($owner->firstname . ' ' . $owner->surname),];
                array_push($thread, $chat);
            }
            $groups = [];
            foreach ($senders as $key => $sender) {
                $sender = ['user' => $key, 'count' => $sender['count'],];
                array_push($groups, $sender);
            }
            // END OF THE SECTION THAT NEEDS OVERHAUL DESIGN
            $this->last->update_lastSeen($user_id);

            $response = array('success' => true, 'messages' => $thread, 'senders' => $groups,
                              // 'status' => $message['is_read'],
            );

            //add the header here
            // header('Content-Type: application/json');
            return json_encode($response);
        }
    }

    public function getListAction() {
        $this->layout = false;
        if (!empty($_GET['napr'])) {
            $napr_list = ['1' => "Бизнес-информатика", '2' => "Гостиничное дело", '3' => "Государственное и муниципальное управление", '4' => "Землеустройство и кадастры", '5' => "Информатика и вычислительная техника", '6' => "Менеджмент", '7' => "Прикладная информатика", '8' => "Продукты питания из растительного сырья", '9' => "Технология продукции и организация общественного питания", '10' => "Товароведение", '11' => "Торговое дело", '12' => "Туризм", '13' => "Управление качеством", '14' => "Управление персоналом", '15' => "Экономика", '16' => "Юриспруденция",];
            $napr = $napr_list[$_GET['napr']];
            $classes = \R::getCol("select class from users where napr_post=?",[$napr]);
        }
        if (isset($_GET['course'])) {
            $course = ($_GET['course'] != '') ? $_GET['course'] : null;
            if ($this->cur_user->access == 3) $list = $this->usr->get_class_list($course, $this->cur_user);
            else $list = $this->usr->get_class_list($course);
            $html = '';
            foreach ($list as $item) if (!empty($item['class'])) {
                if (isset($classes) && is_array($classes) && !in_array($item['class'], $classes)) continue;
                $html .= '<option>' . $item['class'] . '</option>';
            }
//            header('Content-Type: application/json');
//            echo json_encode(['res' => $html]);
            echo $html;
        }
        die;
    }

    public function msgAction() {
        if (!isset($_POST)) header("Location: " . BASE_URL);
        $data['name'] = $_GET['name'];
        $data['id'] = $_GET['id'];
        $this->setMeta('Сообщения');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $this->set($data);
    }

    public function newdialogAction() {
        $data['user'] = \R::load('users',$_GET['id']);
        $this->layout = 'blank';
        $this->set($data);
    }

    public function widgetAction() {
        $d_id = $this->usr->get_dialog_with($_POST['id'], $this->cur_user->id);
//        $msg = json_decode($this->msg->messages($d_id));
        $height = !empty($_POST['h']) ? $_POST['h'] : 300;
        if ($d_id)
            echo '<iframe src="/im/dialog?id='.$d_id.'&widget=1" width="100%" height="'.$height.'" align="left" marginheight="0" marginwidth="0" frameborder="0"></iframe>';
        else {
            echo '<iframe src="/im/newdialog?id='.$_POST['id'].'&widget=1" width="100%" height="241" align="left" marginheight="0" marginwidth="0" frameborder="0"></iframe>';
        }
        die;
    }
}