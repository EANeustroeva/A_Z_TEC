<?php


namespace app\controllers;

class PortfolioController extends AppController {

    public function indexAction() {
        \R::addDatabase('DB1','mysql:host=web02.usue.ru;dbname=fsp_usp;charset=utf8','inoonline','CnhfyyjcnmUtkz25',true);
        $data = $this->data;
        $this->setMeta('Портфолио');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $id = $this->cur_user['id'];
        \R::selectDatabase('DB1');
        $usp_all = \R::getAll("select Gruppa as gruppa, Fam as fam, UNS as uns, Semestr as semestr, Disciplina as disciplina,
Othetnost as othetnost, Ocenka as ocenka, Reiting as reiting, Data as data, Deistvie as deistvie, Famprepod as famprepod
      from uspevaemost where uns = ?", [$this->cur_user->uchet]);
        \R::selectDatabase('default');
//        $data['marks'] = \R::findAll('taskwork', "stud_id = ? and type NOT IN ('Тестирование','Итоговая')", [$this->cur_user->id]);
//        foreach ($data['marks'] as &$m) {
//            $m['task'] = \R::load('tasks', $m['task_id']);
//            $teacher = \R::load('users', $m['task']['create_id']);
//            $name = explode(" ",$teacher->name);
//            $m['teacher'] = count($name) ==3 ? $name[0] . ' ' . mb_substr($name[1],0,1,"UTF-8") . '.' . mb_substr($name[2],0,1,"UTF-8") . '.' : $name;
//            $m->t_id = $teacher->id;
//        }
        $marks_all = \R::getAll("select * from taskwork where type NOT IN ('Тестирование','Итоговая') and stud_id = ? and mark is not null order by created", [$this->cur_user->id]);
        $mfiles = \R::getAll("select * from mfiles where (class = ? OR class IS NULL) and type in (0,1,2) and archive=0", [$this->cur_user->class]);
        $y = 2017 - $this->cur_user->course+1;
        $data['port'] = [];
        for ($i=1;$i<9;$i++) {
//            $vkr = \R::getAssoc("select disc from vkrclass where class=? and sem=?",[$this->cur_user->class, $i]);
            $data['port'][$i] = [];
//            $sear2 = ($i%2 == 0) ? "s$i LIKE '%$y'" : "(s$i LIKE '%$y' or s$i LIKE '%".(++$y)."')"; //AND ($sear2) AND (s$i LIKE '%$y')
//            $sear2 = "s$i LIKE '%$y'";
            if ($i%2 == 0) $y++;
//            dump($y);
            $data['port'][$i] = \R::getAssoc("SELECT * FROM plan WHERE class=? AND s$i != '0|0|0|0|0|0|0|0|0' AND plan.gotovo>={$i} ORDER BY disc",[$this->cur_user->class]);
            foreach ($data['port'][$i] as $k => $item) {
//                if (!empty($vkr) && in_array($item['disc'],$vkr)) {
                $vkr_user = \R::findOne('vkruserkontr',"lektor_id is not null and user_id=? and disc=? and sem=?",[$this->cur_user->id, $item['disc'], $i]);
                if ($vkr_user) {
                        $prep = \R::findOne('users','id=?', [$vkr_user->lektor_id]);
                        $data['port'][$i][$k]['user_id'] = $vkr_user->lektor_id;
                        $data['port'][$i][$k]['lektor'] = $prep->name;
//                        . '<span class="pull-right" data-toggle="popover" data-html="true" data-trigger="hover"
//                                data-placement="right" data-content="распределено"><i style="color: #f60; font-size: 18px; cursor:pointer;"
//                                class="glyphicon glyphicon-info-sign"></i></span>';
                    }
//                }
                $mark = array_values(array_filter($marks_all, function ($v) use ($i, $item) {
                    return $v['sem'] == $i && $v['disc'] == $item['disc'];
                }));
                $files = [];
                $files['add'] = array_filter($mfiles, function ($v) use ($i, $item) { return $v['sem'] == $i && $v['disc'] == $item['disc'] && $v['type'] == 0; });
                $files['rpd'] = array_filter($mfiles, function ($v) use ($i, $item) { return $v['sem'] == $i && $v['disc'] == $item['disc'] && $v['type'] == 1; });
                $files['fos'] = array_filter($mfiles, function ($v) use ($i, $item) { return $v['sem'] == $i && $v['disc'] == $item['disc'] && $v['type'] == 2; });
                $data['port'][$i][$k]['ww'] = count($mark) ? $mark : [];
                $data['port'][$i][$k]['files'] = count($files) ? $files : [];
//                if (isset($_GET['qwe'])) dd($mark);
                $marks = [];
                foreach ($mark as &$ii) {
                    if ($ii['mark'] == 6) $ii['mark'] = 'зач';
                    if ($ii['mark'] == 7) $ii['mark'] = 'на дораб.';
                    $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['type']}:<b>{$ii['mark']}</b>".'</span>';
                }
                $t_marks = [];
//                if (\R::findOne('taskwork',"stud_id=? and disc=?",[$this->cur_user->id, $item['disc']])) $t_marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">4</span>';
                // and sem=? , $i
//                $usp = \R::findAll('uspevaemost',"gruppa=? and fam = ? and disciplina = ? and semestr=?", [$this->cur_user->class, $this->cur_user->name, $item['disc'], $i]);
                $usp = array_filter($usp_all, function ($v) use ($i, $item) { return $v['semestr'] == $i && $v['disciplina'] == $item['disc']; });
//                \R::selectDatabase('DB1');
//                $usp = \R::getAll("select Gruppa as gruppa, Fam as fam, UNS as uns, Semestr as semestr, Disciplina as disciplina,
//Othetnost as othetnost, Ocenka as ocenka, Reiting as reiting, Data as data, Deistvie as deistvie, Famprepod as famprepod
//      from uspevaemost where uns = ? and disciplina = ? and semestr=?", [$this->cur_user->uchet, $item['disc'], $i]);
//                \R::selectDatabase('default');
                foreach ($usp as $ii) {
                    switch ($ii['othetnost']) {
                        case 'Экзамен': $ii['othetnost']='экз'; break;
                        case 'Зачет': $ii['othetnost']='зач'; break;
                        case 'Дифференцированный зачет': case 'Зачет дифференцированный': $ii['othetnost']='диф.з'; break;
                        case 'Аттестация': $ii['othetnost']='атт'; break;

                        case 'Контрольная работа': $ii['othetnost']='к/р'; break;
                        case 'Домашняя контрольная работа': $ii['othetnost']='д.к/р'; break;
                        case 'Аудиторная контрольная работа': case 'Контрольная работа аудиторная': $ii['othetnost']='ауд.к/р'; break;
                        case 'Курсовая работа': $ii['othetnost']='курс/р'; break;
                        case 'Курсовой проект': $ii['othetnost']='курс/пр'; break;
                    }

                    if (!empty( $ii['ocenka'])) {
                        if ($ii['othetnost']!=='экз'   &&
                            $ii['othetnost']!=='зач'   &&
                            $ii['othetnost']!=='диф.з' &&
                            $ii['othetnost']!=='атт') {
                            $marks[] =   '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['othetnost']}:<b>{$ii['ocenka']}</b>".'</span>';
                        } else {
                            if ($ii['ocenka']<3) {
                                $marks[] =   '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['othetnost']}:<b>{$ii['ocenka']}</b>".'</span>';
                            } else {
                                $t_marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['othetnost']}:<b>{$ii['ocenka']}</b>".'</span>';
                            }
                        }
                    }
                }
                $data['port'][$i][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
                $data['port'][$i][$k]['total_marks'] = !empty($t_marks) ? implode(' ', $t_marks) : '';
                $marks_ = count(array_filter($mark, function ($v) { return isset($v['mark']) && is_numeric($v['mark']) && ($v['mark']>0 || $v['mark']<=6); }));
                $parse = explode('|',$item["s$i"]);
                if ($parse[4]==0 && ($parse[5]!=0 || $parse[7]!=0)
                    && $parse[0]==0 && $parse[1]==0 && $parse[2]==0
                    && $parse[3]==0 && $parse[6]==0 && $parse[8]==0
                    && empty($t_marks)) $data['port'][$i][$k]['total_marks'] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Без оценки</span>';
                if ($i==1 && ($parse[4]==1 || ((int)$parse[5] == 0 && (int)$parse[7] == 0))) {
                    $cp = \R::findOne('classprof', "class=?", [$this->cur_user->class]);
                    if ($cp) {
                        $cd = \R::findOne('compdisc', "course=0 and prof=?", [$cp->prof]);
                        if ($cd && !empty($cd->tests)) {
//                            dd($cd);
                            foreach (explode('|', $cd->disc) as $kk=>$disc) {
                                if ($disc != $item['disc']) continue;
                                $tests = explode(',',explode('|', $cd->tests)[$kk]);
                                $res = \R::findOne('testres',"user_id={$this->cur_user->id} and test_id in ("
                                    . \R::genSlots($tests) . ") and total > 49 order by total desc", $tests);
                                if ($res) {
//                                    1) от 50% до 69% - оценка "удовлетворительно"
//                                    2) от 70% до 89% - оценка "хорошо"
//                                    3) от 90% до 100% - оценка "отлично"
//                                    $m = $res->total >= 90 ? 5 : ($res->total >= 70 ? 4 : 3);
                                    $m = $res->total >= 90 ? 'отлично' : ($res->total >= 70 ? 'хорошо' : 'удовлетворительно');
                                    $data['port'][$i][$k]['marks'] = "<b>{$m}</b>";//'<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Тест:<b>'.$m.'</b></span>';
                                }
                            }
                        }
                    }
                    if ($this->cur_user->class != 'ИНО ДО-18-1') {
                        if (isset($cd)) {
                            $key = array_search ($item['disc'], explode('|',$cd->disc));
                            if($key && !empty(explode('|',$cd->tests)[$key])) $data['port'][$i][$k]['total_marks'] = 'Тестирование';
                        }
                    }
//                    if ($this->cur_user->class != 'ИНО ДО-18-1') $data['port'][$i][$k]['total_marks'] = 'Тестирование';//'<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Тестирование</span>';
                }
//                if ($item["s$i"] == '0|0|0|0|0|2|2|0|0' && empty($t_marks)) $data['port'][$i][$k]['total_marks'] = 'Без оценки';
//                if ($mark) $data['port'][$i][$k]['marks'] = implode(', ',$marks);
//                else $data['port'][$i][$k]['marks'] = '';
                $data['port'][$i][$k]['kurs'] = ($parse[2] != 0);
            }

        }
//        dd($data['port']);
//        $data['plan'] = \R::getAssoc("SELECT * FROM plan WHERE class=? AND ($sear) AND ($sear2) ORDER BY disc",[$this->cur_user->class]);
//        dd($data['plan']);

        $curs = \R::getAll("select * from vkrusercurs where user_id=? and sem is not null and lektor_id is not null order by sem", [$this->cur_user->id]);
            foreach ($curs as $k => $cur) {
                $lektor = \R::findOne('users',"id=?", [$cur['lektor_id']]);
                $curs[$k]['lektor'] = $lektor ? $lektor->name : '';
            }
            $data['curs'] = $curs;
            foreach ($data['curs'] as $k => $item) {
                $mark = \R::getAll("select mark,type from taskwork 
                    where disc=? and stud_id = ? and type='кп' and sem=? and mark is not null order by marked desc",
                    [$item['disc'], $this->cur_user->id, $item['sem']]);
                $marks = [];
                foreach ($mark as &$i) {
                    if (count($marks) || $i['mark'] > 5) continue;
                    if ($i['mark'] == 6) $i['mark'] = 'зач';
                    if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
                    $i['type'] = 'курсовая';
                    $marks[] = "<b>{$i['mark']}</b>";
                }
                $data['curs'][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
            }

            $vkr = \R::getAll("select * from vkruservkrs where user_id=? and sem is not null and lektor_id is not null order by sem", [$this->cur_user->id]);
            foreach ($vkr as $k => $cur) {
                $lektor = \R::findOne('users',"id=?", [$cur['lektor_id']]);
                $vkr[$k]['lektor'] = $lektor ? $lektor->name : '';
            }
            $data['vkr'] = $vkr;
            foreach ($data['vkr'] as $k => $item) {
                $mark = \R::getAll("select mark,type from taskwork 
                    where disc=? and stud_id = ? and type='вкр' and sem=? and mark is not null order by marked desc",
                    [$item['disc'], $this->cur_user->id, $item['sem']]);
                $marks = [];
                foreach ($mark as &$i) {
                    if (count($marks) && $i['mark'] > 5) break;
                    if ($i['mark'] != 7 && $i['mark'] != 0) $i['mark'] = 'допущен';
                    if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
                    $i['type'] = 'вкр';
                    $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."<b>{$i['mark']}</b>".'</span> ';
                }
                $data['vkr'][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
            }

            $pract = \R::getAll("select * from vkruserpract where user_id=? and sem is not null and lektor_id is not null order by sem", [$this->cur_user->id]);
            foreach ($pract as $k => $cur) {
                $lektor = \R::findOne('users',"id=?", [$cur['lektor_id']]);
                $pract[$k]['lektor'] = $lektor ? $lektor->name : '';
            }
            $data['pract'] = $pract;
            foreach ($data['pract'] as $k => $item) {
                $mark = \R::getAll("select mark,type from taskwork 
                    where disc=? and stud_id = ? and type='практ' and sem=? and mark is not null order by marked desc",
                    [$item['disc'], $this->cur_user->id, $item['sem']]);
                $marks = [];
                foreach ($mark as &$i) {
                    if (count($marks) && $i['mark'] > 5) break;
                    if ($i['mark'] == 6) $i['mark'] = 'зач';
                    if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
                    $i['type'] = 'практ';
                    $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['type']}:<b>{$i['mark']}</b>".'</span> ';
                }
                $data['pract'][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
            }

        $data['docs'] = $this->doc->getList($this->cur_user->id);
//        dd($data['docs']);

        $this->set($data);
    }
  
  

}