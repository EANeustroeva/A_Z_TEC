<?php


namespace app\controllers;

use DateTime;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\TemplateProcessor;

class TasksController extends AppController {

    public function _indexAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['user'] = $this->cur_user;
//        ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
        if ($this->cur_user->access == 1) $this->view = 'manager';
//        if ($this->cur_user->access <= 3) $this->layout = 'manager';

        if ($this->cur_user->access == 4) {
            $this->view = 'studs';
            $disc = $_GET['disc'];
            $class = $this->cur_user->class;
//            if (isset($_GET['dd'])) dd($this->sem);


            if (!empty($disc)) $mfiles = \R::findAll('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and type=0 and archive=0", [$this->sem, $class, $disc]);
            if (!empty($disc)) $data['rpd'] = \R::findOne('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and archive=0 and type=1 order by id desc", [$this->sem, $class, $disc]);
            if (!empty($disc)) $data['fos'] = \R::findOne('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and archive=0 and type=2 order by id desc", [$this->sem, $class, $disc]);
            $data['docs'] = $mfiles; //todo semestr
            $sem = $this->cur_user->sem; // $this->cur_user->course * 2;
//            $data['plan'] = \R::getAssocRow("SELECT * FROM plan WHERE class=? AND s" . ($this->cur_user->course * 2) . " != '0|0|0|0|0|0|0|0|0' AND disc=? ORDER BY disc", [$this->cur_user->class, $disc])[0];
            $data['plan'] = \R::getAssocRow("SELECT * FROM plan WHERE class=? AND disc=? ORDER BY disc", [$this->cur_user->class, $disc])[0];

            $data['plan']['user_id'] = \R::findOne('users', 'name=?', [$data['plan']['lektor']])->id;

            $vkr = \R::getAssoc("select disc from vkrclass_ where class=? and sem=?",[$this->cur_user->class, $sem]);
             if (!empty($vkr) && in_array($disc,$vkr)) {
                $vkr_user = \R::findOne('vkruser',"lektor_id is not null and status!=2 and user_id=? and disc=? and sem=?",[$this->cur_user->id, $disc, $sem]);
                if ($vkr_user) {
                    $prep = \R::findOne('users','id=?', [$vkr_user->lektor_id]);
                    $data['plan']['user_id'] = $vkr_user->lektor_id;
                    $data['plan']['lektor'] = $prep->name;
                }
            }

            $d_id = $this->usr->get_dialog_with($data['plan']['user_id'], $this->cur_user->id);
            $data['msg'] = json_decode($this->msg->messages($d_id));

            $cl = addcslashes(json_encode($this->cur_user->class), '\\');
            $data['tasks'] = \R::getAll("SELECT t.* FROM tasks t, plan uc WHERE (t.class IS NULL OR t.class LIKE ?) AND (t.course IS NULL OR t.course = ?) AND t.create_id=uc.user_id AND uc.class=?", ["%$cl%", $this->cur_user->course, $this->cur_user->class]);
            foreach ($data['tasks'] as &$task) {
                $teacher = \R::load('users', $task['user_id']);
                $name = explode(" ", $teacher->name);
                $task['teacher'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
            }

            $vid = \R::findOne('mfilesnext',"class=? and disc=? and sem=?",[$class, $disc, $sem]);

            $data['video'] = $vid;
        }
        elseif ($this->cur_user->access == 3){
//            ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//            \R::fancyDebug(true);
//            $clses = array_values(\R::getAssoc("select class from plan where lektor=?",[$this->cur_user->name]));
//            $discs = array_values(\R::getAssoc("select disc from plan where lektor=?",[$this->cur_user->name]));
            $discs = ($this->cur_user->uchet != 9999999) ? \R::getAssoc("select disc from plan where lektor=?",[$this->cur_user->name]) : [];

            //$discs = [];//['Управление человеческими ресурсами' => 'Управление человеческими ресурсами'];

            $sql_in = $sql_ex = [];
            $vkr_discs = \R::getAssoc("select disc from vkruser where lektor_id=? and status!=2 ",[$this->cur_user->id]);
            if (!empty($vkr_discs)) {
                foreach ($vkr_discs as $vkr_disc) {
//                    if (isset($_GET['dd'])) \R::fancyDebug(true);
                    $vkr_in = \R::getAssoc("select user_id from vkruser where lektor_id=? and disc=? and status!=2 ",[$this->cur_user->id, $vkr_disc]);
                    if (!empty($vkr_in)) $sql_in[] = "disc='{$vkr_disc}' and stud_id in (".implode(',',array_values($vkr_in)).")";
                }
            }
//            if (!empty($vkr)) $sql_in = "(disc = stud_id in (".implode(',',array_values($vkr))."))";
            if ($discs) {
                foreach ($discs as $k => $item) {
//                if (isset($_GET['dd'])) \R::fancyDebug(false);
                    $discs[$k] = array_values(\R::getAssoc("select class from plan where lektor=? and disc=?", [
                        $this->cur_user->name,
                        $item
                    ]));
//                    if ($this->cur_user->id == 9684) $discs[$k] = [];//array_values(['СЗУП-17' => 'СЗУП-17']);
//                if (isset($_GET['dd'])) \R::fancyDebug(true);

                    $vkr_ex = \R::getAssoc("select user_id from vkruser where lektor_id is not null and lektor_id!=? and disc=? and status!=2", [
                        $this->cur_user->id,
                        $item
                    ]);
                    if (!empty($vkr_ex)) $sql_ex[] = "(disc='{$item}' and stud_id not in (" . implode(',', array_values($vkr_ex)) . "))";
                }
            }

            $sql = [];
            /* update taskwork t
            inner join users u on t.stud_id=u.id
            set t.class=u.class */
            if ($discs) {
                foreach ($discs as $k => $item) {
//                foreach ($item as &$it) $it = "class like '%$it%'";
                    foreach ($item as &$it) $it = "'$it'";
//                $sql[] = "(disc='{$k}' and (".implode(' or ',$item) ."))";
                    $sql[] = "(disc='{$k}' and class in (" . implode(', ', $item) . "))";
                }
            }
            $sql = implode(' or ',$sql);
//            if (isset($_GET['dd'])) dd(implode(' or ',$sql_in));
            $sql_in = !empty($sql_in) ? "(" . implode(' or ',$sql_in) .")" : '';
//            $sql_ex = !empty($sql_ex) ? " and (" . implode(' or ',$sql_ex) .")" : '';

//            $sql_in = $sql_ex = '';
//            foreach ($discs as &$item) $item = "disc = '$item'";
//            foreach ($clses as &$item) $item = "class like '%$item%'";

            /*$sql = !empty($sql_in) ? "({$sql} {$sql_in})" : $sql;
            $sql = !empty($sql) ? $sql .' and' : '';*/
//            $sql = $sql ?: '1';
//            if (isset($_GET['dd'])) dd($sql);
            if (isset($_GET['dd'])) {
//                dd($sql);
            }
            $data['files'] = $sql ? \R::findAll('mfiles', "($sql) and (user_id={$this->cur_user->id} or user_id is null) and archive=0") : [];
            if (isset($_GET['dd'])) {
//                dd($sql);
            }
            $data['tasks'] = $data['files'];//\R::findAll('tasks', "create_id=? or ", [$this->cur_user->id]);
         /*   $ids = \R::getAll("select id from mfiles where (". implode(' or ',$clses) .") and (" . implode(' or ',$discs) . ")");
            dump($ids);*/
            /*$data['zagr'] = \R::findAll('taskwork', "(task_id=0 and
                (" . implode(' or ',$discs) . ") and stud_id in (select id from users where (". implode(' or ',$clses) .")))
                or
                (task_id = 0 or task_id in (
                    select id from mfiles where (". implode(' or ',$clses) .") and (" . implode(' or ',$discs) . ")
                )) order by status");*/
//            if (isset($_GET['dd'])) \R::fancyDebug(true);
//            $data['zagr2'] = \R::findAll('taskwork',"({$sql}) and archive=0 and status != 2 order by status"); //


             if ($sql) {
                $sql = !empty($sql_in) ? "({$sql} or {$sql_in}) and" : $sql .' and';
            } else $sql = !empty($sql_in) ? "{$sql_in} and" : '';

            if (isset($_GET['dd'])) {
//                dd($sql);
            }

            $data['zagr'] = $sql ? \R::findAll('taskwork',"{$sql} archive=0 order by status") : ''; //{$sql_ex}
//            if (isset($_GET['dd'])) dd($data['zagr2']);
            $counter = 0;
            if ($sql) {
                foreach ($data['zagr'] as $kz => $zagr) {
                    if ($zagr['status'] == 2) $counter++;
//                    $stud = \R::load('users', $zagr['stud_id']);
                    $stud = \R::findOne('users', "id=?",[$zagr['stud_id']]);
                    if ($stud->kodstatusa != 240) continue;
                    $name = preg_replace("#\s\(.*\)\s#", ' ', $stud->name);
//                $name = explode(" ", $name);
//                $data['zagr'][$kz]['student'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
                    $data['zagr'][$kz]['student'] = $name;
                    $data['zagr'][$kz]['class'] = $stud->class;
                    $data['zagr'][$kz]['created_'] = $zagr['created'];
                    $data['zagr'][$kz]['created'] = date("d/m/Y H:i", strtotime($zagr['created']));
                }
            }
            /*if (isset($_GET['test'])) */{
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
                $this->view = 'indextest';

                if ($this->isAjax()) {
                    $t = [];
                    $i = 0;
                    foreach ($data['zagr'] as $item) {
                        $type = '';
                        switch ($item['type']) {
                            case 'кр': $type = 'Контр.раб.'; break;
                            case 'зач': $type = 'Зач.'; break;
                            case 'прр': $type = 'Пров.раб.'; break;
                            case 'экз': $type = 'Экз.раб.'; break;
                            case 'кп': $type = 'Курс.раб.'; break;
                        }
                        $link = '/download?f=' . base64_encode('../upload/works/' . $item['file']) . '&c=' . urlencode($item['ftitle']);
                        $dwnld = (!empty($item['file'])) ? '<a href="'.$link . '" class="btn btn-warning btn-xs"
                        target="_blank"><span class="glyphicon glyphicon-download"></span>&nbsp;<span class="hidden-xs">Скачать</span></a>' : '';
                        $perc = (!is_null($item['perc'])) ? $item['perc'] . '%' . '<a target="_blank" class="btn btn-xs btn-success pull-right" href="' . $item['pdf'] . '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>' : '<span data-id="' . $item['id'] . '" class="work btn btn-xs btn-default pull-right" title="Отправить на проверку"><i class="glyphicon glyphicon-check"></i></span>';
                        $mark = '<select id="mark' . $item['id'] . '" class="mark" style="height: 23px;padding: 0;margin-bottom: 0;">
                                <option value="0" ' . ($item['mark'] == 0 ? 'selected="selected"' : '') . '>--</option>
                                <option value="3" ' . ($item['mark'] == 3 ? 'selected="selected"' : '') . '>3</option>
                                <option value="4" ' . ($item['mark'] == 4 ? 'selected="selected"' : '') . '>4</option>
                                <option value="5" ' . ($item['mark'] == 5 ? 'selected="selected"' : '') . '>5</option>
                                <option value="6" ' . ($item['mark'] == 6 ? 'selected="selected"' : '') . '>зач</option>
                                <option value="7" ' . ($item['mark'] == 7 ? ' selected="selected"' : '') . '>на дораб.</option>
                            </select>';
                        $com = '<button type="button" class="btn btn-xs btn-' . (!empty($item['comment']) ? 'success' : 'primary') . '" data-toggle="modal" data-target="#commentModal" data-id="' . $item['id'] . '" data-title="' . @$item['comment'] . '" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></button>';

                        $t[] = [
                            'tid'    => ++$i,
                            'tname'  => $item['student'],
                            'tdate'  => $item['created'],
                            'tdate_'  => $item['created_'],
                            'tclass' => $item['class'],
                            'tdisc'  => $item['disc'],
                            'ttype'  => $type,
                            'tdwnld' => $dwnld,
                            'tperc'  => $perc,
                            'tmark'  => $mark,
                            'tcom'   => $com,
                            'tstatus'=> $item['status']
                        ];
                    }
                    die(json_encode(['data' => $t]));
                }
            }
            $data['counter'] = $sql ? $counter . ' из ' . count($data['zagr']) : 0;
        }

        if (!empty($_GET['disc'])) {
            $data['marks'] = \R::findAll('taskwork', "stud_id = ? and disc=? and archive=0 order by id desc", [$this->cur_user->id,$_GET['disc']]);
        }
        else $data['marks'] = \R::findAll('taskwork', "stud_id = ? and archive=0 order by id desc", [$this->cur_user->id]);

        foreach ($data['marks'] as &$m) {
            $m['task'] = \R::load('mfiles', $m['task_id']);
            $teacher = $data['plan']['lektor'];//\R::load('users', $m['task']['user_id']); //todo
            if ($teacher) {
                $name = explode(" ", $teacher);
                $m['teacher'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
            }
        }
        if ($data['tasks']) {
            foreach ($data['tasks'] as $k => &$t) {
                $t['predmet_name'] = \R::getRow("SELECT * FROM predmets WHERE id=?", [$t['predmet']])['sname'];
                if (!empty($t['users'])) {
                    $personal = explode("|", $t['users']);
                    $grlist = [];
                    foreach ($personal as $item) {
                        $cl = \R::getRow("SELECT class FROM users WHERE id=?", [(int)$item])['class'];
                        if (!in_array($cl, $grlist)) $grlist[] = $cl;
                    }
                    $t['gruppa'] = $grlist;
                } else $t['gruppa'] = json_decode($t['class']);
                $t['works'] = \R::getAll("SELECT * FROM taskwork WHERE task_id=? and archive=0 order by status", [$t['id']]);
                $t['created'] = date("d F", strtotime($t['created'])) . '<span class="hidden-xs">' . date(" H:i:s", strtotime($t['created'])) . '</span>';
                foreach ($t['works'] as &$work) {
                    $stud = \R::load('users', $work['stud_id']);
                    $name = explode(" ", $stud->name);
                    $work['stud'] = $stud;
                    $work['name'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
                    $work['created'] = date("d F", strtotime($work['created'])) . '<span class="hidden-xs">' . date(" H:i:s", strtotime($work['created'])) . '</span>';
                }
            }
        }
//        dd($data['marks']);
//        dd($data['tasks']);

//        if (!empty($_GET['dd'])) {
//                dd($data['plan']);


//            dd($vid);
//        }

        if (isset($_GET['test'])) $this->view = 'indextest';

        $this->set($data);
    }

    function _usort_object($a, $b){
        // поля по которым сортировать
        $array = array( 'status'=>'desc', 'created_'=>'asc' );

        $res = 0;
        foreach( $array as $k=>$v ){
            if( $a->$k == $b->$k ) continue;

            $res = ( $a->$k < $b->$k ) ? -1 : 1;
            if( $v=='desc' ) $res= -$res;
            break;
        }

        return $res;
    }

    public function indexAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['user'] = $this->cur_user;

        if ($this->cur_user->access == 1) $this->view = 'manager';
        if ($this->cur_user->access == 3) redirect('/tasks/prep');
        if ($this->cur_user->access == 4) {
            $this->view = 'studs';
            $disc = $_POST['disc'];
            $class = $this->cur_user->class;

            $sem = isset($_POST['s']) ? $_POST['s'] : $this->sem;

            if (!empty($disc)) $mfiles = \R::findAll('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and type=0 and archive=0", [$sem, $class, $disc]);
            if (!empty($disc)) $data['rpd'] = \R::findOne('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and archive=0 and type=1 order by id desc", [$sem, $class, $disc]);
            if (!empty($disc)) $data['fos'] = \R::findOne('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and archive=0 and type=2 order by id desc", [$sem, $class, $disc]);
            $data['docs'] = $mfiles; //todo semestr
//            $sem = $this->cur_user->sem;
            $data['plan'] = \R::getAssocRow("SELECT * FROM plan WHERE class=? AND disc=? ORDER BY disc", [$this->cur_user->class, $disc])[0];

            $parse = explode('|',$data['plan']["s$sem"]);
            if ($sem == $this->sem) {
                $enabled = $parse[3] != 0 ? true : false;
            } else {
                $enabled = false;
                if ($parse[3] != 0 && !empty($_POST['dolg'])) $enabled = true;
            }
//            ddd($this->sem);

            $data['plan']['enabled'] = $enabled;

            $data['plan']['user_id'] = \R::findOne('users', 'name=?', [$data['plan']['lektor']])->id;

            $vkr = \R::getAssoc("select disc from vkruserkontr where class=? and sem=?",[$this->cur_user->class, $sem]);
             if (!empty($vkr) && in_array($disc,$vkr)) {
                $vkr_user = \R::findOne('vkruserkontr',"lektor_id is not null and user_id=? and disc=? and sem=?",[$this->cur_user->id, $disc, $sem]);
                if ($vkr_user) {
                    $prep = \R::findOne('users','id=?', [$vkr_user->lektor_id]);
                    $data['plan']['user_id'] = $vkr_user->lektor_id;
                    $data['plan']['lektor'] = $prep->name;
                }
            }

            $d_id = $this->usr->get_dialog_with($data['plan']['user_id'], $this->cur_user->id);
            $data['msg'] = json_decode($this->msg->messages($d_id));

            $cl = addcslashes(json_encode($this->cur_user->class), '\\');
            $data['tasks'] = \R::getAll("SELECT t.* FROM tasks t, plan uc WHERE (t.class IS NULL OR t.class LIKE ?) AND (t.course IS NULL OR t.course = ?) AND t.create_id=uc.user_id AND uc.class=?", ["%$cl%", $this->cur_user->course, $this->cur_user->class]);
            foreach ($data['tasks'] as &$task) {
                $teacher = \R::load('users', $task['user_id']);
                $name = explode(" ", $teacher->name);
                $task['teacher'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
            }

            $vid = \R::findOne('mfilesnext',"class=? and disc=? and sem=?",[$class, $disc, $sem]);

            $data['video'] = $vid;
        }
        elseif ($this->cur_user->access == 3){
            $discs = ($this->cur_user->uchet != 9999999) ? \R::getAssoc("select disc from plan where lektor=?",[$this->cur_user->name]) : [];

            $kr = $cr = $vkr = $pr = true;
            if ($this->isAjax()) {
                $kr = isset($_GET['kr']); $cr = isset($_GET['cr']); $vkr = isset($_GET['vkr']); $pr = isset($_GET['pract']);
                $sort = (isset($_POST['sort']) && $_POST['sort'] == 'true') ? true:false;
            }
            $sql_in = $sql_ex = [];

//            $vkr_users = \R::getAssoc("select user_id from vkrusercurs where lektor_id=?",[$this->cur_user->id]);

            if ($kr) {
                $vkr_discs = \R::getAssoc("select disc from vkruserkontr where lektor_id=?",[$this->cur_user->id]);
                if (!empty($vkr_discs)) {
                    foreach ($vkr_discs as $vkr_disc) {
                        $vkr_in = \R::getAssoc("select user_id from vkruserkontr where lektor_id=? and disc=?",[$this->cur_user->id, $vkr_disc]);
                        if (!empty($vkr_in)) {
                            $sql_in[] = "disc='{$vkr_disc}' and stud_id in (".implode(',',array_values($vkr_in)).") and type='кр'";
//                            $sql_ex[$vkr_disc] = "and stud_id not in (".implode(',',array_values($vkr_in)).")";
                        }
                    }
                }
            }
            if ($cr) {
                $vkr_discs_curs = \R::getAssoc("select disc from vkrusercurs where lektor_id=?", [$this->cur_user->id]);
                if (!empty($vkr_discs_curs)) {
                    foreach ($vkr_discs_curs as $vkr_disc) {
                        $vkr_in = \R::getAssoc("select user_id from vkrusercurs where lektor_id=? and disc=?", [$this->cur_user->id, $vkr_disc]);
                        if (!empty($vkr_in)) $sql_in[] = "disc='{$vkr_disc}' and stud_id in (" . implode(',', array_values($vkr_in)) . ") and type='кп'";
                    }
                }
            }
            if ($vkr) {
                $vkr_discs_vkr = \R::getAssoc("select disc from vkruservkrs where lektor_id=?", [$this->cur_user->id]);
                if (!empty($vkr_discs_vkr)) {
                    foreach ($vkr_discs_vkr as $vkr_disc) {
                        $vkr_in = \R::getAssoc("select user_id from vkruservkrs where lektor_id=? and disc=?", [$this->cur_user->id, $vkr_disc]);
                        if (!empty($vkr_in)) $sql_in[] = "disc='{$vkr_disc}' and stud_id in (" . implode(',', array_values($vkr_in)) . ") and type='вкр'";
                    }
                }
            }
            if ($pr) {
                $vkr_discs_pr = \R::getAssoc("select disc from vkruserpract where lektor_id=?", [$this->cur_user->id]);
                if (!empty($vkr_discs_pr)) {
                    foreach ($vkr_discs_pr as $vkr_disc) {
                        $vkr_in = \R::getAssoc("select user_id from vkruserpract where lektor_id=? and disc=?", [$this->cur_user->id, $vkr_disc]);
                        if (!empty($vkr_in)) $sql_in[] = "disc='{$vkr_disc}' and stud_id in (" . implode(',', array_values($vkr_in)) . ") and type='практ'";
                    }
                }
            }
            if ($discs && $kr) {
                foreach ($discs as $k => $item) {
                    $discs[$k] = array_values(\R::getAssoc("select class from plan where lektor=? and disc=?", [ $this->cur_user->name, $item ]));
                }
            }

            $sql = [];
            if ($discs && $kr) {
                foreach ($discs as $k => $item) {
                    foreach ($item as &$it) $it = "'$it'";
                    $ex = '';
                    if (!empty($vkr_disc)) {
                        $vkr_ex = \R::getAssoc("select user_id from vkruserkontr where lektor_id!=? and disc=? and lektor_id is not null",[$this->cur_user->id, $vkr_disc]);
                        $ex = (!empty($vkr_ex)) ? "and stud_id not in (" . implode(',', array_values($vkr_ex)) . ")" : '';
                    }
                    $sql[] = "(disc='{$k}' and class in (" . implode(', ', $item) . ") and type='кр' {$ex})";
                }
            }
            $sql = implode(' or ',$sql);
            $sql_in = !empty($sql_in) ? "(" . implode(' or ',$sql_in) .")" : '';

            if ($sql) { $sql = !empty($sql_in) ? "({$sql} or {$sql_in}) and" : $sql .' and'; }
            else $sql = !empty($sql_in) ? "{$sql_in} and" : '';
//            $data['zagr'] = $sql ? \R::findAll('taskwork',"{$sql} archive=0 order by status") : ''; //{$sql_ex}
//            $sort = $sort ? 'status desc,created desc' : 'created desc';
//            $sort = 'created desc';
            $data['zagr'] = $sql ? \R::getAll("select taskwork.* from taskwork where {$sql} archive=0 order by created desc") : '';
            $resultArray = [];
//            $total = count($data['zagr']);
            $counter = 0;
            array_walk($data['zagr'], function($item, $key) use (&$resultArray, &$counter/*, &$vkr_users*/) {
                $stud = \R::findOne('users', "id=?",[$item['stud_id']]);
                if ($item['status'] == 2) $counter++;
                if ($stud->kodstatusa != 240) return;
//                if (isset($vkr_users[$item['stud_id']])) unset($vkr_users[$item['stud_id']]);

                $item['student'] = $stud->name;
                $item['class'] = $stud->class;
                $item['created_'] = $item['created'];
                $item['created'] = date("d/m/Y H:i", strtotime($item['created']));

                $resultArray[$stud->id][] = $item;
            });
//            dd($data['zagr']);

//            usort($resultArray, function($a, $b) { return $a['status'] <=> $b['status']; });

            $data['zagr'] = $resultArray;
            $counter = $counter2 = $counter3 = 0;
            $total = count($data['zagr']);
            foreach ($resultArray as $k=>$user) {
                if (current($user)['status'] == 0) {
                    $counter++;
                }
            }
            $this->view = isset($_GET['qwe']) ? 'indextest4':'indextest3';
            if ($this->isAjax()) {
                $fdisc = !empty($_POST['disc']) ? $_POST['disc'] : null;
                $t = [];
                $i = 0;
                foreach ($data['zagr'] as $k=>$user) {
                    if (!is_null($fdisc)) {
                        $ct = 0;
                        foreach ($user as $item)  if ($fdisc == $item['disc']) $ct++;
                        if (!$ct) continue;
                    }
                    $user_work = [];
                    $status = null;
                    foreach ($user as $item) {
                        if (!is_null($fdisc) && $fdisc != $item['disc']) continue;
                        $type = '';
                        switch ($item['type']) {
                            case 'кр': $type = 'Контр.раб.'; break;
                            case 'зач': $type = 'Зач.'; break;
                            case 'прр': $type = 'Пров.раб.'; break;
                            case 'экз': $type = 'Экз.раб.'; break;
                            case 'кп': $type = 'Курс.раб.'; break;
                            case 'вкр': $type = 'ВКР'; break;
                            case 'практ': $type = 'Практ.'; break;
                        }
                        $link = '/download?f=' . base64_encode('../upload/works/' . $item['file']) . '&c=' . urlencode($item['ftitle']);
                        $dwnld = (!empty($item['file'])) ? '<a href="'.$link . '" class="btn btn-warning btn-xs"
                        target="_blank"><span class="glyphicon glyphicon-download"></span>&nbsp;<span class="hidden-xs">Скачать</span></a>' : '';
                        $perc = (!is_null($item['perc'])) ? $item['perc'] . '%' . '<a target="_blank" class="btn btn-xs btn-success pull-right" href="' . $item['pdf'] . '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>' : '<span data-id="' . $item['id'] . '" class="work btn btn-xs btn-default pull-right" title="Отправить на проверку"><i class="glyphicon glyphicon-check"></i></span>';
                        $mark = '<select data-id="mark' . $item['id'] . '" class="mark" style="height: 23px;padding: 0;margin-bottom: 0;">
                                <option value="0" ' . ($item['mark'] == 0 ? 'selected' : '') . '>--</option>
                                <option value="3" ' . ($item['mark'] == 3 ? 'selected' : '') . '>3</option>
                                <option value="4" ' . ($item['mark'] == 4 ? 'selected' : '') . '>4</option>
                                <option value="5" ' . ($item['mark'] == 5 ? 'selected' : '') . '>5</option>
                                <option value="6" ' . ($item['mark'] == 6 ? 'selected' : '') . '>зач</option>
                                <option value="7" ' . ($item['mark'] == 7 ? 'selected' : '') . '>на дораб.</option>
                            </select>';
                        $com = '<button type="button" class="btn btn-xs btn-' . (!empty($item['comment']) ? 'success' : 'primary') . '" data-toggle="modal" data-target="#commentModal" data-id="' . $item['id'] . '" data-title="' . @$item['comment'] . '" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></button>';
                        $user_work[] = [
                            'tdisc'  => $item['disc'],
                            'ttype'  => $type,
                            'tdwnld' => $dwnld,
                            'tperc'  => $perc,
                            'tmark'  => $mark,
                            'tcom'   => $com,
                            'tdate'  => $item['created'],
                            'tstatus'=> $item['status'],
                            'tmarked'=> $item['marked'] ? date("d.m.Y H:i", strtotime($item['marked'])) : '',
                        ];
//                            $status = is_null($status) ? $item['status'] : min($status, $item['status']);
//                            $status = $item['status'];
                    }
                    $t[] = [
                        'tid'    => ++$i,
                        'tname'  => $item['student'],
                        'tdate'  => $item['created'],
                        'tdate_'  => $item['created_'],
                        'tclass' => $item['class'],
                        'tstatus'=> current($user)['status'], //$status,
                        'tchild' => $user_work
                    ];
                }
//                if ($sort) usort($t, function($a, $b) { return $a['tstatus'] <=> $b['tstatus']; });
//                else usort($t, function($a, $b) { return strtotime($b['tdate_']) <=> strtotime($a['tdate_']); });
//                if ($cr && $kr)
                /*foreach ($vkr_users as $item) {
                    $stud = \R::findOne('users', "id=?",[$item]);
                    if (!$stud) continue;
                    if ($stud->kodstatusa != 240) continue;
                    $t[] = [
                        'tid'    => ++$i,
                        'tname'  => $stud['name'],
                        'tdate'  => '',
                        'tdate_'  => '',
                        'tclass' => $stud['class'],
                        'tstatus'=> 2, //$status,
                        'tchild' => []
                    ];
                }*/

                die(json_encode(['data' => $t]));
            }
            $data['counter'] = $sql ? ($total - $counter) . ' из ' . $total : 0;
        }

        if (!empty($_POST['disc'])) {

            $data['marks'] = \R::findAll('taskwork', "stud_id = ? and disc=? and type='кр' and sem = ? and archive=0 order by id desc", [$this->cur_user->id,$_POST['disc'], $sem]);
        }
        else $data['marks'] = \R::findAll('taskwork', "stud_id = ? and type='кр' and sem = ? and archive=0 order by id desc", [$this->cur_user->id, $sem]);

        foreach ($data['marks'] as &$m) {
            $m['task'] = \R::load('mfiles', $m['task_id']);
            $teacher = $data['plan']['lektor'];//\R::load('users', $m['task']['user_id']); //todo
            if ($teacher) {
                $name = explode(" ", $teacher);
                $m['teacher'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
            }
        }

        $this->set($data);
    }

    function convert(&$arr, $a, $b) {
       $fdisc = !empty($_POST['disc']) ? $_POST['disc'] : null;
       $export = [];
        foreach ($arr as $k => $item) {
            if (is_null($item[$b])) continue;
            if ($fdisc && $item[$a]!=$fdisc) { unset($export[$k]); continue; }
            if (!isset($export[$item[$a]])) $export[$item[$a]] = [];
            if (!in_array($item[$b], $export[$item[$a]])) {
                $export[$item[$a]][] = $item[$b];
//                unset($arr[$k]);
            }
        }
        return $export;
    }

    public function prepAction() {
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['user'] = $this->cur_user;
        /*if ($this->cur_user->login == 'plutomi') */
//        $this->view = isset($_GET['qwe']) ? 'preptest' : 'prep';
        $this->view = 'preptest';

        $data['recent'] = [
            'all' => \R::getCol("select comment,count(*) from taskwork where prep_id=? and comment like '____%' group by comment having count(*) > 3 order by count(*) desc limit 5", [$this->cur_user->id]),
            'kr' => \R::getCol("select comment,count(*) from taskwork where type='кр' and prep_id=? and comment like '____%' group by comment having count(*) > 3 order by count(*) desc limit 5", [$this->cur_user->id]),
            'cr' => \R::getCol("select comment,count(*) from taskwork where type='кп' and prep_id=? and comment like '____%' group by comment having count(*) > 3 order by count(*) desc limit 5", [$this->cur_user->id]),
            'vkr' => \R::getCol("select comment,count(*) from taskwork where type='вкр' and prep_id=? and comment like '____%' group by comment having count(*) > 3 order by count(*) desc limit 5", [$this->cur_user->id]),
            'pr' => \R::getCol("select comment,count(*) from taskwork where type='практ' and prep_id=? and comment like '____%' group by comment having count(*) > 3 order by count(*) desc limit 5", [$this->cur_user->id])
            ];

        $c = [];
        $kr = isset($_GET['kr']); $cr = isset($_GET['cr']); $vkr = isset($_GET['vkr']); $pr = isset($_GET['pr']); $dst = isset($_GET['dst']);
        $sql = $t = $class_list = $user_list = $tws = $discs = $data['discs'] = [];
        if ($kr || !$this->isAjax()) {
            $discs = ($this->cur_user->uchet == 9999999) ? [] : \R::getAll("select * from plan where lektor=?",[$this->cur_user->name]);
            $kontr = \R::getAll("select * from vkruserkontr where lektor_id=?", [$this->cur_user->id]);
//            if (isset($_GET['qwe'])) {
                $ds = $us = $us_ex = [];
                foreach ($discs as $item) { for ($i = 1; $i <= 9; $i++) { if ($item['s' . $i] != '0|0|0|0|0|0|0|0|0') $ds[$item['disc']][$i][] = $item['class']; } }
                foreach ($ds as $k => $d) foreach ($d as $kk => $dd) $ds[$k][$kk] = (count($dd) > 1 ? "class in ('" . implode("','", $dd) . "')" : "class='{$dd[0]}'");
                $discs_list = !empty($ds) ? "('". implode("','",array_keys($ds)) ."')" : false;
                $kontr_ex = $discs_list ? \R::getAll("select * from vkruserkontr where lektor_id!=? and lektor_id is not null and disc in {$discs_list}",[$this->cur_user->id]) : [];
                foreach ($kontr_ex as $item) $us_ex[$item['disc']][$item['sem']][] = $item['user_id'];
                foreach ($us_ex as $k => $d) { foreach ($d as $kk => $dd) { if (!empty($ds[$k][$kk])) $ds[$k][$kk] = 'stud_id not in (' . implode(',', $dd) . ') and ' . $ds[$k][$kk]; }}
                foreach ($kontr as $item) $us[$item['disc']][$item['sem']][] = $item['user_id'];
                foreach ($us as $k => $d) foreach ($d as $kk => $dd) {if (empty($ds[$k][$kk])) $ds[$k][$kk] = ""; else $ds[$k][$kk] .= ' or '; $ds[$k][$kk] .= 'stud_id in (' . implode(',', $dd) . ')'; }
                foreach ($ds as $k=>$d) foreach ($d as $kk => $dd) $ds[$k][$kk] = 'sem='.$kk.' and ('.$dd.')';
                foreach ($ds as $k=>$d) $ds[$k] = 'disc="'.$k.'" and (' . implode(' or ',array_values($d)) . ')';
//                $ds = 'type="кр" and ('.implode(' or ',array_values($ds)).')';
//                $sql[] = $ds;
                if (!empty($ds)) $sql[] = 'type="кр" and ('.implode(' or ',array_values($ds)).')';
//            }
            $kontr = \R::getAll("select * from vkruserkontr where lektor_id=?", [$this->cur_user->id]);
            $discs = $this->convert($discs,'disc','class');
            $kontr = $this->convert($kontr,'disc','user_id');
            $discs_list = !empty($discs) ? "('". implode("','",array_keys($discs)) ."')" : false;
            $kontr_ex = $discs_list ? \R::getAll("select * from vkruserkontr where lektor_id!=? and lektor_id is not null and disc in {$discs_list}",[$this->cur_user->id]) : [];
            $kontr_ex = $this->convert($kontr_ex,'disc','user_id');
//            dd($kontr_ex);
            foreach ($discs as $disc => $classes) {
                if (empty($classes)) continue;
                $class_list = array_merge($class_list, $classes);
                $classes_ = (count($classes) > 1) ? "in ('" . implode("','",$classes) . "')" : "= '".current($classes)."'";
                $ex = !empty($kontr_ex[$disc]) ? " and stud_id not in (" . implode(",",$kontr_ex[$disc]) . ")" : '';
//                $sql[] = "disc='{$disc}' and class {$classes_}{$ex} and type='кр'";
            }
            foreach ($kontr as $disc => $ids) {
                $user_list = array_merge($user_list, $ids);
//                $sql[] = !empty($kontr[$disc]) ? "disc='{$disc}' and stud_id in (" . implode(",",$kontr[$disc]) . ") and type='кр'" : '';
            }
            if (!$this->isAjax()) {
                $ct = 0; $tws_ = [];
                $sql_str_ = !empty($sql) ? "and (" . implode(' or ', $sql) . ")" : '';
                $tw_kontr_ = !empty($sql_str_) ? \R::getAll("select * from taskwork where archive=0 {$sql_str_} order by created desc") : [];
                foreach ($tw_kontr_ as $k => $item) { if (!isset($tws_[$item['stud_id']])) $tws_[$item['stud_id']] = []; $tws_[$item['stud_id']][] = $item; }
                foreach ($tws_ as $k => $item) { if (current($item)['status']==2) $ct++; } $c[] = count($tws_)-$ct;
//                dd($sql);
            }
        }
        if ($cr || !$this->isAjax()) {
            if (!$this->isAjax()) { $sql = []; }
            $curs = \R::getAll("select * from vkrusercurs where lektor_id=?",[$this->cur_user->id]);
            $curs = $this->convert($curs,'disc','user_id');
            foreach ($curs as $disc => $ids) {
                $user_list = array_merge($user_list, $ids);
                $sql[] = !empty($curs[$disc]) ? "disc='{$disc}' and stud_id in (" . implode(",",$curs[$disc]) . ") and type='кп'" : '';// and perc>49
            }
            if (!$this->isAjax()) {
                $ct = 0; $tws_ = [];
                $sql_str_ = !empty($sql) ? "and (" . implode(' or ', $sql) . ")" : '';
                $tw_kontr_ = !empty($sql_str_) ? \R::getAll("select * from taskwork where archive=0 {$sql_str_} order by created desc") : []; //(perc>49 or perc is null) and
                foreach ($tw_kontr_ as $k => $item) { if (!isset($tws_[$item['stud_id']])) $tws_[$item['stud_id']] = []; $tws_[$item['stud_id']][] = $item; }
                foreach ($tws_ as $k => $item) { if (current($item)['status']==2) $ct++; } $c[] = count($tws_)-$ct;
            }
        }
        if ($vkr || !$this->isAjax()) {
            if (!$this->isAjax()) { $sql = []; }
            $vkr = \R::getAll("select * from vkruservkrs where lektor_id=?",[$this->cur_user->id]);
            $vkr = $this->convert($vkr,'disc','user_id');
            foreach ($vkr as $disc => $ids) {
                $user_list = array_merge($user_list, $ids);
                $sql[] = !empty($vkr[$disc]) ? "disc='{$disc}' and stud_id in (" . implode(",",$vkr[$disc]) . ") and type='вкр'" : '';// and perc>49
            }
            if (!$this->isAjax()) {
                $ct = 0; $tws_ = [];
                $sql_str_ = !empty($sql) ? "and (" . implode(' or ', $sql) . ")" : '';
                $tw_kontr_ = !empty($sql_str_) ? \R::getAll("select * from taskwork where archive=0 {$sql_str_} order by created desc") : []; //(perc>49 or perc is null) and
                foreach ($tw_kontr_ as $k => $item) { if (!isset($tws_[$item['stud_id']])) $tws_[$item['stud_id']] = []; $tws_[$item['stud_id']][] = $item; }
                foreach ($tws_ as $k => $item) { if (current($item)['status']==2) $ct++; } $c[] = count($tws_)-$ct;
            }
        }
        if ($pr || !$this->isAjax()) {
            if (!$this->isAjax()) { $sql = []; }
            $pr = \R::getAll("select * from vkruserpract where lektor_id=?",[$this->cur_user->id]);
            $pr = $this->convert($pr,'disc','user_id');
            foreach ($pr as $disc => $ids) {
                $user_list = array_merge($user_list, $ids);
                $sql[] = !empty($pr[$disc]) ? "disc='{$disc}' and stud_id in (" . implode(",",$pr[$disc]) . ") and type='практ'" : '';
            }
            if (!$this->isAjax()) {
                $ct = 0; $tws_ = [];
                $sql_str_ = !empty($sql) ? "and (" . implode(' or ', $sql) . ")" : '';
                $tw_kontr_ = !empty($sql_str_) ? \R::getAll("select * from taskwork where archive=0 {$sql_str_} order by created desc") : [];
                foreach ($tw_kontr_ as $k => $item) { if (!isset($tws_[$item['stud_id']])) $tws_[$item['stud_id']] = []; $tws_[$item['stud_id']][] = $item; }
                foreach ($tws_ as $k => $item) { if (current($item)['status']==2) $ct++; } $c[] = count($tws_)-$ct;
            }
        }
        if ($dst || !$this->isAjax()) {
            if (!$this->isAjax()) { $sql = []; }
            $dst = \R::getAll("select * from vkruserdist where lektor_id=?",[$this->cur_user->id]);
            $dst = $this->convert($dst,'disc','user_id');
            foreach ($dst as $disc => $ids) {
                $user_list = array_merge($user_list, $ids);
                $sql[] = !empty($dst[$disc]) ? "disc='{$disc}' and stud_id in (" . implode(",",$dst[$disc]) . ") and type='дист'" : '';
            }
            if (!$this->isAjax()) {
                $ct = 0; $tws_ = [];
                $sql_str_ = !empty($sql) ? "and (" . implode(' or ', $sql) . ")" : '';
                $tw_kontr_ = !empty($sql_str_) ? \R::getAll("select * from taskwork where archive=0 {$sql_str_} order by created desc") : [];
                foreach ($tw_kontr_ as $k => $item) { if (!isset($tws_[$item['stud_id']])) $tws_[$item['stud_id']] = []; $tws_[$item['stud_id']][] = $item; }
                foreach ($tws_ as $k => $item) { if (current($item)['status']==2) $ct++; } $c[] = count($tws_)-$ct;
            }
        }
        $data['ct'] = $c;
        $data['discs'] = array_unique(array_merge(
            !empty($discs) ? array_keys($discs) : [],
            !empty($kontr) ? array_keys($kontr) : [],
            !empty($curs) ? array_keys($curs) : [],
            !empty($vkr) ? array_keys($vkr) : [],
            !empty($prakt) ? array_keys($prakt) : []
        ));

        if ($this->isAjax()) {
            $sql_str = !empty($sql) ? "and (" . implode(' or ', $sql) . ")" : '';
            $tw_kontr = !empty($sql_str) ? \R::getAll("select * from taskwork where (type in ('кр','практ') or type not in ('кр','практ')) and archive=0 {$sql_str} order by created desc") : []; // and (perc>49 or perc is null)
            foreach ($tw_kontr as $k => $item) { if (!isset($tws[$item['stud_id']])) $tws[$item['stud_id']] = []; $tws[$item['stud_id']][] = $item; }

            $us_sql = [];
            $class_list = array_unique($class_list);
            if (!empty($class_list)) $us_sql[] = "class in ('".implode("','",$class_list)."')";
            if (!empty($user_list)) $us_sql[] = "id in (".implode(",",$user_list).")";
            $users = !empty($us_sql) ? \R::getAssoc("select id,name from users where ".implode(' or ', $us_sql)) : [];

            $users_uns = $usp_all = [];
//            if (!empty($us_sql)) {
//                $users_uns = \R::getAssoc("select id,uchet from users where ".implode(' or ', $us_sql));
//                \R::addDatabase('DB1','mysql:host=web02.usue.ru;dbname=fsp_usp;charset=utf8','inoonline','CnhfyyjcnmUtkz25',true);
//                \R::selectDatabase('DB1');
//                $usp_all = \R::getAll("select Gruppa as gruppa, Fam as fam, UNS as uns, Semestr as semestr, Disciplina as disciplina,
//                Othetnost as othetnost, Ocenka as ocenka, Reiting as reiting, Data as data, Deistvie as deistvie, Famprepod as famprepod
//                from uspevaemost where uns in (?)", [implode(',',array_values($users_uns))]);
//                \R::selectDatabase('default');
//            }
//            $sems = \R::getAssoc("select class,ks from classsem where enabled=1");



            foreach ($tws as $id => $tw) {
                $user_work = [];
                $related = [];
                $status = null;
                foreach ($tw as $key => $item) {
//                    if (!is_null($item['perc']) && $item['perc'] < 50) continue;
                    $type = $url = 'curstasks';
                    switch ($item['type']) {
                        case 'кр': $type = 'Контр.раб.'; $url = 'kontrtasks'; break;
                        case 'зач': $type = 'Зач.'; break;
                        case 'прр': $type = 'Пров.раб.'; break;
                        case 'экз': $type = 'Экз.раб.'; break;
                        case 'кп': $type = 'Курс.раб.'; $url = 'curstasks'; break;
                        case 'вкр': $type = 'ВКР'; $url = 'vkrtasks'; break;
                        case 'практ': $type = 'Практ.'; $url = 'practtasks'; break;
                        case 'дист': $type = 'Дист.'; $url = 'disttasks'; break;
                    }
                    $link = '/download?f=' . base64_encode('../upload/works/' . $item['file']) . '&c=' . urlencode($item['ftitle']);
                    $forms = '<div class="clear"></div>
                <form action="/'.$url.'/docs" target="_blank" method="post" style="width: 50%;float:left;">
                    <input type="hidden" name="sem" value="'. $item['sem']. '">
                    <input type="hidden" name="disc" value="'. $item['disc']. '">
                    <input type="hidden" name="user_id" value="'. $item['stud_id'] .'">
                    <button style="width: 100%;" type="submit" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-download"></span>&nbsp;Cправка</button></form><div class="clear"></div>
                <form action="/'.$url.'/docsb" target="_blank" method="post" style="width: 50%;float:left;">
                    <input type="hidden" name="sem" value="'. $item['sem']. '">
                    <input type="hidden" name="disc" value="'. $item['disc']. '">
                    <input type="hidden" name="user_id" value="'. $item['stud_id'] .'">
                    <button style="width: 100%;" type="submit" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-download"></span>&nbsp;Отзыв</button></form>';
                    $dwnld = (!empty($item['file'])) ? '<a href="'.$link . '" class="btn btn-warning btn-xs" target="_blank"><span class="glyphicon glyphicon-download"></span>&nbsp;<span class="hidden-xs">Скачать</span></a>' : '';
                    if (!in_array($item['type'], ['кр','практ']) && !empty($dwnld)) $dwnld .= $forms;
                    if ($item['type']=='кп') {
                        $perc = (!is_null($item['perc'])) ? $item['perc'] . '%' . '<a target="_blank" class="btn btn-xs btn-success pull-right" href="' . $item['pdf'] . '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>' : '<span data-id="' . $item['id'] . '" class="work btn btn-xs btn-default pull-right" title="Отправить на проверку"><i class="glyphicon glyphicon-check"></i></span>';
                    } else $perc = '';

                    $date1 = new DateTime($item['marked']);
                    $date2 = new DateTime();
                    $interval = $date2->diff($date1);
                    $disabled_mark = $interval->days >= 1 ? 'disabled' : '';
                    if ($item['type'] == 'вкр') {
                        $mark = '<select '.$disabled_mark.' data-id="mark' . $item['id'] . '" class="mark" style="height: 23px;padding: 0;margin-bottom: 0;">
                            <option value="0" ' . ($item['mark'] == 0 ? 'selected' : '') . '>--</option>
                            <option value="6" ' . ($item['mark'] != 0 && $item['mark'] != 7 ? 'selected' : '') . '>допущен</option>
                            <option value="7" ' . ($item['mark'] == 7 ? 'selected' : '') . '>на дораб.</option>
                        </select>';
                    } else
                    $mark = '<select '.$disabled_mark.' data-id="mark' . $item['id'] . '" class="mark" style="height: 23px;padding: 0;margin-bottom: 0;">
                        <option value="0" ' . ($item['mark'] == 0 ? 'selected' : '') . '>--</option>
                        <option value="3" ' . ($item['mark'] == 3 ? 'selected' : '') . '>3</option>
                        <option value="4" ' . ($item['mark'] == 4 ? 'selected' : '') . '>4</option>
                        <option value="5" ' . ($item['mark'] == 5 ? 'selected' : '') . '>5</option>
                        <option value="6" ' . ($item['mark'] == 6 ? 'selected' : '') . '>зач</option>
                        <option value="7" ' . ($item['mark'] == 7 ? 'selected' : '') . '>на дораб.</option>
                    </select>';
                    $com = '<button type="button" class="btn btn-xs btn-' . (!empty($item['comment']) ? 'success' : 'primary') . '" data-toggle="modal" data-target="#commentModal" data-id="' . $item['id'] . '" data-title="' . htmlentities(@$item['comment']) . '" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></button>';
                    $lektor = '';
                    if ($item['prep_id']) {
                        $lektor = explode(" ",\R::load('users',$item['prep_id'])->name);
                        $lektor = $lektor[0] . ' ' . mb_substr($lektor[1],0,1,"UTF-8") . '.' . mb_substr($lektor[2],0,1,"UTF-8") . '.';
                        $lektor = '<br>'.$lektor;
                    }
                    $marked = $item['marked'] ? date("d.m.Y H:i", strtotime($item['marked'])) .$lektor : '';
                    $marked = !empty($marked) ? '<i data-toggle="popover" tabindex="0" data-html="true"
                        data-content="'.htmlentities($marked).'" style="color:#337ab7; font-size: 18px; cursor:pointer;" 
                        class="glyphicon glyphicon-info-sign pull-right"></i>' : '';
                    $dolg = '';

                    if ($item['type']=='практ' && !empty($item['work_id'])) {
                        $link = '/download?f=' . base64_encode('../upload/works/' . $item['file']) . '&c=' . urlencode($item['ftitle']);
                        $related[$item['work_id']] = (!empty($item['file'])) ? '<a href="'.$link . '" class="btn btn-warning btn-xs" target="_blank" style="margin-top: 5px;"><span class="glyphicon glyphicon-download"></span>&nbsp;<span class="hidden-xs">Индив.задание</span></a>' : '';
                        unset($tws[$id][$key]);
                        continue;
                    }
                    if (!empty($item['work_id']) && $this->cur_user->id == 13152) {
//                        var_dump($item);
//                        die;
                    }
                    $user_work[$item['id']] = [
                        'tdisc'  => $item['disc'],
                        'ttype'  => $type . $dolg,
                        'tdwnld' => $dwnld,
                        'tperc'  => $perc,
                        'tmark'  => $mark,
                        'tcom'   => $com,
                        'tdate'  => date("d/m/Y H:i", strtotime($item['created'])),
                        'tdatestring'  => strtotime($item['created']),
                        'tstatus'=> $item['status'],
                        'tmarked'=> $marked,
                        'tsem' => $item['sem']
                    ];
                }

                $tdsc = [];
                foreach ($user_work as $uw) $tdsc[$uw['tdisc']][] = $uw['tstatus'];
                foreach ($tdsc as &$tds) $tds = current($tds);
                $final_status = 2;
                foreach ($tdsc as &$tds) if ($tds == 0) {
                    $final_status = 0; break;
                }

                $cur_tw = current($tw);
                $ss = !empty($user_list) && in_array($id, $user_list) ? 'распределением нагрузки' : 'учебным планом';
                $cc = !empty($user_list) && in_array($id, $user_list) ? '#5cb85c' : '#337ab7';
                $post = '<span><i data-toggle="popover" tabindex="0" data-html="true"
                        data-content="Работа пришла в соответствии с <b>'.$ss.'</b>" style="color: '.$cc.'; font-size: 18px; cursor:pointer;" 
                        class="glyphicon glyphicon-info-sign pull-right"></i></span>';
                if ($this->cur_user->id == 13152) {
//                        var_dump($user_work);
//                        var_dump($related);
//                        die;
                }
                if (count($related)) {
                    foreach ($related as $ke => $it) {
                        $user_work[$ke]['tdwnld'] .= $it;
//                        break;
                    }
                }

                usort($user_work, function ($a, $b) {
                    return !($a['tdatestring'] <=> $b['tdatestring']);
                });

                $t[] = [
                    'tname'   => $users[$id].$post,
                    'tdate'   => date("d/m/Y H:i", strtotime($cur_tw['created'])),
                    'tdate_'  => $cur_tw['created'],
                    'tclass'  => $cur_tw['class'],
                    'tstatus' => (string) $final_status,//$cur_tw['status'], //$status,
                    'tchild'  => $user_work,
                    'tid'     => $id,
                ];
            }

            die(json_encode(['data' => $t]));
        }

        $this->set($data);
    }

    public function filesAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['user'] = $this->cur_user;

        $res = [];
        for ($sem = 1; $sem<10; $sem++) {
            $plans = \R::findAll('plan',"user_id=? and s{$sem} != '0|0|0|0|0|0|0|0|0'",[$this->cur_user->id]);
            $p = [];
            foreach ($plans as $plan) $p[$plan->disc][] = "'".$plan->class."'";
            foreach ($p as $k=>&$p_) $p_ = 'class in ('. implode(', ', $p_) . ") and disc='{$k}'";
            $sql = implode(' or ', array_values($p));
//            dd($p);
            $files = \R::findAll('mfiles', "sem={$sem} and ({$sql}) and type=0 and archive=0");
            dd(123);
            dd($files);
            $res[$sem] = 0;
        }
//        $mfiles = \R::findAll('mfiles', "course=? AND (class LIKE ? OR class IS NULL) AND disc=? and type=0 and archive=0", [
//            $this->cur_user->course, "%$class%", $disc]);
        $this->set($data);
    }

    public function workviewAction() {
        $data = $this->data;
        if (!isset($_GET['id'])) header("Location: " . BASE_URL . 'tasks');
        $this->view = 'work';
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $t = \R::findOne('mfiles', "id=? and archive=0", [$_GET['id']]);
        $t['works'] = \R::getAll("SELECT * FROM taskwork WHERE task_id=? and archive=0 order by status", [$t['id']]);
        if (!empty($t['works'])) {
            foreach ($t['works'] as &$work) {
                $stud = \R::load('users', $work['stud_id']);
                $name = explode(" ", $stud->name);
                $work['stud'] = $stud;
                $work['name'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
                $work['created_str'] = strtotime($work['created']); //strftime("%d %b %H:%M",strtotime($work['created']));
                $work['created'] = date("d/m/Y",strtotime($work['created'])); //strftime("%d %b %H:%M",strtotime($work['created']));
//                $work['created'] = date("d F", strtotime($work['created'])) . '<span class="hidden-xs">' . date(" H:i:s", strtotime($work['created'])) . '</span>';
            }
        }
        $data['t'] = $t;
//        dd($data['t']);
        $this->set($data);
    }

    public function workstudAction() {
//                ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
        $data = $this->data;
        if (isset($_GET['test'])) $this->view = 'workstudtest';
//        if (!isset($_GET['id'])) header("Location: " . BASE_URL . 'tasks');
        $this->view = 'workstud';
        $this->setMeta('Антиплагиат');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $t['works'] = \R::getAll("SELECT * FROM taskworks WHERE stud_id=? and archive=0 order by status", [$this->cur_user->id]);
        if (!empty($t['works'])) {
            foreach ($t['works'] as &$work) {
                $stud = \R::load('users', $work['stud_id']);
                $name = explode(" ", $stud->name);
                $work['stud'] = $stud;
                $work['name'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
                $work['created_str'] = strtotime($work['created']); //strftime("%d %b %H:%M",strtotime($work['created']));
                $work['created'] = date("d/m/Y",strtotime($work['created'])); //strftime("%d %b %H:%M",strtotime($work['created']));
//                $work['created'] = date("d F", strtotime($work['created'])) . '<span class="hidden-xs">' . date(" H:i:s", strtotime($work['created'])) . '</span>';
            }
        }
/*
        $data['t'] = [];

        foreach ($t as $item) {
            $data[$t] .= [];
        }*/

        $data['t'] = $t;

//        dd($data['t']);
        $this->set($data);
    }

    public function workstudupluadAction() {
        $this->layout = false;
        if (!isset($_POST['id'])) redirect();
        $uploaddir = WWW . '/upload/works/';
//        $uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
        $uploadfile = $uploaddir . ($_FILES['userfile']['name']);
        $file = $_FILES['userfile'];

        $ext = strtolower(substr(strrchr($file['name'], '.'), 1));
        $ftitle = md5(uniqid()) .  '.' . $ext;
        while (file_exists(WWW. '/ino/' . $ftitle)) {
            $ftitle .= rand(10, 99);
        }
        $res = move_uploaded_file($file['tmp_name'],$uploaddir.$ftitle);
        if (!$res) redirect(BASE_URL . "tasks?disc=" . $_GET['disc']);

        $tasks = \R::dispense('taskworks');
        $tasks->stud_id = $this->cur_user->id;
        $tasks->task_id = $_POST['id'];
        $tasks->disc = $_GET['disc'];
        $tasks->class = $this->cur_user->class;
        $tasks->type = $_POST['type'];
        $tasks->file = $ftitle;
        $tasks->ftitle = $file['name'];
        $tasks->created = \R::isoDateTime();
        \R::store($tasks);

        redirect(BASE_URL . "tasks/workstud");
    }
    public function teststudAction() {
    //        ini_set('error_reporting', E_ALL);
    //ini_set('display_errors', 1);
    //ini_set('display_startup_errors', 1);
        $id = $_GET['id'] ?: null;
        if (!$id) die();

        require LIBS . '/antiplagiat.php';

        $task = \R::findOne('taskworks','id=?',[$id]);
        $file = WWW. '/upload/works/' . $task->file;
        $ap = new \Anti();
//        $test = $ap->soapDebug();
//        die();
//        dd2($test);
        $scor = $ap->get_web_report($file);
        header('Content-Type: application/json');

        if (isset($scor['goodpercentage'])) {
            $score = $scor['goodpercentage'];
            $task->perc = $score;
            $task->pdf = $scor['full_report'];
            \R::store($task);
            die(json_encode(['success' => "{$score}", 'pdf' => $scor['full_report']]));
        }
        die(json_encode($scor));
    }

    public function editAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;

        $data['users'] = \R::getAll("SELECT u.* FROM users u, plan uc WHERE u.class=uc.class AND uc.user_id=?", [$this->cur_user->id]);

        if (!empty($_POST['id'])) {
            $data['tasks'] = \R::load('tasks', $_POST['id']);
            $personal = $data['tasks']['users'];
            if (!empty($personal)) {
                $personal = explode("|", $personal);
                $data['personal'] = $personal;
            }
        }
        else {
            $tasks = \R::dispense('tasks');
            $tasks->createId = $this->cur_user->id;
            $tasks->created = \R::isoDateTime();
            $data['task_id'] = \R::store($tasks);
            $data['tasks'] = \R::load('tasks', $data['task_id']);
        }
//        $data['next'] = \R::getInsertID();
//        dd($data['next']);
        $data['class'] = $this->usr->get_class_list(null, $this->cur_user);
        $data['course'] = $this->usr->get_course_list();
//        $up = \R::getAll("SELECT u.id AS uid, p.id, p.name, p.sname FROM userpred u,predmets p WHERE p.id=u.pred_id AND u.user_id=?", [$this->cur_user->id]);
        $up = \R::getAssoc("SELECT DISTINCT p.name, u.id AS uid, p.id, p.sname FROM plan u LEFT JOIN predmets p ON u.disc=p.name WHERE u.user_id=? AND  p.name!='' ORDER BY p.name", [$this->cur_user->id]);
//        dd($up);
        $data['predmet'] = $up;
        //\R::getAll("SELECT DISTINCT * FROM predmets");

//dd($data['predmet']);
        $task_id = !empty($_POST['id']) ? $_POST['id'] : $data['task_id'];
        $data['files'] = \R::findAll('files', "task_id=?", [$task_id]);

        $this->set($data);
    }

    public function testAction() {
//        ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
        $id = $_GET['id'] ?: null;
        if (!$id) die();
die;
        require LIBS . '/antiplagiat.php';

        $task = \R::findOne('taskwork','id=?',[$id]);
        $file = WWW. '/upload/works/' . $task->file;
        $ap = new \Anti();
//        $test = $ap->soapDebug();
//        die();
//        dd2($test);
        $scor = $ap->get_web_report($file);
        header('Content-Type: application/json');

        if (isset($scor['goodpercentage'])) {
            $score = $scor['goodpercentage'];
            $task->perc = $score;
            $task->pdf = $scor['full_report'];
            \R::store($task);
            die(json_encode(['success' => "{$score}", 'pdf' => $scor['full_report']]));
        }
        die(json_encode($scor));
    }

    public function saveAction() {
        $this->layout = false;

        $uploaddir = WWW . '/upload/tasks/';
//        $uploadfile = $uploaddir . basename($_FILES['userfile']['name']);


        $uploadfile = $uploaddir . ($_FILES['userfile']['name']);

        move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile);

        if (isset($_POST['id'])) $tasks = \R::load('tasks', $_POST['id']);
        else $tasks = \R::dispense('tasks');
        $tasks->createId = $this->cur_user->id;
        $tasks->title = $_POST['title'];
        $tasks->desc = $_POST['comment'];

        $tasks->type = $_POST['type']; //todo check
        $tasks->predmet = !empty($_POST['predmet']) ? $_POST['predmet'] : null;


        $personal = !empty($_POST['usr_id']) ? $_POST['usr_id'] : null;
//        dd($personal);
        if (!empty($personal)) {
            $tasks->users = implode("|", $personal);
        } else {
            $tasks->users = null;
            $tasks->fac = !empty($_POST['dfac']) ? $_POST['dfac'] : null;
            $tasks->course = !empty($_POST['course']) ? $_POST['course'] : null;
            $tasks->class = !empty($_POST['class']) ? json_encode($_POST['class']) : null;
        }

        if ($_FILES['userfile']['name'] != '') $tasks->taskfile = $_FILES['userfile']['name'];
        $tasks->created = \R::isoDateTime();
        \R::store($tasks);

        redirect();
    }

    public function docsAction() {
//                ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
        $disc = isset($_POST['disc']) ? $_POST['disc'] : false;
        $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : false;
        $sem = isset($_POST['sem']) ? $_POST['sem'] : false;
        if (!$disc || !$user_id || !$sem ) die('Ошибка');
//        dd2($user_id);
        $vkr = \R::findOne('vkruserkontr',"sem=? and disc=? and user_id=?",[$sem,$disc,$user_id]);
//        if (!$vkr) die('Не найдено');
        $title = $disc;
//        if (empty($title)) die('Тема не указана!');
        $mark = \R::getRow("select * from taskwork where disc=? and stud_id = ? and 
            type='кр' and sem=? order by marked desc",[$disc, $user_id, $sem]);
        if ($mark) {
            if ($mark['mark'] == 6) $mark['mark'] = 'зач';
            if ($mark['mark'] == 7) $mark['mark'] = 'на дораб.';
        }
//        if (empty($mark['perc'])) die('Справка будет доступна после проверки работы в сервисе антиплагиат');
        if ($vkr) {
            $prepod = ($vkr->lektor_id) ? \R::findOne('users',"id=?",[$vkr->lektor_id])->name : '';
            $user = ($vkr->user_id) ? \R::findOne('users',"id=?",[$vkr->user_id])->name : '';
        } else {
            $us = \R::findOne('users',"id=?",[$user_id]);
            $user = $us ? $us->name : '';
            $vkr = \R::findOne('plan',"s{$sem}!='0|0|0|0|0|0|0|0|0' and disc=? and class=? and user_id is not null",[$disc,$us->class]);
            $prepod = $vkr ? \R::findOne('users',"id=?",[$vkr->user_id])->name : '';
        }
        $mark = ($mark) ? $mark['perc'] : '0';

        setlocale(LC_TIME, 'Russian');
        $templateProcessor = new TemplateProcessor(WWW . '/faqres/справка о контрольной.docx');
        $templateProcessor->setValue('title', htmlspecialchars($title));
        $templateProcessor->setValue('perc', htmlspecialchars($mark));
        $templateProcessor->setValue('student', htmlspecialchars($user));
        $templateProcessor->setValue('prepod', htmlspecialchars($prepod));

        $templateProcessor->saveAs(WWW.'/tmp/sampledocument.docx');
        if(ini_get('zlib.output_compression')) ini_set('zlib.output_compression', 'Off');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        header("Content-Disposition: attachment; filename=\"Справка о публикации.docx\";");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: ".filesize(WWW.'/tmp/sampledocument.docx'));
        @readfile(WWW.'/tmp/sampledocument.docx');
        exit;

        die("Успешно");
    }

    public function viewAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['user'] = $this->cur_user;
        $data['cur_user'] = $this->cur_user;

        if (isset($_POST['id'])) {

            $data['files'] = \R::findAll('mfiles', "id=? and archive=0", [$_POST['id']]);
//            $data['task'] = \R::load('tasks', $_POST['id']);
        } else redirect();


        $this->set($data);
    }

    public function workAction() {
//        $this->layout = false;
        if (!isset($_POST['id'])) redirect();
        $uploaddir = WWW . '/upload/works/';
//        $uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
        $uploadfile = $uploaddir . ($_FILES['userfile']['name']);
        $file = $_FILES['userfile'];

        $ext = strtolower(substr(strrchr($file['name'], '.'), 1));
        $ftitle = md5(uniqid()) .  '.' . $ext;
        while (file_exists(WWW. '/ino/' . $ftitle)) {
            $ftitle .= rand(10, 99);
        }
        $res = move_uploaded_file($file['tmp_name'],$uploaddir.$ftitle);
        if (!$res) {
            $_SESSION['info_msg'][] = 'Кончилось место на диске! Обратитесь к администратору.';
            $_SESSION['info_msg'][] = 'Кончилось место на диске! Обратитесь к администратору.';
        } else {
            date_default_timezone_set('Asia/Yekaterinburg');
            $tasks = \R::dispense('taskwork');
            $tasks->stud_id = $this->cur_user->id;
            $tasks->task_id = $_POST['id'];
            $tasks->disc = $_POST['disc'];
            $tasks->class = $this->cur_user->class;
            $tasks->sem = (!empty($_POST['s'])) ? $_POST['s'] : $this->sem;
    //        if ($this->sem) $tasks->sem = $this->sem;
            $tasks->type = $_POST['type'];
            $tasks->dolg = !empty($_POST['dolg'])?1:0;
            $tasks->file = $ftitle;
            $tasks->ftitle = $file['name'];
            $tasks->created = \R::isoDateTime();
            \R::store($tasks);

            $this->send('worksend', null, ['%predmet%' => $tasks->disc]);
            if (!empty($_POST['prep_id'])) $this->send('worknew',$_POST['prep_id'],
                ['%predmet%' => $tasks->disc, '%fio_stud%' => $this->cur_user->name, '%gruppa%' => $this->cur_user->class]);
            $data = $this->data;
            $this->setMeta('Задания');
            $data['menu'] = $this->menu;
            $data['meta'] = $this->meta;
            $data['user'] = $this->cur_user;
            $data['cur_user'] = $this->cur_user;
    //        redirect(BASE_URL . "tasks?s=".$_POST['s']."&disc=". $_GET['disc']);
        }
    }

    public function markAction() {
//   ini_set('error_reporting', E_ALL);
//    ini_set('display_errors', 1);
//    ini_set('display_startup_errors', 1);
        date_default_timezone_set('Asia/Yekaterinburg');
        $this->layout = false;
        $this->view = false;
        if ($this->isAjax()) {
            $id = substr($_POST['id'], 4);
            $mark = !empty($_POST['mark']) ? $_POST['mark'] : null;
            $comment = isset($_POST['comment']) ? $_POST['comment'] : null;

            $t = \R::findOne('taskwork', "id=?",[$id]);
            $t->mark = $mark;
            $t->status = 2;
            $t->prep_id = $this->cur_user->id;
            $t->marked = \R::isoDateTime();
            $t->comment = $comment;
            \R::store($t);
            if ($mark == 6) $mark = 'зач.';
            if ($mark == 7) $mark = 'н/зач';
//            $this->send('workmark',$t->stud_id,['%predmet%' => $t->disc, '%ocenka%' => $mark]);
            die;
        }
        return false;
    }

    public function commentAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        if (isset($_POST['id'])) {
            $data['id'] = $_POST['id'];
            $data['comment'] = \R::load('taskwork', $data['id'])->comment;
        } else redirect();
        $this->set($data);
    }

    public function comSetAction() {
        $this->layout = false;
        $this->view = false;
        if (isset($_POST['id'])) {
            $comment = \R::load('taskwork', $_POST['id']);
            $comment->comment = isset($_POST['comment']) ? $_POST['comment'] : null;
            \R::store($comment);
        }
//        redirect(BASE_URL . 'tasks');
        die;
    }

    public function uploadtaskAction() {
        $this->layout = false;
        require_once LIBS . '/qqfileuploader.php';

        // list of valid extensions, ex. array("jpeg", "xml", "bmp")
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', "doc", "docs", "xls", "xlsx", "txt", "pdf", "rar", "zip",];
// max file size in bytes
        $sizeLimit = 1 * 1024 * 1024;
//echo BASE_PATH . 'upload/';
        $uploader = new \qqFileUploader($allowedExtensions, $sizeLimit);
        $result = $uploader->handleUpload(BASE_PATH . 'upload/tasks/', FALSE);

// to pass data through iframe you will need to encode all html tags

        if (isset($result['success']) && $result['success']) {
            $file = $result['file'];
//            dd2($result['real']);
            $doc = \R::dispense('files');
            $doc->user_id = $this->cur_user['id'];
            $doc->task_id = $_GET['task'];
            $doc->type = 1;
            $doc->fext = strtolower(substr(strrchr($file, '.'), 1));
            $doc->fname = str_replace('.' . $doc->fext, '', strtolower(substr(strrchr($file, '/'), 1)));
            $doc->ftitle= $result['real'];
            $doc->fsize = round((filesize($file) / 1024), 2);
            $doc->fdata = \R::isoDate();
            \R::store($doc);
            $result['url'] = $this->path_to_url($file);
            unset($result['file']);

            $imgsize = getimagesize($file);
            $result['width'] = $imgsize[0];
            $result['height'] = $imgsize[1];
        }
        echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
        die;
    }

    function path_to_url($path) {
        $path = str_replace('\\', '/', $path);
        return strpos($path, BASE_PATH) === 0 ? BASE_URL . substr($path, strlen(BASE_PATH)) : $path;
    }

    public function deletefileAction() {
        $this->layout = false;
        if (isset($_POST['id'])) {
            \R::trash('files', $_POST['id']);
        }
        $count = \R::count('files', "task_id=?", [$_POST['task']]);
        echo json_encode(['success' => true, 'count' => $count]);
        die;
    }

    public function getTasksAction() {
        $this->layout = false;
        $class = isset($_GET['class']) ? $_GET['class'] : false;
        $disc = isset($_GET['disc']) ? $_GET['disc'] : false;
        $user = isset($_GET['user']) ? $_GET['user'] : false;

        $sql = [];
        if ($class) $sql[] = "class = '{$class}'";
        if ($disc)  $sql[] = "disc = '{$disc}'";
        if ($user)  $sql[] = "stud_id = '{$user}'";
        $sql = implode(' and ',$sql);

        if (!empty($sql)) {
            $works = \R::getAll("SELECT * FROM taskwork WHERE {$sql} and archive=0 order by created desc");
            $html = '';
            foreach ($works as $item) {

                $stud = \R::findOne('users','id = ?',[$item['stud_id']]);

                $html .= '<tr>';

                $html .= "<td>{$item['created']}</td>";
                $html .= "<td>{$stud->name}</td>";
                $html .= "<td>{$item['class']}</td>";
                $html .= "<td style='word-break: break-all; text-align: left;'>{$item['disc']}</td>";
                $html .= "<td>{$item['type']}</td>";
                $html .= (!empty($item['file'])) ? "<td><a href='upload/works/{$item['file']}' class='btn btn-warning btn-xs' target='_blank'><span class='glyphicon glyphicon-download'></span>&nbsp;<span class='hidden-xs'>Скачать</span></a></td>" : "<td></td>";

                $mark = '';
                if ($item['mark'] == 6) $mark = 'зач';
                if ($item['mark'] == 7) $mark = 'на дораб.';
                $html .= !empty($item['mark']) ? "<td>{$mark}</td>" : "<td></td>";
                $html .= "<td><span data-id='{$item['id']}' class='btn btn-xs btn-danger remove'><i class='glyphicon glyphicon-remove'></i></span></td>";

                $html .= '</tr>';
            }
            echo $html;
        }
        die;
        if (!empty($_GET['user'])) {
            $works = \R::getAll("SELECT * FROM taskwork WHERE stud_id=? and archive=0 order by created desc", [$_GET['user']]);
            $html = '';
            foreach ($works as $item) {
                $html .= '<tr>';

                $html .= "<td>{$item['created']}</td>";
                $html .= "<td>{$item['stud_id']}</td>";
                $html .= "<td>{$item['class']}</td>";
                $html .= "<td style='word-break: break-all; text-align: left;'>{$item['disc']}</td>";
                $html .= "<td>{$item['type']}</td>";
                $html .= (!empty($item['file'])) ? "<td><a href='upload/works/{$item['file']}' class='btn btn-warning btn-xs' target='_blank'><span class='glyphicon glyphicon-download'></span>&nbsp;<span class='hidden-xs'>Скачать</span></a></td>" : "<td></td>";

                $mark = '';
                if ($item['mark']==6) $mark = 'зач';
                if ($item['mark']==7) $mark = 'на дораб.';
                $html .= !empty($item['mark']) ? "<td>{$mark}</td>":"<td></td>";

               /* $comment = !empty($item['comment'])?'success':'primary';

                $html .= '<td><form action="<?= BASE_URL ?>tasks/comment" method="post" target="_blank">
                            <input type="hidden" name="id" value="'. $item['id'] .'">
                            <button  data-toggle="tooltip" title="'. @$item['comment'] .'" class="btn btn-xs btn-'. $comment .'" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></button></form></td>';*/
               $html .= "<td><span data-id='{$item['id']}' class='btn btn-xs btn-danger remove'><i class='glyphicon glyphicon-remove'></i></span></td>";

                $html .= '</tr>';
            }
            echo $html;
        }
        else {
            $works = \R::getAll("SELECT * FROM taskwork WHERE archive=0 order by created desc", []);
            $html = '';
            foreach ($works as $item) {
                $html .= '<tr>';

                $html .= "<td>{$item['created']}</td>";
                $html .= "<td style='word-break: break-all; text-align: left;'>{$item['disc']}</td>";
                $html .= "<td>{$item['type']}</td>";
                $html .= (!empty($item['file'])) ? "<td><a href='upload/works/{$item['file']}' class='btn btn-warning btn-xs' target='_blank'><span class='glyphicon glyphicon-download'></span>&nbsp;<span class='hidden-xs'>Скачать</span></a></td>" : "<td></td>";

                $mark = '';
                if ($item['mark']==6) $mark = 'зач';
                if ($item['mark']==7) $mark = 'на дораб.';
                $html .= !empty($item['mark']) ? "<td>{$mark}</td>":"<td></td>";

               /* $comment = !empty($item['comment'])?'success':'primary';

                $html .= '<td><form action="<?= BASE_URL ?>tasks/comment" method="post" target="_blank">
                            <input type="hidden" name="id" value="'. $item['id'] .'">
                            <button  data-toggle="tooltip" title="'. @$item['comment'] .'" class="btn btn-xs btn-'. $comment .'" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></button></form></td>';*/
               $html .= "<td><span data-id='{$item['id']}' class='btn btn-xs btn-danger remove'><i class='glyphicon glyphicon-remove'></i></span></td>";

                $html .= '</tr>';
            }
            echo $html;
        }
        die;
    }

    public function getListDiscsAction() {
        $this->layout = false;
        if (!empty($_GET['class'])) {
            $class = ($_GET['class'] != '') ? $_GET['class'] : null;
//            $sem = ($_GET['sem'] != '') ? $_GET['sem'] : 1;
            if (!empty($class)) {
                $class_str = "class = '{$class}'";
                if ($this->cur_user->access == 1) {
                    if (!empty($_GET['sem'])) $list = \R::getAssoc("SELECT disc FROM plan WHERE ($class_str) AND s" . $_GET['sem'] . " != '0|0|0|0|0|0|0|0|0' ORDER BY disc"); else $list = \R::getAssoc("SELECT disc FROM plan WHERE $class_str ORDER BY disc");
                } else {
                    if (!empty($_GET['sem'])) $list = \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND s" . $_GET['sem'] . " != '0|0|0|0|0|0|0|0|0' ORDER BY disc", [$this->cur_user->id]); else $list = \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND kafedra<>'' ORDER BY disc", [$this->cur_user->id]);
                }
            }
        }
        $list_str = '';
        foreach ($list as $item) $list_str .= "<option>". $item. "</option>";
        echo $list_str;
        die;
    }

    public function delTaskworkAction() {
        $this->layout = false;
        if (!empty($_GET['id'])) {
            $t = \R::load('taskwork',$_GET['id']);
            $t->archive = 1;
            \R::store($t);
        }
        die;
    }

}
