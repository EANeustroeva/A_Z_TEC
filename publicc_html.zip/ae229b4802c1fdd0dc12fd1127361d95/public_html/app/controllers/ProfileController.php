<?php


namespace app\controllers;

use vendor\core\Router;

class ProfileController extends AppController {

    public function __construct($route) {
        parent::__construct($route);
    }

    public function indexAction() {
        if ($this->cur_user->id == 16685) {
//            Router::add('^$', ['controller' => 'Activity', 'action' => 'index']);
//            ddd();
//            ini_set('error_reporting', E_ALL);
//            ini_set('display_errors', 1);
//            ini_set('display_startup_errors', 1);
            Router::dispatch('activity');
            die;
        }

        if ($this->cur_user->id == 17158) {
            Router::dispatch('planview');
            die;
        }




        \R::addDatabase('DB1','mysql:host=web02.usue.ru;dbname=fsp_usp;charset=utf8','inoonline','CnhfyyjcnmUtkz25',true);
        $data['noty'] = json_decode($this->cur_user->noty,1);
        $data['admin_noty'] = json_decode(\R::findOne("users",'id=?',[1])->noty,1);
        $data['list'] = $this->events;
        $data = $this->data;
        if ($this->cur_user->access == 1 && empty($_GET['id'])) {
            $this->view = 'manager';
            $this->setMeta('Управление');
        }
        else {
            $this->view = 'profile';
            $this->setMeta('Профиль');
        }

        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;

        $id = $_SESSION['logged_user']['id'];

        if (isset($_GET['id'])) {
            $data['user'] = $this->usr->get_user([$_GET['id']])[$_GET['id']];
            if ($data['user']->access == 4 && $this->cur_user->access == 4) redirect('/');
            $live_friend = \R::getRow("SELECT * FROM friends WHERE friend_id = ? AND user_id = ?", [$_GET['id'], $id]);
            $data['live_friend'] = ($live_friend) ? true : false;
            if (!isset($data['user'])) {
                header("Location: " . BASE_URL );
            }

            if ($data['user']['access'] == 4) {
                preg_match("#\d\d#si",$data['user']->class,$cur_year);
                $d = (integer) date('y') - $cur_year[0];
                $data['user']->sem = (date("n") < 7) ? $d*2 : $d*2 + 1;
                $data['user']->course = (date("n") < 7) ? $d : $d + 1;

                $q = \R::findOne('classsem',"class=? and enabled=1",[$data['user']->class]);
                if ($q) {
                    $sem = 9;
                    $ks = explode('|',$q->ks);
                    for ($s=9;$s>0;$s--) {
                        $kss = !empty($ks[$s-1])?$ks[$s-1]:false;
                        if (!$kss) {
                            $sem = $s-1;
                            continue;
                        }
                        $cur_date = strtotime(date('d.m.Y'));
                        $cmp_date = strtotime($kss);
                        if($cur_date > $cmp_date )  {
                            break;
                        }
                        $sem = $s;
                    }
    //                foreach ($ks as $k=>$item) {
    //                    if (empty($item)) break;
    //                    if(strtotime(date('d.m.Y')) > strtotime($item)) $sem++;
    //                }
                    if ($sem>9) $sem = 9;
                    $data['user']->sem = $sem;
                    $data['user']->course = ceil($sem / 2);

                }
            }
        } else {
            $data['user'] = $data['cur_user'];
        }

        $data['uid'] = $data['user']['id'];
        $data['user']['avatar'] = $data['user']['photo'] != '' ? BASE_URL .'order/'.$data['user']['photo']: BASE_URL . 'assets/images/thumbs/no-image.jpg';
        $cur_user = $data['user'];

        if ($data['user']->access == 3 || $data['user']->access == 2) {
            if ($data['user']->access == 3)
                $uc = \R::getAssoc("SELECT DISTINCT class FROM plan WHERE user_id = ? or lektor = ?",[$data['user']->id,$data['user']->name]);
            else $uc = \R::getAssoc("SELECT DISTINCT class FROM userclass WHERE user_id = ?",[$data['user']->id]);
            $resultArray = [];
            array_walk($uc, function($item, $key) use (&$resultArray) {
                preg_match("#.*?(\d\d)#si",$item, $match);
                if (isset($match[1]))
                    $resultArray['20'.$match[1] . 'г'][] = $item;
            });
            ksort($resultArray);

            $resultArray['Распределение'] = $this->vkr_list;

            $data['list'] = $resultArray;
        }

        if ($cur_user->access == 4) {
            \R::selectDatabase('DB1');
            $usp_all = \R::getAll("select Gruppa as gruppa, Fam as fam, UNS as uns, Semestr as semestr, Disciplina as disciplina,
            Othetnost as othetnost, Ocenka as ocenka, Reiting as reiting, Data as data, Deistvie as deistvie, Famprepod as famprepod
            from uspevaemost where uns = ?", [$cur_user->uchet]);
            \R::selectDatabase('default');
            $marks_all = \R::getAll("select * from taskwork where type NOT IN ('Тестирование','Итоговая') and stud_id = ? and mark is not null and archive=0 order by created", [$cur_user->id]);

            $data['classsem'] = $q = \R::findOne('classsem',"class=? and enabled=1",[$cur_user->class]);
            $data['port'] = [];
            $curs = [];

            $vkr = \R::getAll("select * from vkruservkrs where user_id=? and sem is not null and lektor_id is not null order by sem", [$cur_user->id]);
            foreach ($vkr as $k => $cur) {
                $lektor = \R::findOne('users',"id=?", [$cur['lektor_id']]);
                $vkr[$k]['lektor'] = $lektor ? $lektor->name : '';
            }
            $data['vkr'] = $vkr;
            foreach ($data['vkr'] as $k => $item) {
                $mark = \R::getAll("select mark,type from taskwork 
                    where disc=? and stud_id = ? and type='вкр' and sem=? and mark is not null and archive=0 order by marked desc",
                    [$item['disc'], $cur_user->id, $item['sem']]);
                $marks = [];
                foreach ($mark as &$i) {
                    if (count($marks) && $i['mark'] > 5) break;
                    if ($i['mark'] != 7 && $i['mark'] != 0) $i['mark'] = 'допущен';
                    if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
                    $i['type'] = 'вкр';
                    $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."<b>{$i['mark']}</b>".'</span> ';
                }
                $data['vkr'][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
            }

            $pract = \R::getAll("select * from vkruserpract where user_id=? and sem is not null and lektor_id is not null order by sem", [$cur_user->id]);
            foreach ($pract as $k => $cur) {
                $lektor = \R::findOne('users',"id=?", [$cur['lektor_id']]);
                $pract[$k]['lektor'] = $lektor ? $lektor->name : '';
            }
            $data['pract'] = $pract;
            foreach ($data['pract'] as $k => $item) {
                $mark = \R::getAll("select mark,type from taskwork 
                    where disc=? and stud_id = ? and type='практ' and sem=? and mark is not null and archive=0 order by marked desc",
                    [$item['disc'], $cur_user->id, $item['sem']]);
                $marks = [];
                foreach ($mark as &$i) {
                    if (count($marks) && $i['mark'] > 5) break;
                    if ($i['mark'] == 6) $i['mark'] = 'зач';
                    if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
                    $i['type'] = 'практ';
                    $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['type']}:<b>{$i['mark']}</b>".'</span> ';
                }
                $data['pract'][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
            }

            $dists = \R::getAll("select * from vkruserdist where user_id=? and sem is not null and lektor_id is not null order by sem", [$cur_user->id]);
            foreach ($dists as $k => $cur) {
                $lektor = \R::findOne('users',"id=?", [$cur['lektor_id']]);
                $dists[$k]['lektor'] = $lektor ? $lektor->name : '';
            }
            $data['dists'] = $dists;
            foreach ($data['dists'] as $k => $item) {
                $mark = \R::getAll("select mark,type from taskwork 
                    where disc=? and stud_id = ? and type='практ' and sem=? and mark is not null and archive=0 order by marked desc",
                    [$item['disc'], $cur_user->id, $item['sem']]);
                $marks = [];
                foreach ($mark as &$i) {
                    if (count($marks) && $i['mark'] > 5) break;
                    if ($i['mark'] == 6) $i['mark'] = 'зач';
                    if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
                    $i['type'] = 'практ';
                    $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['type']}:<b>{$i['mark']}</b>".'</span> ';
                }
                $data['dists'][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
            }

/*and disc not in ('Выпускная квалификационная работа','Производственная, преддипломная практика',
                  'Преддипломная практика','Производственная , научно-исследовательская работа',
                  'Практика по получению профессиональных умений и опыта профессиональной деятельности','Технологическая практика')*/
            $kontr = \R::getAll("select * from vkruserkontr where user_id=? and sem is not null and lektor_id is not null order by sem", [$cur_user->id]);
//            if (isset($_GET['qwe'])) dd($data['port']);
            for ($i=1;$i<=$cur_user->sem;$i++) {
                if ($i>9) break;
                $data['port'][$i] = [];
                $data['port'][$i] = \R::getAssoc("SELECT * FROM plan WHERE class=? AND plan.gotovo>={$i} AND s$i != '0|0|0|0|0|0|0|0|0' ORDER BY disc",[$cur_user->class]); //AND plan.gotovo>={$i}

                /*\R::selectDatabase('DB1');
                $plan_sel = current($data['port'][$i]);
                $prep_new_all = $plan_sel ? \R::getAll("select * from Plani_Prepodavateli where plan=?", [$plan_sel['plan']]) : [];
                \R::selectDatabase('default');*/
//                if (isset($_GET['qwe']) && $i==5) dd( $data['port'][$i] );
                foreach ($data['port'][$i] as $k => $item) {
//                    if (isset($_GET['qwe']) && $i==5) dump($item);
                    $_vkr = $_pract = $_dist = [];
                    if (!empty($vkr)) foreach ($vkr as $ite) if ($ite['sem']==$i) $_vkr[] = $ite['disc'];
                    if (!empty($pract)) foreach ($pract as $ite) if ($ite['sem']==$i) $_pract[] = $ite['disc'];
                    if (!empty($dists)) foreach ($dists as $ite) if ($ite['sem']==$i) $_dist[] = $ite['disc'];
                    $not = array_merge($_vkr, $_pract);
                    if (in_array($item['disc'], $not)) { unset($data['port'][$i][$k]); continue; }

                    $_kontr = array_filter($kontr, function ($v) use ($item, $i) { return $v['disc']==$item['disc'] && $v['sem']==$i; });

//                    if ($_GET['qwe']) ddd($kontr);
                    $vkr_user = count($_kontr) ? current($_kontr) : false;

//                    $vkr_user = \R::findOne('vkruserkontr',"lektor_id is not null and user_id=? and disc=? and sem=?",[$cur_user->id, $item['disc'], $i]);
                    if ($vkr_user) {
                        $prep = \R::findOne('users','id=?', [$vkr_user['lektor_id']]);
//                        if (isset($_GET['qwe']) && $i==3 && $item['disc']=='Правовая помощь юридическим и физическим лицам') dd($prep);
                        $data['port'][$i][$k]['user_id'] = $vkr_user['lektor_id'];
                        $info = (isset($_GET['raspr']) || isset($_GET['raspr']) && $this->cur_user->id != $data['uid']) ? "<br><small style='color: red'>({$item['lektor']})</small>" : '';
                        $data['port'][$i][$k]['lektor'] = $prep->name . $info;
                    }

                    $mark = array_values(array_filter($marks_all, function ($v) use ($i, $item) {
                        return $v['sem'] == $i && $v['disc'] == $item['disc'];
                    }));

                    $marks = [];
                    foreach ($mark as &$ii) {
                        if ($ii['mark'] == 6) $ii['mark'] = 'зач';
                        if ($ii['mark'] == 7) $ii['mark'] = 'на дораб.';
                        $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['type']}:<b>{$ii['mark']}</b>".'</span>';
                    }
                    $t_marks = [];
                    $usp = array_filter($usp_all, function ($v) use ($i, $item) { return $v['semestr'] == $i && $v['disciplina'] == $item['disc']; });
                    foreach ($usp as $ii) {
                        switch ($ii['othetnost']) {
                            case 'Экзамен': $ii['othetnost']='экз'; break;
                            case 'Зачет': $ii['othetnost']='зач'; break;
                            case 'Дифференцированный зачет': case 'Зачет дифференцированный': $ii['othetnost']='диф.з'; break;
                            case 'Аттестация': $ii['othetnost']='атт'; break;

                            case 'Контрольная работа': $ii['othetnost']='к/р'; break;
                            case 'Домашняя контрольная работа': $ii['othetnost']='д.к/р'; break;
                            case 'Аудиторная контрольная работа': case 'Контрольная работа аудиторная': $ii['othetnost']='ауд.к/р'; break;
                            case 'Курсовая работа': $ii['othetnost']='курс/р'; break;
                            case 'Курсовой проект': $ii['othetnost']='курс/пр'; break;
                        }

                        if (!empty( $ii['ocenka'])) {
                            if ($ii['othetnost']!=='экз'   &&
                                $ii['othetnost']!=='зач'   &&
                                $ii['othetnost']!=='диф.з' &&
                                $ii['othetnost']!=='атт') {
                                $marks[] =   '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['othetnost']}:<b>{$ii['ocenka']}</b>".'</span>';
                            } else {
                                if ($ii['ocenka']<3) {
                                    $marks[] =   '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['othetnost']}:<b>{$ii['ocenka']}</b>".'</span>';
                                } else {
                                    $t_marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['othetnost']}:<b>{$ii['ocenka']}</b>".'</span>';
                                }
                            }
                        }
                    }
                    $data['port'][$i][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
                    $marks_ = count(array_filter($mark, function ($v) { return isset($v['mark']) && is_numeric($v['mark']) && ($v['mark']>0 || $v['mark']<=6); }));
                    $data['port'][$i][$k]['total_marks'] = !empty($t_marks) ? implode(' ', $t_marks) : '';
                    $parse = explode('|',$item["s$i"]);
                    $data['port'][$i][$k]['parse'] = $parse;
                    $data['port'][$i][$k]['sem'] = $i;
                    $data['port'][$i][$k]['dolg'] = ($i < $cur_user->sem) && (($data['port'][$i][$k]['total_marks'] == '' || $data['port'][$i][$k]['marks'] == '' || !$marks_) && $parse[2] == 0 && $parse[3] != 0);
                    if ($cur_user->id == 4759) $data['port'][$i][$k]['dolg'] = true;
                    if ($parse[4]==0 && ($parse[5]!=0 || $parse[7]!=0)
                        && $parse[0]==0 && $parse[1]==0 && $parse[2]==0
                        && $parse[3]==0 && $parse[6]==0 && $parse[8]==0 || ($parse[2] == 0 && $parse[3]) == 0
                        && empty($t_marks)) $data['port'][$i][$k]['total_marks'] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Без оценки</span>';
                    if ($i==1 && ($parse[4]==1 || ((int)$parse[5] == 0 && (int)$parse[7] == 0))) {
                        $cp = \R::findOne('classprof', "class=?", [$cur_user->class]);
                        if ($cp) {
                            $cd = \R::findOne('compdisc', "course=0 and prof=?", [$cp->prof]);
                            if ($cd && !empty($cd->tests)) {
                                foreach (explode('|', $cd->disc) as $kk=>$disc) {
                                    if ($disc != $item['disc']) continue;
                                    $tests = explode(',',explode('|', $cd->tests)[$kk]);
                                    $res = \R::findOne('testres',"user_id={$this->cur_user->id} and test_id in ("
                                        . \R::genSlots($tests) . ") and total > 49 order by total desc", $tests);
                                    if ($res) {
                                        $m = $res->total >= 90 ? 'отлично' : ($res->total >= 70 ? 'хорошо' : 'удовлетворительно');
                                        $data['port'][$i][$k]['marks'] = "<b>{$m}</b>";//'<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Тест:<b>'.$m.'</b></span>';
                                    }
                                }
                            }
                        }
                        if ($cur_user->class != 'ИНО ДО-18-1') {
                            if (isset($cd)) {
                                $key = array_search ($item['disc'], explode('|',$cd->disc));
                                if($key && !empty(explode('|',$cd->tests)[$key])) $data['port'][$i][$k]['total_marks'] = 'Тестирование';
                            }
                        }//'<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Тестирование</span>';
                    }
//                    $data['port'][$i][$k]['kurs'] = ($parse[2] != 0);
                    $data['port'][$i][$k]['has_video'] = \R::findOne('mfilesnext',"class=? and sem=? and disc=? order by id desc", [$cur_user->class, $i, $item['disc']]);
                    if ($parse[2] != 0) {
                        $curs[] = $data['port'][$i][$k];
                    }
                }

            }

            $data['plans'] = [];
            foreach ($data['port'] as $k=>$item) {
            if (!count($item)) { unset($data['port'][$k]); continue; }
                if ($cur_user->sem != $k) {
                    foreach ($item as $i=>$d) {
                        if (($d['total_marks']=='' || $d['marks']=='') && $d['parse'][2] == 0 && $d['parse'][3] != 0) {
                            $d['semestr'] = $k;
                            $data['plans'][] = $d;
                        }
                    }
                }
            }

            $curses = \R::getAll("select * from vkrusercurs where user_id=? and sem is not null and lektor_id is not null order by sem", [$cur_user->id]);
            foreach ($curs as $k => $cur) {
                $curse = array_filter($curses, function ($v) use ($cur) {
                   return $v['disc'] == $cur['disc'] && $v['sem'] == $cur['sem'];
                });
                $curs[$k]['lektor'] = 'Ожидается распределения';

                if (count($curse)) {
                    $curse = current($curse);
                    $lektor = \R::findOne('users',"id=?", [$curse['lektor_id']]);
                    $curs[$k]['lektor'] = $lektor ? $lektor->name : 'Ожидается распределения';
                }
            }
            $data['curs'] = $curs;
            foreach ($data['curs'] as $k => $item) {
                $mark = \R::getAll("select mark,type from taskwork 
                    where disc=? and stud_id = ? and type='кп' and sem=? and mark is not null and archive=0 order by marked desc",
                    [$item['disc'], $cur_user->id, $item['sem']]);
                $marks = [];
                foreach ($mark as &$i) {
                    if (count($marks) || $i['mark'] > 5) continue;
                    if ($i['mark'] == 6) $i['mark'] = 'зач';
                    if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
                    $i['type'] = 'курсовая';
                    $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['type']}:<b>{$i['mark']}</b>".'</span> ';
                }
                $data['curs'][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
            }

            $data['dolg_pay'] = $this->checkPay();
        }

        if ($this->cur_user->access == 1) {
            if ($this->isAjax()) {
                $toadd = '';
                if (!empty($_POST['tab']))
                    switch ($_POST['tab']) {
                        case 'gr_pred':
                            $up = \R::getAssoc("SELECT id,disc,lektor FROM plan WHERE class=?", [$_POST['user_id']]);
                            $c = \R::getAssoc("SELECT disciplina FROM userdisc WHERE disciplina!='' ORDER BY disciplina");
                            if(!empty($up)) {
                                $list_pred = '';
                                foreach ($up as $k=>$item) {
                                    unset($c[$item['disc']]);
                                    $list_pred .= '<a class="btn-xs list-group-item" data-toggle="tooltip" title="'.$item['lektor'].'">' . '<span class="del" value="' . $k . '" style="cursor:pointer;float:right;"> &times;</span>' . '<span>' . $item['disc'] . '</span></a>';
                                }
                            };
                            break;
                        case 'prep_pred':
                            $up = \R::getAssoc("SELECT disc,id FROM plan WHERE user_id=?", [$_POST['user_id']]);
                            $c = \R::getAssoc("SELECT disciplina FROM userdisc WHERE disciplina!='' ORDER BY disciplina");
                            if(!empty($up)) {
                                $list_pred = '';
                                foreach ($up as $k=>$item) {
                                    unset($c[$k]);
                                    $list_pred .= '<a class="list-group-item">' . /*'<span class="del" value="' . $item . '" style="cursor:pointer;float:right;"> &times;</span>' .*/ '<span>' . $k . '</span></a>';
                                }
                            };
                            break;
                        case 'prep_gr':
                            if (!empty($_POST['access'])) {
                                $users = \R::getAll("SELECT * FROM users WHERE access=? ORDER BY name",[$_POST['access']]);
                                $list_prep = '';
                                foreach ($users as $item) {
                                    $list_prep .= ' <option value="' . $item['id'].'">'. $item['name'] .'</option>';
                                }
                                echo $list_prep;
                                die;
                            }
                            $up = \R::getAssoc("SELECT id,class FROM userclass WHERE user_id=?",[$_POST['user_id']]);
                            $exclude = \R::getAssoc("SELECT class FROM userclass WHERE class!='' ORDER BY class");
                            $exclude = array_values($exclude);
                            $c = \R::getAssoc("SELECT class FROM users WHERE class!='' AND class not in (".\R::genSlots($exclude).") ORDER BY class", $exclude);
                            $ct1 = \R::count('userclass',"user_id=?",[$_POST['user_id']]);
                            $groups = [];
                            foreach ($up as $c_item) $groups[] = '' . $c_item . '';
                            $ct2 = \R::count('users',"class in (" . \R::genSlots($groups) . ")",$groups);
                            if(!empty($up)) {
                                $list_pred = '';
                                foreach ($up as $k=>$item) {
                                    unset($c[$item]);
                                    $list_pred .= '<a class="btn-xs list-group-item col-xs-6 col-md-4"><span class="del" value="' . $k . '" style="cursor:pointer;float:right;"> &times;</span><span>' . $item . '</span></a>';
                                }
                            };
                            foreach ($c as $item) $toadd .= '<option>' . $item . '</option>';
                            header('Content-Type: application/json');
                            echo json_encode(['list' => $list_pred, 'toadd'=>$toadd, 'info1' => $ct1, 'info2' => $ct2]);
                            die;
                            break;
                        case 'addremove':
                            $sql = '';
                            $year = 18 - $_POST['course'];

                            if ($_POST['access'] == 4) {
                                /*if (!empty($_POST['course'])) */$sql = " AND class like '" . "%-{$year}%'";
                                if (!empty($_POST['class'])) $sql .= " AND class='" . $_POST['class'] . "'";
                            } elseif ($_POST['access'] == 3) {
//                                if (isset($_POST['course'])) {
//                                    if (!empty($_POST['class'])) {
//                                        $sql .= "  AND id IN (SELECT user_id FROM plan WHERE class='" . $_POST['class'] . "')";
//                                    }
//                                    else {
//                                        $num = 17-$_POST['course']+1;
////                                        $num = date('y')-$_POST['course']+1;
//                                        $cllst = \R::getAssoc("SELECT class FROM plan WHERE class LIKE ?",["%-{$year}%"]);
//                                        foreach ($cllst as &$item) $item = '"'.$item.'"';
//                                        $cllst = implode(", ",$cllst);
//                                        $sql = " AND id IN (SELECT user_id FROM plan WHERE class IN ($cllst))";
//                                    }
//                                }
                            }
                            $users = \R::getAll("SELECT * FROM users WHERE access=?".$sql . " ORDER BY kodstatusa,name",[$_POST['access']]);
                            $list_stud = '';
                            foreach ($users as $k=>$item) {
                                $status = $item['kodstatusa'];
                                if ($status == 1) {
                                    unset($users[$k]); continue;
                                }
                                if ($status && $status != 240) {
                                    switch ($status) {
                                        case 241: $status = 'ДОЛГИ'; break;
                                        case 242: $status = 'АКАДЕМ'; break;
                                        case 243: $status = 'ОТЧИСЛЕН'; break;
                                        case 244: $status = 'ПЕРЕВЕДЕН'; break;
                                        case 246: $status = 'ОТЧИСЛЕН'; break;
                                        case 255: $status = 'ВЫПУСКНИК'; break;
                                    }
                                    $status = "data-content=\"<span class='text-muted'>{$item['name']}</span> <span class='label label-warning pull-right'>{$status}</span>\"";
                                } else $status = '';
                                $list_stud .= "<option {$status} value=\"{$item['id']}\">{$item['name']}</option>";
                            }
                            echo $list_stud;
                            die;
                            break;
                    }
                foreach ($c as $item)
                    $toadd .= '<option>' . $item . '</option>';
                header('Content-Type: application/json');
                echo json_encode(['list' => $list_pred, 'toadd'=>$toadd]);
               die;
            }
            $data['class'] = \R::getAssoc("SELECT class FROM users WHERE class!='' ORDER BY class");
            $data['prepod'] = [];// \R::getAll("SELECT * FROM users WHERE access=3 ORDER BY name");
            $data['metodist'] = \R::getAll("SELECT * FROM users WHERE access=2 ORDER BY name");
            $data['predmet'] = \R::getAssoc("SELECT DISTINCT name,id FROM predmets ORDER BY name");
        }

        if ($this->cur_user->access == 5) {
            $certs = \R::getCol('select event from eventusers where cert=1 and user_id=?',[$this->cur_user->id]);
            if (!empty($certs)) {
                $data['events'] = \R::getAll('select * from eventslist where id in ('.\R::genSlots($certs).')',$certs);
            }
//            dd($data['certs']);
        }

//        if (isset($_GET['qwe'])) $this->layout = 'default_old';
        $this->set($data);
    }

    public function studAction() {
        \R::addDatabase('DB1','mysql:host=web02.usue.ru;dbname=fsp_usp;charset=utf8','inoonline','CnhfyyjcnmUtkz25',true);
        $data = $this->data;
$data['menu'] = $this->menu;
$data['meta'] = $this->meta;
        \R::fancyDebug(true);
        \R::selectDatabase('DB1');
        $usp_all = \R::getAll("select Gruppa as gruppa, Fam as fam, UNS as uns, Semestr as semestr, Disciplina as disciplina,
        Othetnost as othetnost, Ocenka as ocenka, Reiting as reiting, Data as data, Deistvie as deistvie, Famprepod as famprepod
        from uspevaemost where uns = ?", [$this->cur_user->uchet]);
        \R::selectDatabase('default');
        $marks_all = \R::getAll("select * from taskwork where type NOT IN ('Тестирование','Итоговая') and stud_id = ? and mark is not null and archive=0 order by created", [$this->cur_user->id]);
        $data['port'] = [];
        for ($i=1;$i<=9;$i++) {
            $data['port'][$i] = [];
            $data['port'][$i] = \R::getAssoc("SELECT * FROM plan WHERE class=? AND s$i != '0|0|0|0|0|0|0|0|0' AND plan.gotovo>={$i} ORDER BY disc",[$this->cur_user->class]);
//            if ($i == 5) ddd($data['port'][$i]);
            foreach ($data['port'][$i] as $k => $item) {
                $vkr_user = \R::findOne('vkruserkontr',"lektor_id is not null and user_id=? and disc=? and sem=?",[$this->cur_user->id, $item['disc'], $i]);
                if ($vkr_user) {
                    $prep = \R::findOne('users','id=?', [$vkr_user->lektor_id]);
                    $data['port'][$i][$k]['user_id'] = $vkr_user->lektor_id;
                    $data['port'][$i][$k]['lektor'] = $prep->name . '*';
                }
                $mark = array_values(array_filter($marks_all, function ($v) use ($i, $item) {
                    return $v['sem'] == $i && $v['disc'] == $item['disc'];
                }));

                $marks = [];
                foreach ($mark as &$ii) {
                    if ($ii['mark'] == 6) $ii['mark'] = 'зач';
                    if ($ii['mark'] == 7) $ii['mark'] = 'на дораб.';
                    $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['type']}:<b>{$ii['mark']}</b>".'</span>';
                }
                $t_marks = [];
                $usp = array_filter($usp_all, function ($v) use ($i, $item) { return $v['semestr'] == $i && $v['disciplina'] == $item['disc']; });
                foreach ($usp as $ii) {
                    switch ($ii['othetnost']) {
                        case 'Экзамен': $ii['othetnost']='экз'; break;
                        case 'Зачет': $ii['othetnost']='зач'; break;
                        case 'Дифференцированный зачет': case 'Зачет дифференцированный': $ii['othetnost']='диф.з'; break;
                        case 'Аттестация': $ii['othetnost']='атт'; break;

                        case 'Контрольная работа': $ii['othetnost']='к/р'; break;
                        case 'Домашняя контрольная работа': $ii['othetnost']='д.к/р'; break;
                        case 'Аудиторная контрольная работа': $ii['othetnost']='ауд.к/р'; break;
                        case 'Курсовая работа': $ii['othetnost']='курс/р'; break;
                        case 'Курсовой проект': $ii['othetnost']='курс/пр'; break;
                    }

                    if (!empty( $ii['ocenka'])) {
                        if ($ii['othetnost']!=='экз'   &&
                            $ii['othetnost']!=='зач'   &&
                            $ii['othetnost']!=='диф.з' &&
                            $ii['othetnost']!=='атт') {
                            $marks[] =   '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['othetnost']}:<b>{$ii['ocenka']}</b>".'</span>';
                        } else {
                            $t_marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$ii['othetnost']}:<b>{$ii['ocenka']}</b>".'</span>';
                        }
                    }
                }
                $data['port'][$i][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
                $data['port'][$i][$k]['total_marks'] = !empty($t_marks) ? implode(' ', $t_marks) : '';
                $parse = explode('|',$item["s$i"]);
                if ($parse[4]==0 && ($parse[5]!=0 || $parse[7]!=0)
                    && $parse[0]==0 && $parse[1]==0 && $parse[2]==0
                    && $parse[3]==0 && $parse[6]==0 && $parse[8]==0
                    && empty($t_marks)) $data['port'][$i][$k]['total_marks'] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Без оценки</span>';
                if ($i==1 && ($parse[4]==1 || ((int)$parse[5] == 0 && (int)$parse[7] == 0))) {
                    $cp = \R::findOne('classprof', "class=?", [$this->cur_user->class]);
                    if ($cp) {
                        $cd = \R::findOne('compdisc', "course=0 and prof=?", [$cp->prof]);
                        if ($cd && !empty($cd->tests)) {
                            foreach (explode('|', $cd->disc) as $kk=>$disc) {
                                if ($disc != $item['disc']) continue;
                                $tests = explode(',',explode('|', $cd->tests)[$kk]);
                                $res = \R::findOne('testres',"user_id={$this->cur_user->id} and test_id in ("
                                    . \R::genSlots($tests) . ") and total > 49 order by total desc", $tests);
                                if ($res) {
                                    $m = $res->total >= 90 ? 'отлично' : ($res->total >= 70 ? 'хорошо' : 'удовлетворительно');
                                    $data['port'][$i][$k]['marks'] = "<b>{$m}</b>";//'<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Тест:<b>'.$m.'</b></span>';
                                }
                            }
                        }
                    }
                    if ($this->cur_user->class != 'ИНО ДО-18-1') $data['port'][$i][$k]['total_marks'] = 'Тестирование';//'<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Тестирование</span>';
                }
                $data['port'][$i][$k]['kurs'] = ($parse[2] != 0);
            }

        }
//         ddd($data['port']);

        $data['plans'] = [];
        foreach ($data['port'] as $k=>$item) {
            if (!count($item)) { unset($data['port'][$k]); continue; }
            if ($this->cur_user->sem != $k) {
                foreach ($item as $i=>$d) {
                    if ($d['total_marks']=='') {
                        $d['semestr'] = $k;
                        $data['plans'][] = $d;
                    }
                }
            }
        }

        //            $sem = $this->cur_user->sem - 1; // AND ((s{$sem} LIKE '%2017') OR (s{$sem} LIKE '%2017'))
//            $data['plan'] = $sem==0 ? [] : \R::getAssoc("SELECT * FROM plan WHERE class=? AND s{$sem} != '0|0|0|0|0|0|0|0|0' ORDER BY disc", [$this->cur_user->class]);
//            $vkr = \R::getAssoc("select disc from vkrclass where class=? and sem=?",[$this->cur_user->class, $sem]);
            $cp = \R::findOne('classprof', "class=?", [$this->cur_user->class]);
            $cd = ($cp) ? \R::findOne('compdisc', "course=0 and prof=?", [$cp->prof]) : false;

            $data['plan'] = [];
            if ($this->cur_user->sem > 1):
            for ($sem=1;$sem<$this->cur_user->sem;$sem++):
                $data['plan'][$sem] = \R::getAssoc("SELECT * FROM plan WHERE class=? AND s{$sem} != '0|0|0|0|0|0|0|0|0' AND plan.gotovo>={$sem} ORDER BY disc",[$this->cur_user->class]);
                foreach ($data['plan'][$sem] as $k => $item) {
                    $vkr_user = \R::findOne('vkruserkontr',"lektor_id is not null and user_id=? and disc=? and sem=?",[$this->cur_user->id, $item['disc'], $sem]);
                    if ($vkr_user) {
                        $prep = \R::findOne('users','id=?', [$vkr_user->lektor_id]);
                        $data['plan'][$sem][$k]['user_id'] = $vkr_user->lektor_id;
                        $data['plan'][$sem][$k]['lektor'] = $prep->name .'*';
                    }

                    $mark = array_values(\R::getAll("select mark,type from taskwork where disc=? and stud_id = ? and type='кр' and mark is not null and archive=0 ", [$item['disc'], $this->cur_user->id]));
                    $marks = [];
                    foreach ($mark as &$i) {
                        if ($i['mark'] == 6) $i['mark'] = 'зач';
                        if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
                        if ($i['type'] == 'кп') $i['type'] = 'курсовая';
                        $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['type']}:<b>{$i['mark']}</b>".'</span>';
                    }
                    $t_marks = [];
                    \R::selectDatabase('DB1');
                    $usp = \R::getAll("select Gruppa as gruppa, Fam as fam, UNS as uns, Semestr as semestr, Disciplina as disciplina,
    Othetnost as othetnost, Ocenka as ocenka, Reiting as reiting, Data as data, Deistvie as deistvie, Famprepod as famprepod
          from uspevaemost where uns = ? and disciplina = ? and semestr=?", [$this->cur_user->uchet, $item['disc'], $sem]);
                    \R::selectDatabase('default');
                    foreach ($usp as $i) {
                        switch ($i['othetnost']) {
                            case 'Экзамен': $i['othetnost']='экз'; break;
                            case 'Зачет': $i['othetnost']='зач'; break;
                            case 'Дифференцированный зачет': case 'Зачет дифференцированный': $i['othetnost']='диф.з'; break;
                            case 'Аттестация': $i['othetnost']='атт'; break;

                            case 'Контрольная работа': $i['othetnost']='к/р'; break;
                            case 'Домашняя контрольная работа': $i['othetnost']='д.к/р'; break;
                            case 'Аудиторная контрольная работа': $i['othetnost']='ауд.к/р'; break;
                            case 'Курсовая работа': $i['othetnost']='курс/р'; break;
                            case 'Курсовой проект': $i['othetnost']='курс/пр'; break;
                        }

                        if (!empty( $i['ocenka'])) {
                            if ($i['othetnost']!=='экз'   &&
                                $i['othetnost']!=='зач'   &&
                                $i['othetnost']!=='зач'   &&
                                $i['othetnost']!=='диф.з' &&
                                $i['othetnost']!=='атт') {
                                $marks[] =   '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['othetnost']}:<b>{$i['ocenka']}</b>".'</span>';
                            } else {
                                $t_marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['othetnost']}:<b>{$i['ocenka']}</b>".'</span>';
                            }
                        }
                    }
                    $data['plan'][$sem][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
                    $data['plan'][$sem][$k]['total_marks'] = !empty($t_marks) ? implode(' ', $t_marks) : '';
                    $parse = explode('|',$item["s$sem"]);
                    if ($parse[4]==0 && ($parse[5]!=0 || $parse[7]!=0) && $parse[0]==0 && $parse[1]==0 && $parse[2]==0 && $parse[3]==0 && $parse[6]==0 && $parse[8]==0
                        && empty($t_marks)) $data['plan'][$sem][$k]['total_marks'] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Без оценки</span>';
                    if ($sem==1 && ($parse[4]==1 || ((int)$parse[5] == 0 && (int)$parse[7] == 0))) {
                        if ($cd && !empty($cd->tests)) {
                            foreach (explode('|', $cd->disc) as $kk=>$disc) {
                                if ($disc != $item['disc']) continue;
                                $tests = explode(',',explode('|', $cd->tests)[$kk]);
                                $res = \R::findOne('testres',"user_id={$this->cur_user->id} and test_id in ("
                                    . \R::genSlots($tests) . ") and total > 49 order by total desc", $tests);
                                if ($res) {
                                    $m = $res->total >= 90 ? 'отлично' : ($res->total >= 70 ? 'хорошо' : 'удовлетворительно');
                                    $data['plan'][$sem][$k]['marks'] = "<b>{$m}</b>";
                                }
                            }
                        }
                        if ($this->cur_user->class != 'ИНО ДО-18-1') $data['plan'][$sem][$k]['total_marks'] = '<a href="/tests">Тестирование</a>';
                    }
                    $data['plan'][$sem][$k]['kurs'] = ($parse[2] != 0);
                    if (!empty($data['plan'][$sem][$k]['total_marks'])) unset($data['plan'][$sem][$k]);
                }
            endfor;
            endif;
            foreach ($data['plan'] as $k => $item) {
                if (!count($item)) unset($data['plan'][$k]);
            }


        /*$sem2 = $this->cur_user->sem;
            $data['plan2'] = \R::getAssoc("SELECT * FROM plan WHERE class=? AND s{$sem2} != '0|0|0|0|0|0|0|0|0' ORDER BY disc", [$this->cur_user->class]);

//            $vkr = \R::getAssoc("select disc from vkrclass where class=? and sem=?",[$this->cur_user->class, $sem2]);
        foreach ($data['plan2'] as $k => $item) {
//                if (!empty($vkr) && in_array($item['disc'],$vkr)) {
                $vkr_user = \R::findOne('vkruserkontr',"lektor_id is not null and user_id=? and disc=? and sem=?",[$this->cur_user->id, $item['disc'], $sem2]);
                if ($vkr_user) {
                    $prep = \R::findOne('users','id=?', [$vkr_user->lektor_id]);
                    $data['plan2'][$k]['user_id'] = $vkr_user->lektor_id;
                    $data['plan2'][$k]['lektor'] = $prep->name .'*';
                }
//                }

//                $mark = array_values(\R::getAll("select mark,type from taskwork where disc=? and stud_id = ? and type='кр' and mark is not null", [$item['disc'], $this->cur_user->id]));
            $mark = array_values(\R::getAll("select mark,type from taskwork where disc=? and type='кр' and stud_id = ? and mark is not null and sem=?", [$item['disc'], $this->cur_user->id,$sem2]));
            $marks = [];
            foreach ($mark as &$i) {
                if ($i['mark'] == 6) $i['mark'] = 'зач';
                if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
//                    $marks[] = "{$i['type']}:<b>{$i['mark']}</b>";
                if ($i['type'] == 'кп') {
                    continue;
                    $i['type'] = 'курсовая';
                }
                $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['type']}:<b>{$i['mark']}</b>".'</span>';
            }
            $t_marks = [];
            \R::selectDatabase('DB1');
            $usp = \R::getAll("select Gruppa as gruppa, Fam as fam, UNS as uns, Semestr as semestr, Disciplina as disciplina,
Othetnost as othetnost, Ocenka as ocenka, Reiting as reiting, Data as data, Deistvie as deistvie, Famprepod as famprepod
  from uspevaemost where uns = ? and disciplina = ? and semestr=?", [$this->cur_user->uchet, $item['disc'], $sem2]);
            \R::selectDatabase('default');
            foreach ($usp as $i) {
                switch ($i['othetnost']) {
                    case 'Экзамен': $i['othetnost']='экз'; break;
                    case 'Зачет': $i['othetnost']='зач'; break;
                    case 'Дифференцированный зачет':case 'Зачет дифференцированный': $i['othetnost']='диф.з'; break;
                    case 'Аттестация': $i['othetnost']='атт'; break;

                    case 'Контрольная работа': $i['othetnost']='к/р'; break;
                    case 'Домашняя контрольная работа': $i['othetnost']='д.к/р'; break;
                    case 'Аудиторная контрольная работа': $i['othetnost']='ауд.к/р'; break;
                    case 'Курсовая работа': $i['othetnost']='курс/р'; break;
                    case 'Курсовой проект': $i['othetnost']='курс/пр'; break;
                }

                if (!empty( $i['ocenka'])) {
                    if ($i['othetnost']!=='экз'   &&
                        $i['othetnost']!=='зач'   &&
                        $i['othetnost']!=='диф.з' &&
                        $i['othetnost']!=='атт') {
                        $marks[] =   '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['othetnost']}:<b>{$i['ocenka']}</b>".'</span>';
                    } else {
                        $t_marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['othetnost']}:<b>{$i['ocenka']}</b>".'</span>';
                    }
                }
            }
            $data['plan2'][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
            $data['plan2'][$k]['total_marks'] = !empty($t_marks) ? implode(' ', $t_marks) : '';
            $parse = explode('|',$item["s$sem2"]);
            if ($parse[4]==0 && ($parse[5]!=0 || $parse[7]!=0)
                && $parse[0]==0 && $parse[1]==0 && $parse[2]==0
                && $parse[3]==0 && $parse[6]==0 && $parse[8]==0
                && empty($t_marks)) $data['plan2'][$k]['total_marks'] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Без оценки</span>';
//                ekz1,zah1,kur1,k1,a1,l1,lb1,pr1,sr1
            if ($sem2==1 && ($parse[4]==1 || ((int)$parse[5] == 0 && (int)$parse[7] == 0)))
            {
                if ($cd && !empty($cd->tests)) {
                    foreach (explode('|', $cd->disc) as $kk=>$disc) {
                        if ($disc != $item['disc']) continue;
                        $tests = explode(',',explode('|', $cd->tests)[$kk]);
                        $res = \R::findOne('testres',"user_id={$this->cur_user->id} and test_id in ("
                            . \R::genSlots($tests) . ") and total > 49 order by total desc", $tests);
                        if ($res) {
                            $m = $res->total >= 90 ? 'отлично' : ($res->total >= 70 ? 'хорошо' : 'удовлетворительно');
                            $data['plan2'][$k]['marks'] = "<b>{$m}</b>";
                        }
                    }
                }
                if ($this->cur_user->class != 'ИНО ДО-18-1') $data['plan2'][$k]['total_marks'] = '<a href="/tests">Тестирование</a>';
            }
            $data['plan2'][$k]['kurs'] = ($parse[2] != 0);

            $v = \R::findOne('mfilesnext',"class=? and sem=? and disc=? order by id desc", [$this->cur_user->class, $sem2, $item['disc']]);
            $data['plan2'][$k]['has_video'] = $v;
        }
//            dd($data['plan2']);*/

       /* $data['plan'] = [];
        if ($this->cur_user->sem > 1):
        for ($sem=1;$sem<$this->cur_user->sem;$sem++):
            $data['plan'][$sem] = \R::getAssoc("SELECT * FROM plan WHERE class=? AND s{$sem} != '0|0|0|0|0|0|0|0|0' AND plan.gotovo>={$sem} ORDER BY disc",[$this->cur_user->class]);
            foreach ($data['plan'][$sem] as $k => $item) {
                $vkr_user = \R::findOne('vkruserkontr',"lektor_id is not null and user_id=? and disc=? and sem=?",[$this->cur_user->id, $item['disc'], $sem]);
                if ($vkr_user) {
                    $prep = \R::findOne('users','id=?', [$vkr_user->lektor_id]);
                    $data['plan'][$sem][$k]['user_id'] = $vkr_user->lektor_id;
                    $data['plan'][$sem][$k]['lektor'] = $prep->name .'*';
                }

                $mark = array_values(\R::getAll("select mark,type from taskwork where disc=? and stud_id = ? and type='кр' and mark is not null", [$item['disc'], $this->cur_user->id]));
                $marks = [];
                foreach ($mark as &$i) {
                    if ($i['mark'] == 6) $i['mark'] = 'зач';
                    if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
                    if ($i['type'] == 'кп') $i['type'] = 'курсовая';
                    $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['type']}:<b>{$i['mark']}</b>".'</span>';
                }
                $t_marks = [];
                \R::selectDatabase('DB1');
                $usp = \R::getAll("select Gruppa as gruppa, Fam as fam, UNS as uns, Semestr as semestr, Disciplina as disciplina,
Othetnost as othetnost, Ocenka as ocenka, Reiting as reiting, Data as data, Deistvie as deistvie, Famprepod as famprepod
      from uspevaemost where uns = ? and disciplina = ? and semestr=?", [$this->cur_user->uchet, $item['disc'], $sem]);
                \R::selectDatabase('default');
                foreach ($usp as $i) {
                    switch ($i['othetnost']) {
                        case 'Экзамен': $i['othetnost']='экз'; break;
                        case 'Зачет': $i['othetnost']='зач'; break;
                        case 'Дифференцированный зачет': case 'Зачет дифференцированный': $i['othetnost']='диф.з'; break;
                        case 'Аттестация': $i['othetnost']='атт'; break;

                        case 'Контрольная работа': $i['othetnost']='к/р'; break;
                        case 'Домашняя контрольная работа': $i['othetnost']='д.к/р'; break;
                        case 'Аудиторная контрольная работа': $i['othetnost']='ауд.к/р'; break;
                        case 'Курсовая работа': $i['othetnost']='курс/р'; break;
                        case 'Курсовой проект': $i['othetnost']='курс/пр'; break;
                    }

                    if (!empty( $i['ocenka'])) {
                        if ($i['othetnost']!=='экз'   &&
                            $i['othetnost']!=='зач'   &&
                            $i['othetnost']!=='зач'   &&
                            $i['othetnost']!=='диф.з' &&
                            $i['othetnost']!=='атт') {
                            $marks[] =   '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['othetnost']}:<b>{$i['ocenka']}</b>".'</span>';
                        } else {
                            $t_marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['othetnost']}:<b>{$i['ocenka']}</b>".'</span>';
                        }
                    }
                }
                $data['plan'][$sem][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
                $data['plan'][$sem][$k]['total_marks'] = !empty($t_marks) ? implode(' ', $t_marks) : '';
                $parse = explode('|',$item["s$sem"]);
                if ($parse[4]==0 && ($parse[5]!=0 || $parse[7]!=0) && $parse[0]==0 && $parse[1]==0 && $parse[2]==0 && $parse[3]==0 && $parse[6]==0 && $parse[8]==0
                    && empty($t_marks)) $data['plan'][$sem][$k]['total_marks'] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">Без оценки</span>';
                if ($sem==1 && ($parse[4]==1 || ((int)$parse[5] == 0 && (int)$parse[7] == 0))) {
                    if ($cd && !empty($cd->tests)) {
                        foreach (explode('|', $cd->disc) as $kk=>$disc) {
                            if ($disc != $item['disc']) continue;
                            $tests = explode(',',explode('|', $cd->tests)[$kk]);
                            $res = \R::findOne('testres',"user_id={$this->cur_user->id} and test_id in ("
                                . \R::genSlots($tests) . ") and total > 49 order by total desc", $tests);
                            if ($res) {
                                $m = $res->total >= 90 ? 'отлично' : ($res->total >= 70 ? 'хорошо' : 'удовлетворительно');
                                $data['plan'][$sem][$k]['marks'] = "<b>{$m}</b>";
                            }
                        }
                    }
                    if ($this->cur_user->class != 'ИНО ДО-18-1') $data['plan'][$sem][$k]['total_marks'] = '<a href="/tests">Тестирование</a>';
                }
                $data['plan'][$sem][$k]['kurs'] = ($parse[2] != 0);
                if (!empty($data['plan'][$sem][$k]['total_marks'])) unset($data['plan'][$sem][$k]);
            }
        endfor;
        endif;
        foreach ($data['plan'] as $k => $item) {
                if (!count($item)) { unset($data['plan'][$k]); continue; }
                if ($this->cur_user->sem != $k) {

                }
            }*/


        $this->view = 'profile2';


        $this->set($data);
    }

    public function checkPay() {
//         ini_set('error_reporting', E_ALL);
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
//        return;
        /*if ($this->course == 1 || $this->course == 2 || $this->cur_user->id == 7590) {
            $this->cur_user->pay_status = true;
            $user = \R::findOne('users',"id=?", [$this->cur_user->id]);
            $user->pay_status = $this->cur_user->pay_status;
            \R::store($user);
            return 0;
        }*/
        $this->cur_user->pay_status = false;


        \R::selectDatabase('DB1');

        $total = \R::getRow("select * from oplata where UNS=? AND `Primehanie` = 'Итого по студенту'",[$this->cur_user->uchet]);
        \R::selectDatabase('default');
        $dolg = $total['Summa'] > 0 ? ((int)$total['Summa']-(int)$total['№dogovora']) : null;
        $this->cur_user->pay_status = !is_null($dolg) ? ($dolg <= 0) : null;
//        $plan = \R::findOne('plan','class=?',[$this->cur_user->class]);
//        $ks = explode('|', $plan->ks);
//        if (!isset($ks[$this->sem-1])) return;
//        \R::addDatabase('DB1','mysql:host=web02.usue.ru;dbname=fsp_usp;charset=utf8','inoonline','CnhfyyjcnmUtkz25',true);
//        \R::selectDatabase('DB1');
//        $pay = \R::getAll("select * from oplata where UNS=? AND `Primehanie` != 'Итого по студенту'", [$this->cur_user->uchet]);
//        \R::selectDatabase('default');
//        $pay = array_pop($pay);
//        $pay_date = $this->parseDateTime($pay['Data']);
//        $ks_date = $this->parseDateTime($ks[$this->sem-1]);

//        $ks_date_old = isset($ks[$this->sem-2]) ? $this->parseDateTime($ks[$this->sem-2]) : false;
//        if ($pay['Data'] != 0) {
//            if ($pay_date < $ks_date && $pay_date > $ks_date_old) $this->cur_user->pay_status = true;
//        } else {
//            if ($pay_date < $ks_date) $this->cur_user->pay_status = true;
//        }
//        if ($pay_date < $ks_date) $this->cur_user->pay_status = true;
        $user = \R::findOne('users',"id=?", [$this->cur_user->id]);
        $user->pay_status = $this->cur_user->pay_status;
        if ($this->cur_user->master_date) {
            date_default_timezone_set('Asia/Yekaterinburg');
            if (time() > strtotime($this->cur_user->master_date)) {
                $user->master_date = $this->cur_user->master_date = null;
                $user->master_pay = $this->cur_user->master_pay = null;
            }
        }
        \R::store($user);
        return $dolg;
    }

    function parseDateTime($string, $timezone=null) {
        if ($string == '0') return 0;
        $date = new \DateTime(
            $string,
            $timezone ? $timezone : new \DateTimeZone('UTC')
                // Used only when the string is ambiguous.
                // Ignored if string has a timezone offset in it.
        );
        if ($timezone) {
            // If our timezone was ignored above, force it.
            $date->setTimezone($timezone);
        }
        return $date;
    }

    public function addworkdateAction() {
        $workdate = json_decode($this->cur_user->workdate,1);
        $workdate[] = '';
        $this->cur_user->workdate = json_encode($workdate);
        \R::store($this->cur_user);
        redirect('/edit');
    }

    public function delworkdateAction() {
        $i = $_GET['i'];
        $workdate = json_decode($this->cur_user->workdate,1);
        unset($workdate[$i]);
        $this->cur_user->workdate = json_encode(array_values($workdate));
        \R::store($this->cur_user);
        redirect('/edit');
    }

    public function editAction() {
        $data = $this->data;
        $this->setMeta('Профиль');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['user'] = $this->cur_user;
        $data['my_id'] = $data['user']['id'];
        if ($this->cur_user->access == 3) {
            $data['worktime'] = json_decode($this->cur_user->worktime,1);
            $data['workdate'] = json_decode($this->cur_user->workdate,1);
            $data['workdatetime'] = json_decode($this->cur_user->workdatetime,1);
        }
//dump($data['worktime']);
        $data['basic'] = [];
        $data['school'] = ['Группа' => $this->cur_user->class, 'Курс' => $this->cur_user->course,
                           '№ Зачетки' => $this->cur_user->credit_book,
                           'Статус оплаты' => $this->cur_user->pay_status,];
        $data['personal'] = [];
        $data['edu'] = [];
        $data['carier'] = [];
        $data['add'] = [];

        $data['noty'] = json_decode($this->cur_user->noty,1);
        $data['admin_noty'] = json_decode(\R::findOne("users",'id=?',[1])->noty,1);
        $data['list'] = $this->events;
        $data['noty_list'] = \R::getAssoc("select alias,header,message from noty");
        $data['config'] = \R::findOne('configs',"_key=?",['test_all_msg'])->_value;
        $data['config_metodist_email'] = \R::findOne('configs',"_key=?",['metodist_email'])->_value;

//        if (isset($_GET['qwe'])) {
//            $msg = \R::getAssoc("select alias,header as subject, message from noty");
//            dd($msg);
//        }

        $this->set($data);
    }

    public function emailAction() {
//                ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
        $data = $this->data;
        $this->setMeta('Тест сообщения Email');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;

        $action = $_GET['alias'] ?: '';
        $noty = \R::findOne('noty',"alias=?",[$action]);

        $ids = \R::getCol("select id from users where access=? and email is not null AND email != ''",[4]);
        $random_index = rand(0, sizeof($ids)-1);
        $user = \R::findOne('users', "id=?",[$ids[$random_index]]);

        $ids2 = \R::getCol("select id from users where access=? and email is not null AND email != ''",[3]);
        $random_index2 = rand(0, sizeof($ids2)-1);
        $user2 = \R::findOne('users', "id=?",[$ids2[$random_index2]]);

        $ids3 = \R::getCol("select id from users where access=? and email is not null AND email != ''",[2]);
        $random_index3 = rand(0, sizeof($ids3)-1);
        $user3 = \R::findOne('users', "id=?",[$ids3[$random_index3]]);

        $ids4 = \R::getCol("select id from cont");
        $random_index4 = rand(0, sizeof($ids4)-1);
        $user4 = \R::findOne('cont', "id=?",[$ids4[$random_index4]]);
        $user4->name = $user4->fio;

        $ids_ = \R::getCol("select id from taskwork where prep_id is not null AND mark is not null AND disc is not null");
        $random_index_ = rand(0, sizeof($ids_)-1);
        $task = \R::findOne('taskwork', "id=?",[$ids_[$random_index_]]);

        $mark = $task->mark;
        if ($mark == 6) $mark = 'зач.';
        if ($mark == 7) $mark = 'н/зач';
        $vars = [
            '%predmet%' => $task->disc,
            '%fio_stud%' => $user->name,
            '%gruppa%' => $user->class,
            '%ocenka%' => $mark
        ];

        $to = $user->email;
        $prep = false;
        if ($action == 'worknew' || $action == 'workmark') {
            $prep = $user2;
            $to = $prep->email;
        }

        if ($action == 'metodist') {
            $prep = $user3;
            $to = $prep->email;
            $vars = [
                '%fio_stud%' => $user4->fio,
                '%gruppa%' => $user4->class,
                '%akadem_from%' => $user4->fromd,
                '%akadem_to%' => $user4->tod
            ];
        }

        $message = $noty['message'];
        $subject = $noty['header'];
        $to      = $to ?: $user['email'];
        date_default_timezone_set('Asia/Yekaterinburg');
        $d_vars = [
            '%email%' => $to,
            '%date%' => date("d.m.Y"),
            '%time%' => date("H:i:s"),
            '%fio%' => $prep ? $prep->name : $user->name,
        ];

        foreach ($vars as $k=>$var) {
            $message = str_replace($k, $var, $message);
            $subject = str_replace($k, $var, $subject);
        }

        foreach ($d_vars as $k=>$var) {
            $message = str_replace($k, $var, $message);
            $subject = str_replace($k, $var, $subject);
        }

        $data['message'] = $message;
        $data['subject'] = $subject;

        $this->set($data);
    }

    public function saveAction() {
//        ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
        $this->layout = false;
        $this->view = false;
        $save = $_POST;
//        dd($save);
        switch ($_POST['name']) {
            case 'school':
                $this->cur_user->class = $save[0];
                $this->cur_user->course = $save[1];
                $this->cur_user->credit_book = $save[2];
                $this->cur_user->pay_status = $save[3];
                break;
            case 'basic':
                if ($this->cur_user->access == 3 || $this->cur_user->access == 2) {
                    $worktime = [
                        'from' => [
                            '1' => $save['w_from_1'],
                            '2' => $save['w_from_2'],
                            '3' => $save['w_from_3'],
                            '4' => $save['w_from_4'],
                            '5' => $save['w_from_5'],
                            '6' => $save['w_from_6'],
                            '7' => $save['w_from_7'],
                        ],
                        'to' => [
                            '1' => $save['w_to_1'],
                            '2' => $save['w_to_2'],
                            '3' => $save['w_to_3'],
                            '4' => $save['w_to_4'],
                            '5' => $save['w_to_5'],
                            '6' => $save['w_to_6'],
                            '7' => $save['w_to_7'],
                        ]
                    ];

                    $workdate = $save['workdate'];

                    $wt = [];
                    foreach ($workdate as $k => $item) {
                        $wt[] = [$save['wt_from'][$k], $save['wt_to'][$k]];
                    }


                    $this->cur_user->worktime = json_encode($worktime) or null;
                    $this->cur_user->workdate = json_encode($workdate) or null;
                    $this->cur_user->workdatetime = json_encode($wt) or null;


                    $this->cur_user->komnata = $save['komnata'];
                }
                if ($this->cur_user->access == 1) {
                    if (isset($save['config'])) {
                        $conf = \R::findOne('configs',"_key=?",['test_all_msg']);
                        $conf->_value = $save['config'];
                        \R::store($conf);
                    }

                    if (isset($save['config_metodist_email'])) {
                        $metod = \R::findOne('configs',"_key=?",['metodist_email']);
                        $metod->_value = $save['config_metodist_email'];
                        \R::store($metod);
                    }
                }
                $this->cur_user->email = $save['email'];
                $this->cur_user->phone = $save['phone'];
                $this->cur_user->mphone = $save['mphone'];
                $this->cur_user->sex = $save['sex'];
                break;
            case 'noty':
                if ($this->cur_user->access != 2) {
                    $to_s = [];
                    foreach ($save['noty'] as $k => $i) $to_s[] = $k;
                    $this->cur_user->noty = json_encode($to_s);
                }
                if ($this->cur_user->access == 1) {
                    $header = $save['header'];
                    $msg = $save['message'];
                    foreach ($header as $k => $item) {
                        $noty = \R::findOne('noty',"alias=?", [$k]);
                        $noty->header = $header[$k];
                        $noty->message = $msg[$k];
                        \R::store($noty);
                    }
                    if (isset($save['config_metodist_email'])) {
                        $metod = \R::findOne('configs',"_key=?",['metodist_email']);
                        $metod->_value = $save['config_metodist_email'];
                        \R::store($metod);
                    }
                }
        }
        unset($this->cur_user->sem);
        \R::store($this->cur_user);
        $_SESSION['info_msg'][] = 'Успешно сохранено!';
        redirect();
        die;
//        header('Location: ' . BASE_URL . 'edit');
    }

    public function accAction() {
        if ($this->cur_user != 1) header("Location: ".BASE_URL);
        if ($this->isAjax()) {
            $users =  \R::getAssoc("SELECT * FROM users WHERE class=?",[$_GET['class']]);
            $res = '';
            foreach ($users as $user) {
                $res .= '<tr>';
                $res .=     '<td>'.$user['name'].'</td>';
                $res .=     '<td>'.$user['class'].'</td>';
                $res .=     '<td>'.$user['username'].'</td>';
                $res .=     '<td>'.$user['password'].'</td>';
//                $res .=     '<td><a href="#" class="btn btn-xs btn-warning">смс</a><a href="#" class="btn btn-xs btn-default">email</a></td>';
                $res .=     '<td>'. (($user['pay_status']) ? 'Да' : 'Нет') .'</td>';
                $res .= '</tr>';
            }
            echo $res;
            die;
        }
        $data = $this->data;
        $this->setMeta('Аккаунты');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['users'] = \R::getAssoc("SELECT * FROM users WHERE access=4 LIMIT 15");

        $this->set($data);
    }

    public function uploadAvatarAction() {
        $this->layout = false;
        $my_id = $_SESSION['logged_user']['id'];
        $uploadDir = 'uploads/';
        $fileTypes = array('jpg', 'jpeg');
        $verifyToken = md5('unique_salt' . $_POST['timestamp']);

//if ($_POST['token'] == md5($my_id.'_avatar_'.$secret)) {
        $tempFile = $_FILES['Filedata']['tmp_name'];
        $uploadDir = BASE_PATH . $uploadDir;
//        dd($uploadDir);
        $targetFile = $uploadDir . 'upload_' . $my_id . '.jpg';
        $fileParts = pathinfo($_FILES['Filedata']['name']);
        if (in_array(strtolower($fileParts['extension']), $fileTypes)) {
            move_uploaded_file($tempFile, $targetFile);
            $im = imagecreatefromjpeg($targetFile);
            list($w, $h) = getimagesize($targetFile);
            $koe = $w / 1000;
            $new_h = ceil($h / $koe);
            $im1 = imagecreatetruecolor(1000, $new_h);
            imagecopyresampled($im1, $im, 0, 0, 0, 0, 1000, $new_h, imagesx($im), imagesy($im));
            imagejpeg($im1, $targetFile, 100);
            imagedestroy($im);
            imagedestroy($im1);
            echo 1;
        } else {
            echo 'Неверный тип файла.';
        }
//} else {
//    echo 0;
//}
    }

    public function resizeAvatarAction() {
        $this->layout = false;
        $my_id = $_SESSION['logged_user']['id'];
        $ava_x = htmlspecialchars(addslashes($_POST['ava_x']));
        $ava_y = htmlspecialchars(addslashes($_POST['ava_y']));
//        $ava_x2 = htmlspecialchars(addslashes($_POST['ava_x2']));
//        $ava_y2 = htmlspecialchars(addslashes($_POST['ava_y2']));
        $ava_w = htmlspecialchars(addslashes($_POST['ava_w']));
        $ava_h = htmlspecialchars(addslashes($_POST['ava_h']));
        $img_w = htmlspecialchars(addslashes($_POST['img_w']));
        $img_h = htmlspecialchars(addslashes($_POST['img_h']));

        $uploadDir = 'uploads/';
        $saveDir = 'photo/';
        $uploadDir = BASE_PATH . $uploadDir;
        $saveDir = BASE_PATH . $saveDir;

        $rand = rand(1000000, 9999999);
        $targetFile = BASE_PATH  . 'uploads/upload_' . $my_id . '.jpg';
        $tempFile = $_FILES['Filedata']['tmp_name'];
        move_uploaded_file($tempFile, $targetFile);
        $saveFile = $saveDir . $rand . '.jpg';
        $saveFileMini = $saveDir . 'm_' . $rand . '.jpg';

        $im = imagecreatefromjpeg($targetFile);
        list($w, $h) = getimagesize($targetFile);
        $koe = $w / 600;
        $new_h = ceil($h / $koe);
        $im1 = imagecreatetruecolor(600, $new_h);
        imagecopyresampled($im1, $im, 0, 0, 0, 0, 600, $new_h, imagesx($im), imagesy($im));
        imagejpeg($im1, $saveFile, 100);
        imagedestroy($im);
        imagedestroy($im1);

        $save_h = $new_h;

        if ($h > $w) {
            $im = imagecreatefromjpeg($targetFile);
            list($w, $h) = getimagesize($targetFile);
            $koe = $w / 200;
            $new_h = ceil($h / $koe);
            $im1 = imagecreatetruecolor(200, $new_h);
            imagecopyresampled($im1, $im, 0, 0, 0, 0, 200, $new_h, imagesx($im), imagesy($im));
            imagejpeg($im1, $saveFileMini, 200);
            imagedestroy($im);
            imagedestroy($im1);
        } else {
            $im = imagecreatefromjpeg($targetFile);
            list($w, $h) = getimagesize($targetFile);
            $koe = $h / 200;
            $new_w = ceil($w / $koe);
            $im1 = imagecreatetruecolor($new_w, 200);
            imagecopyresampled($im1, $im, 0, 0, 0, 0, $new_w, 200, imagesx($im), imagesy($im));
            imagejpeg($im1, $saveFileMini, 200);
            imagedestroy($im);
            imagedestroy($im1);
        }

        $date = date('U');
        $pu = \R::dispense('photouser');
        $pu->user_id = $my_id;
        $pu->name = $rand;
        $pu->width = 600;
        $pu->height = $save_h;
        $pu->date = $date;
        \R::store($pu);


        $src = BASE_PATH . 'uploads/upload_' . $my_id . '.jpg';
        $src2 = BASE_PATH . 'order/' . $my_id . '.jpg';
        $size = getimagesize($src);
        $kx = $size[0] / $img_w;
        $ky = $size[1] / $img_h;

        $new_width = $ava_w * $kx;
        $new_height = $ava_h * $ky;
        $left = $ava_x * $kx;
        $top = $ava_y * $ky;

        $size = getimagesize($src);
        $format = strtolower(substr($size['mime'], strpos($size['mime'], '/') + 1));
        $icfunc = "imagecreatefrom" . $format;
        $isrc = $icfunc($src);
        $dst = imagecreatetruecolor($new_width, $new_height);
        imagecopyresampled($dst, $isrc, 0, 0, $left, $top, $new_width, $new_height, $new_width, $new_height);
        imagejpeg($dst, $src, 100);
        imagedestroy($dst);


        $im = imagecreatefromjpeg($src);
        list($w, $h) = getimagesize($src);
        $koe = $w / 100;
        $new_h = ceil($h / $koe);
        $im1 = imagecreatetruecolor(100, $new_h);
        imagecopyresampled($im1, $im, 0, 0, 0, 0, 100, $new_h, imagesx($im), imagesy($im));
        imagejpeg($im1, $src2, 100);
        imagedestroy($im);
        imagedestroy($im1);

        unlink($src);
        $u = \R::load('users',$my_id);
        $u->avatar = '1';
        \R::store($u);

        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'name' => 'm_' . $rand]);
    }

    public function delAvatarAction() {
        $this->layout = false;
        $my_id = $_SESSION['logged_user']['id'];
        $u = \R::load('users',$my_id);
        $u->avatar = '0';
        \R::store($u);
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
    }

    public function adduserpredAction() {
        $this->layout = false;
//        dd($_POST);
        if (!empty($_POST['prepod']) && !empty($_POST['toadd'])) {
            foreach ($_POST['toadd'] as $item) {
                switch ($_POST['tab']) {
                    case 'prep_pred':
                        dd('123');
                        if (empty(\R::findOne('userpred',"user_id=? AND pred_id=?",[$_POST['prepod'],$item]))) {
                            $u = \R::dispense('userpred');
                            $u->user_id = $_POST['prepod'];
                            $u->pred_id = $item;
                            \R::store($u);
                        }
                        break;
                    case 'prep_gr':
                       if (empty(\R::findOne('userclass',"user_id=? AND class=?",[$_POST['prepod'],$item]))) {
                            $u = \R::dispense('userclass');
                            $u->user_id = $_POST['prepod'];
                            $u->class = $item;
                            \R::store($u);
                        }
                        break;
                    case 'gr_pred':
                        $pr = \R::findOne('predmets', "id=?", [$item]);
//                        \R::fancyDebug(true);
                        if (empty(\R::findOne('plan',"class=? AND disc=?",[$_POST['prepod'],$pr->name]))) {
                            $u = \R::dispense('plan');
                            $u->class = $_POST['prepod']; // $_POST['prepod'] - группа
                            $u->disc = $pr->name;
                            \R::store($u);
                        }
                        break;
                }

            }
        }
        header("Location: ".$_SERVER['HTTP_REFERER']);
        die;
    }

    public function deluserpredAction() {
        $this->layout = false;
        if (!empty($_POST['id']) && !empty($_POST['tab'])) {
            switch ($_POST['tab']) {
                case 'prep_pred':
//                    \R::trash('userpred',$_POST['id']);
                    break;
                case 'prep_gr':
                    \R::trash('userclass',$_POST['id']);
                    break;
                case 'gr_pred':
                    \R::trash('plan',$_POST['id']);
                    break;
            }
        }
//        header("Location: ".$_SERVER['HTTP_REFERER']);
        die;
    }

    public function getinfoAction() {
        $this->layout = false;
        $data = [];
        if (!empty($_POST['id'])) {
            $user = \R::load('users', $_POST['id']);
            $data['photo'] = (!empty($user->photo)) ? BASE_URL .'order/'. $user->photo : BASE_URL . 'assets/images/thumbs/no-image.jpg';
            $data['id'] = $user->id;
            $data['name'] = $user->name;
            $data['class'] = $user->class;
            $data['login'] = $user->username;
            $data['loginad'] = $user->login;
            $data['password'] = $user->password;
            $data['phone'] = $user->phone;
            $data['email'] = $user->email;
            $data['access'] = $user->access;
            $data['pasport_s'] = $user->pasport_s;
            $data['pasport_n'] = $user->pasport_n;
            $data['dolg'] = $user->dolg;
            $data['obozdolg'] = $user->obozdolg;
            $data['uhstep'] = $user->uhstep;
            $data['uhzvan'] = $user->uhzvan;
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        die;
    }

    public function saveinfoAction() {
        $this->layout = false;
        if (!empty($_POST['id'])) {
            $user = \R::load('users', $_POST['id']);
            if (!$user) die();
            foreach ($_POST as $k => $v) {
                $user->$k = $v;
            }
            \R::store($user);
            die('1');
        }
        die();
    }

    public function setpwdAction() {
        ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
        $this->layout = false;
        if (!empty($_POST['id'])) {
            $user = \R::load('users', $_POST['id']);
            if (!$user) die();
            if (!$_POST['password']) die();
            if (!$_POST['email'] && !$user->login) die();
            if (strlen($_POST['password']) < 5) die();
             if ($this->cur_user->access != 1) redirect();
            /*$config = [
                'domain_controllers'    => ['ldap.usue.ru'],
                'base_dn'               => 'dc=usue,dc=ru',
                'admin_username'        => 'inoonline_dev@usue.ru',
                'admin_password'        => 'rheukzi35%^',
//                'use_ssl' => true,
//                'use_tls' => false,
//                'account_prefix' => 'domain\\',
//                'custom_options' => [
//                    LDAP_OPT_X_TLS_REQUIRE_CERT => LDAP_OPT_X_TLS_NEVER
//                ]
            ];
            $ad = new \Adldap\Adldap();
            $ad->addProvider($config);
            try {
                $provider = $ad->connect();
                $u = $provider->search()->users()->find($user->login);
//                dd2($u);
                $u->setPassword($_POST['password']);
                if($user->update()) {
                    echo '<div class="uu-success"><b><span>Операция выполнена!</span><br> Ваш логин: '.$user->login
                        .' <br> Ваш пароль: '.$_POST['password'].'</b></div>';
                    die();
                }
            } catch (\Adldap\Auth\BindException $e) {
                die("Can't connect / bind to the LDAP server! Error: $e");
            }
            die('1');*/
            require ROOT.'/public/exporter/phpQuery.php';
            $email = $_POST['email'] ?: ($user->login ? $user->login . '@usue.ru' : '');
            $form = [
                'name' 	=> $user->name,
                'pass1' => $user->pasport_s,
                'pass2' => $user->pasport_n,
                'password' => $_POST['password'],
                'password2' => $_POST['password'],
                'email' => $email,
            ];
            $data = $this->get_content('https://portfolio.usue.ru/reg/updateaduser/',$form,true);
            echo '<div class="block"><div class="uu-success"><b><span>Операция выполнена!</span><br> Ваш логин: '.$user->login
                        .' <br> Ваш пароль: '.$_POST['password'].'</b></div></div>';
            die();
            $doc = \phpQuery::newDocument($data);
            $data = $doc->find('.uu-success')->html();
            if (empty($data)) $data = $doc->find('.uu-error')->html();


            die('1');
        }
        die();
    }

    public function getListFilterAction() {
        $this->layout = false;
        $course = $_POST['course']/* == 0 ? null : $_POST['course']*/;
        $user = $this->cur_user->access == 3 ? $this->cur_user : null;
        $list = $this->usr->get_class_list($course, $user);
//        dd2($course);
        $html = '';
        foreach ($list as $item) if (!empty($item['class'])) $html .= '<option>' . $item['class'] . '</option>';
        echo $html;
        die;
    }

    public function getUserListAction() {
        $this->layout = false;
        if (!empty($_GET['class'])) {
            $list = \R::findAll('users',"class=? order by name",[$_GET['class']]);
            $html = '';
            foreach ($list as $item) $html .= '<option value="'.$item['id'].'">' . $item['name'] . '</option>';
            echo $html;
        }
        die;
    }

    public function selflAction() {
        $this->layout = false;
        if (empty($_POST['fl'])) redirect('/');
        $user = \R::findOne('users',"id=?",[$this->cur_user->id]);
        $user->fl = $_POST['fl'];
        \R::store($user);
        $_SESSION['info_msg'][] = 'Успешно сохранено!';
        redirect('/');
    }

    function get_content($url, $post = 0,$auth = false) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url ); // отправляем на
        curl_setopt($ch, CURLOPT_HEADER, 0); // пустые заголовки
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // возвратить то что вернул сервер
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); // следовать за редиректами
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);// таймаут4
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,  2);
//    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
//    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Host: portfolio.usue.ru'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);// просто отключаем проверку сертификата
        if ($auth)
            curl_setopt($ch, CURLOPT_COOKIEJAR,  ROOT.'/public/exporter/my_cookies.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE,  ROOT.'/public/exporter/my_cookies.txt');
        curl_setopt($ch, CURLOPT_POST, $post !== 0);
        if ($post) {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
            curl_setopt($ch, CURLOPT_POSTREDIR, 3);
        }
        $data = curl_exec($ch);
//        curl_getinfo($ch);
        curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        return $data;
    }

    public function loginuserAction() {
        if ($this->cur_user->access != 1 || empty($_GET['id'])) redirect(BASE_URL);
        if (!empty($_SESSION['logged_user'])) {
            unset($_SESSION['logged_user']);
            unset($_SESSION['popup']);
        }
        $user = \R::findOne('users', 'id=?', [$_GET['id']]);

        $_SESSION['logged_user'] = $user->export();
        $_SESSION['popup'][] = true;
        $u = \R::load('users', $_SESSION['logged_user']['id']);
        if ($m = $u->rules) {
            $m = explode(',', $m);
            $menu = \R::findOne('menu', "id IN (" . \R::genSlots($m) . ")", $m);
            redirect(BASE_URL . $menu['alias']);
            exit;
        }
        redirect(BASE_URL);
    }

    public function roleAction()
    {
        $action = $_GET['a'];
        $role = $_GET['v'];
        $add = $_GET['v2'];
        $res = ''; $out = '';
        $notselect = '<option>Не выбрано</option>';
        switch ($action) {
            case 'role':
                if (empty($role)) die('');
                switch ($role) {
                    case 2:case 3:
                        $users = \R::getAssoc("select id,name from users where access=? order by name",[$role]);
                        $res = $notselect . implode('', array_map(function ($k, $v) { return "<option value='$k'>$v</option>"; }, array_keys($users), $users));
                        $out = 'login';
                        break;
                    case 4:
                        $res = $notselect.implode('', array_map(function ($v) { return "<option>$v</option>"; }, \R::getCol("select distinct class from users where access=4 order by class")));
                        $out = 'add';
                        break;
                }
                break;
            case 'add':
                if (empty($role)) die('');
                switch ($role) {
                    case 4:
                        $users = \R::getAssoc("select id,name from users where class=? order by name", [$add]);
                        $res = $notselect . implode('', array_map(function ($k, $v) { return "<option value='$k'>$v</option>"; }, array_keys($users), $users));
                        $out = 'login';
                        break;
                }
                break;
        }
        die(json_encode(compact('res','out')));
    }

    public function loginAction()
    {
        if(empty($_POST['id'])) die(0);
        $user = \R::load('users', $_POST['id']);
        $_SESSION['la'] = $user->export();
        $_SESSION['popup'][] = true;
        die('1');
    }

}