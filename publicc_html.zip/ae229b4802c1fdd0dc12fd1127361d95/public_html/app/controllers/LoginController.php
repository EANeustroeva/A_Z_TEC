<?php

namespace app\controllers;

use app\models\Auth;
use R;
use vendor\core\base\Controller;

class LoginController extends Controller
{
    public $errors = [];
    public $data = [];

    public function __construct($route)
    {
        parent::__construct($route);
        new Auth();
    }

    public function indexAction()
    {
        $this->setMeta('Страница авторизации');
        $meta = $this->meta;
        $this->set(compact('meta'));
        $this->layout = 'login';
    }

    public function konkursAction()
    {
        if (isset($_GET['new'])) {
            unset($_SESSION['k_poll_voted_id']);
            $users = R::findAll("konkurs_users");
            foreach ($users as $user) { $user->votes = 0; R::store($user); }
            R::wipe('konkurs');
            $_SESSION['info_msg'][] = 'Результаты голосования успешно сброшены!';
            redirect('/konkurs');
        }
        if (isset($_GET['reset'])) {
            unset($_SESSION['k_poll_voted_id']);
            $_SESSION['info_msg'][] = 'Текущая сессия обновлена!';
            redirect('/konkurs');
        }

        if (empty($_SESSION['k_poll_voted_id'])) $_SESSION['k_poll_voted_id'] = uniqid();

        if (isset($_GET['id'])) {
            $user = R::load('konkurs_users', $_GET['id']);
            $voted = R::findOne('konkurs',"user_id=? and uniqid=?",[$_GET['id'], $_SESSION['k_poll_voted_id']]);

            if (isset($_GET['fix'])) {
                if (!$voted) {
                    $voted = R::dispense('konkurs');
                    $voted->uniqid = $_SESSION['k_poll_voted_id'];
                    $voted->user_id = $_GET['id'];
                }

                if (isset($_GET['m'])) { $voted->votes = $_GET['m']; }
                if (isset($_GET['n'])) { $voted->votes2 = $_GET['n']; }

                //R::store($voted);
                //$_SESSION['info_msg'][] = 'Ваша оценка для <b>'.$user['fio'].'</b> зафиксирована';
                redirect('/konkurs');
            }
        }
        $this->layout = 'metro';
        $users = R::getAll("select * from konkurs_users order by n");

        $this->set(compact('users', 'user', 'voted' ));
    }

    public function stageAction()
    {
        if ($this->isAjax()) {
            $id = $_GET['id'];
            $m = $_GET['m'];
            $user = R::load('konkurs_users', $id);
            $user->votes = $m;
            R::store($user);
            die('1');
        }
        $this->layout = 'metro';
        $users = R::getAssoc("select * from konkurs_users order by n");
        $voted = R::findAll('konkurs');
        foreach ($users as $id=>$user) {
            $sum = 0;
            $votes = array_filter($voted, function ($v) use ($id){ return $v['user_id'] == $id && !is_null($v['votes']); });
            foreach ($votes as $item) { $sum += $item->votes; }
            $users[$id]['vote'] = count($votes) ? round($sum / count($votes),1) : 0;
        }

        $this->set(compact('users'));
    }

    public function resultAction()
    {
        $this->layout = 'blank';
        $users_list = R::getAll("select * from konkurs_users order by n");
        $voted = R::findAll('konkurs');
        foreach ($users_list as $k=>$user) {
            $sum = 0;
            $votes = array_filter($voted, function ($v) use ($user){ return $v['user_id'] == $user['id'] && !is_null($v['votes']); });
            foreach ($votes as $item) { $sum += $item->votes; }
            $sum = count($votes) ? ($sum / count($votes)) : $sum;
            $users_list[$k]['sum'] = round($user['pre'] + $sum + $user['votes'], 1);
        }
//        usort($users_list, function ($a, $b) { return $a['sum'] <=> $b['sum']; });
        $users_list = array_values($users_list);
        $users = [];
        $i = 0;
        foreach ($users_list as $k=>$item) {
            if ($k % 10 == 0) $i++;
            $users[$i][] = $item;
        }
        $this->set(compact('users', 'voted' ));
    }

    public function resultsAction()
    {
        $this->layout = 'metro';
        $users = R::getAssoc("select * from konkurs_users order by fio");
        $voted = R::findAll('konkurs');
        $users2 = $users3 =  $users4 = $users;

        foreach ($users as $id=>$user) {
            $sum = 0;
            $votes = array_filter($voted, function ($v) use ($id){ return $v['user_id'] == $id && !is_null($v['votes']); });
            foreach ($votes as $item) { $sum += $item->votes; }
            $users[$id]['sum'] = $sum;
            $users[$id]['votes'] = $votes;
        }

        foreach ($users4 as $id=>$user) {
            $sum = 0;
            $votes = array_filter($voted, function ($v) use ($id){ return $v['user_id'] == $id && !is_null($v['votes']); });
            foreach ($votes as $item) { $sum += $item->votes; }
            $sum = count($votes) ? ($sum / count($votes)) : $sum;
            $users4[$id]['sum'] = round($user['pre'] + $sum + $user['votes'], 1);
        }

        usort($users, function ($a, $b) { return $b['sum'] <=> $a['sum']; });
        usort($users2, function ($a, $b) { return $b['votes'] <=> $a['votes']; });
        usort($users3, function ($a, $b) { return $b['pre'] <=> $a['pre']; });
        usort($users4, function ($a, $b) { return $b['sum'] <=> $a['sum']; });

        $this->set(compact('users', 'users2', 'users3',  'users4', 'user', 'voted' ));
    }

    public function _konkursAction()
    {
        if (isset($_GET['reset'])) {
            unset($_SESSION['k_poll_voted']);
            unset($_SESSION['k_poll_voted2']);
            unset($_SESSION['k_poll_voted_id']);
            redirect('/konkurs');
        }
        if (!empty($_GET['m'])) {
            if (empty($_SESSION['k_poll_voted_id'])) $_SESSION['k_poll_voted_id'] = uniqid();
            if (!in_array($_GET['c'], $_SESSION['k_poll_voted'])) {
                $_SESSION['k_poll_voted'][] = $_GET['c'];
                $k = R::dispense('konkurs');
                $k->class = $_GET['c'];
                $k->votes = $_GET['m'];
                $k->uniqid = $_SESSION['k_poll_voted_id'];
                R::store($k);
            }
            $_SESSION['info_msg'][] = 'Ваша оценка для <b>'.$_GET['c'].'</b> учтена';
            redirect('/konkurs');
        }
        if (isset($_GET['n'])) {
            if (!in_array($_GET['c'], $_SESSION['k_poll_voted2'])) {
                $_SESSION['k_poll_voted2'][] = $_GET['c'];
                if (!empty($_SESSION['k_poll_voted_id'])) $k = R::findOne('konkurs',"class=? and uniqid=?",[$_GET['c'], $_SESSION['k_poll_voted_id']]);
                else $k = R::dispense('konkurs');
                $k->class = $_GET['c'];
                $k->votes2 = $_GET['n'];
                R::store($k);
            }
            $_SESSION['info_msg'][] = 'Ваша оценка для <b>'.$_GET['c'].'</b> учтена';
            redirect('/konkurs');
        }
        $this->setMeta('Конкурс «Лучший студент среднего профессионального образования»');
        $meta = $this->meta;
        $users = R::getAll("select * from konkurs_users order by fio");
        $this->layout = 'faq';
        if (isset($_GET['qwe'])) {
            $this->layout = 'metro';
        }
        $this->set(compact('meta','users'));
    }

    protected function setMeta($title = '', $description = '', $keywords = '') {
        $this->meta['title'] = $title;
        $this->meta['desc'] = $description;
        $this->meta['keywords'] = $keywords;
    }
}

//[{"poll":"№1 Першин Александр Олегович","votes":0},{"poll":"№2 Галстян Арсен Тигранович","votes":0},{"poll":"№3 Коцюрба Александр Андреевич","votes":0},{"poll":"№4 Бумажников Родион Евгеньевич","votes":0},{"poll":"№5 Алексеев Сергей Алексеевич","votes":0},{"poll":"№6 Пиминов Андрей Павлович","votes":0},{"poll":"№7 Маслова Ариадна Витальевна","votes":0},{"poll":"№8 Квиленкова Анастасия Михайловна","votes":0},{"poll":"№9 Стрелков Алексей Александрович","votes":0},{"poll":"№10 Тихомирова Екатерина Витальевна","votes":0},{"poll":"№11 Сапсай Наталья Артемовна","votes":0},{"poll":"№12 Пучкина Татьяна Сергеевна","votes":0},{"poll":"№13 Колтышев Максим Анатольевич","votes":0},{"poll":"№14 Банзюк Виктория Михайловна","votes":0},{"poll":"№15 Сергиенко Яна Александровна","votes":0},{"poll":"№16 Медведкова Ольга Алексеевна","votes":0},{"poll":"№17 Матевосян Сильва Вагеевна","votes":0},{"poll":"№18 Бархатов Данил Романович","votes":0},{"poll":"№19 Денисов Дмитрий Владимирович","votes":0},{"poll":"№20 Еськин Алексей Сергеевич","votes":0},{"poll":"№21 Кожин Антон Андреевич","votes":0},{"poll":"№22 Арутюнян Роксана Гариковна","votes":0},{"poll":"№23 Александрова Анастасия Сергеевна","votes":0},{"poll":"№24 Майданова Елизавета Дмитриевна","votes":0},{"poll":"№25 Власов Александр Вадимович","votes":0},{"poll":"№26 Саморуков Дмитрий Евгеньевич","votes":0},{"poll":"№27 Величко Алексей Анатольевич","votes":0},{"poll":"№28 Зайцева  Дарья Васильевна","votes":0},{"poll":"№29 Мальцева Елизавета валерьевна","votes":0},{"poll":"№30 Базарова Анастасия Вадимовна","votes":0},{"poll":"№31 Ефремова Анна Дмитриевна","votes":0},{"poll":"№32 Тувышев Александр Игоревич","votes":0},{"poll":"№33 Силенок Юлия Сергеевна","votes":0},{"poll":"№34 Зобнина Наталья Павловна","votes":0},{"poll":"№35 Ермакова Елизавета Александровна","votes":0},{"poll":"№36 Вишневский Никита Сергеевич","votes":0},{"poll":"№37 Карташов Савелий Владиславович","votes":0},{"poll":"№38 Летягина Дарья Олеговна","votes":0},{"poll":"№39 Яковлев Егор Алексеевич","votes":0},{"poll":"№40 Лазаренко Диана Андреевна","votes":0}]

//[{"poll":"\u21161 \u041f\u0435\u0440\u0448\u0438\u043d \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440 \u041e\u043b\u0435\u0433\u043e\u0432\u0438\u0447","votes":2},{"poll":"\u21162 \u0413\u0430\u043b\u0441\u0442\u044f\u043d \u0410\u0440\u0441\u0435\u043d \u0422\u0438\u0433\u0440\u0430\u043d\u043e\u0432\u0438\u0447","votes":0},{"poll":"\u21163 \u041a\u043e\u0446\u044e\u0440\u0431\u0430 \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440 \u0410\u043d\u0434\u0440\u0435\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u21164 \u0411\u0443\u043c\u0430\u0436\u043d\u0438\u043a\u043e\u0432 \u0420\u043e\u0434\u0438\u043e\u043d \u0415\u0432\u0433\u0435\u043d\u044c\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u21165 \u0410\u043b\u0435\u043a\u0441\u0435\u0435\u0432 \u0421\u0435\u0440\u0433\u0435\u0439 \u0410\u043b\u0435\u043a\u0441\u0435\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u21166 \u041f\u0438\u043c\u0438\u043d\u043e\u0432 \u0410\u043d\u0434\u0440\u0435\u0439 \u041f\u0430\u0432\u043b\u043e\u0432\u0438\u0447","votes":0},{"poll":"\u21167 \u041c\u0430\u0441\u043b\u043e\u0432\u0430 \u0410\u0440\u0438\u0430\u0434\u043d\u0430 \u0412\u0438\u0442\u0430\u043b\u044c\u0435\u0432\u043d\u0430","votes":0},{"poll":"\u21168 \u041a\u0432\u0438\u043b\u0435\u043d\u043a\u043e\u0432\u0430 \u0410\u043d\u0430\u0441\u0442\u0430\u0441\u0438\u044f \u041c\u0438\u0445\u0430\u0439\u043b\u043e\u0432\u043d\u0430","votes":0},{"poll":"\u21169 \u0421\u0442\u0440\u0435\u043b\u043a\u043e\u0432 \u0410\u043b\u0435\u043a\u0441\u0435\u0439 \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432\u0438\u0447","votes":0},{"poll":"\u211610 \u0422\u0438\u0445\u043e\u043c\u0438\u0440\u043e\u0432\u0430 \u0415\u043a\u0430\u0442\u0435\u0440\u0438\u043d\u0430 \u0412\u0438\u0442\u0430\u043b\u044c\u0435\u0432\u043d\u0430","votes":0},{"poll":"\u211611 \u0421\u0430\u043f\u0441\u0430\u0439 \u041d\u0430\u0442\u0430\u043b\u044c\u044f \u0410\u0440\u0442\u0435\u043c\u043e\u0432\u043d\u0430","votes":0},{"poll":"\u211612 \u041f\u0443\u0447\u043a\u0438\u043d\u0430 \u0422\u0430\u0442\u044c\u044f\u043d\u0430 \u0421\u0435\u0440\u0433\u0435\u0435\u0432\u043d\u0430","votes":0},{"poll":"\u211613 \u041a\u043e\u043b\u0442\u044b\u0448\u0435\u0432 \u041c\u0430\u043a\u0441\u0438\u043c \u0410\u043d\u0430\u0442\u043e\u043b\u044c\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u211614 \u0411\u0430\u043d\u0437\u044e\u043a \u0412\u0438\u043a\u0442\u043e\u0440\u0438\u044f \u041c\u0438\u0445\u0430\u0439\u043b\u043e\u0432\u043d\u0430","votes":0},{"poll":"\u211615 \u0421\u0435\u0440\u0433\u0438\u0435\u043d\u043a\u043e \u042f\u043d\u0430 \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432\u043d\u0430","votes":0},{"poll":"\u211616 \u041c\u0435\u0434\u0432\u0435\u0434\u043a\u043e\u0432\u0430 \u041e\u043b\u044c\u0433\u0430 \u0410\u043b\u0435\u043a\u0441\u0435\u0435\u0432\u043d\u0430","votes":3},{"poll":"\u211617 \u041c\u0430\u0442\u0435\u0432\u043e\u0441\u044f\u043d \u0421\u0438\u043b\u044c\u0432\u0430 \u0412\u0430\u0433\u0435\u0435\u0432\u043d\u0430","votes":0},{"poll":"\u211618 \u0411\u0430\u0440\u0445\u0430\u0442\u043e\u0432 \u0414\u0430\u043d\u0438\u043b \u0420\u043e\u043c\u0430\u043d\u043e\u0432\u0438\u0447","votes":1},{"poll":"\u211619 \u0414\u0435\u043d\u0438\u0441\u043e\u0432 \u0414\u043c\u0438\u0442\u0440\u0438\u0439 \u0412\u043b\u0430\u0434\u0438\u043c\u0438\u0440\u043e\u0432\u0438\u0447","votes":0},{"poll":"\u211620 \u0415\u0441\u044c\u043a\u0438\u043d \u0410\u043b\u0435\u043a\u0441\u0435\u0439 \u0421\u0435\u0440\u0433\u0435\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u211621 \u041a\u043e\u0436\u0438\u043d \u0410\u043d\u0442\u043e\u043d \u0410\u043d\u0434\u0440\u0435\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u211622 \u0410\u0440\u0443\u0442\u044e\u043d\u044f\u043d \u0420\u043e\u043a\u0441\u0430\u043d\u0430 \u0413\u0430\u0440\u0438\u043a\u043e\u0432\u043d\u0430","votes":0},{"poll":"\u211623 \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432\u0430 \u0410\u043d\u0430\u0441\u0442\u0430\u0441\u0438\u044f \u0421\u0435\u0440\u0433\u0435\u0435\u0432\u043d\u0430","votes":0},{"poll":"\u211624 \u041c\u0430\u0439\u0434\u0430\u043d\u043e\u0432\u0430 \u0415\u043b\u0438\u0437\u0430\u0432\u0435\u0442\u0430 \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432\u043d\u0430","votes":0},{"poll":"\u211625 \u0412\u043b\u0430\u0441\u043e\u0432 \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440 \u0412\u0430\u0434\u0438\u043c\u043e\u0432\u0438\u0447","votes":0},{"poll":"\u211626 \u0421\u0430\u043c\u043e\u0440\u0443\u043a\u043e\u0432 \u0414\u043c\u0438\u0442\u0440\u0438\u0439 \u0415\u0432\u0433\u0435\u043d\u044c\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u211627 \u0412\u0435\u043b\u0438\u0447\u043a\u043e \u0410\u043b\u0435\u043a\u0441\u0435\u0439 \u0410\u043d\u0430\u0442\u043e\u043b\u044c\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u211628 \u0417\u0430\u0439\u0446\u0435\u0432\u0430  \u0414\u0430\u0440\u044c\u044f \u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432\u043d\u0430","votes":0},{"poll":"\u211629 \u041c\u0430\u043b\u044c\u0446\u0435\u0432\u0430 \u0415\u043b\u0438\u0437\u0430\u0432\u0435\u0442\u0430 \u0432\u0430\u043b\u0435\u0440\u044c\u0435\u0432\u043d\u0430","votes":0},{"poll":"\u211630 \u0411\u0430\u0437\u0430\u0440\u043e\u0432\u0430 \u0410\u043d\u0430\u0441\u0442\u0430\u0441\u0438\u044f \u0412\u0430\u0434\u0438\u043c\u043e\u0432\u043d\u0430","votes":0},{"poll":"\u211631 \u0415\u0444\u0440\u0435\u043c\u043e\u0432\u0430 \u0410\u043d\u043d\u0430 \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432\u043d\u0430","votes":0},{"poll":"\u211632 \u0422\u0443\u0432\u044b\u0448\u0435\u0432 \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440 \u0418\u0433\u043e\u0440\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u211633 \u0421\u0438\u043b\u0435\u043d\u043e\u043a \u042e\u043b\u0438\u044f \u0421\u0435\u0440\u0433\u0435\u0435\u0432\u043d\u0430","votes":0},{"poll":"\u211634 \u0417\u043e\u0431\u043d\u0438\u043d\u0430 \u041d\u0430\u0442\u0430\u043b\u044c\u044f \u041f\u0430\u0432\u043b\u043e\u0432\u043d\u0430","votes":0},{"poll":"\u211635 \u0415\u0440\u043c\u0430\u043a\u043e\u0432\u0430 \u0415\u043b\u0438\u0437\u0430\u0432\u0435\u0442\u0430 \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432\u043d\u0430","votes":0},{"poll":"\u211636 \u0412\u0438\u0448\u043d\u0435\u0432\u0441\u043a\u0438\u0439 \u041d\u0438\u043a\u0438\u0442\u0430 \u0421\u0435\u0440\u0433\u0435\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u211637 \u041a\u0430\u0440\u0442\u0430\u0448\u043e\u0432 \u0421\u0430\u0432\u0435\u043b\u0438\u0439 \u0412\u043b\u0430\u0434\u0438\u0441\u043b\u0430\u0432\u043e\u0432\u0438\u0447","votes":0},{"poll":"\u211638 \u041b\u0435\u0442\u044f\u0433\u0438\u043d\u0430 \u0414\u0430\u0440\u044c\u044f \u041e\u043b\u0435\u0433\u043e\u0432\u043d\u0430","votes":0},{"poll":"\u211639 \u042f\u043a\u043e\u0432\u043b\u0435\u0432 \u0415\u0433\u043e\u0440 \u0410\u043b\u0435\u043a\u0441\u0435\u0435\u0432\u0438\u0447","votes":0},{"poll":"\u211640 \u041b\u0430\u0437\u0430\u0440\u0435\u043d\u043a\u043e \u0414\u0438\u0430\u043d\u0430 \u0410\u043d\u0434\u0440\u0435\u0435\u0432\u043d\u0430","votes":0}]