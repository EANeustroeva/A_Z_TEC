<?php


namespace app\controllers;


class PollsController extends AppController {

    public function indexAction() {
        $data = $this->data;
        $data['polls'] = \R::findAll('polls',"order by ordering");

        $group = [];
        foreach ($data['polls'] as $poll) {
            $group[$poll->alias][] = $poll;
        }
        $data['polls'] = $group;

        $this->setMeta('Опросы');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $this->set($data);
    }

    public function changeTextAction() {
        $poll = \R::load('polls',$_POST['pk']);
        $poll->text = !empty($_POST['value']) ? $_POST['value'] : null;
        \R::store($poll);
        dd2($_POST);
    }

    public function upAction() {
        if (empty($_GET['id'])) redirect();
        $poll = \R::load('polls', $_GET['id']);
        if (!$poll) redirect();
        $prev = \R::findOne('polls', "ordering < ? order by ordering desc",[$poll->ordering]);
        if ($prev) {
            $poll->ordering -= 1;
            \R::store($poll);
            $prev->ordering += 1;
            \R::store($prev);
        }
        redirect();
    }
    public function downAction() {
        if (empty($_GET['id'])) redirect();
        $poll = \R::load('polls', $_GET['id']);
        if (!$poll) redirect();
        $prev = \R::findOne('polls', "ordering > ? order by ordering",[$poll->ordering]);
        if ($prev) {
            $prev->ordering -= 1;
            \R::store($prev);
            $poll->ordering += 1;
            \R::store($poll);
        }
        redirect();
    }

    public function resetAllAction() {
        $polls = \R::findAll('polls');
        foreach ($polls as $poll)
        {
            $options = json_decode($poll->polls);
            foreach ($options as $k=>$item) { $item->votes = 0; }
            $poll->polls = json_encode($options);
            $poll->published = 1;
            \R::store($poll);
        }
        $_SESSION['info_msg'][] = 'Опрос успешно начат!';
        redirect();
    }

    public function endAction() {
        $polls = \R::findAll('polls');
        foreach ($polls as $poll)
        {
            $poll->published = 0;
            \R::store($poll);
        }
        $_SESSION['info_msg'][] = 'Опрос успешно остановлен!';
        redirect();
    }

    public function preAction() {
        date_default_timezone_set('Asia/Yekaterinburg');
        if (!empty($_GET['num'])) {
            $max = \R::getCol("select ordering from polls order by ordering desc");
            $poll = \R::dispense('polls');
            $options = [];
            for ($i=0; $i<$_GET['num'];$i++) $options[] = ['poll' => '', 'votes' => 0];
            $poll->polls = json_encode($options);
            if (!empty($_GET['title'])) $poll->title = $_GET['title'];
            $poll->created = \R::isoDateTime();
            $poll->created_by = $this->cur_user->id;
            $poll->ordering = current($max) + 1;
            $id = \R::store($poll);
            redirect('/polls/edit?id='.$id);
        }
        $data = $this->data;
        $this->setMeta('Опросы');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $this->set($data);
    }

    public function editAction() {
        if (empty($_GET['id'])) redirect();
        $data = $this->data;

        $poll = \R::load('polls', $_GET['id']);
        if (!$poll) redirect();
        $data['poll'] = $poll;

        $group = [];
        $polls = \R::getAssoc("select id,text,alias from polls  order by ordering", [$_GET['id']]); //where id != ?
        foreach ($polls as $k=>$item) {
            $alias = empty($item['alias']) ? 'Нет алиаса' : $item['alias'];
            $group[$alias][$k] = $item['text'];
        }
        $data['polls'] = $group;
//        if (isset($_GET['qwe'])) ddd($group[$poll->alias]);

        $this->setMeta('Опросы');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $this->set($data);
    }

    public function dubAction()
    {
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        $id = !empty($_POST['id']) ? $_POST['id'] : false;
        $dub = !empty($_POST['dub']) ? $_POST['dub'] : false;
        if (!$id || !$dub) redirect();
        $from = \R::load('polls',$id);
        $to = \R::load('polls',$dub);
        if (!$from || !$to) redirect();
        $to->polls = $from->polls;
        foreach ($to->polls as &$item) $item['votes']=0;
        \R::store($to);
        $_SESSION['info_msg'][] = 'Успешно скопировано!';
        redirect();
    }

    public function resultsAction() {
        if (empty($_GET['id'])) redirect();
        $data = $this->data;

        $polls = \R::findAll('polls', "alias=?", [$_GET['id']]);
        if (empty($polls)) redirect();
        $data['polls'] = $polls;

//        $poll = \R::load('polls', $_GET['id']);
//        if (!$poll) redirect();
//        $data['poll'] = $poll;

        $this->setMeta('Опросы');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $this->set($data);
    }

    public function saveAction() {
        date_default_timezone_set('Asia/Yekaterinburg');
        if (empty($_POST['id'])) redirect();
        $poll = \R::load('polls', $_POST['id']);
        $poll->title = !empty($_POST['title'])?$_POST['title']:'';
        $poll->text = !empty($_POST['text'])?$_POST['text']:'';
        $poll->redirect = !empty($_POST['redirect'])?$_POST['redirect']:null;

        $old = json_decode($poll->polls,1);
        $options = [];
        if (!empty($_POST['poll'])) {
            foreach ($_POST['poll'] as $k=>$item) {
                $ol = array_filter($old, function ($v) use ($item){ return $v['poll'] == $item; });
                $options[] = ['poll' => $item, 'votes' => (count($ol)) ? current($ol)['votes'] : 0];
            }
        }

//        $options = json_decode($poll->polls);
//        foreach ($options as $k=>&$item) {
//            $item->poll = $_POST['poll'][$k];
//        }
//        if (!empty($_POST['num'])) {
//            if($_POST['num'] > count($options)) {
//                for ($i=count($options);$i<$_POST['num'];$i++) {
//                    $options[] = ['poll' => '', 'votes' => 0];
//                }
//            }
//        }
        $poll->polls = json_encode($options);
        $poll->alias = $_POST['url'];
        $poll->type = $_POST['type'];
        $poll->modified = \R::isoDateTime();
        $poll->modified_by = $this->cur_user->id;
        $id = \R::store($poll);
        $_SESSION['info_msg'][] = 'Успешно сохранено';
        redirect();
    }

    public function deleteAction() {
        \R::trash('polls',$_GET['id']);
        redirect('/polls');
    }

    public function resetAction() {
        if (empty($_POST['id'])) redirect();
        $polls = \R::findAll('polls', "alias=?", [$_POST['id']]);
        $date = \R::isoDateTime();
        foreach ($polls as $poll) {
            //        $poll = \R::load('polls', $_POST['id']);
            $options = json_decode($poll->polls);
            $archive = [];
            foreach ($options as $k=>$item) {
                $archive[] = $item->votes;
                $item->votes = 0;
            }

            $poll_archive = json_decode($poll->archive,1);
            if (empty($poll_archive)) $poll_archive = [];
            $poll->archive = json_encode(array_merge($poll_archive, [$date => $archive]));

            $poll->polls = json_encode($options);
            \R::store($poll);
        }

        redirect('/polls/results?id='.$_POST['id']);
    }

    public function archiveAction() {
        if (empty($_GET['id'])) redirect();
        $polls = \R::findAll('polls', "alias=?", [$_GET['id']]);
        if (empty($polls)) redirect();
        $data['polls'] = $polls;
        $this->setMeta('Опросы');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $this->set($data);
    }

}