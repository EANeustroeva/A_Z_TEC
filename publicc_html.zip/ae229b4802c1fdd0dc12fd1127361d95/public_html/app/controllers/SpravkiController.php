<?php


namespace app\controllers;

use Carbon\Carbon;
use DateTime;
use Exception;
use PhpOffice\PhpWord\Exception\CopyFileException;
use PhpOffice\PhpWord\Exception\CreateTemporaryFileException;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\TemplateProcessor;

use vendor\core\base\Controller;

class SpravkiController extends AppController {

    public function indexAction() {
        $data = $this->data;
        $this->setMeta('Справки');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $id = $this->cur_user['id'];
        if ($this->cur_user->access == 1) {
            $this->view = 'manager';
            $classes = \R::getAssoc("select distinct class from users where class is not null order by class");
            $resultArray = [];
            array_walk($classes, function($item, $key) use (&$resultArray) {
                preg_match("#.*?(\d\d)#si",$item, $match);
                if (isset($match[1])) {
                    $resultArray['20'.$match[1]][] = $item;
                }
            });
            krsort($resultArray);
            $data['classes'] = $resultArray;
        }
        $this->set($data);
    }

    public function obhodnoyAction() {
        $u = $this->cur_user;
        $date = strtotime($u->pasport_d);
        $month = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
        $d = !empty($u->pasport_d) ? date('d',$date) : '';
//        $m = !empty($u->pasport_d) ? $month[date('n',$date)+1] : '';
        $m = !empty($u->pasport_d) ? date('m',$date) : '';
        $y = !empty($u->pasport_d) ? date('Y',$date) : '';
        $username = (strpos($u->name, '(')) ? preg_replace( '~ \(.*\) ~' , " ", $u->name ) : $u->name;
        $name = explode(' ', str_replace('  ', ' ', $username));

        setlocale(LC_TIME, 'Russian');
        $templateProcessor = new TemplateProcessor(WWW . '/faqres/Obxodnoi_list_zaochka-2017.docx');
        $templateProcessor->setValue('fio1', htmlspecialchars(@$name[0]));
        $templateProcessor->setValue('fio2', htmlspecialchars(@$name[1]));
        $templateProcessor->setValue('fio3', htmlspecialchars(@$name[2]));
        $templateProcessor->setValue('course', htmlspecialchars(@$u->course));
        $templateProcessor->setValue('napr', htmlspecialchars(@$u->napr_post));
        $templateProcessor->setValue('prof', htmlspecialchars(@$u->profile));
        $templateProcessor->setValue('class', htmlspecialchars($u->class));
        $templateProcessor->setValue('pass', htmlspecialchars($u->pasport_s));
        $templateProcessor->setValue('pasn', htmlspecialchars($u->pasport_n));
        $templateProcessor->setValue('pask', htmlspecialchars($u->pasport_k));
        $templateProcessor->setValue('d', htmlspecialchars($d));
        $templateProcessor->setValue('m', htmlspecialchars($m));
        $templateProcessor->setValue('y', htmlspecialchars($y));

        $templateProcessor->saveAs(WWW.'/tmp/sampledocument.docx');
        if(ini_get('zlib.output_compression')) ini_set('zlib.output_compression', 'Off');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        header("Content-Disposition: attachment; filename=\"Обходной лист.docx\";");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: ".filesize(WWW.'/tmp/sampledocument.docx'));
        @readfile(WWW.'/tmp/sampledocument.docx');
        exit;

        die("Успешно");
    }

    public function obhodnoymanagerAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        if (!empty($_POST['users'])) {
            $users = $_POST['users'];
            $users = \R::findAll('users','id in (' . \R::genSlots($users) . ')', $users);
        } else {
            if (empty($_POST['class'])) {
                $_SESSION['info_msg'][] = "Ничего не выбрано!";
                redirect();
            }
            $class = $_POST['class'];
            $users = \R::findAll('users','class in (' . \R::genSlots($class) . ')', $class);
        }
        $course = [];
        foreach ($_POST['class'] as $class) {
            $course[$class] = $this->get_course($class);
        }

        $out = [];
        setlocale(LC_TIME, 'Russian');

        foreach ($users as $u) {
            $date = strtotime($u->pasport_d);
            $d = !empty($u->pasport_d) ? date('d',$date) : '';
            $m = !empty($u->pasport_d) ? date('m',$date) : '';
            $y = !empty($u->pasport_d) ? date('Y',$date) : '';
            $username = (strpos($u->name, '(')) ? preg_replace( '~ \(.*\) ~' , " ", $u->name ) : $u->name;
            $name = explode(' ', str_replace('  ', ' ', $username));

            $out[] = [
                'fio1' => htmlspecialchars(@$name[0]),
                'fio2' => htmlspecialchars(@$name[1]),
                'fio3' => htmlspecialchars(@$name[2]),
//                'course' => htmlspecialchars(@$u->course),
                'course' => htmlspecialchars(@$course[$u->class]),
                'napr' => htmlspecialchars(@$u->napr_post),
                'prof' => htmlspecialchars(@$u->profile),
                'class' => htmlspecialchars($u->class),
                'pass' => htmlspecialchars($u->pasport_s),
                'pasn' => htmlspecialchars($u->pasport_n),
                'pask' => htmlspecialchars($u->pasport_k),
                'd' => htmlspecialchars($d),
                'm' => htmlspecialchars($m),
                'y' => htmlspecialchars($y),
            ];
        }

        $templateProcessor = new TemplateProcessor('/var/www/html/public/faqres/Obxodnoi_list_zaochka-2020.docx');
        $templateProcessor->cloneRow('u', count($out));

        foreach ($out as $n=>$item) {
            $templateProcessor->setValue('u#'.($n+1), '');
            foreach ($item as $k=>$v) {
                $templateProcessor->setValue($k.'#'.($n+1), $v);
            }
        }

        $templateProcessor->saveAs('/var/www/html/public/tmp/sampledocument2.docx');
        if(ini_get('zlib.output_compression')) ini_set('zlib.output_compression', 'Off');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        header("Content-Disposition: attachment; filename=\"Обходной лист.docx\";");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: ".filesize('/var/www/html/public/tmp/sampledocument2.docx'));
        @readfile('/var/www/html/public/tmp/sampledocument2.docx');
        exit;
    }

    private function get_course($class) {
        preg_match("#\d\d#si",$class,$cur_year);
        $d = (integer) date('y') - $cur_year[0];
//        $this->sem = (date("n") < 7) ? $d*2 : $d*2 + 1;
        $course = (date("n") < 7) ? $d : $d + 1;
        $q = \R::findOne('classsem',"class=? and enabled=1",[$class]);
        if ($q) {
            $sem = 1;
            $q = \R::findOne('classsem',"class=? and enabled=1",[$class]);
            $ns = explode('|',$q->ns);
            for ($s=0;$s<9;$s++) {
                if (empty($ns[$s])) break;
                if (Carbon::parse($ns[$s])->lte(Carbon::now()))
                    $sem = $s+1;
            }
            if ($sem>9) $sem = 9;
//            $this->sem = $sem;
            $course = ceil($sem / 2);
        }
        return $course;
    }

    public function obhodnoyActi() {
        $u = $this->cur_user;
        $date = strtotime($u->pasport_d);
        $month = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
        $d = !empty($u->pasport_d) ? date('d',$date) : '';
        $m = !empty($u->pasport_d) ? $month[date('n',$date)+1] : '';
        $y = !empty($u->pasport_d) ? date('y',$date) : '';
        setlocale(LC_TIME, 'Russian');
        $templateProcessor = new TemplateProcessor(WWW . '/faqres/obhodnoy.docx');
        $templateProcessor->setValue('fio', htmlspecialchars($u->name));
        $templateProcessor->setValue('class', htmlspecialchars($u->class));
        $templateProcessor->setValue('pass', htmlspecialchars($u->pasport_s));
        $templateProcessor->setValue('pasn', htmlspecialchars($u->pasport_n));
        $templateProcessor->setValue('d', htmlspecialchars($d));
        $templateProcessor->setValue('m', htmlspecialchars($m));
        $templateProcessor->setValue('y', htmlspecialchars($y));

        $templateProcessor->saveAs(WWW.'/tmp/sampledocument.docx');
        if(ini_get('zlib.output_compression')) ini_set('zlib.output_compression', 'Off');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        header("Content-Disposition: attachment; filename=\"Обходной лист.docx\";");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: ".filesize(WWW.'/tmp/sampledocument.docx'));
        @readfile(WWW.'/tmp/sampledocument.docx');
        exit;

        die("Успешно");
    }

    public function getStudlistAction() {
        $class = $_GET['class'];
        $studs = \R::getAssoc("select id,`name` from users where class in (".\R::genSlots($class).") order by name",$class);
//        $out = '<option value="" disabled selected>Все студенты</option>';
        $out = '';
        foreach ($studs as $id => $stud) $out .= '<option value="'.$id.'">'.$stud.'</option>';
        echo $out;
        exit;
    }

}