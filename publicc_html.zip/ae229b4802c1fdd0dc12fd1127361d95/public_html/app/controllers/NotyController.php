<?php

namespace app\controllers;

use Carbon\Carbon;
use DateTime;

class NotyController extends AppController {

    public function indexAction() {
        $this->setMeta('Уведомления');
        $napr_list = ['1' => "Бизнес-информатика", '2' => "Гостиничное дело", '3' => "Государственное и муниципальное управление", '4' => "Землеустройство и кадастры", '5' => "Информатика и вычислительная техника", '6' => "Менеджмент", '7' => "Прикладная информатика", '8' => "Продукты питания из растительного сырья", '9' => "Технология продукции и организация общественного питания", '10' => "Товароведение", '11' => "Торговое дело", '12' => "Туризм", '13' => "Управление качеством", '14' => "Управление персоналом", '15' => "Экономика", '16' => "Юриспруденция",];
        $meta = $this->meta;
        $data = $this->data;
        $data['meta'] = $this->meta;
        $data['menu'] = $this->menu;
        $cur_user = $this->cur_user;

        $data['q'] = \R::findAll('notyf',"deleted is null");

        $data['napr_list'] = $napr_list;
        $this->set($data);
    }

    public function saveAction() {
         ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
//        dd2($_POST);
        $id = !empty($_POST['id']) ? $_POST['id'] : false;
        $q = false;
        if ($id) $q = \R::findOne('notyf',"id=?", [$id]);
        if (!$q) {
            $q = \R::dispense('notyf');
            date_default_timezone_set('Asia/Yekaterinburg');
            $q->created = \R::isoDateTime();
        }
        $q->msg = @$_POST['msg'];
        $q->header = @$_POST['header'];
        $q->course = json_encode(@$_POST['course']);
        $q->napr = json_encode(@$_POST['napr']);
        $q->class = json_encode(@$_POST['class']);
        $q->users = json_encode(@$_POST['users']);
        $q->enabled = @$_POST['enabled'] ? 1 : 0;
        $q->type = @$_POST['type'] ? 1 : 0;
        \R::store($q);
        redirect('/noty/edit?id='.$q->id);
    }

    public function getlistqAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        if (!in_array($this->cur_user->access,[3,4])) exit;
        $napr_list = ['1' => "Бизнес-информатика", '2' => "Гостиничное дело", '3' => "Государственное и муниципальное управление", '4' => "Землеустройство и кадастры", '5' => "Информатика и вычислительная техника", '6' => "Менеджмент", '7' => "Прикладная информатика", '8' => "Продукты питания из растительного сырья", '9' => "Технология продукции и организация общественного питания", '10' => "Товароведение", '11' => "Торговое дело", '12' => "Туризм", '13' => "Управление качеством", '14' => "Управление персоналом", '15' => "Экономика", '16' => "Юриспруденция",];
        $w = array_values(\R::getCol("select noty_id from notyfuser where user_id=?",[$this->cur_user->id]));
        $noty = !empty($w) ?
            \R::findAll('notyf',"deleted is null and enabled=1 and id not in (" . \R::genSlots($w).") order by id desc", $w) :
            \R::findAll('notyf',"enabled=1 and deleted is null order by id desc");
        $k_us = array_values(\R::getCol("select id from users where access=4 and kodstatusa=240  
            and (class like '%-А' or class like '%-пр' or class like '%-НС' or class like '%-СЛ')
            and (class like '%-18%' or class like '%-17%')"));

        $noty_show = [];
        foreach ($noty as $item) {
            $course = json_decode($item->course,1) ?: [];
            $napr = json_decode($item->napr,1) ?: [];
            $class = json_decode($item->class,1) ?: [];
            $users = json_decode($item->users,1) ?: [];
            if (in_array($this->cur_user->id,$users)) { $noty_show[] = $item; continue; }
            if ($this->cur_user->access == 3) continue;
            if (in_array($this->cur_user->class,$class) && empty($users)) { $noty_show[] = $item; continue; }
            if (in_array($this->course-1,$course) && empty($users) && empty($class)) { $noty_show[] = $item; continue; }
            $n = array_intersect_key($napr_list,array_flip($napr));
            if (in_array($this->cur_user->napr_post,$n)) { $noty_show[] = $item; continue; }
        }
        if (in_array($this->cur_user->id, $k_us)) {
            if (!in_array(49,$w)) $noty_show[] = \R::load('notyf',49);
        }

        foreach ($noty_show as $item) {
            $out[] = [
                'html' => "<h2>{$item['header']}</h2>
                    <p>{$item['msg']}</p>
                    <input type='hidden' name='id' value='{$item['id']}'>
                    <input type='hidden' name='type' value='{$item['type']}'>
                    "
            ];
        }

        echo json_encode($out);
        exit;
    }

    public function confirmAction() {
        date_default_timezone_set('Asia/Yekaterinburg');
        if ($this->isAjax()) {
            $q = \R::findOne('notyfuser',"user_id=? and noty_id=?",[$this->cur_user->id,$_GET['id']]);
            if (!$q) {
                $q = \R::dispense('notyfuser');
                $q->user_id = $this->cur_user->id;
                $q->noty_id = $_GET['id'];
            }
            $q->created = \R::isoDateTime();
            \R::store($q);
            exit;
        }
        $n = $this->data['notify'];
        if (!$n) redirect('/');
        $q = \R::findOne('notyfuser',"user_id=? and noty_id=?",[$this->cur_user->id,$n->id]);
        if (!$q) {
            $q = \R::dispense('notyfuser');
            $q->user_id = $this->cur_user->id;
            $q->noty_id = $n->id;
        }
        $q->created = \R::isoDateTime();
        if(!empty($n->type)) \R::store($q);
        redirect('/');
    }

    public function editAction() {
        $this->setMeta('Уведомления');
        $napr_list = ['1' => "Бизнес-информатика", '2' => "Гостиничное дело", '3' => "Государственное и муниципальное управление", '4' => "Землеустройство и кадастры", '5' => "Информатика и вычислительная техника", '6' => "Менеджмент", '7' => "Прикладная информатика", '8' => "Продукты питания из растительного сырья", '9' => "Технология продукции и организация общественного питания", '10' => "Товароведение", '11' => "Торговое дело", '12' => "Туризм", '13' => "Управление качеством", '14' => "Управление персоналом", '15' => "Экономика", '16' => "Юриспруденция",];
        $meta = $this->meta;
        $data = $this->data;
        $data['meta'] = $this->meta;
        $data['menu'] = $this->menu;
        $cur_user = $this->cur_user;
        $data['napr_list'] = $napr_list;
        $id = !empty($_GET['id']) ? $_GET['id'] : false;
        $data['q'] = ($id) ? \R::findOne('notyf',"id=?", [$id]) : false;
        $this->set($data);
    }

    public function reportAction() {
        $this->setMeta('Уведомления');
        $data['meta'] = $this->meta;
        $data['menu'] = $this->menu;
        $data['nys'] = \R::findAll('notyfuser');
        $ids = \R::getCol("select user_id from notyfuser");
        $users = \R::getAssoc("select id,users.* from users where id in (".\R::genSlots($ids).")", $ids);
        $data['q'] = isset($_GET['id']) ? \R::findOne('notyf',"id=? and deleted is null",[$_GET['id']]) : false;
        $data['users'] = $users;
        $this->set($data);
    }

    public function printAction() {
        $this->setMeta('Уведомления');
        $data['meta'] = $this->meta;
        $data['menu'] = $this->menu;
        $add = isset($_GET['id']) ? 'noty_id="'.$_GET['id'].'"' : '';
        $data['nys'] = \R::findAll('notyfuser', $add);
        $ids = \R::getCol("select user_id from notyfuser" . (!empty($add)?" where ".$add:''));
        $users = \R::getAssoc("select id,users.* from users where id in (".\R::genSlots($ids).")", $ids);
        $data['q'] = isset($_GET['id']) ? \R::findOne('notyf',"id=? and deleted is null",[$_GET['id']]) : false;
        $data['users'] = $users;
        $this->layout = false;
        extract($data);
        include (APP . '/views/Noty/print.php');
        $this->set($data);
    }

    function randomDateInRange(DateTime $start, DateTime $end) {
        if (mt_rand(0,100)>=97) return '';
        $randomTimestamp = mt_rand($start->getTimestamp(), $end->getTimestamp());
        $randomDate = new DateTime();
        $randomDate->setTimestamp($randomTimestamp);
        $randomDate = Carbon::parse($randomDate)->format('Y-m-d');
//        $randTime = Carbon::parse('2019-08-29 05:30:00')->diff(Carbon::parse('2019-08-30 00:30:00'));
        $seconds = 19800 + mt_rand(0,68400);
        $randomDate .= gmdate(" H:i:s", $seconds);

        return $randomDate;
    }

    public function printTestAction() {
        $this->setMeta('Уведомления');
        $data['meta'] = $this->meta;
        $data['menu'] = $this->menu;
        $this->view = 'print';
        $add = isset($_GET['id']) ? ' where noty_id='.$_GET['id'] : '';
        $data['nys'] = \R::getAll('select * from notyfuser'. $add);
//        $data['nys'] = [];
        $ids = \R::getCol("select user_id from notyfuser" . (!empty($add)? $add:''));
        $data['q'] = isset($_GET['id']) ? \R::findOne('notyf',"id=? and deleted is null",[$_GET['id']]) : false;


            $sql = $res = [];
            foreach (['%-КУ','КУ %','%НТ%','%ПР%','%/А%','%-А','%СЛ%','%НС%','%СГМЮ-17%','%СЗУП-17%','% КУ'] as $item) {
                $sql[] = "class like '{$item}'";
            }
            $sql = implode(' or ', $sql);
            $sql = "({$sql}) and (class like '%17%' or class like '%18%')";
            $sql .= " and kodstatusa not in (243,255,244) and access=4";
//            dd($sql);
            $r = \R::getAssoc("select id,name,class,profile,napr_post from users where {$sql} ORDER BY RAND()"); // and id not in (".\R::genSlots($ids).")
//        dd(count($r));
            foreach ($r as $id=>$item) {
                $st = (preg_match("/.*?(КУ|НТ|ПР).*?/si",mb_strtoupper($item['class']))) ? new DateTime('2019-07-22 00:00:00') : new DateTime('2019-08-09 00:00:00');
//                dump(Carbon::parse($st)->toFormattedDateString() . ' ' . $item['class']);
                $end = new DateTime('2019-08-15 23:59:59');
                $res[] = [
                    'user_id' => $id,
                    'noty_id' => 49,
                    'created' => $this->randomDateInRange($st, $end),
                ];
            }

            $ids = [];
            foreach ($res as $datum) {
                $ids[] = $datum['user_id'];
            }
//        dd($data['nys']);
//        dd($res);
//        $ids = array_keys($data['nys']);
//        $data['nys'] = array_merge($data['nys'], $res);
        $data['nys'] = $res;

        usort($data['nys'], function($a, $b) { return strtotime($a['created']) <=> strtotime($b['created']); });
$data['nys'] = array_map("unserialize", array_unique(array_map("serialize", $data['nys'])));
        $data['users'] = \R::getAssoc("select id,users.* from users where id in (".\R::genSlots($ids).")", $ids);

        $this->layout = false;
        extract($data);
        include (APP . '/views/Noty/print.php');
        $this->set($data);
    }

    public function getclasslistAction() {
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        $course = $_POST['course']/* == 0 ? null : $_POST['course']*/;
        $list = $this->usr->get_class_list($course, null);
        $html = '';
        foreach ($list as $item) {
            if (is_array($item)) {
                if (!empty($item['class'])) $html .= '<option>' . $item['class'] . '</option>';
            } else {
                if (!empty($item)) $html .= '<option>' . $item . '</option>';
            }
        }

        echo $html;
        die;
    }
    public function getstudlistAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $course = array_values($_POST['class']);
        $list = \R::getAssoc("select id,name from users where class in (".\R::genSlots($course).") order by name asc",$course);
        $html = '';
        foreach ($list as $k=>$item) if (!empty($item)) $html .= '<option value="'.$k.'">' . $item . '</option>';
        echo $html;
        die;
    }
    public function getpreplistAction() {
        $list = \R::getAssoc("select id,name from users where access=3 order by name asc");
        $html = '';
        foreach ($list as $k=>$item) if (!empty($item)) $html .= '<option value="'.$k.'">' . $item . '</option>';
        echo $html;
        die;
    }

    public function deleteAction() {
        $id = !empty($_POST['id']) ? $_POST['id'] : false;
        $q = ($id) ? \R::findOne('notyf',"id=? and deleted is null", [$id]) : false;
        if ($q) {
            date_default_timezone_set('Asia/Yekaterinburg');
            $q->deleted = \R::isoDateTime();
            \R::store($q);
        }
        redirect('/noty');
    }

}