<?php


namespace app\controllers;


class WorksController extends AppController {

     public function indexAction() {
        $this->setMeta('Трудоустройство');
        $napr_list = ['1' => "Бизнес-информатика", '2' => "Гостиничное дело", '3' => "Государственное и муниципальное управление", '4' => "Землеустройство и кадастры", '5' => "Информатика и вычислительная техника", '6' => "Менеджмент", '7' => "Прикладная информатика", '8' => "Продукты питания из растительного сырья", '9' => "Технология продукции и организация общественного питания", '10' => "Товароведение", '11' => "Торговое дело", '12' => "Туризм", '13' => "Управление качеством", '14' => "Управление персоналом", '15' => "Экономика", '16' => "Юриспруденция",];
        $meta = $this->meta;
        $data = $this->data;
        $data['meta'] = $this->meta;
        $data['menu'] = $this->menu;
        $cur_user = $this->cur_user;

        $data['ids'] = \R::getCol("select noty_id from worksuser where user_id=?",[$cur_user->id]);
        $data['int_good'] = \R::getCol("select noty_id from worksuser where user_id=? and interested=1",[$cur_user->id]);
        $data['int_bad'] = \R::getCol("select noty_id from worksuser where user_id=? and interested=0",[$cur_user->id]);
        $data['count'] = count($data['ids']) ? \R::count('works',"deleted is null and enabled=1 and id not in (".\R::genSlots($data['ids']).")", $data['ids']) :
            \R::count('works',"deleted is null and enabled=1");

        if ($cur_user->access == 1 && !isset($_GET['view'])) {
            $this->view = 'manager';
            if (isset($_GET['deleted'])) {
                $data['q'] = \R::getAll("select * from works where deleted is not null order by created desc");
            } else {
                $data['q'] = \R::getAll("select * from works where deleted is null order by created desc");
            }
        } else {
            $napr_list = ['1' => "Бизнес-информатика", '2' => "Гостиничное дело", '3' => "Государственное и муниципальное управление", '4' => "Землеустройство и кадастры", '5' => "Информатика и вычислительная техника", '6' => "Менеджмент", '7' => "Прикладная информатика", '8' => "Продукты питания из растительного сырья", '9' => "Технология продукции и организация общественного питания", '10' => "Товароведение", '11' => "Торговое дело", '12' => "Туризм", '13' => "Управление качеством", '14' => "Управление персоналом", '15' => "Экономика", '16' => "Юриспруденция",];

            if (isset($_GET['favorites'])) {
                $data['q'] = count($data['int_good']) ? \R::getAll("select * from works where deleted is null and enabled=1 and id in (".\R::genSlots($data['int_good']).") order by created desc", $data['int_good']) : [];
            } else {
                $data['q'] = count($data['int_bad']) ? \R::getAll("select * from works where date_end >= '".\R::isoDate()."' and deleted is null and enabled=1 and id not in (".\R::genSlots($data['int_bad']).") order by created desc", $data['int_bad']) : \R::getAll("select * from works where date_end >= '".\R::isoDate()."' and deleted is null and enabled=1 order by created desc");
                $data['q'] = count($data['q']) ? array_filter($data['q'], function ($v) {
                    $course = json_decode($v['course'],1) ?: [];
                    $napr = json_decode($v['napr'],1) ?: [];
                    $class = json_decode($v['class'],1) ?: [];
                    $users = json_decode($v['users'],1) ?: [];
//                    if (!count($course) && !count($class) && !count($users)) return true;
                    if (empty($users) || in_array($this->cur_user->id,$users)) return true;
                    if (empty($class) || in_array($this->cur_user->class,$class) && empty($users)) return true;
                    if (empty($course) || in_array($this->course-1,$course) && empty($users) && empty($class)) return true;
                }) : [];
            }
            $data['count'] = count(array_filter($data['q'], function ($v) use ($data) { return count($data['ids']) ? !in_array($v['id'],$data['ids']) : true; }));
        }

        $data['napr_list'] = $napr_list;
        $this->set($data);

        /*$napr_list = ['1' => "Бизнес-информатика", '2' => "Гостиничное дело", '3' => "Государственное и муниципальное управление", '4' => "Землеустройство и кадастры", '5' => "Информатика и вычислительная техника", '6' => "Менеджмент", '7' => "Прикладная информатика", '8' => "Продукты питания из растительного сырья", '9' => "Технология продукции и организация общественного питания", '10' => "Товароведение", '11' => "Торговое дело", '12' => "Туризм", '13' => "Управление качеством", '14' => "Управление персоналом", '15' => "Экономика", '16' => "Юриспруденция",];
        $s = false;
        $w = array_values(\R::getCol("select noty_id from notyfuser where user_id=?",[$this->cur_user->id]));
        $q = !empty($w) ? \R::findAll('notyf',"deleted is null and enabled=1 and id not in (" . \R::genSlots($w).") order by id desc", $w) :
            \R::findAll('notyf',"enabled=1 and deleted is null order by id desc");
//        dd($this->course);
        foreach ($q as $item) {
            $course = json_decode($item->course,1) ?: [];
            $napr = json_decode($item->napr,1) ?: [];
            $class = json_decode($item->class,1) ?: [];
            $users = json_decode($item->users,1) ?: [];
            if (in_array($this->cur_user->id,$users)) { $s = $item; break; }
            if (in_array($this->cur_user->class,$class) && empty($users)) { $s = $item; break; }
            if (in_array($this->course-1,$course) && empty($users) && empty($class)) { $s = $item; break; }
        }
        if (!$s) {
            foreach ($q as $item) {
                $n = array_intersect_key($napr_list,array_flip($napr));
                if (in_array($this->cur_user->napr_post,$n)) { $s = $item; break; }
            }
        }
        return $s;*/
    }

    public function saveAction() {
         ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
//        dd2($_POST);
        $id = !empty($_POST['id']) ? $_POST['id'] : false;
        $q = false;
        if ($id) $q = \R::findOne('works',"id=?", [$id]);
        if (!$q) {
            $q = \R::dispense('works');
            date_default_timezone_set('Asia/Yekaterinburg');
            $q->created = \R::isoDateTime();
        }
        $q->msg = @$_POST['msg'];
        $q->header = @$_POST['header'];
        $q->course = json_encode(@$_POST['course']);
        $q->napr = json_encode(@$_POST['napr']);
        $q->class = json_encode(@$_POST['class']);
        $q->users = json_encode(@$_POST['users']);
        $q->enabled = @$_POST['enabled'] ? 1 : 0;
        $q->price = $_POST['price'];
        $q->employer = $_POST['employer'];
        $q->address = $_POST['address'];
        $q->phone = $_POST['phone'];
        $q->date_end = !empty($_POST['date_end']) ? date("Y-m-d",strtotime($_POST['date_end'])) : null;
        \R::store($q);
        redirect('/works/edit?id='.$q->id);
    }

    public function confirmAction() {
        date_default_timezone_set('Asia/Yekaterinburg');
        $id = $_GET['id'];
        $q = \R::findOne('worksuser',"user_id=? and noty_id=?",[$this->cur_user->id,$id]);
        $watch = false;
        if (!$q) {
            $q = \R::dispense('worksuser');
            $q->user_id = $this->cur_user->id;
            $q->noty_id = $id;
        } else {
            $watch = true;
        }
        $q->created = \R::isoDateTime();
        \R::store($q);
        die($watch?'already':'ok');
    }

    public function confirmiAction() {
        $id = $_GET['id'];
        $q = \R::findOne('worksuser',"user_id=? and noty_id=?",[$this->cur_user->id,$id]);
        if (!$q) {
            $q = \R::dispense('worksuser');
            $q->user_id = $this->cur_user->id;
            $q->noty_id = $id;
            $q->created = \R::isoDateTime();
        }
        $q->interested = $_GET['int'];
        \R::store($q);
        die($_GET['int'] ? 'ok' : 'not');
    }

    public function editAction() {
        $this->setMeta('Трудоустройство');
        $napr_list = ['1' => "Бизнес-информатика", '2' => "Гостиничное дело", '3' => "Государственное и муниципальное управление", '4' => "Землеустройство и кадастры", '5' => "Информатика и вычислительная техника", '6' => "Менеджмент", '7' => "Прикладная информатика", '8' => "Продукты питания из растительного сырья", '9' => "Технология продукции и организация общественного питания", '10' => "Товароведение", '11' => "Торговое дело", '12' => "Туризм", '13' => "Управление качеством", '14' => "Управление персоналом", '15' => "Экономика", '16' => "Юриспруденция",];
        $meta = $this->meta;
        $data = $this->data;
        $data['meta'] = $this->meta;
        $data['menu'] = $this->menu;
        $cur_user = $this->cur_user;
        $data['napr_list'] = $napr_list;
        $id = !empty($_GET['id']) ? $_GET['id'] : false;
        $data['q'] = ($id) ? \R::findOne('works',"id=?", [$id]) : false;
        $this->set($data);
    }

    public function reportAction() {
        $this->setMeta('Трудоустройство');
        $data['meta'] = $this->meta;
        $data['menu'] = $this->menu;
        $data['nys'] = \R::findAll('worksuser');
        $ids = \R::getCol("select user_id from worksuser");
        $users = \R::getAssoc("select id,users.* from users where id in (".\R::genSlots($ids).")", $ids);
        $data['q'] = isset($_GET['id']) ? \R::findOne('works',"id=? and deleted is null",[$_GET['id']]) : false;
        $data['users'] = $users;
        $this->set($data);
    }

    public function printAction() {
        $this->setMeta('Трудоустройство');
        $data['meta'] = $this->meta;
        $data['menu'] = $this->menu;
        $data['nys'] = \R::findAll('worksuser');
        $ids = \R::getCol("select user_id from worksuser");
        $users = \R::getAssoc("select id,users.* from users where id in (".\R::genSlots($ids).")", $ids);
        $data['q'] = isset($_GET['id']) ? \R::findOne('works',"id=? and deleted is null",[$_GET['id']]) : false;
        $data['users'] = $users;
        $this->layout = false;
        extract($data);
        include (APP . '/views/Noty/print.php');
        $this->set($data);
    }

    public function getclasslistAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $course = $_POST['course']/* == 0 ? null : $_POST['course']*/;
        $list = !empty($course) ? $this->usr->get_class_list($course, null) : \R::getAssoc("select distinct class from users where access=4 order by class");
//        var_dump($list); die;
        $html = '';
        foreach ($list as $item) if (!empty($item)) $html .= '<option>' . $item . '</option>';
        echo $html;
        die;
    }
    public function getstudlistAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $course = !empty($_POST['class']) ? array_values($_POST['class']) : false;
        $list = $course? \R::getAssoc("select id,name from users where class in (".\R::genSlots($course).") order by name asc",$course) : [];
        $html = '';
        foreach ($list as $k=>$item) if (!empty($item)) $html .= '<option value="'.$k.'">' . $item . '</option>';
        echo $html;
        die;
    }

    public function deleteAction() {
        $id = !empty($_POST['id']) ? $_POST['id'] : false;
        $q = ($id) ? \R::findOne('works',"id=? and deleted is null", [$id]) : false;
        if ($q) {
            date_default_timezone_set('Asia/Yekaterinburg');
            $q->deleted = \R::isoDateTime();
            \R::store($q);
        }
        $_SESSION['info_msg'][] = 'Успешно удалено!';
        redirect('/works');
    }

    public function restoreAction() {
        $id = !empty($_POST['id']) ? $_POST['id'] : false;
        $q = ($id) ? \R::findOne('works',"id=? and deleted is not null", [$id]) : false;
        if ($q) {
            $q->deleted = null;
            \R::store($q);
        }
        $_SESSION['info_msg'][] = 'Успешно восстановлено!';
        redirect('/works');
    }

}