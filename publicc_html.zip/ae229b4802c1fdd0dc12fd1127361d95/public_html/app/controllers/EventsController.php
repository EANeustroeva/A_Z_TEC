<?php


namespace app\controllers;


use vendor\libs\Event;
use function vendor\libs\parseDateTime;

class EventsController extends AppController {
    public function __construct($route) {
        parent::__construct($route);
    }

    public function indexAction() {
        $data = $this->data;
        $this->setMeta('Расписание');
        $this->view = 'fullcalendar';
        if ($this->cur_user->access < 4)
            $this->layout = 'manager';
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        /*if ($this->cur_user->access == 3) {
            $pr = explode(' ', $this->cur_user->name);
//            \R::fancyDebug(true);
            $rasp = \R::getAll("SELECT r.*,p.sname FROM raspisanie r 
                LEFT OUTER JOIN predmets p ON r.koddisciplini=p.id
                WHERE r.prepod LIKE ? ORDER BY datakal ASC",
                [$pr[0].'%']);
        }
        else */
        if ($this->cur_user->access == 4) {
            /*$rasp = \R::getAll("SELECT r.*,p.sname FROM raspisanie r, predmets p 
                WHERE r.koddisciplini=p.id AND gruppa = ? ORDER BY datakal ASC",
                [$this->cur_user->class]);*/
			$rasp = \R::getAll("SELECT r.* FROM raspisanie r
                WHERE gruppa = ? ORDER BY datakal ASC",
                [$this->cur_user->class]);
    //        dd($rasp);
            $res = [];
            foreach ($rasp as $item) {
                $res[$item['para']][$item['day']] = preg_replace("(\(.+?\))", '', $item['sname']) . ' (' . $item['type'] . ')<br>' . $item['prep'] . ', ' . $item['aud'];
            }

            $data['rasp'] = $rasp;
        }
        $list = $this->usr->get_class_list();
        $html = '';
        foreach ($list as $item) if (!empty($item['class'])) $html .= '<option>' . $item['class'] . '</option>';
        $data['classlist']= $html;
        $this->set($data);
    }

    public function getEventsAction() {
        $this->layout = false;
        require LIBS .'/utils.php';
        if (!isset($_POST['start']) || !isset($_POST['end'])) {
            die("Please provide a date range.");
        }
        $range_start = parseDateTime($_POST['start']);
        $range_end = parseDateTime($_POST['end']);
        $timezone = null;
        if (isset($_GET['timezone'])) {
            $timezone = new DateTimeZone($_POST['timezone']);
        }
/*
        $input_arrays = [['title'=> "ИСУВК (Лек) Семенова А.С., 615/1",
                          'start'=> '2017-07-19T01:00:00',
                          'end'=> '2017-07-19T02:00:00'
                         ],
            ];//json_decode($json, true);
*/
        if ($this->cur_user->access == 4) $class = $this->cur_user->class;
        else $class = $_POST['class'];
        if ($this->cur_user->class == 'ТЕСТ-18') $class = 'ИНО ЗИК-18';

        if ($this->cur_user->access == 3) {
            $pr = explode(' ', $this->cur_user->name);
//            \R::fancyDebug(true);
            if (!empty($class))
            $rasp = \R::getAll("SELECT r.datakal,r.gruppa,r.para,r.zanitie,r.prepod,r.auditorij,p.sname,r.disciplina FROM raspisanie r 
                LEFT OUTER JOIN predmets p ON r.koddisciplini=p.id
                WHERE gruppa = ? AND r.prepod LIKE ? ORDER BY datakal ASC",
                [$class,$pr[0].'%']);
            else $rasp = \R::getAll("SELECT r.datakal,r.gruppa,r.para,r.zanitie,r.prepod,r.auditorij,p.sname,r.disciplina FROM raspisanie r 
                LEFT OUTER JOIN predmets p ON r.koddisciplini=p.id
                WHERE r.prepod LIKE ? ORDER BY datakal ASC",
                [$pr[0].'%']);
        }
        else {
//			ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
            $start = $_POST['start'];
            $range = [];
//            \R::fancyDebug(true);
//            for ($i=0;$i<7;$i++) {
//                $range[] = 'datakal = "'.date("d.m.Y",strtotime($start++)) .'"';
//            }
            $range = implode(' and ', $range);
            $podgr = (isset($_POST['podgr'])) ? $_POST['podgr'] : '';
            /*$rasp = \R::getAll("SELECT r.datakal,r.para,r.zanitie,r.prepod,r.auditorij,p.sname,r.disciplina FROM raspisanie r 
                LEFT OUTER JOIN predmets p ON r.koddisciplini=p.id
                WHERE gruppa = ? AND (podruppa=? OR podruppa IS NULL) ORDER BY datakal ASC",
                [$class, $podgr]);*/
//			$rasp = \R::getAll("SELECT r.* FROM raspisanie r
//                WHERE gruppa = ? AND (podruppa=? OR podruppa='все' OR podruppa IS NULL) ORDER BY datakal ASC",
//                [$class, $podgr]);
			$rasp = \R::getAll("SELECT r.* FROM raspisanie r
                WHERE gruppa = ? ORDER BY datakal ASC",
                [$class]);
        }
//        dd2(date("d.m.Y",strtotime($start)));
//        dd2($rasp);
        $res = [];
        $rasp2 = [];
        foreach ($rasp as $k => $item) {
            $prepod = explode(' ', $item['prepod']);
            if (count($prepod)>2) $prepod = $prepod[0] . " " . mb_substr($prepod[1],0,1,'UTF-8').'.'. mb_substr($prepod[2],0,1,'UTF-8').'.';
            else $prepod = $item['prepod'];
            if (!isset($item['sname'])) $item['sname'] = $item['disciplina'];
            // if (!empty($_POST['view']) && $_POST['view']=='month') {
                // $res[$k]['title'] = preg_replace("(\(.+?\))", '', $item['sname']);
            // } else
            if ($this->cur_user->access == 3) {
                $result = array_filter($rasp2, function($innerArray) use ($item){
                    //return in_array($needle, $innerArray);    //Поиск по всему массиву
                    return ($innerArray['auditorij'] == $item['auditorij']) &&
                           ($innerArray['datakal'] == $item['datakal']) &&
                           ($innerArray['para'] == $item['para']);
                });
                if ($result) {
                    $key = key($result);
                    $res[$key]['title'] .= ",\n{$item['gruppa']}";
                    continue;
                }
                $res[$k]['title'] = $item['auditorij'] . ', ' .preg_replace("(\(.+?\))", '', $item['sname']) . "\n" . $item['gruppa'] ;
            }
            else {
                $podgr = '';
                switch ($item['podruppa']) {
                    case 1: $p_color = '#5cb85c'; $podgr = ' (1подгруппа)'; break;
                    case 2: $p_color = '#d9534f'; $podgr = ' (2подгруппа)'; break;
                    case 3: $p_color = '#f0ad4e'; $podgr = ' (3подгруппа)'; break;
                    default: $p_color = '#337ab7'; break;
                }
                $res[$k]['title'] = $item['auditorij'] . ', '  . $prepod .', '.  preg_replace("(\(.+?\))", '', $item['sname']) . ' (' . $item['zanitie'] . ') ' . $podgr;
                $res[$k]['textColor'] = '#fff';
                $res[$k]['color'] = $p_color;
            }

            $res[$k]['start'] = $item['datakal'].'T0'.$item['para'].':00:00';
            $res[$k]['end'] = $item['datakal'].'T0'.($item['para']+1).':00:00';
            $rasp2[$k] = $item;
        }
        $input_arrays = $res;
//        dd2($input_arrays);
        $output_arrays = array();
        foreach ($input_arrays as $array) {
            $event = new Event($array, $timezone);
            if ($event->isWithinDayRange($range_start, $range_end)) {
                $output_arrays[] = $event->toArray();
            }
        }

        echo json_encode($output_arrays);
        die;
    }

    public function getlistmodalAction() {
        $class = $_POST['class'];
        $plan = \R::getAssoc("SELECT p.disc,pr.sname,p.lektor FROM plan p, predmets pr WHERE p.disc=pr.name AND p.class=? AND p.lektor!='' ORDER BY p.lektor",[$class]);
       // dd($plan);
        $rasp = \R::getAssoc("SELECT auditorij FROM raspisanie WHERE auditorij!='' ORDER BY auditorij");
        $disc = $lekt = $aud = '<option disabled selected hidden value="">Не выбрано</option>';
        foreach ($plan as $k=>$item) {

        }
        foreach ($plan as $k=>$item) {
            $disc .= '<option value="'.$item['sname'].'">'.$k.'</option>';
            $prepod = explode(' ', $item['lektor']);
            if (count($prepod)>2) $prepod = $prepod[0] . ' ' . mb_substr($prepod[1],0,1,'UTF-8').'.'. mb_substr($prepod[2],0,1,'UTF-8').'.';
            if (!strpos($lekt,$prepod)) {
                $lekt .= '<option value="'.$prepod.'">' . $item['lektor'] . '</option>';
            }
        }
        foreach ($rasp as $item) {
            $aud .= '<option>'.$item.'</option>';
        }

        echo json_encode(['disc'=>$disc,'lekt'=>$lekt,'aud'=>$aud]);
        die;
    }
}