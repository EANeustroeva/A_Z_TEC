<?php

namespace app\controllers;


use DateTime;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\TemplateProcessor;

class PracttasksController extends AppController {
    public function indexAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['user'] = $this->cur_user;

        if ($this->cur_user->access == 4) {
            $this->view = 'studs2';
            if ($this->cur_user->id == 13151) {
//                ini_set('error_reporting', E_ALL);
//                ini_set('display_errors', 1);
//                ini_set('display_startup_errors', 1);
                $this->view = 'studs2';
            }
            $disc = $_POST['disc'];
            $sem = $_POST['sem'];
            $class = $this->cur_user->class;

            $curs = \R::findOne('vkruserpract',"user_id=? and disc=? and sem=?",[$this->cur_user->id, $disc, $sem]);
            $data['curs'] = $curs;

            if (!empty($disc)) $mfiles = \R::findAll('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and type=0 and archive=0", [$sem, $class, $disc]);
            if (!empty($disc)) $data['rpd'] = \R::findOne('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and archive=0 and type=1 order by id desc", [$sem, $class, $disc]);
            if (!empty($disc)) $data['fos'] = \R::findOne('mfiles', "sem=? AND (class = ? OR class IS NULL) AND disc=? and archive=0 and type=2 order by id desc", [$sem, $class, $disc]);
            $data['docs'] = $mfiles; //todo semestr
            $data['plan'] = \R::getAssocRow("SELECT * FROM plan WHERE class=? AND disc=? ORDER BY disc", [$this->cur_user->class, $disc])[0];

            $prep = \R::findOne('users','id=?', [$curs->lektor_id]);
            $data['plan']['user_id'] = $prep ? $curs->lektor_id : null;
            $data['plan']['lektor'] = $prep ? $prep->name : null;

            $d_id = $this->usr->get_dialog_with($data['plan']['user_id'], $this->cur_user->id);
            $data['msg'] = json_decode($this->msg->messages($d_id));

//            $cl = addcslashes(json_encode($this->cur_user->class), '\\');
       /*     $data['tasks'] = \R::getAll("SELECT t.* FROM tasks t, plan uc WHERE (t.class IS NULL OR t.class LIKE ?) AND (t.course IS NULL OR t.course = ?) AND t.create_id=uc.user_id AND uc.class=?", ["%$cl%", $this->cur_user->course, $this->cur_user->class]);
            foreach ($data['tasks'] as &$task) {
                $teacher = \R::load('users', $task['user_id']);
                $name = explode(" ", $teacher->name);
                $task['teacher'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
            }*/

            $vid = \R::findOne('mfilesnext',"class=? and disc=? and sem=?",[$class, $disc, $sem]);

            $data['video'] = $vid;
        }

        if (!empty($_POST['disc'])) {
            $data['marks'] = \R::getAssoc("select * from taskwork where stud_id = ? and type='практ' and disc=? and archive=0 order by id desc", [$this->cur_user->id,$_POST['disc']]);
        } else $data['marks'] = [];
//        else $data['marks'] = \R::getAssoc("select * from taskwork where stud_id = ? and type='практ' and archive=0 order by id desc", [$this->cur_user->id]);

        foreach ($data['marks'] as $k=>&$m) {
            $m['task'] = \R::load('mfiles', $m['task_id']);
            $teacher = $data['plan']['lektor'];//\R::load('users', $m['task']['user_id']); //todo
            if ($teacher) {
                $name = explode(" ", $teacher);
                $m['teacher'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
            }
//            if ($this->cur_user->id == 13151) {
                if (!empty($m['work_id'])) {
                    $data['marks'][$m['work_id']]['related'] = $m;
                    unset($data['marks'][$k]);
                }
//            }
        }

        /*if ($data['tasks']) {
            foreach ($data['tasks'] as $k => &$t) {
                $t['predmet_name'] = \R::getRow("SELECT * FROM predmets WHERE id=?", [$t['predmet']])['sname'];
                if (!empty($t['users'])) {
                    $personal = explode("|", $t['users']);
                    $grlist = [];
                    foreach ($personal as $item) {
                        $cl = \R::getRow("SELECT class FROM users WHERE id=?", [(int)$item])['class'];
                        if (!in_array($cl, $grlist)) $grlist[] = $cl;
                    }
                    $t['gruppa'] = $grlist;
                } else $t['gruppa'] = json_decode($t['class']);
                $t['works'] = \R::getAssoc("SELECT * FROM taskwork WHERE task_id=? and type='практ' and archive=0 order by status", [$t['id']]);
                $t['created'] = date("d F", strtotime($t['created'])) . '<span class="hidden-xs">' . date(" H:i:s", strtotime($t['created'])) . '</span>';
                foreach ($t['works'] as $kk=>&$work) {
                    $stud = \R::load('users', $work['stud_id']);
                    $name = explode(" ", $stud->name);
                    $work['stud'] = $stud;
                    $work['name'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
                    $work['created'] = date("d F", strtotime($work['created'])) . '<span class="hidden-xs">' . date(" H:i:s", strtotime($work['created'])) . '</span>';
                    if (!empty($work['work_id'])) {
                        $t['works'][$work['work_id']]['related'] = $work;
                        unset($t['works'][$kk]);
                    }
                }
            }
        }*/

        $this->set($data);
    }

     public function filesAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['user'] = $this->cur_user;

        $res = [];
        for ($sem = 1; $sem<10; $sem++) {
            $plans = \R::findAll('plan',"user_id=? and s{$sem} != '0|0|0|0|0|0|0|0|0'",[$this->cur_user->id]);
            $p = [];
            foreach ($plans as $plan) $p[$plan->disc][] = "'".$plan->class."'";
            foreach ($p as $k=>&$p_) $p_ = 'class in ('. implode(', ', $p_) . ") and disc='{$k}'";
            $sql = implode(' or ', array_values($p));
//            dd($p);
            $files = \R::findAll('mfiles', "sem={$sem} and ({$sql}) and type=0 and archive=0");
            dd(123);
            dd($files);
            $res[$sem] = 0;
        }
//        $mfiles = \R::findAll('mfiles', "course=? AND (class LIKE ? OR class IS NULL) AND disc=? and type=0 and archive=0", [
//            $this->cur_user->course, "%$class%", $disc]);
        $this->set($data);
    }

    public function workviewAction() {
        $data = $this->data;
        if (!isset($_GET['id'])) header("Location: " . BASE_URL . 'tasks');
        $this->view = 'work';
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $t = \R::findOne('mfiles', "id=? and archive=0", [$_GET['id']]);
        $t['works'] = \R::getAll("SELECT * FROM taskwork WHERE task_id=? and type='практ' and archive=0 order by status", [$t['id']]);
        if (!empty($t['works'])) {
            foreach ($t['works'] as &$work) {
                $stud = \R::load('users', $work['stud_id']);
                $name = explode(" ", $stud->name);
                $work['stud'] = $stud;
                $work['name'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
                $work['created_str'] = strtotime($work['created']); //strftime("%d %b %H:%M",strtotime($work['created']));
                $work['created'] = date("d/m/Y",strtotime($work['created'])); //strftime("%d %b %H:%M",strtotime($work['created']));
//                $work['created'] = date("d F", strtotime($work['created'])) . '<span class="hidden-xs">' . date(" H:i:s", strtotime($work['created'])) . '</span>';
            }
        }
        $data['t'] = $t;
//        dd($data['t']);
        $this->set($data);
    }

    public function workstudAction() {
//                ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
        $data = $this->data;
        if (isset($_GET['test'])) $this->view = 'workstudtest';
//        if (!isset($_GET['id'])) header("Location: " . BASE_URL . 'tasks');
        $this->view = 'workstud';
        $this->setMeta('Антиплагиат');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $t['works'] = \R::getAll("SELECT * FROM taskworks WHERE stud_id=? and archive=0 order by status", [$this->cur_user->id]);
        if (!empty($t['works'])) {
            foreach ($t['works'] as &$work) {
                $stud = \R::load('users', $work['stud_id']);
                $name = explode(" ", $stud->name);
                $work['stud'] = $stud;
                $work['name'] = $name[0] . ' ' . mb_substr($name[1], 0, 1, "UTF-8") . '.' . mb_substr($name[2], 0, 1, "UTF-8") . '.';
                $work['created_str'] = strtotime($work['created']); //strftime("%d %b %H:%M",strtotime($work['created']));
                $work['created'] = date("d/m/Y",strtotime($work['created'])); //strftime("%d %b %H:%M",strtotime($work['created']));
//                $work['created'] = date("d F", strtotime($work['created'])) . '<span class="hidden-xs">' . date(" H:i:s", strtotime($work['created'])) . '</span>';
            }
        }
/*
        $data['t'] = [];

        foreach ($t as $item) {
            $data[$t] .= [];
        }*/

        $data['t'] = $t;

//        dd($data['t']);
        $this->set($data);
    }

    public function workstudupluadAction() {
        $this->layout = false;
        if (!isset($_POST['id'])) redirect();
        $uploaddir = WWW . '/upload/works/';
//        $uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
        $uploadfile = $uploaddir . ($_FILES['userfile']['name']);
        $file = $_FILES['userfile'];

        $ext = strtolower(substr(strrchr($file['name'], '.'), 1));
        $ftitle = md5(uniqid()) .  '.' . $ext;
        while (file_exists(WWW. '/ino/' . $ftitle)) {
            $ftitle .= rand(10, 99);
        }
        $res = move_uploaded_file($file['tmp_name'],$uploaddir.$ftitle);
        if (!$res) redirect(BASE_URL . "tasks?disc=" . $_GET['disc']);

        $tasks = \R::dispense('taskworks');
        $tasks->stud_id = $this->cur_user->id;
        $tasks->task_id = $_POST['id'];
        $tasks->disc = $_GET['disc'];
        $tasks->class = $this->cur_user->class;
        $tasks->type = $_POST['type'];
        $tasks->file = $ftitle;
        $tasks->ftitle = $file['name'];
        $tasks->created = \R::isoDateTime();
        \R::store($tasks);

        redirect(BASE_URL . "tasks/workstud");
    }
    public function teststudAction() {
    //        ini_set('error_reporting', E_ALL);
    //ini_set('display_errors', 1);
    //ini_set('display_startup_errors', 1);
        $id = $_GET['id'] ?: null;
        if (!$id) die();
die;
        require LIBS . '/antiplagiat.php';

        $task = \R::findOne('taskworks','id=?',[$id]);
        $file = WWW. '/upload/works/' . $task->file;
        $ap = new \Anti();
//        $test = $ap->soapDebug();
//        die();
//        dd2($test);
        $scor = $ap->get_web_report($file);
        header('Content-Type: application/json');

        if (isset($scor['goodpercentage'])) {
            $score = $scor['goodpercentage'];
            $task->perc = $score;
            $task->pdf = $scor['full_report'];
            \R::store($task);
            die(json_encode(['success' => "{$score}", 'pdf' => $scor['full_report']]));
        }
        die(json_encode($scor));
    }

    public function editAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;

        $data['users'] = \R::getAll("SELECT u.* FROM users u, plan uc WHERE u.class=uc.class AND uc.user_id=?", [$this->cur_user->id]);

        if (!empty($_POST['id'])) {
            $data['tasks'] = \R::load('tasks', $_POST['id']);
            $personal = $data['tasks']['users'];
            if (!empty($personal)) {
                $personal = explode("|", $personal);
                $data['personal'] = $personal;
            }
        }
        else {
            $tasks = \R::dispense('tasks');
            $tasks->createId = $this->cur_user->id;
            $tasks->created = \R::isoDateTime();
            $data['task_id'] = \R::store($tasks);
            $data['tasks'] = \R::load('tasks', $data['task_id']);
        }
//        $data['next'] = \R::getInsertID();
//        dd($data['next']);
        $data['class'] = $this->usr->get_class_list(null, $this->cur_user);
        $data['course'] = $this->usr->get_course_list();
//        $up = \R::getAll("SELECT u.id AS uid, p.id, p.name, p.sname FROM userpred u,predmets p WHERE p.id=u.pred_id AND u.user_id=?", [$this->cur_user->id]);
        $up = \R::getAssoc("SELECT DISTINCT p.name, u.id AS uid, p.id, p.sname FROM plan u LEFT JOIN predmets p ON u.disc=p.name WHERE u.user_id=? AND  p.name!='' ORDER BY p.name", [$this->cur_user->id]);
//        dd($up);
        $data['predmet'] = $up;
        //\R::getAll("SELECT DISTINCT * FROM predmets");

//dd($data['predmet']);
        $task_id = !empty($_POST['id']) ? $_POST['id'] : $data['task_id'];
        $data['files'] = \R::findAll('files', "task_id=?", [$task_id]);

        $this->set($data);
    }

    public function testAction() {
//        ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
        $id = $_GET['id'] ?: null;
        if (!$id) die();
die;
        require LIBS . '/antiplagiat.php';

        $task = \R::findOne('taskwork','id=?',[$id]);
        $file = WWW. '/upload/works/' . $task->file;
        $ap = new \Anti();
//        $test = $ap->soapDebug();
//        die();
//        dd2($test);
        $scor = $ap->get_web_report($file);
        header('Content-Type: application/json');

        if (isset($scor['goodpercentage'])) {
            $score = $scor['goodpercentage'];
            $task->perc = $score;
            $task->pdf = $scor['full_report'];
            \R::store($task);
            die(json_encode(['success' => "{$score}", 'pdf' => $scor['full_report']]));
        }
        die(json_encode($scor));
    }

    public function testcheckAction() {
//        ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
        $id = $_GET['id'] ?: null;
        if (!$id) die();
        $task = \R::findOne('taskwork','id=?',[$id]);
        if (!$task) die();
        echo $task->perc;
        die;
    }

    public function docstitleAction() {
        $disc = isset($_POST['disc']) ? $_POST['disc'] : false;
        $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : false;
        $sem = isset($_POST['sem']) ? $_POST['sem'] : false;
        $title = isset($_POST['title']) ? $_POST['title'] : null;
        if (!$disc || !$user_id || !$sem) die('Ошибка');
        $vkr = \R::findOne('vkruserpract',"sem=? and disc=? and user_id=?",[$sem,$disc,$user_id]);
        if (!$vkr) die('Не найдено');
        $vkr->title = $title;
        \R::store($vkr);
        die("Успешно сохранено!");
    }

    public function docsAction() {
         if (isset($_POST['disc']) && strpos( $_POST['disc'],'|')) {
            list($sem,$disc) = explode('|', $_POST['disc']);
        } else {
            $disc = isset($_POST['disc']) ? $_POST['disc'] : false;
            $sem = isset($_POST['sem']) ? $_POST['sem'] : false;
        }
        $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : false;
        if (!$disc || !$user_id || !$sem ) die('Ошибка');
//        dd2($user_id);
        $vkr = \R::findOne('vkruserpract',"sem=? and disc=? and user_id=?",[$sem,$disc,$user_id]);
        if (!$vkr) die('Не найдено');
        $title = $vkr->title;
        if (empty($title)) die('Тема не указана!');
        $mark = \R::getRow("select * from taskwork where disc=? and stud_id = ? and 
            type='практ' and sem=? order by marked desc",[$disc, $user_id, $sem]);
        if ($mark) {
            if ($mark['mark'] == 6) $mark['mark'] = 'зач';
            if ($mark['mark'] == 7) $mark['mark'] = 'на дораб.';
        }

        $prepod = ($vkr->lektor_id) ? \R::findOne('users',"id=?",[$vkr->lektor_id])->name : '';
        $user = ($vkr->user_id) ? \R::findOne('users',"id=?",[$vkr->user_id])->name : '';
        $mark = ($mark) ? $mark['perc'] : '';

        setlocale(LC_TIME, 'Russian');
        $templateProcessor = new TemplateProcessor(WWW . '/faqres/справка о публикации.docx');
        $templateProcessor->setValue('title', htmlspecialchars($title));
        $templateProcessor->setValue('perc', htmlspecialchars($mark));
        $templateProcessor->setValue('student', htmlspecialchars($user));
        $templateProcessor->setValue('prepod', htmlspecialchars($prepod));

        $templateProcessor->saveAs(WWW.'/tmp/sampledocument.docx');
        if(ini_get('zlib.output_compression')) ini_set('zlib.output_compression', 'Off');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        header("Content-Disposition: attachment; filename=\"Справка о публикации.docx\";");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: ".filesize(WWW.'/tmp/sampledocument.docx'));
        @readfile(WWW.'/tmp/sampledocument.docx');
        exit;

        die("Успешно");
    }

    public function docsbAction() {
//                ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//        foreach ($_POST as $k => $v) $$k = $v;
        $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : false;
         if (isset($_POST['disc']) && strpos( $_POST['disc'],'|')) {
            list($sem,$disc) = explode('|', $_POST['disc']);
        } else {
            $disc = isset($_POST['disc']) ? $_POST['disc'] : false;
            $sem = isset($_POST['sem']) ? $_POST['sem'] : false;
        }
        if (!$disc || !$user_id || !$sem) die('Ошибка');
        $vkr = \R::findOne('vkruserpract',"sem=? and disc=? and user_id=?",[$sem,$disc,$user_id]);
        if (!$vkr) die('Не найдено');
        $title = $vkr->title;
        if (empty($title)) die('Тема не указана!');
        $mark = \R::getRow("select * from taskwork where disc=? and stud_id = ? and 
            type='практ' and sem=? order by marked desc",[$disc, $user_id, $sem]);

        $prepod = ($vkr->lektor_id) ? \R::findOne('users',"id=?",[$vkr->lektor_id])->name : '';
        $user = ($vkr->user_id) ? \R::findOne('users',"id=?",[$vkr->user_id])->name : '';
        $mark = ($mark) ? $mark['comment'] : '';

        setlocale(LC_TIME, 'Russian');
        $templateProcessor = new TemplateProcessor(WWW . '/faqres/Отзыв о работе.docx');
        $templateProcessor->setValue('title', htmlspecialchars($title));
        $templateProcessor->setValue('comment', htmlspecialchars($mark));
        $templateProcessor->setValue('student', htmlspecialchars($user));
        $templateProcessor->setValue('prepod', htmlspecialchars($prepod));

        $templateProcessor->saveAs(WWW.'/tmp/sampledocument2.docx');
        if(ini_get('zlib.output_compression')) ini_set('zlib.output_compression', 'Off');
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        header("Content-Disposition: attachment; filename=\"Отзыв о работе.docx\";");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: ".filesize(WWW.'/tmp/sampledocument2.docx'));
        @readfile(WWW.'/tmp/sampledocument2.docx');
        exit;

        die("Успешно");
    }

    public function saveAction() {
        $this->layout = false;

        $uploaddir = WWW . '/upload/tasks/';
//        $uploadfile = $uploaddir . basename($_FILES['userfile']['name']);


        $uploadfile = $uploaddir . ($_FILES['userfile']['name']);

        move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile);

        if (isset($_POST['id'])) $tasks = \R::load('tasks', $_POST['id']);
        else $tasks = \R::dispense('tasks');
        $tasks->createId = $this->cur_user->id;
        $tasks->title = $_POST['title'];
        $tasks->desc = $_POST['comment'];

        $tasks->type = $_POST['type']; //todo check
        $tasks->predmet = !empty($_POST['predmet']) ? $_POST['predmet'] : null;


        $personal = !empty($_POST['usr_id']) ? $_POST['usr_id'] : null;
//        dd($personal);
        if (!empty($personal)) {
            $tasks->users = implode("|", $personal);
        } else {
            $tasks->users = null;
            $tasks->fac = !empty($_POST['dfac']) ? $_POST['dfac'] : null;
            $tasks->course = !empty($_POST['course']) ? $_POST['course'] : null;
            $tasks->class = !empty($_POST['class']) ? json_encode($_POST['class']) : null;
        }

        if ($_FILES['userfile']['name'] != '') $tasks->taskfile = $_FILES['userfile']['name'];
        $tasks->created = \R::isoDateTime();
        \R::store($tasks);

        redirect();
    }

    public function viewAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['user'] = $this->cur_user;
        $data['cur_user'] = $this->cur_user;

        if (isset($_POST['id'])) {

            $data['files'] = \R::findAll('mfiles', "id=? and archive=0", [$_POST['id']]);
//            $data['task'] = \R::load('tasks', $_POST['id']);
        } else redirect();


        $this->set($data);
    }

    public function workAction() {
        date_default_timezone_set('Asia/Yekaterinburg');
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['user'] = $this->cur_user;
        $data['cur_user'] = $this->cur_user;
//        $this->layout = false;
        $disc = isset($_POST['disc']) ? $_POST['disc'] : false;
        $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : false;
        $sem = isset($_POST['sem']) ? $_POST['sem'] : false;
        $title = isset($_POST['title']) ? $_POST['title'] : null;
        $place = isset($_POST['place']) ? $_POST['place'] : null;
        if (!$disc || !$user_id || !$sem) die('Ошибка');
        $vkr = \R::findOne('vkruserpract',"sem=? and disc=? and user_id=?",[$sem,$disc,$user_id]);
        if (!$vkr) die('Не найдено');
        $vkr->title = $title;
        $vkr->place = $place;
        \R::store($vkr);

        if ($this->cur_user->id == 13151) {
//            ddd($_FILES);
        }
        if (!isset($_POST['id'])) redirect(BASE_URL);
        $uploaddir = WWW . '/upload/works/';
//        $uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
        $uploadfile = $uploaddir . ($_FILES['userfile']['name']);
        $file = $_FILES['userfile'];
        $ext = strtolower(substr(strrchr($file['name'], '.'), 1));
        $ftitle = md5(uniqid()) .  '.' . $ext;
        while (file_exists(WWW. '/ino/' . $ftitle)) {
            $ftitle .= rand(10, 99);
        }
        $res = move_uploaded_file($file['tmp_name'],$uploaddir.$ftitle);
        if ($res) {
            $tasks = \R::dispense('taskwork');
            $tasks->stud_id = $this->cur_user->id;
            $tasks->task_id = $_POST['id'];
            $tasks->disc = $_GET['disc'];
            $tasks->class = $this->cur_user->class;
            $tasks->sem = $_POST['sem'];
            $tasks->type = 'практ';
            $tasks->file = $ftitle;
            $tasks->ftitle = $file['name'];
            $tasks->created = \R::isoDateTime();
            $id =\R::store($tasks);
        }

//        if ($this->cur_user->id == 13151) {
            $file = $_FILES['userfile2'];
            $ext = strtolower(substr(strrchr($file['name'], '.'), 1));
            $ftitle = md5(uniqid()) .  '.' . $ext;
            while (file_exists(WWW. '/ino/' . $ftitle)) {
                $ftitle .= rand(10, 99);
            }
            $res = move_uploaded_file($file['tmp_name'],$uploaddir.$ftitle);
            if ($res && !empty($id)) {
                $tasks = \R::dispense('taskwork');
                $tasks->stud_id = $this->cur_user->id;
                $tasks->task_id = $_POST['id'];
                $tasks->disc = $_GET['disc'];
                $tasks->class = $this->cur_user->class;
                $tasks->sem = $_POST['sem'];
                $tasks->type = 'практ';
                $tasks->file = $ftitle;
                $tasks->ftitle = $file['name'];
                $tasks->work_id = $id;
                $tasks->created = \R::isoDateTime();
                \R::store($tasks);
            }
//        }

//        $this->send('worksend', null, ['%predmet%' => $tasks->disc]);
//        if (!empty($_POST['prep_id'])) $this->send('worknew',$_POST['prep_id'],
//            ['%predmet%' => $tasks->disc, '%fio_stud%' => $this->cur_user->name, '%gruppa%' => $this->cur_user->class]);
//        redirect(BASE_URL);
        $this->set($data);
    }

    public function markAction() {
//   ini_set('error_reporting', E_ALL);
//    ini_set('display_errors', 1);
//    ini_set('display_startup_errors', 1);
        date_default_timezone_set('Asia/Yekaterinburg');
        $this->layout = false;
        $this->view = false;
        if ($this->isAjax()) {
            $id = substr($_POST['id'], 4);
            $mark = !empty($_POST['mark']) ? $_POST['mark'] : null;

            $t = \R::findOne('taskwork', "id=?",[$id]);
            $t->mark = $mark;
            $t->status = 2;
            $t->prep_id = $this->cur_user->id;
            $t->marked = \R::isoDateTime();
            \R::store($t);
            if ($mark == 6) $mark = 'зач.';
            if ($mark == 7) $mark = 'н/зач';
            $this->send('workmark',$t->stud_id,['%predmet%' => $t->disc, '%ocenka%' => $mark]);
            die;
        }
        return false;
    }

    public function commentAction() {
        $data = $this->data;
        $this->setMeta('Задания');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        if (isset($_POST['id'])) {
            $data['id'] = $_POST['id'];
            $data['comment'] = \R::load('taskwork', $data['id'])->comment;
        } else redirect();
        $this->set($data);
    }

    public function comSetAction() {
        $this->layout = false;
        $this->view = false;
        if (isset($_POST['id'])) {
            $comment = \R::load('taskwork', $_POST['id']);
            $comment->comment = isset($_POST['comment']) ? $_POST['comment'] : null;
            \R::store($comment);
        }
//        redirect(BASE_URL . 'tasks');
        die;
    }

    public function uploadtaskAction() {
        $this->layout = false;
        require_once LIBS . '/qqfileuploader.php';

        // list of valid extensions, ex. array("jpeg", "xml", "bmp")
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', "doc", "docs", "xls", "xlsx", "txt", "pdf", "rar", "zip",];
// max file size in bytes
        $sizeLimit = 1 * 1024 * 1024;
//echo BASE_PATH . 'upload/';
        $uploader = new \qqFileUploader($allowedExtensions, $sizeLimit);
        $result = $uploader->handleUpload(BASE_PATH . 'upload/tasks/', FALSE);

// to pass data through iframe you will need to encode all html tags

        if (isset($result['success']) && $result['success']) {
            $file = $result['file'];
//            dd2($result['real']);
            $doc = \R::dispense('files');
            $doc->user_id = $this->cur_user['id'];
            $doc->task_id = $_GET['task'];
            $doc->type = 1;
            $doc->fext = strtolower(substr(strrchr($file, '.'), 1));
            $doc->fname = str_replace('.' . $doc->fext, '', strtolower(substr(strrchr($file, '/'), 1)));
            $doc->ftitle= $result['real'];
            $doc->fsize = round((filesize($file) / 1024), 2);
            $doc->fdata = \R::isoDate();
            \R::store($doc);
            $result['url'] = $this->path_to_url($file);
            unset($result['file']);

            $imgsize = getimagesize($file);
            $result['width'] = $imgsize[0];
            $result['height'] = $imgsize[1];
        }
        echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
        die;
    }

    function path_to_url($path) {
        $path = str_replace('\\', '/', $path);
        return strpos($path, BASE_PATH) === 0 ? BASE_URL . substr($path, strlen(BASE_PATH)) : $path;
    }

    public function deletefileAction() {
        $this->layout = false;
        if (isset($_POST['id'])) {
            \R::trash('files', $_POST['id']);
        }
        $count = \R::count('files', "task_id=?", [$_POST['task']]);
        echo json_encode(['success' => true, 'count' => $count]);
        die;
    }

    public function getTasksAction() {
        $this->layout = false;
        $class = isset($_GET['class']) ? $_GET['class'] : false;
        $disc = isset($_GET['disc']) ? $_GET['disc'] : false;
        $user = isset($_GET['user']) ? $_GET['user'] : false;

        $sql = [];
        if ($class) $sql[] = "class = '{$class}'";
        if ($disc)  $sql[] = "disc = '{$disc}'";
        if ($user)  $sql[] = "stud_id = '{$user}'";
        $sql = implode(' and ',$sql);

        if (!empty($sql)) {
            $works = \R::getAll("SELECT * FROM taskwork WHERE {$sql} and archive=0 order by created desc");
            $html = '';
            foreach ($works as $item) {

                $stud = \R::findOne('users','id = ?',[$item['stud_id']]);

                $html .= '<tr>';

                $html .= "<td>{$item['created']}</td>";
                $html .= "<td>{$stud->name}</td>";
                $html .= "<td>{$item['class']}</td>";
                $html .= "<td style='word-break: break-all; text-align: left;'>{$item['disc']}</td>";
                $html .= "<td>{$item['type']}</td>";
                $html .= (!empty($item['file'])) ? "<td>
                    <a href='upload/works/{$item['file']}' class='btn btn-warning btn-xs' target='_blank'>
                    <span class='glyphicon glyphicon-download'></span>&nbsp;<span class='hidden-xs'>Скачать</span></a></td>" : "<td></td>";

                $mark = '';
                if ($item['mark'] == 6) $mark = 'зач';
                if ($item['mark'] == 7) $mark = 'на дораб.';
                $html .= !empty($item['mark']) ? "<td>{$mark}</td>" : "<td></td>";
                $html .= "<td><span data-id='{$item['id']}' class='btn btn-xs btn-danger remove'><i class='glyphicon glyphicon-remove'></i></span></td>";

                $html .= '</tr>';
            }
            echo $html;
        }
        die;
    }

    public function getListDiscsAction() {
        $this->layout = false;
        if (!empty($_GET['class'])) {
            $class = ($_GET['class'] != '') ? $_GET['class'] : null;
//            $sem = ($_GET['sem'] != '') ? $_GET['sem'] : 1;
            if (!empty($class)) {
                $class_str = "class = '{$class}'";
                if ($this->cur_user->access == 1) {
                    if (!empty($_GET['sem'])) $list = \R::getAssoc("SELECT disc FROM plan WHERE ($class_str) AND s" . $_GET['sem'] . " != '0|0|0|0|0|0|0|0|0' ORDER BY disc"); else $list = \R::getAssoc("SELECT disc FROM plan WHERE $class_str ORDER BY disc");
                } else {
                    if (!empty($_GET['sem'])) $list = \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND s" . $_GET['sem'] . " != '0|0|0|0|0|0|0|0|0' ORDER BY disc", [$this->cur_user->id]); else $list = \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND kafedra<>'' ORDER BY disc", [$this->cur_user->id]);
                }
            }
        }
        $list_str = '';
        foreach ($list as $item) $list_str .= "<option>". $item. "</option>";
        echo $list_str;
        die;
    }

    public function delTaskworkAction() {
        $this->layout = false;
        if (!empty($_GET['id'])) {
            $t = \R::load('taskwork',$_GET['id']);
            $t->archive = 1;
            \R::store($t);
        }
        die;
    }
}