<?php


namespace app\controllers;

use PhpOffice\PhpSpreadsheet\IOFactory;
use vendor\libs\Event;
use function vendor\libs\parseDateTime;
use Whoops\Example\Exception;

class DocsnextController extends AppController {

    public function indexAction() {
//        if ($this->cur_user->access != 1) redirect('view');
        $this->view = 'test2';

        $data = $this->data;
        $this->setMeta('ЭОК');
        $data['meta'] = $this->meta;

//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);

        $docs = \R::findAll('mfilesnext','napr is null order by id desc');

        $out = [];

        try {
//            $xml = simplexml_load_file('http://lib.wbstatic.usue.ru/video/Video.xlsx');
//            $handle = @opendir(PATH . '/upload/xls_data/xl/worksheets');
            //$tmpfname = "test.xlsx";
            $url = "http://lib.wbstatic.usue.ru/video/Video.xlsx";
            $filecontent = file_get_contents($url);
            $tmpfname = tempnam(sys_get_temp_dir(), "tmpxls");
            file_put_contents($tmpfname, $filecontent);

            $excelReader = IOFactory::createReaderForFile($tmpfname);
            $excelObj = $excelReader->load($tmpfname);
            $worksheet = $excelObj->getSheet(0);
            $lastRow = $worksheet->getHighestRow();


//            echo "<table>";
//            $eok = \R::getCol("select fname from mfilesnext where fname like '%usue%'");
            $eok = \R::getAll("select fname,disc,class from mfilesnext where fname like '%usue%'");
            foreach ($eok as $k=>$item) {
                $key = str_replace('.mp4','', str_replace('http://lib.wbstatic.usue.ru/video/','',$item['fname']) );
//                if (empty($eok[$item['fname']])) $eok[$item['fname']] = [];
                $eok[$key][] = $item['class'];
                unset($eok[$k]);
            }
            for ($row = 1; $row <= $lastRow; $row++) {
                $val = $worksheet->getCell('C' . $row)->getValue();
                if (empty($val)) continue;
//                if (!count(array_filter($eok, function ($v) use ($val) {
//                    return strpos($v, $val);
//                })))
                $out[$val] = !empty($eok[$val]) ? $eok[$val] : [];
//                echo "<tr><td>";
//                echo $worksheet->getCell('A'.$row)->getValue();
//                echo "</td><td>";
//                echo $worksheet->getCell('B'.$row)->getValue();
//                echo "</td><tr>";
            }
//            echo "</table>";
//            dd($out);
        } catch (Exception $e) {

        }

        $data['missed'] = $out;
//        if (isset($_GET['qwe'])) dd($out);
        if ($this->isAjax()) {
            require LIBS .'/utils.php';
            if (!isset($_GET['start']) || !isset($_GET['end'])) {
                die("Please provide a date range.");
            }
            $range_start = parseDateTime($_GET['start']);
            $range_end = parseDateTime($_GET['end']);
            $timezone = null;
            if (isset($_GET['timezone'])) {
                $timezone = new \DateTimeZone($_GET['timezone']);
            }

            $course = $_GET['course'] ?: null;
            $sem =    $_GET['sem'] ?: null;
            $class =  $_GET['class'] ?: null;
            $disc =   $_GET['disc'] ?: null;

            if (!$class) die;

            $plan = \R::findAll('plan',"s{$sem} != '0|0|0|0|0|0|0|0|0' and class = ?", [$class]);
            $ns = explode('|', current($plan)->ns);
            $ks = explode('|', current($plan)->ks);

            $output_arrays = [];
            foreach ($ns as $k => $item) {
                if ($ns == '0' || $ks[$k] == '0') continue;
                $event = new Event([
                    'title' => '',
                    'start' => parseDateTime($item)->format('Y-m-d'),
                    'end' => parseDateTime($ks[$k])->format('Y-m-d'),
                    'rendering' => 'background',
                    'color' => '#ff9f89'
                ], $timezone);
                if ($event->isWithinDayRange($range_start, $range_end)) {
                    $output_arrays[] = $event->toArray();
                }
            }

            if ($disc) {
                $docs = \R::findAll('mfilesnext','napr is not null and class = ? and disc = ?order by id desc', [$class, $disc]);
            } else {
                $docs = \R::findAll('mfilesnext','napr is not null and class = ? order by id desc', [$class]);
            }
            foreach ($docs as $item) {
                list($start, $end) = explode('|', $item->napr);
                $disc = $item->disc ?: 'Предмет не выбран';
                $event = new Event([
                    'id' => $item->id,
                    'title' => $disc . ' - ' . $item->ftitle,
                    'start' => parseDateTime($start)->format('Y-m-d'),
                    'end' => parseDateTime($end)->format('Y-m-d'),
                    'color' => $item->descr ?: '#3a87ad'
                ], $timezone);
                if ($event->isWithinDayRange($range_start, $range_end)) {
                    $output_arrays[] = $event->toArray();
                }

            }
//            dd($output_arrays);
            die(json_encode($output_arrays));
            //        $docs = \R::findAll('mfilesnext','order by id desc');

        }

        $data['docs'] = $docs;
        $this->set($data);
    }

    public function instructAction() {
        $data = $this->data;
        $this->setMeta('ЭОК');
        $data['meta'] = $this->meta;
        $this->set($data);
    }

    public function getsemAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        require LIBS .'/utils.php';

        if (!isset($_GET['date']) || !$_GET['class']) die("Please provide a date range.");
        $date = parseDateTime($_GET['date']);
        $class =  $_GET['class'];
        $plan = \R::findOne('plan',"class = ?", [$class]);
        $ks = explode('|', $plan->ks);

        $sem = 1;
        foreach ($ks as $key=>$item) {
            if ($item == 0) continue;
            $k = parseDateTime($item);
            if ($k->diff($date)->format('%R') == '+') $sem = $key+2;
        }
        echo (int)$sem;
        die();
    }

    public function getinfoAction() {
        $f = \R::findOne('mfilesnext',"id=?", [$_POST['id']]);
        list($start, $end) = explode('|', $f->napr);
        $tests = $f->dop ? explode('|', $f->dop) : false;

        $html = '<h4> </h4><div class="form-group">
                    Для группы: <span class="text-danger">'.$f->class.'</span><hr>
                    По предмету: <span class="text-danger">'.$f->disc.'</span><hr>
                    Выбран файл: <span class="text-danger">'.$f->ftitle.'</span><hr>
                    Семестр: <span class="text-danger">'.$f->sem.'</span><hr>
                    Дата начала события: <span class="text-danger">'.$start.'</span><hr>
                    Дата конца события: <span class="text-danger">'.$end.'</span>';

        if ($tests) {
            $html .= '<hr>Связанные тесты: <span class="text-danger"><br>';
            foreach ($tests as $item) {
                $test = \R::findOne('tests',"id=?",[$item]);
                $html .= "<li><a href='/tests/edit?id={$test->id}' style='font-size: 0.8em;' target='_blank'>{$test->title}</a></li>";
            }
            $html .= '</span>';
        }

        $html .= '<hr class="margin-bottom:15px"><div class="form-group">
                    <a class="btn btn-warning form-control" href="/docsnext/edit?id='.$f->id.'">Редактировать</a>
                </div>
                <div class="form-group">
                    <span data-id="'. $f->id .'" class="btn btn-danger form-control del">Удалить</span>
                </div>
            </div>';
        die($html);
    }

    public function getvideosAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $course = !empty($_GET['course']) ? $_GET['course'] : null;
        $sem =    !empty($_GET['sem']) ? $_GET['sem'] : null;
        $class =  !empty($_GET['class']) ? $_GET['class'] : null;
        $disc =   ($_GET['disc'] !== NULL) ? $_GET['disc'] : null;
        if (!$class) die;
        $discs = [];

        if (is_null($disc)) {
            $plan = \R::findAll('plan',"s{$sem} != '0|0|0|0|0|0|0|0|0' and class = ?", [$class]);
            foreach ($plan as $item) { $discs[] = '"'.$item->disc.'"'; }
            $docs = \R::findAll('mfilesnext','sem = ? and class like ? and (disc in ('.implode(',',$discs).') or disc is null) order by id desc',
                [$sem, "%$class%"]);
        } else {
            $docs = \R::findAll('mfilesnext','sem = ? and (class like ? or class is null) and (disc = ? or disc is null) order by id desc',
                [$sem, "%$class%", $disc]);
        }
        $list = '';
        foreach ($docs as $item)
            $list .= '<a href="/docsnext/edit?id='. $item->id .'"  class="btn-xs fc-event" data-toggle="tooltip" title="" data-original-title=""><span>'. $item->ftitle .'</span></a>';
        die($list);
    }

    public function _indexAction() {
        if ($this->cur_user->access == 4)
            redirect('view');
        $data = $this->data;
        $this->setMeta('Документы');

        $arr = [];
        if ($this->cur_user->access == 1 || $this->cur_user->access == 3) {
            $this->view = 'manager';
        }

        switch ($this->cur_user->access) {
            case 1:
                $mfiles = \R::findAll('mfilesnext');
                foreach ($mfiles as $file) {
                    $course = $file['course'] . ' курс';
                    // $napr = $file['napr'];
                    // $s1 = $file['dop'];
                    $s1 = str_replace('|','; ',$file['class']);
                    $s2 = !empty($file['sem']) ? $file['sem'] . ' семестр' : null;
                    $s3 = $file['disc'];
                    $fname = $file['ftitle'];
                    if (empty($s1) && empty($s2) && empty($s3))    $arr[$course][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && empty($s2) && empty($s3))   $arr[$course][$s1][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && empty($s3))   $arr[$course][$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && empty($s2) && !empty($s3))   $arr[$course][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && !empty($s2) && empty($s3))  $arr[$course][$s1][$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && !empty($s3))  $arr[$course][$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && empty($s2) && !empty($s3))  $arr[$course][$s1][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && !empty($s2) && !empty($s3)) $arr[$course][$s1][$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                }
                // dd($arr);
                break;
            case 3:
//                $gr = \R::getAssoc("SELECT class FROM userclass WHERE user_id=? ORDER BY class",[$this->cur_user->id]);
//                $ds = \R::getAssoc("SELECT disc FROM plan WHERE user_id=? ORDER BY disc",[$this->cur_user->id]);
//                foreach ($gr as &$item) $item = "class LIKE '%$item%'";
//                foreach ($ds as &$item) $item = "disc = '$item'";
//                $dsstr = (!empty($ds)) ? ' ('.implode(' OR ', $ds).' OR disc IS NULL)': 'disc IS NULL';
//                $mfiles = \R::findAll('mfiles', '('.implode(' OR ', $gr).') AND '.$dsstr);
                $mfiles = \R::findAll('mfilesnext', "user_id=?",[$this->cur_user->id]);
                foreach ($mfiles as $file) {
                    $s1 = str_replace('|','; ',$file['class']);
                    $s2 = !empty($file['sem']) ? $file['sem'] . ' семестр' : null;
                    $s3 = $file['disc'];
                    $fname = $file['ftitle'];
                    if (empty($s1) && empty($s2) && empty($s3)) $arr[$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && empty($s2) && empty($s3)) $arr[$s1][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && empty($s3)) $arr[$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && empty($s2) && !empty($s3)) $arr[$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && !empty($s2) && empty($s3)) $arr[$s1][$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && !empty($s3)) $arr[$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && empty($s2) && !empty($s3)) $arr[$s1][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (!empty($s1) && !empty($s2) && !empty($s3)) $arr[$s1][$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                }
                break;
            case 4:
                $mfiles = \R::findAll('mfilesnext', "(course=?  OR course IS NULL) AND class=?",
                    [$this->cur_user->course, $this->cur_user->class]);
                foreach ($mfiles as $file) {
                    // $napr = $file['napr'];
                    // $s1 = $file['dop'];
                    $s2 = !empty($file['sem']) ? $file['sem'] . ' семестр' : null;
                    $s3 = $file['disc'];
                    $fname = $file['ftitle'];

                    if (empty($s1) && empty($s2) && empty($s3)) $arr[$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    // if (!empty($s1) && empty($s2) && empty($s3)) $arr[$s1][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && empty($s3)) $arr[$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && empty($s2) && !empty($s3)) $arr[$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    // if (!empty($s1) && !empty($s2) && empty($s3)) $arr[$s1][$s2][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    if (empty($s1) && !empty($s2) && !empty($s3)) $arr[$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    // if (!empty($s1) && empty($s2) && !empty($s3)) $arr[$s1][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                    // if (!empty($s1) && !empty($s2) && !empty($s3)) $arr[$s1][$s2][$s3][$fname] = ['file'=>$file['fname'],'descr'=>$file['descr']];
                }
                break;
        }

        $data['meta'] = $this->meta;
        $data['docs'] = $this->doc->getList($this->cur_user->id);
        $data["full_size"] = $data['docs']["full_size"];
        unset($data['docs']["full_size"]);

        function getListFilesAcc($a, &$i = 0, $lvl = -1) {
            $lvl++;
            $html = $st = '';
            switch ($lvl) {
                case 0:
                    $st = 'area';
                    break;
                case 1:
                    $st = 'equipamento';
                    break;
                case 2:
                    $st = 'ponto';
                    break;

            }
            foreach ($a as $k => $item) {
                if (isset($item['file']) && !is_array($item['file']))
                    $html .= '<a data-toggle="tooltip" title="'.$item['descr'].'" class="list-group-item" href="' . BASE_URL . 'download?f=' . base64_encode('../ino/' . $item['file']) . '&c=' . urlencode($k) . '"><i class="glyphicon glyphicon-open-file"></i> ' . $k . '</a>';
                else {
                    $html .= '
                    <div class="panel panel-default">
                        <div class="panel-heading ' . $st . '">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#collapse' . $i . '" href="#collapse' . ++$i . '">' . $k . '</a>
                            </h4>
                        </div>
                        <div id="collapse' . $i . '" class="panel-collapse collapse">
                            <div class="panel-body">';
                    $html .= getListFilesAcc($item, $i, $lvl);
                    $html .= '</div>
                        </div>
                    </div>';
                }
                $i++;
            }
            return $html;
        }

        $html = '<div class="panel-group" id="collapse0">';
        /************************/
        $i=0;
        $courses = 8;
        for ($j = 1; $j<=$courses; $j++) {
            $ii=0;
            $html .= '
                    <div class="panel panel-default">
                        <div class="panel-heading area">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#collapse' . $i . '" href="#collapse' . ++$i . '">' . $j . ' курс</a>
                            </h4>
                        </div>
                        <div id="collapse' . $i . '" class="panel-collapse collapse">
                            <div class="panel-body">';
//
                            $classes = \R::getAssoc("select class from users where course=? and class<>''",[$j]);
                            foreach ($classes as $class_item) {
                                $html .= '
                                    <div class="panel panel-default">
                                        <div class="panel-heading equipamento">
                                            <h4 class="panel-title">';
                                $ii++;
                                $html .= '
                                                <a data-toggle="collapse" data-parent="#collapse' . $i . '_' . ($ii-1) . '" href="#collapse' . $i . '_' .$ii . '">' . $class_item . '</a>
                                            </h4>
                                        </div>
                                        <div id="collapse' . $i . '_' . $ii . '" class="panel-collapse collapse">
                                            <div class="panel-body">';

                                                for ($jj = 1; $jj <= 6; $jj++) {
                                                    $html .= '
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading ponto">
                                                            <h4 class="panel-title">';
                                                    $html .= '
                                                                <a data-toggle="collapse" data-parent="#collapse' . $i . '_' . $ii . '_' . ($jj-1) . '" href="#collapse' . $i . '_' . $ii . '_' . $jj . '">' . $jj . ' семестр</a>
                                                            </h4>
                                                        </div>
                                                        <div id="collapse' . $i . '_' . $ii . '_' . $jj . '" class="panel-collapse collapse">
                                                            <div class="panel-body">';
                                                                $discs = \R::getAssoc("select disc from plan where class=? and s{$jj} != '0|0|0|0|0|0|0|0|0'",[$class_item]);

                                                    $html .=    '<table>
                                                                    <thead>
                                                                        <tr>
                                                                            <th>Название</th>                                                   
                                                                            <th>РПД</th>                                                   
                                                                            <th>ФОС</th>                                                   
                                                                            <th>Доп. файлы</th>                                                   
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>';
                                                                foreach ($discs as $disc_item) {

                                                                $html .= "<tr>
                                                                            <td>{$disc_item}</td>
                                                                            <td></td>
                                                                            <td></td>
                                                                            <td></td>
                                                                          </tr>";

                                                                }
                                                        $html .=   '</tbody>
                                                                </table>';

                                                $html .=    '</div>
                                                        </div>
                                                    </div>';
                                                }

                                    $html .=    '</div>
                                            </div>
                                        </div>';

                            }

                    $html .= '</div>
                        </div>
                    </div>';
        }

        /************************/
//        $html .= getListFilesAcc($arr);
        $html .= '';
        $html .= '</div>';

        $data['mfiles'] = $html;
/*        if (!function_exists('glob_recursive')) {
            // Does not support flag GLOB_BRACE

            function glob_recursive($pattern, $flags = 0) {
                $files = glob($pattern, $flags);*/
               // foreach (glob(dirname($pattern) . '/*', GLOB_ONLYDIR | GLOB_NOSORT) as $dir) {
               /*     $files = array_merge($files, glob_recursive($dir . '/' . basename($pattern), $flags));
                }

                return $files;
            }
        }*/
      //  $plan = glob_recursive(WWW . "/doc/*/" . $this->cur_user->class . "*");
      /*  if (!empty($plan)) {
            $data['sem'] = $this->doc->getListDir($plan[0]);
            $data['plan'] = str_replace(WWW . '/', '', $plan[0]);
        }*/

        $this->set($data);
    }

    public function uploadAction() {
        $this->layout = false;
        require_once LIBS . '/qqfileuploader.php';

        // list of valid extensions, ex. array("jpeg", "xml", "bmp")
        $allowedExtensions = [];//['jpg', 'jpeg', 'png', 'gif', "doc", "docs", "xls", "xlsx", "txt", "pdf", "rar", "zip",];
// max file size in bytes
        $sizeLimit = 50 * 1024 * 1024;
//echo BASE_PATH . 'upload/';
        $uploader = new \qqFileUploader($allowedExtensions, $sizeLimit);
        $result = $uploader->handleUpload(BASE_PATH . 'upload/docs/', FALSE);

// to pass data through iframe you will need to encode all html tags

        if (isset($result['success']) && $result['success']) {
            $file = $result['file'];
//            dd2(round( (filesize($file)/1024) ,2));
            $doc = \R::dispense('filesnext');
            $doc->user_id = $this->cur_user['id'];
            $doc->type = 0;
            $doc->fext = strtolower(substr(strrchr($file, '.'), 1));
            $doc->fname = str_replace('.' . $doc->fext, '', strtolower(substr(strrchr($file, '/'), 1)));
            $doc->ftitle = $result['real'];
            $doc->fsize = round((filesize($file) / 1024), 2);
            $doc->fdata = \R::isoDate();
            \R::store($doc);
            $result['url'] = $this->path_to_url($file);
            unset($result['file']);

            $imgsize = getimagesize($file);
            $result['width'] = $imgsize[0];
            $result['height'] = $imgsize[1];
        }
        echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
        die;
    }

    function path_to_url($path) {
        $path = str_replace('\\', '/', $path);
        return strpos($path, BASE_PATH) === 0 ? BASE_URL . substr($path, strlen(BASE_PATH)) : $path;
    }

    public function deleteAction() {
        $this->layout = false;
        if (isset($_POST['id'])) {
            \R::trash('mfilesnext', $_POST['id']);
        }
        die();
    }

    public function viewAction() {
        if (empty($_POST['disc'])) redirect(BASE_URL);
        $data = $this->data;
        $this->setMeta("Документы");
        $data['meta']['title'] = "Документы";
        $disc = $_POST['disc'];
        if (!empty($disc)) $mfiles = \R::findAll('mfilesnext', "course=? AND (class=? OR class IS NULL) AND disc=? and archive=0", [$this->cur_user->course, $this->cur_user->class, $disc]);
        $data['docs'] = $mfiles;
        $data['plan'] = \R::getAssocRow("SELECT * FROM plan WHERE class=? AND s".($this->cur_user->course * 2 -1)." != '0|0|0|0|0|0|0|0|0' AND disc=? ORDER BY disc",[$this->cur_user->class,$disc])[0];
//        dd($data['plan']);
        $data['plan']['user_id'] = \R::findOne('users','name=?',[$data['plan']['lektor']])->id;
        $d_id = $this->usr->get_dialog_with($data['plan']['user_id'], $this->cur_user->id);
//        dd($d_id);
        $data['msg'] = json_decode($this->msg->messages($d_id));
//        dd($d_id);
//        dd(json_decode($this->msg->messages(10)));
//        dd($data);
        $this->set($data);
    }

    public function editAction() {
        if ($this->cur_user->access == 4) header("Location: " . BASE_URL . 'docs');
        $data = $this->data;
        $this->setMeta("ЭОК");
        $data['meta']['title'] = "ЭОК";

        $tests = \R::findAll('tests');
        $data['event'] = isset($_GET['id']) ? \R::findOne('mfilesnext',"id = ?", [$_GET['id']]) : false;
        if ($data['event'] and !empty($data['event']['class'])) {
            preg_match("#\d\d#si",$data['event']['class'],$cur_year);
            $d = (integer) 18 - $cur_year[0];
            $data['event']['course'] = (date("n") < 7) ? $d : $d + 1;
        }

        $data['tests'] = $tests;
        $data['fileb'] = \R::findAll('mfilesnext');

        $this->set($data);
    }

    public function uploaduchAction() {
        if (is_null($_FILES['file'])) {
            die;
        };
        $this->layout = false;
        $file = $_FILES['file'];
//        dd($file);
        $ext = strtolower(substr(strrchr($file['name'], '.'), 1));
        $ftitle = md5(uniqid()) .  '.' . $ext;
//        dd(WWW. '/ino/' . $ftitle);
        while (file_exists(WWW. '/ino_videos/' . $ftitle)) {
            $ftitle .= rand(10, 99);
        }
        $res = move_uploaded_file($file['tmp_name'],WWW .'/ino_videos/'.$ftitle);
//            file_put_contents('C:\OpenServer\domains\eduproj.loc\public\tst\ino\\' . $ftitle.'.'.$ext, get_content($url.$file->attr('href')));
//        if (!$res && empty($_POST['fileb'])) header("Location: ". BASE_URL . 'docsnext');

        $f =(!empty($_POST['id'])) ? \R::findOne('mfilesnext',"id=?",[$_POST['id']]) : \R::dispense('mfilesnext');
        if ($res) {
            $f->ftitle = $file['name'];
            $f->fname = $ftitle;
        } elseif (!empty($_POST['fileb'])){
            $fb = \R::findOne('mfilesnext', "id=?", [$_POST['fileb']]);
            $f->ftitle = $fb->ftitle;
            $f->fname = $fb->fname;
        }

        if (!empty($_POST['course'])) $f->course = $_POST['course'];
        if (!empty($_POST['disc'])) $f->disc = $_POST['disc'];
        if (!empty($_POST['class'])) $f->class = $_POST['class'];
        if (!empty($_POST['sem'])) $f->sem =  $_POST['sem'];
        if (!empty($_POST['color'])) $f->descr = $_POST['color'];
        if (!empty($_POST['test'])) $f->dop =  implode("|", $_POST['test']);

        $f->napr = $_POST['start'] . '|' . $_POST['end'];

        if ($this->cur_user->access == 3) $f->user_id = $this->cur_user->id;
//            dd($f->export());
        \R::store($f);

        redirect();

         echo json_encode(['success' => '<h4>Успешно загружено</h4>']);
        // echo '<a href="'.BASE_URL.'docs" class="btn btn-success">Вернуться назад</a>';
//        header("Location: ". BASE_URL . 'docs');
        die;
    }

    public function getListDiscAction() {
        $this->layout = false;
        if (!empty($_GET['class'])) {
            $class = ($_GET['class'] != '') ? $_GET['class'] : null;
            $sem = ($_GET['sem'] != '') ? $_GET['sem'] : 1;
            if (!empty($class)) {
//                foreach ($class as &$item) $item = 'class = "'.$item.'"';
//                $class_str = implode(' OR ', $class);
                $class_str = "class = '{$class}'";
                if ($this->cur_user->access == 1) {
                    if (!empty($sem)) $list = \R::getAssoc("SELECT disc FROM plan WHERE ($class_str) AND s".$sem." != '0|0|0|0|0|0|0|0|0' ORDER BY disc");
                    else $list = \R::getAssoc("SELECT disc FROM plan WHERE $class_str ORDER BY disc");
                }
                else {
                    if (!empty($_GET['sem'])) $list = \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND s".$_GET['sem']." != '0|0|0|0|0|0|0|0|0' ORDER BY disc",[$this->cur_user->id]);
                    else $list = \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND kafedra<>'' ORDER BY disc",[$this->cur_user->id]);
                }
            }

            $html3 = $html4 = $html5 = '';

            $html5 = '<table class="table table-striped table-hover table-bordered table-responsive">
<thead>
    <tr>
        <th style="width: 40%;">Название предмета</th>
        <th>Доп. файлы</th>
    </tr>                
</thead>
<tbody>';

            $html = '<table class="table table-striped table-hover table-bordered table-responsive">
<thead>
    <tr>
        <th style="width: 40%;">Название предмета</th>
        <th>РПД</th>
        <th>ОС</th>
        <th>Доп. файлы</th>
    </tr>                
</thead>
<tbody>';
            $vkr = array_values(\R::getAssoc("select disc from vkrclass_ where class=? and sem=?",[$class,$sem]));
//            dd2($vkr);
            foreach ($list as $item) {
                $html3 .= '<option>' . $item . '</option>';
                $vkr_sel = in_array($item,$vkr) ? ' selected' : '';
                $html4 .= '<option'.$vkr_sel.'>' . $item . '</option>';
                $files = \R::findAll('mfilesnext',"class=? and sem=? and disc=? and archive=0",[$class, $sem, $item]);
                $files_str = [];
                $rpd = $fos = '';
                foreach ($files as $file) {
                    if ($file->type == 1) { $rpd = "<span style='cursor: pointer' data-id='{$file->id}' title='{$file->ftitle}' class='label label-success'><i class='glyphicon glyphicon-file'></i></span>"; continue; }
                    if ($file->type == 2) { $fos = "<span style='cursor: pointer' data-id='{$file->id}' title='{$file->ftitle}' class='label label-success'><i class='glyphicon glyphicon-file'></i></span>"; continue; }
                    $label = mb_strimwidth($file->ftitle, 0, 25, '..');
                    $files_str[] = "<span style='cursor: pointer' data-id='{$file->id}' title='{$file->ftitle}' class='label label-success'>{$label}</span>";
                }
                $files = implode(' ', $files_str);
                $rflag = ($rpd!='' && $fos!='') ? '':'danger';
//<a type="button" class="close" data-dismiss="alert" aria-label="Close">
//                    <span aria-hidden="true">&times;</span>
//                </a>

                $files2 = \R::findAll('mfilesnext',"class=? and sem=? and disc=? and archive=0",[$class, $sem, $item]);
                $files_str2 = [];
                foreach ($files2 as $file) {
                    $label = mb_strimwidth($file->ftitle, 0, 25, '..');
                    $files_str2[] = "<span style='cursor: pointer' data-id='{$file->id}' title='{$file->ftitle}' class='label label-success'>{$label}</span>";
                }
                $files2 = implode(' ', $files_str);
                $html5 .= "<tr class=''>";
                $html5 .=    "<td class='text-left'>{$item}</td>";
                $html5 .=    '<td class="text-left"><button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-plus" data-toggle="modal" data-target="#exampleModal" data-whatever="'.$item.'" data-doctype="файл"></button> '.$files2.'</a></td>';
                $html5 .= '</tr>';

                $html .= "<tr class='{$rflag}'>";
                $html .=    "<td class='text-left'>{$item}</td>";
                $html .= ($rpd=='') ? '<td class="text-left"><button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-plus" data-toggle="modal" data-target="#exampleModal" data-whatever="'.$item.'" data-doctype="РПД"></button></a></td>' : "<td>{$rpd}</td>";
                $html .= ($fos=='') ? '<td class="text-left"><button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-plus" data-toggle="modal" data-target="#exampleModal" data-whatever="'.$item.'" data-doctype="ФОС"></button></a></td>' : "<td>{$fos}</td>";
                $html .=    '<td class="text-left"><button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-plus" data-toggle="modal" data-target="#exampleModal" data-whatever="'.$item.'" data-doctype="файл"></button> '.$files.'</a></td>';
                $html .= '</tr>';
            }
            $html .= '</tbody></table>';
            $html5 .= '</tbody></table>';

            $html2 = '';
            if ($class) {
                $class2 = explode('-',$class);
                $list = \R::getAll("SELECT DISTINCT class FROM users WHERE class like '{$class2[0]}-{$class2[1]}%' ORDER BY class ASC");
                foreach ($list as $item) if (!empty($item['class'])) $html2 .= '<option>' . $item['class'] . '</option>';
            }


            header('Content-Type: application/json');
            echo json_encode(['res' => $html,'res2' => $html2,'res3' => $html3,'res4' => $html4,'res5' => $html5]);
//            echo $html;
        }
        die;
    }

    public function dubAction() {
        $discs = $_POST['discs'];
        $in = $_POST['class'];
        $out = $_POST['class2'];
        if (empty($in) || empty($out)) die;
        $disc = \R::findAll('mfilesnext',"class=? and archive=0",[$in]);
        foreach ($disc as $item) {
            if (!in_array($item->disc, $discs)) continue;
            $dub = \R::duplicate($item);
            $dub->class = $out;
            \R::store($dub);
        }
        echo '1';
        die;
    }

    public function getFileByIdAction() {
        $this->layout = false;

        $file = \R::load('mfilesnext', $_GET['id']);
        $file->link = '<a title="'.$file['descr'].'" class="list-group-item" href="' . BASE_URL . 'download?f=' . base64_encode('../ino/' . $file->fname) . '&c=' . urlencode($file['ftitle']) . '"><i class="glyphicon glyphicon-open-file"></i> ' .$file['ftitle'] . '</a>';
        echo json_encode($file);

        die;
    }

    public function savedocAction() {
        $this->layout = false;
        $file = \R::load('mfilesnext', $_GET['id']);
        $file->descr = $_GET['descr'];
        $file->type = $_GET['type'];
        \R::store($file);

        die;
    }

    public function deletedocAction() {
        $this->layout = false;
        $file = \R::load('mfilesnext', $_GET['id']);
        $file->archive = 1;
        \R::store($file);

        die;
    }

    public function incdocsAction() {
        if ($this->cur_user->access != 1) redirect();
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        $data = $this->data;
        $this->setMeta('Отчеты');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        if (!empty($_POST['course'])) {
            $course = $_POST['course'];
            $sem = $_POST['sem'];
            $classes = \R::getAssoc("select distinct class from users 
              where course=? and class is not null",[$course]);
            foreach ($classes as $k => $class) {
                /*$prof = \R::findOne(" select prof from classprof where class=?",[$class]);
                if ($prof) {
                    $discs = \R::findOne(" select disc from compdisc where prof=?",[$prof->prof]);
                    $discs = explode('|',$item['disc']);
                }*/


                $discs = [];
                $list = \R::getAssoc("SELECT disc FROM plan WHERE class='{$class}' AND s{$sem} != '0|0|0|0|0|0|0|0|0' ORDER BY disc");
                foreach ($list as $item) {
                    $c1 = \R::count('mfilesnext', "class=? and type=0 and sem=? and disc=? and archive=0", [$class, $sem, $item]);
                    $c2 = \R::count('mfilesnext', "class=? and type=1 and sem=? and disc=? and archive=0", [$class, $sem, $item]);
                    $c3 = \R::count('mfilesnext', "class=? and type=2 and sem=? and disc=? and archive=0", [$class, $sem, $item]);
                    if ($c1 == 0 || $c2 == 0 || $c3 == 0) {
//                        dd($c1);
                        if ($c1 == 0) $discs[$item][0] = true;
                        if ($c2 == 0) $discs[$item][1] = true;
                        if ($c3 == 0) $discs[$item][2] = true;
                    }
                }
//                dd($discs);
                if (empty($discs)) unset($classes[$k]);
                else $classes[$k] = $discs;
            }
//            dd($classes);
            $data['docs'] = $classes;
            if (!empty($_POST['print'])) {
                $this->layout = false;
                $html = '';
                if (!empty($data['docs'])) {
                    $html = '
    <table border="1" class="table table-bordered">
        <thead>
        <tr>
            <th>Группа</th>
            <th>РПД</th>
            <th>ФОС</th>
            <th>Задания</th>
        </tr>
        </thead>
        <tbody>';
        foreach ($data['docs'] as $k => $item) {
            $html .= '<tr>
                <td>'. $k .'</td>
                <td class="text-left">';
            foreach ($item as $key => $value) { if (isset($value[1])) $html.= "<li>{$key}</li>"; }
            $html .= '</td>
                <td class="text-left">';
            foreach ($item as $key => $value) { if (isset($value[2])) $html.= "<li>{$key}</li>"; }
            $html .= '</td>
                <td class="text-left">';
            foreach ($item as $key => $value) { if (isset($value[0])) $html.= "<li>{$key}</li>"; }
            $html.='</td>
            </tr>';
        }
        $html .= '</tbody>
    </table>';
                }

                echo $html;
                die;
            }
        }
//        $data['docs'] = \R::getAll('select * from classad');
        $this->set($data);
    }

    public function genloginAction() {
//      ini_set('max_execution_time', 9000);
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $class = isset($_POST['class']) ? $_POST['class'] : null;
        $html = '';
        if ($class) {
            $html .= "<div>
                        <div style='float: left;font-size: 1.17em;font-weight: bold;'>Регистрация обучающихся ИНО в КИИС модуль \"Студент ИНО\"*</div>
                        <div style='float: right;'>Форма 144</div></div><div style='clear: both'></div>";

            $html .= "<h3 style='text-align: center; margin: 0;'>Группа {$class}</h3>";
            $users = \R::findAll('users',"access=4 and class=? order by name",[$class]);
            $html .= "<table border='1' style='border-collapse:collapse;width: 100%;'>";
            $html .= "<tr>";
                $html .= "<th align='center'>№</th>";
                $html .= "<th>Фамилия Имя Отчество</th>";
                $html .= "<th>Логин</th>";
                $html .= "<th>Подпись</th>";
                $html .= "</tr>";
            $ct = 0;
            foreach ($users as $user) {
                $ct++;
                $html .= "<tr>";
                $html .= "<td align='center'>{$ct}</td>";
                $html .= "<td>{$user->name}</td>";
                $html .= "<td align='center'>{$user->login}</td>";
                $html .= "<td width='100'>&nbsp</td>";
                $html .= "</tr>";
            }
            $html .= "</table>";
            $html .= "<p style='margin: 0;'>* - пароль задаётся самим студентом непосредственно при первом входе на портал</p>";
        } else $html = "Группа не выбрана!";

        echo $html;
        die;

        require_once LIBS . '/../phpdocx/phpdocx/Classes/Phpdocx/Create/CreateDocx.inc';
        $docx = new \Phpdocx\Create\CreateDocx();
        $options = [
            'parseDivsAsPs'  => true,
            'baseURL'        => 'http://en.wikipedia.org/',
            'downloadImages' => true,
            'parseFloats' => true,
            'marginTop' => '571', 'marginRight' => '571', 'marginBottom' => '571', 'marginLeft' => '571'
        ];
        $docx->modifyPageLayout('A4', ['marginTop' => '571', 'marginRight' => '571', 'marginBottom' => '571', 'marginLeft' => '571',]);
        $docx->embedHTML($html,$options);
        $docx->createDocxAndDownload ('AccessLogins', true);
        die;
    }
}