<?php


namespace app\controllers;


use vendor\core\base\Controller;

class VkrdistrController extends AppController {

    public function indexAction() {
        if ($this->cur_user->access == 4) redirect(BASE_URL . '/vkrdistr/stud');
        $data = $this->data;
        $this->setMeta('Распределение нагрузки');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $prep = \R::findAll('users','access=3');
        $list = [];
        foreach ($prep as $item) {
            $list .= "<option value='{$item->id}'>{$item->name}</option>";
        }
        $data['prepod'] = $list;

        $id = $this->cur_user['id'];
        $this->layout = $this->cur_user->access == 4 ? 'stud' : 'manager';

//        dd($this->layout);

        $vkr_access = \R::getAssoc("select user_id from vkraccess");
        $managers = \R::getAssoc("select id,name from users where access = 1 and id!=1");
        $prepods = \R::getAssoc("select id,name from users where access = 3 order by name");
        $users = $users2 = $users_ = $users2_ = '';
        foreach ($managers as $k => $item) {
            if (in_array($k, $vkr_access)) $users_ .= "<option value='{$k}'>{$item}</option>";
            $users .= "<option value='{$k}'>{$item}</option>";
        }
        foreach ($prepods as $k => $item) {
            if (in_array($k, $vkr_access)) $users_ .= "<option value='{$k}'>{$item}</option>";
            $users2 .= "<option value='{$k}'>{$item}</option>";
        }
        $data['users'] = '<optgroup label="Менеджеры">'.$users.'</optgroup>';
        $data['users'] .= '<optgroup label="Преподаватели">'.$users2.'</optgroup>';
        $data['users_'] = '<optgroup label="Менеджеры">'.$users_.'</optgroup>';
        $data['users_'] .= '<optgroup label="Преподаватели">'.$users2_.'</optgroup>';
        $this->view = 'test';
        if (isset($_GET['test2'])) $this->view = 'test';
        $this->set($data);
    }

    public function studAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);

        $data = $this->data;
        $this->view = 'stud';
        $this->setMeta('Распределение нагрузки');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['uid'] = $id = $this->cur_user['id'];
        $sem2 = $this->cur_user->course * 2;
        $data['plan2'] = \R::getAssoc("SELECT * FROM plan WHERE class=? AND s{$sem2} != '0|0|0|0|0|0|0|0|0' ORDER BY disc", [$this->cur_user->class]);

        foreach ($data['plan2'] as $k => $item) {
            $mark = array_values(\R::getAll("select mark,type from taskwork where disc=? and stud_id = ? and mark is not null", [$item['disc'], $this->cur_user->id]));
            $marks = [];
            foreach ($mark as &$i) {
                if ($i['mark'] == 6) $i['mark'] = 'зач';
                if ($i['mark'] == 7) $i['mark'] = 'на дораб.';
//                    $marks[] = "{$i['type']}:<b>{$i['mark']}</b>";
                $marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['type']}:<b>{$i['mark']}</b>".'</span>';
            }
            $t_marks = [];
            $usp = \R::findAll('uspevaemost',"gruppa=? and fam = ? and disciplina = ? and semestr=?",
                [$this->cur_user->class, $this->cur_user->name, $item['disc'], $sem2]);
//                if ($item['disc'] == 'Информационные технологии в управлении') { dump($usp); die; }
//                dd2($usp);
            // and othetnost in ('Экзамен', 'Зачет', 'Дифференцированный зачет', 'Аттестация')
            foreach ($usp as $i) {
                switch ($i['othetnost']) {
                    case 'Экзамен': $i['othetnost']='экз'; break;
                    case 'Зачет': $i['othetnost']='зач'; break;
                    case 'Дифференцированный зачет': $i['othetnost']='диф.з'; break;
                    case 'Аттестация': $i['othetnost']='атт'; break;

                    case 'Домашняя контрольная работа': $i['othetnost']='д.к/р'; break;
                    case 'Аудиторная контрольная работа': $i['othetnost']='ауд.к/р'; break;
                    case 'Курсовая работа': $i['othetnost']='курс/р'; break;
                    case 'Курсовой проект': $i['othetnost']='курс/пр'; break;
                }

                if (!empty( $i['ocenka'])) {
                    if ($i['othetnost']!=='экз'   &&
                        $i['othetnost']!=='зач'   &&
                        $i['othetnost']!=='диф.з' &&
                        $i['othetnost']!=='атт') {
                        $marks[] =   '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['othetnost']}:<b>{$i['ocenka']}</b>".'</span>';
                    } else {
                        $t_marks[] = '<span class="btn btn-xs btn-default" style="margin: 2px 2px 2px 0;">'."{$i['othetnost']}:<b>{$i['ocenka']}</b>".'</span>';
                    }
                }
            }
            $data['plan2'][$k]['marks'] = !empty($marks) ? implode(' ',$marks) : '';
            $data['plan2'][$k]['total_marks'] = !empty($t_marks) ? implode(' ', $t_marks) : '';
            $parse = explode('|',$item["s$sem2"]);
            if ($parse[4]==0 && ($parse[5]!=0 || $parse[7]!=0)
                && $parse[0]==0 && $parse[1]==0 && $parse[2]==0
                && $parse[3]==0 && $parse[6]==0 && $parse[8]==0
                && empty($t_marks)) $data['plan2'][$k]['total_marks'] = 'Без оценки';
            if ($this->cur_user->course==1 && $parse[4]==1) $data['plan2'][$k]['total_marks'] = 'Тестирование';
        }

        $this->set($data);
    }

    public function getVkrTasksAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $this->layout = false;
        $class = isset($_GET['class']) ? $_GET['class'] : false;
//        $disc = isset($_GET['disc']) ? $_GET['disc'] : false;
        $sem = isset($_GET['sem']) ? $_GET['sem'] : false;

        $sql = [];
//        if ($class) $sql[] = "class='{$class}'";
//        if ($disc) $sql[] = "disc='{$disc}'";
//        if ($sem) $sql[] = "sem='{$sem}'";
//        $sql = implode(' and ', $sql);

        $html = [];

        $vkr_user = \R::getAssoc("select * from vkruser where sem='{$sem}' and lektor_id is not null order by user_id and status!=2");

        foreach ($vkr_user as $item) {
            $st = \R::findOne('users',"id=?", [$item['user_id']]);
            $pr = \R::findOne('users',"id=?", [$item['lektor_id']]);
            if ($class) if ($st->class != $class) continue;
            $c_class = addcslashes(json_encode( $st['class']),'\\');
            $c_disc = addcslashes(json_encode( $item['disc']),'\\');

            $ua = \R::findOne('vkraccess',"class like ? and disc like ?",["%$c_class%", "%$c_disc%"]);
            $uac = $ua ? \R::findOne('users',"id=?",[$ua['user_id']])['name'] : '';

            $html[] = [$st->name, $st->class, $item['disc'], $uac, $pr->name, 'Лектор'];
        }
        header('Content-Type: application/json');
        die(json_encode(['data' => $html]));
    }

    public function getVkrAccessTableAction() {
//        ini_set('error_reporting', E_ALL);
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
        $this->layout = false;
        $class = isset($_GET['class']) ? $_GET['class'] : false;
        $disc = isset($_GET['disc']) ? $_GET['disc'] : false;


        $sql = [];
//        if ($class) $sql[] = "class='{$class}'";
//        if ($disc) $sql[] = "disc='{$disc}'";
//        $sql = !empty($sql) ? implode(' and ', $sql) : 1;

        $html = [];

        $vkr_user = \R::findAll('vkraccess');

        foreach ($vkr_user as $item) {
            if (($item['class'] == 'null') && ($item['disc'] == 'null')) continue;
            $st = \R::findOne('users',"id=?", [$item['user_id']]);

            $d_class = !is_null($item['class']) ? json_decode($item['class'],1) : null;
            $d_disc = json_decode($item['disc'],1);
//            dd($d_napr == null);
            $class = !is_null($d_class) ? implode(', ', $d_class) : '';
            $disc = !is_null($d_disc) ? implode(', ', $d_disc) : '';
//            $pr = \R::findOne('users',"id=?", [$item['lektor_id']]);
//            if ($class) if ($st->class != $class) continue;
//            $c_class = addcslashes(json_encode( $st['class']),'\\');
//            $c_disc = addcslashes(json_encode( $item['disc']),'\\');

//            $ua = \R::findOne('vkraccess',"class like ? and disc like ?",["%$c_class%", "%$c_disc%"]);
//            $uac = $ua ? \R::findOne('users',"id=?",[$ua['user_id']])['name'] : '';

            $html[] = [$st->name, $class, $disc];
        }
        header('Content-Type: application/json');
        die(json_encode(['data' => $html]));
    }

    public function getTasksAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $this->layout = false;
        $user = isset($_GET['user']) && $_GET['user']!='null' ? $_GET['user'] : false;
        $class = isset($_GET['class']) && $_GET['class']!='null' ? $_GET['class'] : false;
        $disc = isset($_GET['disc']) && $_GET['disc']!='null' ? $_GET['disc'] : false;
        $sem = isset($_GET['sem']) && $_GET['sem']!='null' ? $_GET['sem'] : false;
        $print = isset($_GET['print']) && $_GET['print']!='null' ? $_GET['print'] : false;

        $html = [];
        $sql = [];

        if (!$user || $user == 1) die(json_encode(['data' => []]));;
        $mgr = \R::findOne('vkraccess',"user_id=?", [$user]);
        $mgr_ = \R::findOne('users',"id=?",[$user]);

        $m_class = json_decode($mgr->class,1);
        $m_disc = json_decode($mgr->disc,1);
//        $m_users = json_decode($mgr->users,1);

        if (is_null($m_class) || is_null($disc)) die(json_encode(['data' => []]));;

        if ($class) $sql[] = "class = '{$class}'";
        else { foreach ($m_class as &$item) $item = "'".$item."'"; $sql[] = "class in (".implode(',',$m_class).")"; }

        if ($disc) $sql[] = "disc = '{$disc}'";
        elseif (!empty($m_disc)) { foreach ($m_disc as &$item) $item = "'".$item."'"; $sql[] = "disc in (".implode(',',$m_disc).")"; }
//        if (!is_null($m_users)) { foreach ($m_users as &$item) $item = "'".$item."'"; $sql[] = "lektor_id in (".implode(',',$m_users).")"; }

        $sql = 'and '.implode(' and ', $sql);
        $vkr_class = \R::findAll('vkrclass',"sem=? {$sql}",[$sem]);
$i = 0;
        foreach ($vkr_class as $vkr_c) {
            $class_ = $vkr_c->class;
            $disc_ = $vkr_c->disc;
            $studs = \R::findAll('users',"class=? and kodstatusa=240 order by name",[$class_]);
            foreach ($studs as $stud) {
                $prep = \R::findOne('vkruser',"disc=? and user_id=? and lektor_id is not null and status!=2",[$disc_, $stud->id]);
                $prep_ = $prep ? \R::findOne('users','id=?', [$prep->lektor_id])->name : '';

                $button = '<button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-pencil pull-right" 
                    data-toggle="modal" data-target="#exampleModal2" data-userid="'.$stud->id.'" data-predmet="'.$disc_.'"></button>';
                $status = '';
                if ($prep) switch ($prep->status) {
                    case 0: $status = 'Лектор'; break;
                    case 1: $status = 'Промежуточный контроль'; break;
                    case 2: $status = 'Руководитель курсовой'; break;
                    case 3: $status = 'Проверяющий контрольной'; break;
                }
                $html[] = [$stud->id.'|'.$disc_, ++$i, $stud->name, $class_, $disc_, $mgr_->name, $prep_, $status, $button];
            }
        }
        if ($print) {
            $table = "<table border='1' style='border-collapse:collapse;width: 100%;font-size: 0.75em;'>";
            $table .= "<tr>";
                $table .= "<th align='center'>№</th>";
                $table .= "<th align='left'>ФИО Студента</th>";
                $table .= "<th>Группа</th>";
                $table .= "<th>Предмет</th>";
                $table .= "<th>Ответственный</th>";
                $table .= "<th>ФИО Преподавателя</th>";
                $table .= "<th>Статус</th>";
            $table .= "</tr>";
            foreach ($html as $item) {
            $table .= "<tr>";
                $table .= "<td>{$item[1]}</td>";
                $table .= "<td>{$item[2]}</td>";
                $table .= "<td>{$item[3]}</td>";
                $table .= "<td>{$item[4]}</td>";
                $table .= "<td>{$item[5]}</td>";
                $table .= "<td>{$item[6]}</td>";
                $table .= "<td>{$item[7]}</td>";
            $table .= "</tr>";
            }
            $table .= "</table>";
            echo $table;
            die();
        }
        die(json_encode(['data' => $html]));

        $sql = '';
        if ($disc) $sql = " and disc='{$disc}'";

        $html = [];
        $vkr = \R::getAssoc("select * from vkruser where sem='{$sem}' and lektor_id is not null and status!=2 order by user_id");
//        $stud = ($user) ? \R::findAll('users','id = ? order by name',[$user]) :
//            \R::findAll('users','class = ? order by name',[$class]);
        $i = 0;
        foreach ($vkr as $item) {
//            foreach ($stud as $st) {
            $st = \R::findOne('users',"id=?", [$item['user_id']]);
            $prep = \R::findOne('users','id=?', [$item['lektor_id']]);
            $mgr = \R::findOne('vkraccess',"users like ?", ['%"'.$prep->id.'"%']);
            $mgr = ($mgr) ? \R::findOne('users',"id=?",[$mgr->user_id]) : '';

            $button = '<button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-pencil pull-right" data-toggle="modal" data-target="#exampleModal2" data-userid="'.$st->id.'" data-predmet="'.$item['disc'].'"></button>';

            $html[] = ['', ++$i, $st->name, $st->class, $item['disc'], $mgr, $prep->name, 'Лектор',$button];
                //                $html .= (!empty($item['file'])) ? "<td><a href='upload/works/{$item['file']}' class='btn btn-warning btn-xs' target='_blank'><span class='glyphicon glyphicon-download'></span>&nbsp;<span class='hidden-xs'>Скачать</span></a></td>" : "<td></td>";
                //                $html .= "<td><span data-id='{$item['id']}' class='btn btn-xs btn-danger remove'><i class='glyphicon glyphicon-remove'></i></span></td>";
//            }
        }
        die(json_encode(['data' => $html]));
    }

    public function getTasksCursAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $this->layout = false;
        $class = isset($_GET['class']) && $_GET['class']!='null' ? $_GET['class'] : false;
        $disc = isset($_GET['disc']) && $_GET['disc']!='null' ? $_GET['disc'] : false;
        $print = isset($_GET['print']) && $_GET['print']!='null' ? $_GET['print'] : false;
        if (!$class) die(json_encode(['data' => []]));

        $html = [];
        $sql = [];

        if ($class) $sql[] = "class = '{$class}'";
        if ($disc) $sql[] = "disc = '{$disc}'";

        $sql = implode(' and ', $sql);
        $vkr_class = \R::findAll('vkrclass',"{$sql}");
$i = 0;
        foreach ($vkr_class as $vkr_c) {
            $class_ = $vkr_c->class;
            $disc_ = $vkr_c->disc;
            $studs = \R::findAll('users',"class=? and kodstatusa=240 order by name",[$class_]);
            foreach ($studs as $stud) {
                $prep = \R::findOne('vkrusercurs',"disc=? and user_id=? and lektor_id is not null",[$disc_, $stud->id]);
                $prep_ = $prep ? \R::findOne('users','id=?', [$prep->lektor_id])->name : '';

                $button = '<button type="button" class="btn btn-primary btn-xs glyphicon glyphicon-pencil pull-right" 
                    data-toggle="modal" data-target="#exampleModal3" data-userid="'.$stud->id.'" data-predmet="'.$disc_.'"></button>';
                $html[] = [$stud->id.'|'.$disc_, ++$i, $stud->name, $class_, $disc_, $prep_, $button];
            }
        }
        if ($print) {
            $table = "<table border='1' style='border-collapse:collapse;width: 100%;font-size: 0.75em;'>";
            $table .= "<tr>";
                $table .= "<th align='center'>№</th>";
                $table .= "<th align='left'>ФИО Студента</th>";
                $table .= "<th>Группа</th>";
                $table .= "<th>Предмет</th>";
                $table .= "<th>ФИО Преподавателя</th>";
            $table .= "</tr>";
            foreach ($html as $item) {
            $table .= "<tr>";
                $table .= "<td>{$item[1]}</td>";
                $table .= "<td>{$item[2]}</td>";
                $table .= "<td>{$item[3]}</td>";
                $table .= "<td>{$item[4]}</td>";
                $table .= "<td>{$item[5]}</td>";
            $table .= "</tr>";
            }
            $table .= "</table>";
            echo $table;
            die();
        }
        die(json_encode(['data' => $html]));
    }

    public function savePrepodAction() {
        $selected = ($_POST['selected']) ?: null;
        $stud_id = ($_POST['stud_id']) ?: null;
        $predm = ($_POST['predm']) ?: null;
        $sem = ($_POST['sem']) ?: null;
        $prepod = ($_POST['prepod']) ?: null;
        $status = ($_POST['status']) ?: null;
        if (!$sem) die(0);

        if ($selected) {
            foreach ($selected as $item) {
                list($s, $d) = explode('|',$item);
                $vkr = \R::findOne('vkruser', "disc=? and sem=? and user_id=? and status!=2",[$d,$sem,$s]);
                if (!$prepod)  { if ($vkr) \R::trash($vkr); continue; }
                if (!$vkr) {
                    $vkr = \R::dispense('vkruser');
                    $vkr->sem = $sem;
                    $vkr->disc = $d;
                    $vkr->user_id = $s;
                }
                if ($status) $vkr->status = $status;
                $vkr->lektor_id = $prepod;
                \R::store($vkr);
            }
            die(1);
        }

        if (!$stud_id || !$predm) die(0);
        $vkr = \R::findOne('vkruser', "disc=? and sem=? and user_id=? and status!=2",[$predm,$sem,$stud_id]);
        if (!$prepod)  { if ($vkr) \R::trash($vkr); die(1); }
        if (!$vkr) {
            $vkr = \R::dispense('vkruser');
            $vkr->sem = $sem;
            $vkr->disc = $predm;
            $vkr->user_id = $stud_id;
        }
        if ($status) $vkr->status = $status;
        $vkr->lektor_id = $prepod;
        \R::store($vkr);
        die(1);
    }

    public function savePrepodCursAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $selected = ($_POST['selected']) ?: null;
        $stud_id = ($_POST['stud_id']) ?: null;
        $predm = ($_POST['predm']) ?: null;
        $prepod = ($_POST['prepod']) ?: null;

        if ($selected) {
            foreach ($selected as $item) {
                list($s, $d) = explode('|',$item);
                $vkr = \R::findOne('vkrusercurs', "disc=? and user_id=?",[$d,$s]);
                if (!$prepod)  { if ($vkr) \R::trash($vkr); continue; }
                if (!$vkr) {
                    $vkr = \R::dispense('vkrusercurs');
                    $vkr->disc = $d;
                    $vkr->user_id = $s;
                }
                $vkr->lektor_id = $prepod;
                \R::store($vkr);
            }
            die(1);
        }

        if (!$stud_id || !$predm) die(0);
        $vkr = \R::findOne('vkrusercurs', "disc=? and user_id=?",[$predm,$stud_id]);
        if (!$prepod)  { if ($vkr) \R::trash($vkr); die(1); }
        if (!$vkr) {
            $vkr = \R::dispense('vkrusercurs');
            $vkr->disc = $predm;
            $vkr->user_id = $stud_id;
        }
        $vkr->lektor_id = $prepod;
        \R::store($vkr);
        die(1);
    }

    public function getClassAction()
    {
        $class = ($_POST['class']) ?: null;
        $sem = ($_POST['sem']) ?: null;
        if (!$class || !$sem) die(0);
        $vkr = array_values(\R::getAssoc("select disc from vkrclass where class=? and sem=?",[$class,$sem]));
        $res = '';
        foreach ($vkr as $item) {
            $res .= "<option>{$item}</option>";
        }
        die($res);
    }

    public function saveClassAction()
    {
        $discs = ($_POST['discs']) ?: null;
        $class = ($_POST['class']) ?: null;
        $sem = ($_POST['sem']) ?: null;

        if (!$discs || !$class || !$sem) {
            echo 0;
            die;
        };
        $discs = json_decode($discs);
        $list = [];
        foreach ($discs as $disc) $list[] = "'" . $disc . "'";
        $beans = \R::findAll('vkrclass', "class='{$class}' and sem='{$sem}' and disc not in (" . \R::genSlots($list) . ")", $list);
        \R::trashAll($beans);
        $res = '';
        date_default_timezone_set('Asia/Yekaterinburg');
        foreach ($discs as $disc) {
            $res .= "<option>{$disc}</option>";
            $vkr = \R::dispense('vkrclass');
            $vkr->class = $class;
            $vkr->disc = $disc;
            $vkr->sem = $sem;
            $vkr->created = \R::isoDateTime();
            \R::store($vkr);
        }

//        header('Content-Type: application/json');
        die(1);
    }

    public function saveAccessAction()
    {
        $user_id = ($_POST['user']) ?: null;
        $discs = ($_POST['discs']) ?: null;
        $class = ($_POST['class']) ?: null;

        if (!$user_id) die(0);

        $user = \R::findOne('vkraccess',"user_id=?", [$user_id]);
        if (!$user) $user = \R::dispense('vkraccess');

        $user->user_id = $user_id;
        $user->disc = json_encode($discs);
        $user->class = json_encode($class);
        \R::store($user);
        die(1);
    }

    public function saveAccesssAction() {
        $user_id = ($_POST['user']) ?: null;
        $prep_id = ($_POST['prepod']) ?: null;

        if (!$user_id || !$prep_id) die(0);

        $user = \R::findOne('vkraccess',"user_id=?", [$user_id]);
        if (!$user) die(0);

        $users = json_decode($user->users,1);
        $users[] = $prep_id;
        $user->users = json_encode($users);

        \R::store($user);
        die(1);
    }

    public function delPrepodAction() {
        $user_id = ($_POST['user']) ?: null;
        $prep_id = ($_POST['prepod']) ?: null;

        if (!$user_id || !$prep_id) die(0);

        $user = \R::findOne('vkraccess',"user_id=?", [$user_id]);
        if (!$user) die(0);

        $users = json_decode($user->users,1);
        unset($users[array_search($prep_id, $users)]);

        $user->users = json_encode($users);

        \R::store($user);
        die(1);
    }

    public function getVkrInfoAction() {
        $user = ($_GET['user']) ?: null;
        if (!$user) die(0);
        $vkr = \R::findOne('vkraccess',"user_id=?",[$user]);
        if (!$vkr) die(0);
        header('Content-Type: application/json');
        die(json_encode([
            'class' => json_decode($vkr->class),
            'disc' => json_decode($vkr->disc),
        ]));
    }

    public function getVkrInfoBAction() {
            $user = ($_GET['user']) ?: null;
            if (!$user) die(0);
            $vkr = \R::findOne('vkraccess',"user_id=?",[$user]);
            if (!$vkr) die(0);
            $html = $prep = '';

            $vkr_users = json_decode($vkr->users);

            foreach ($vkr_users as $item) {
                $us = \R::findOne('users',"id=?",[$item]);
                $username = (strpos($us->name, '(')) ? preg_replace( '~ \(.*\) ~' , " ", $us->name ) : $us->name;
                $name = explode(' ', str_replace('  ', ' ', $username));

                $prep .= '<option value="'.$us->id.'">'.$username.'</option>';

                $html .= '<a class="btn-xs list-group-item col-xs-6 col-md-4">
                            <span class="del" data-id="'.$us->id.'" style="cursor:pointer;float:right;"> ×</span>
                            <span>'.$name[0].'</span>
                        </a>';
            }

            $c = $d = '<option disabled selected value="">Не выбрано</option>';

            $class = json_decode($vkr->class);
            $disc = json_decode($vkr->disc);

            foreach ($class as $item) $c .= '<option>'.$item.'</option>';
            foreach ($disc as $item) $d .= '<option>'.$item.'</option>';

//            die($html);
            header('Content-Type: application/json');
            die(json_encode([
                'users' => $html,
                'prep' => $prep,
                'class' => $c,
                'disc' => $d,
            ]));
        }

    public function getVkrDiscAction() {
        $class = ($_GET['class']) ?: null;
        if (empty($class)) die(0);
        if (!is_array($class)) $class = [$class];
        $html = '';
        $vkr = array_values(\R::getAssoc("select disc from vkrclass where class in (".
            \R::genSlots($class).")",$class));
        foreach ($vkr as $item) {
            $html .= '<option>' . $item . '</option>';
//            $vkr_sel = in_array($item,$vkr) ? 'true' : '';
//            $html4 .= '<li class="list-group-item" data-value="'.
//                $item.'" data-checked="'.$vkr_sel.'">' . $item . '</li>';
        }
        die($html);
    }

    public function getVkrDiscBAction() {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
            $class = ($_GET['class']) ?: null;
            $sem = ($_GET['sem']) ?: null;
            $user = ($_GET['user']) ?: null;

            $user_ = \R::findOne('vkraccess',"user_id=?",[$user]);
            $discs = json_decode($user_->disc,1);
            $class_ = json_decode($user_->class,1);
            if (!$discs || !$sem) die('');
            if (!$class) {
                $vkr = array_values(\R::getAssoc("select disc from vkrclass where sem={$sem} and class in (".
                    \R::genSlots($class_).")",$class_));
            } else {
                $vkr = array_values(\R::getAssoc("select disc from vkrclass where sem={$sem} and class = ?",[$class]));
            }

            $html = '';
            foreach ($vkr as $item) {
                if (!in_array($item, $discs)) continue;
                $html .= '<option>' . $item . '</option>';
            }
            die($html);
        }

    public function getListDiscAction() {
        $this->layout = false;
        if (!empty($_GET['class'])) {
            $class = ($_GET['class'] != '') ? $_GET['class'] : null;
            $sem = ($_GET['sem'] != '') ? $_GET['sem'] : 1;
            if (!empty($class)) {
                $class_str = "class = '{$class}'";
                if ($this->cur_user->access == 1) {
                    if (!empty($sem)) $list = \R::getAssoc("SELECT disc FROM plan WHERE ($class_str) AND s".$sem." != '0|0|0|0|0|0|0|0|0' ORDER BY disc");
                    else $list = \R::getAssoc("SELECT disc FROM plan WHERE $class_str ORDER BY disc");
                }
                else {
                    if (!empty($_GET['sem'])) $list = \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND s".$_GET['sem']." != '0|0|0|0|0|0|0|0|0' ORDER BY disc",[$this->cur_user->id]);
                    else $list = \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND kafedra<>'' ORDER BY disc",[$this->cur_user->id]);
                }
            }

            $html4 = '';
            $vkr = array_values(\R::getAssoc("select disc from vkrclass where class=? and sem=?",[$class,$sem]));
            foreach ($list as $item) {
                $vkr_sel = in_array($item,$vkr) ? 'true' : '';
//                $html4 .= '<option'.$vkr_sel.'>' . $item . '</option>';
                $html4 .= '<li class="list-group-item" data-value="'.
                    $item.'" data-checked="'.$vkr_sel.'">' . $item . '</li>';
            }


            header('Content-Type: application/json');
            echo json_encode(['res' => $html4]);
        }
        die;
    }

    public function getListDiscCursAction() {
        $this->layout = false;
        if (!empty($_GET['class'])) {
            $class = ($_GET['class'] != '') ? $_GET['class'] : null;
            if (!empty($class)) {
                $class_str = "class = '{$class}'";
                $list = ($this->cur_user->access == 1) ? \R::getAssoc("SELECT disc FROM plan WHERE {$class_str} ORDER BY disc") :
                    \R::getAssoc("SELECT disc FROM plan WHERE user_id = ? AND ($class_str) AND kafedra<>'' ORDER BY disc",[$this->cur_user->id]);
            }

            $html4 = '';
            $vkr = array_values(\R::getAssoc("select disc from vkrclass where class=?",[$class]));
            foreach ($list as $item) {
                $vkr_sel = in_array($item,$vkr) ? 'true' : '';
                $html4 .= '<li class="list-group-item" data-value="'. $item.'" data-checked="'.$vkr_sel.'">' . $item . '</li>';
            }

            header('Content-Type: application/json');
            echo json_encode(['res' => $html4]);
        }
        die;
    }
}