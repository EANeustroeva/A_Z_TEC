<?php

namespace app\controllers;

class PlanviewController extends AppController
{

    public function __construct($route)
    {
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);

        parent::__construct($route);

        $this->layout = 'manager';
    }

    public function indexAction()
    {
        if ($this->cur_user->id != 17158) die;
//        $data['menu'] = [];
        $this->setMeta('Просмотр планов');
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;
        $data['port'] = [];
        $data['napr_list'] = ['1' => "Бизнес-информатика", '2' => "Гостиничное дело", '3' => "Государственное и муниципальное управление", '4' => "Землеустройство и кадастры", '5' => "Информатика и вычислительная техника", '6' => "Менеджмент", '7' => "Прикладная информатика", '8' => "Продукты питания из растительного сырья", '9' => "Технология продукции и организация общественного питания", '10' => "Товароведение", '11' => "Торговое дело", '12' => "Туризм", '13' => "Управление качеством", '14' => "Управление персоналом", '15' => "Экономика", '16' => "Юриспруденция",];
        $print = !empty($_GET['print']);

        if ($print) {
            $data['html'] = $this->getPlanAction();
            $this->layout = 'empty';
            $this->view = 'print';
        }
        $this->set($data);
    }

    public function getPlanAction() {
        $this->layout = false;
        if (empty($_GET['class'])) die('error');
        $print = !empty($_GET['print']);
        $class = ($_GET['class'] != '') ? $_GET['class'] : null;
        $sem = ($_GET['sem'] != '') ? $_GET['sem'] : 1;
        $list = \R::getAssoc("SELECT * FROM plan WHERE class=? AND s".$sem." != '0|0|0|0|0|0|0|0|0' ORDER BY disc", [$class]);
        $html = $print ? '<h3>Группа: '.$class.'</h3><h3>Семестр: '.$sem.'</h3>' : '';
        $html .= '<table class="table table-striped table-hover table-condensed table-bordered table-responsive">
            <thead>
            <tr>
                <th>Предмет</th>
                <th>Итого</th>
                <th>Лек.</th>
                <th>Прак.</th>
                <th>Лаб.</th>
                <th>Экз.</th>
                <th>Зач.</th>
                <th>Кур.</th>
                <th>Атт.</th>
                <th>Контр.</th>
                <th>Преподаватель</th>
            </tr>                
            </thead>
            <tbody>';
        foreach ($list as $item) {
            $parse = explode('|',$item["s$sem"]);
            switch ($parse[4]) {
                case 1: $att='экз'; break;
                case 2: $att='зач'; break;
                case 15: $att='диф.зач'; break;
                default: $att=$parse[4];
            }
            $teacher = '';
            if ($item['lektor']) {
                $name = explode(" ",$item['lektor']);
                $teacher = $name[0] . '&nbsp;' . mb_substr($name[1],0,1,"UTF-8") . '.' . mb_substr($name[2],0,1,"UTF-8") . '.';
            }

            $html .= "<tr>";
            $html .=    "<td class='text-left'>{$item['disc']}</td>";
            $html .=    "<td>".(int)($parse[5]+(int)$parse[7])."</td>";
            $html .=    "<td>".$parse[5]."</td>";
            $html .=    "<td>".$parse[7]."</td>";
            $html .=    "<td>".$parse[6]."</td>";
            $html .=    "<td>".($parse[0]?'экз':'')."</td>";
            $html .=    "<td>".(($parse[1]>0)?'зач':(($parse[1]<0)?'диф.зач':""))."</td>";
            $html .=    "<td>".$parse[2]."</td>";
            $html .=    "<td>{$att}</td>";
            $html .=    "<td>".(($parse[3]>0)?'к.р':(($parse[3]<0)?'дом.к.р':""))."</td>";
            $html .=    "<td>{$teacher}</td>";
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';

        if ($class && $class_sem = \R::findOne('classsem','enabled=1 and class=?',[$class])) {
            $ns = !empty($class_sem['ns']) ? explode('|', $class_sem['ns']) : ['','','','','','','','',''];
            $ks = !empty($class_sem['ks']) ? explode('|', $class_sem['ks']) : ['','','','','','','','',''];
            $html .= '<h4>Начало сессии: '.@$ns[$sem-1].'</h4>';
            $html .= '<h4>Конец сессии: '.@$ks[$sem-1].'</h4>';
        }
        if (!$print) {
            $html .= '
<form target="_blank">
    <input type="hidden" name="class" value="'.$class.'">
    <input type="hidden" name="sem" value="'.$sem.'">
    <input type="hidden" name="print" value="1">
    <input type="submit" value="Версия для печати" class="btn btn-warning">
</form>
<div class="alert alert-warning fade in" role="alert" style="margin-top: 1em;">
    Чтобы распечатать документ после генерации, нажмите <kbd><kbd>ctrl</kbd> + <kbd>P</kbd></kbd>,
    также, в окне распечатки, в дополнительных настройках уберите галочку "Верхние и нижние колонтитулы" (прим. Chrome)
</div>';
        } else {
            return $html;
        }

        header('Content-Type: application/json');
        echo json_encode(['res' => $html]);

        die;
    }

    public function toggleTestsAction() {
        $user = \R::load('users',$_POST['pk']);
        $user->restored = current($_POST['value']) ?: null;
        \R::store($user);
        dd2($_POST);
    }

    public function selectTestsAction() {
        $user = \R::load('users',$_POST['pk']);
        $user->restored_tests = $_POST['value'] ? trim($_POST['value'],','): null;
        \R::store($user);
        die;
    }

    public function selectTestsAllAction() {
        if (empty($_POST['pk'])) die();
        foreach (explode(',',$_POST['pk']) as $id) {
            $user = \R::load('users',$id);
            $user->restored_tests = $_POST['value'] ? trim($_POST['value'],','): null;
            \R::store($user);
        }
        die;
    }

}