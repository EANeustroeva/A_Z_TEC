<?php
namespace app\controllers;

use app\models\Auth;
use vendor\core\base\Controller;

class AskController extends Controller {
    public $errors = [];
    public $data = [];

    public function __construct($route) {
        parent::__construct($route);
        new Auth();
    }

    public function indexAction() {
        if (isset($_GET['test'])) {
            ini_set('error_reporting', E_ALL);
            ini_set('display_errors', 1);
            ini_set('display_startup_errors', 1);
        }
//        $alias = !empty($_GET) ? str_replace('qwerty','',current(array_keys($_GET))) : '';
        $alias = !empty($_GET) ? preg_replace("/^ask\//i",'',current(array_keys($_GET))) : '';
//        $alias = str_replace('/', '', $alias);
        $this->setMeta('Страница Опроса');
        $meta = $this->meta;

        $polls = \R::getAssoc('select id from polls where alias=? order by ordering', [$alias]);
        foreach ($polls as $item) {
            $cookie_key = 'sp_poll_voted_' . $item;
            $cookie = !empty($_COOKIE[$cookie_key]) ? $_COOKIE[$cookie_key] : null;
            if (!isset($_GET['test']) && !is_null($cookie)) unset($polls[$item]);
        }
        if (!isset($_GET['test']) && !count($polls) || empty($alias)) redirect('http://ino.usue.ru');

        if (isset($_POST['id'])) {
            $id 	 = isset($_POST['id'])      ? $_POST['id']      : null;
            $vote  	 = isset($_POST['vote'])    ? $_POST['vote']    : null;

            $poll = $this->getPoll($id);

            if (isset($_GET['test'])) dump($_POST);

            if (!is_null($vote)) {
                $user_vote = 'yes';
                $cookie_key = 'sp_poll_voted_' . $id;
                $cookie = !empty($_COOKIE[$cookie_key]) ? $_COOKIE[$cookie_key] : null;
                if (is_null($cookie))
                {
                    $options = json_decode($poll->polls);

                    $new_polls = [];
                    $custom = false;
                    foreach ($options as $key => $value) {
                        if(is_array($vote)&&in_array($key, $vote) || $key == $vote) {
                            $new_polls[] = ['poll' =>$value->poll, 'votes' =>$value->votes + 1];
                            $user_vote = base64_encode($value->poll);
                            if (!empty($_POST['value']) && strpos($value->poll,'_')!==false) {
                                $custom = $_POST['value'];
                            }
                        } else {
                            $new_polls[] = ['poll' =>$value->poll, 'votes' =>$value->votes];
                        }
                    }

                    // Update
                    if (!isset($_GET['test'])) {
//                        if (strpos())
                        $this->updatePoll($new_polls, $id, $custom);
                        setcookie('sp_poll_voted_' . $id, $user_vote, strtotime("+30 day"));
                    }
                }

            }

            $poll = !empty($alias) ? \R::findOne('polls', "alias=? and ordering>? order by ordering",[$alias, $poll->ordering]) :
                \R::findOne('polls', "ordering>? order by ordering",[$poll->ordering]);

            if (isset($_GET['test'])) {
//                $poll = \R::findOne('polls', "alias=?",[$alias, $poll->ordering]);
//                dd($id,$alias,$poll);
            }
        } else {
            $poll = \R::findOne('polls',"alias='{$alias}' and id in (".\R::genSlots(array_values($polls)).") order by ordering",array_values($polls));
//            $poll = !empty($alias) ? \R::findOne('polls',"alias=? order by ordering",[$alias]) :
//                \R::findOne('polls',"order by ordering");
        }

        if (!empty($_SESSION['redirect_'])) {
            $query = $_SESSION['redirect_'];
            unset($_SESSION['redirect_']);
            redirect($query);
        }

        if (!$poll) redirect('http://ino.usue.ru');

        $cookie_key = 'sp_poll_voted_' . $poll->id;
        $cookie = !empty($_COOKIE[$cookie_key]) ? $_COOKIE[$cookie_key] : null;

        if (!empty($poll->redirect) && !empty($_POST)) $_SESSION['redirect_'] = (!parse_url($poll->redirect, PHP_URL_SCHEME)?'http://':'').$poll->redirect;

//        foreach ($polls as $poll) {
            $options = json_decode($poll->polls);
            $votes = 0;
            foreach ($options as $key => $value) $votes += $value->votes;

            if ($votes == 0 && !is_null($cookie)) {
                unset($_COOKIE[$cookie_key]);
                setcookie($cookie_key, $_COOKIE[$cookie_key], time()-3600);
            }
//        }

        $this->set(compact('meta', 'poll', 'alias'));
        $this->layout = 'faq';
    }

    public function resultsAction() {
        $data = $this->data;
//preg_replace("/^qwerty\//i",'',current(array_keys($_GET)))
//        $alias = !empty($_GET) ? str_replace(['qwerty','results'],'',current(array_keys($_GET))) : '';
        $alias = !empty($_GET) ? str_replace(['ask/','results'],'',current(array_keys($_GET))) : '';
        $alias = str_replace('/', '', $alias);

        $polls = !empty($alias) ? \R::findAll('polls',"alias=? order by ordering", [$alias]) :
            \R::findAll('polls',"type=0 order by ordering");
        if (current($polls)->type==1) {
            $this->view = 'resultss';
            $polls = current($polls);
        }
//        $poll = \R::load('polls', $_GET['id']);
//        if (!$poll) redirect();
        $data['polls'] = $polls;

        $this->setMeta('Результаты опросов');
        $data['meta'] = $this->meta;
        $this->set($data);
        $this->layout = 'faq';
    }

    public function resultssAction() {
        $data = $this->data;

        $polls = \R::findOne('polls',"type=1");
//        $poll = \R::load('polls', $_GET['id']);
//        if (!$poll) redirect();
        $data['polls'] = $polls;

        $this->setMeta('Результаты опросов');
        $data['meta'] = $this->meta;
        $this->set($data);
        $this->layout = 'faq';
    }

    public function ajaxAction(){
        ini_set('error_reporting', E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        $id 	 = !empty($_POST['id'])      ? $_POST['id']      : null;
		$subtask = !empty($_POST['subtask']) ? $_POST['subtask'] : null;
		$vote  	 = !empty($_POST['vote'])    ? $_POST['vote']    : null;
        $type    = !empty($_POST['type'])    ? $_POST['type']    : null;

		$user_vote = 'yes';

		$cookie_key = 'sp_poll_voted_' . $id;
        $cookie = !empty($_COOKIE[$cookie_key]) ? $_COOKIE[$cookie_key] : null;

        $votes = 0;
        foreach (json_decode($this->getPoll($id)->polls) as $key => $value) $votes += $value->votes;

		if($subtask != 'result') {
			if ($votes == 0 || is_null($cookie))
			{
				$poll = $this->getPoll($id);
				$options = json_decode($poll->polls);

				$new_polls = [];
				foreach ($options as $key => $value) {
					if($key == $vote) {
						$new_polls[] = ['poll' =>$value->poll, 'votes' =>$value->votes + 1];
						$user_vote = base64_encode($value->poll);
					} else {
						$new_polls[] = ['poll' =>$value->poll, 'votes' =>$value->votes];
					}
				}

				// Update
				$this->updatePoll($new_polls, $id);
			}
			else
			{
				die('<p></p><p class="alert alert-danger">Вы уже проголосовали!</p>');
			}
		}

		$poll = $this->getPoll($id);
		$options = json_decode($poll->polls);

		$output = $this->result($options); //JLayoutHelper::render('results', array( 'options'=>$options));

		// Set Cookie
		if($subtask != 'result') {
			setcookie('sp_poll_voted_' . $id, $user_vote, strtotime("+30 day"));
		}

		die($output);

	}

	public function getPoll($id = null) {
        return \R::load('polls',$id);
	}

	// Update Poll
	public function updatePoll($poll_data, $id, $custom_value = false) {
        $poll = \R::load('polls',$id);
        if ($poll->published) {
            $poll->polls = json_encode($poll_data);
            \R::store($poll);

            if ($custom_value) {
                $custom = \R::dispense('pollcustom');
                $custom->poll_id = $id;
                $custom->value = $custom_value;
                \R::store($custom);
            }

        } else {
            die('<p></p><p class="alert alert-danger">Голосование уже окончено!</p>');
        }
        return;
	}

	public function result($options) {
        $total_votes = 0;

        foreach ($options as $key => $option) {
            $total_votes = $total_votes + $option->votes;
        }

        // output
        $output = '<div class="sp-poll-result">';
        foreach ($options as $value) {
            if ($value->votes == 0) continue;

            if($total_votes) {
                $percentage = round($value->votes/$total_votes, 2)*100;
            } else {
                $percentage = 0;
            }

            $output .= '<div class="sp-poll-resul-item">';
            $output .= '<p class="poll-info"><span class="poll-question" style="font-size: 1.2em;">' . $value->poll . '</span><span class="poll-votes">Голосов: ' . $value->votes . '</span></p>';

            $output .= '<div class="progress">';

            $progress = ' progress-bar-default';
            if($percentage>60) {
                $progress = ' progress-bar-danger';
            } elseif($percentage>50) {
                $progress = ' progress-bar-warning';
            } elseif($percentage>40) {
                $progress = ' progress-bar-success';
            } elseif($percentage>30) {
                $progress = ' progress-bar-info';
            } elseif($percentage>20) {
                $progress = ' progress-bar-primary';
            }

            $output .= '<div class="progress-bar'. $progress .'" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="min-width: 2em; width: ' . $percentage . '%;">';
            $output .= $percentage . '%';
            $output .= '</div>';
            $output .= '</div>';

            $output .= '</div>';

            $total_vote[] = $value->votes;
        }
        $output .= '</div>';

        return $output;
    }

    protected function setMeta($title = '', $description = '', $keywords = '') {
        $this->meta['title'] = $title;
        $this->meta['desc'] = $description;
        $this->meta['keywords'] = $keywords;
    }

}