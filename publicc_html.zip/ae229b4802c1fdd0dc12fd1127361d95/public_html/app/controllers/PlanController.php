<?php
/**
 * Created by PhpStorm.
 * User: Sophie Svanur
 * Date: 28.12.2017
 * Time: 1:14
 */

namespace app\controllers;


class PlanController extends AppController {

    public function indexAction() {
        $data = $this->data;
        $this->setMeta('Учебный план');
        $data['menu'] = $this->menu;
        $data['meta'] = $this->meta;
        $data['cur_user'] = $this->cur_user;

        if ($this->cur_user->access == 1) {
            $this->view = 'manager';
        } else {
            $class = $this->cur_user->class;
            $data['marks'] = \R::findAll('taskwork', "stud_id = ?", [$this->cur_user->id]);
            foreach ($data['marks'] as &$m) {
                $m['task'] = \R::load('tasks', $m['task_id']);
                $teacher = \R::load('users', $m['task']['create_id']);
                $name = explode(" ",$teacher->name);
                $m['teacher'] = $name[0] . ' ' . mb_substr(@$name[1],0,1,"UTF-8") . '.' . mb_substr(@$name[2],0,1,"UTF-8") . '.';
                $m->t_id = $teacher->id;
            }
        }

//        $y = date('Y') - $this->cur_user->course+1;

        $data['port'] = [];
        for ($i=1;$i<9;$i++) {
            $data['port'][$i] = [];
//            if ($i%2 == 0) $y++;
            $data['port'][$i] = \R::getAssoc("SELECT * FROM plan WHERE class=? AND s$i != '0|0|0|0|0|0|0|0|0' AND plan.gotovo>={$i} ORDER BY disc",[$class]);
        }

        $this->set($data);
    }

    public function getPlanAction() {
        $this->layout = false;
        if (empty($_GET['class'])) die('error');
        $class = ($_GET['class'] != '') ? $_GET['class'] : null;
        $sem = ($_GET['sem'] != '') ? $_GET['sem'] : 1;
        $list = \R::getAssoc("SELECT * FROM plan WHERE class=? AND s".$sem." != '0|0|0|0|0|0|0|0|0' ORDER BY disc", [$class]);
        $html = '<table class="table table-striped table-hover table-condensed table-bordered table-responsive">
            <thead>
            <tr>
                <th>Предмет</th>
                <th>Итого</th>
                <th>Лек.</th>
                <th>Прак.</th>
                <th>Лаб.</th>
                <th>Экз.</th>
                <th>Зач.</th>
                <th>Кур.</th>
                <th>Атт.</th>
                <th>Контр.</th>
                <th>Преподаватель</th>
            </tr>                
            </thead>
            <tbody>';
        foreach ($list as $item) {
            $parse = explode('|',$item["s$sem"]);
            switch ($parse[4]) {
                case 1: $att='экз'; break;
                case 2: $att='зач'; break;
                case 15: $att='диф.зач'; break;
                default: $att=$parse[4];
            }
            $teacher = '';
            if ($item['lektor']) {
                $name = explode(" ",$item['lektor']);
                $teacher = $name[0] . '&nbsp;' . mb_substr($name[1],0,1,"UTF-8") . '.' . mb_substr($name[2],0,1,"UTF-8") . '.';
            }

            $html .= "<tr>";
            $html .=    "<td class='text-left'>{$item['disc']}</td>";
            $html .=    "<td>".(int)($parse[5]+(int)$parse[7])."</td>";
            $html .=    "<td>".$parse[5]."</td>";
            $html .=    "<td>".$parse[7]."</td>";
            $html .=    "<td>".$parse[6]."</td>";
            $html .=    "<td>".($parse[0]?'экз':'')."</td>";
            $html .=    "<td>".(($parse[1]>0)?'зач':(($parse[1]<0)?'диф.зач':""))."</td>";
            $html .=    "<td>".$parse[2]."</td>";
            $html .=    "<td>{$att}</td>";
            $html .=    "<td>".(($parse[3]>0)?'к.р':(($parse[3]<0)?'дом.к.р':""))."</td>";
            $html .=    "<td>{$teacher}</td>";
            $html .= '</tr>';
        }
        $html .= '</tbody></table><br>';

        /*$cp = \R::findOne('classprof',"class=?",[$class]);
        if (!$cp) {
            $prof = \R::findOne('users',"class=? and profile is not null",[$class]);
            $cp = \R::findOne('classprof',"prof=?",[$prof->profile]);
        }
        $cd = $cp ? \R::findOne('compdisc', "tests is not null and prof=?",[$cp->prof]) : false;*/

        $tests_list_ = \R::getAssoc("select tests,disc from compdisc where tests is not null and tests!='|||||'");
        $tests_list = [];
        foreach ($tests_list_ as $k=>$item) {
            foreach (explode('|',$item) as $i => $v) {
                $id = explode('|',$k)[$i];
                foreach (explode(',',$id) as $ii => $vv) {
//                    $tests_list[$vv] = $v;
                    $tests_list[] = $vv;
                }
            }
        }
        $comp_list = \R::getCol("select id from tests where type=3");
        $comp_list2 = \R::getCol("select id from tests where type=1");
        $tsts = [];
        $ids = array_merge($tests_list, $comp_list, $comp_list2);
//        var_dump(array_reverse($tests_list));
//        die;
//        $tests_str = '[]';
//        if ($cd) {
            /*$tests = explode('|',$cd->tests);
            if (is_array($tests)) foreach ($tests as $test) {
                $sub = explode(',',$test);
                if (is_array($sub)) foreach ($sub as $item) $ids[] = $item;
                elseif (!empty($sub)) $ids[] = $sub;
            }*/
            if (count($ids)) {
                $opts1 = $opts2 = $opts3 = [];
                $tests = \R::getAll("SELECT id,title FROM tests WHERE id in (".\R::genSlots($ids).") order by title", $ids);
                foreach ($tests as $test) {
                    if (in_array($test['id'],$tests_list)) $opts1[] = ['id'=>$test['id'], 'text'=>$test['title']];
                    elseif (in_array($test['id'],$comp_list2)) $opts2[] = ['id'=>$test['id'], 'text'=>$test['title']];
                    else $opts3[] = ['id'=>$test['id'], 'text'=>$test['title']];
                }
                if (count($opts1)) $tsts[] = ['id' => '', 'text'=>'Общие', 'children'=>$opts1];
                if (count($opts2)) $tsts[] = ['id' => '', 'text'=>'Перезачет', 'children'=>$opts2];
//                if (count($opts3)) $tsts[] = ['id' => '', 'text'=>'По компетенциям', 'children'=>$opts3];
                $tsts2 = array_merge($opts1, $opts2, $opts3);
                $tsts = $tsts2;
            }
//        }

        $tests_str = json_encode($tsts);//'['.implode(',', $tsts).']';

        $studs = \R::getAll("select * from users where access=4 and class=? order by name",[$class]);
        $html .= '<table id="tests" class="table table-striped table-hover table-condensed table-bordered table-responsive">
            <tr><th><input type="checkbox" name="select_all" value="1" id="example-select-all2" style="margin-top: 3px;"></th><th>Студент</th><th>Включить тесты</th><th>Активные тесты</th></tr>';
        foreach ($studs as $stud) {
            $data_tests = $stud['restored_tests'] ? "data-value=\"{$stud['restored_tests']}\"" : '';
//            $data_vals = [];
//            if (!empty($tests) && $stud['restored_tests']) {
//                foreach (explode(',',$stud['restored_tests']) as $item) {
//                    $data_vals[] = $tests[$item];
//                }
//            }
//            $data_vals = implode(', ', $data_vals);
            $html .= '<tr>';
            $html .=    '<td width="1"><input type="checkbox" name="selected[]" value="'.$stud['id'].'" style="margin-top: 3px;"></td>';
            $html .=    '<td width="250" class="text-left">'.$stud['name'].'</td>';
            $html .=    "<td><a href=\"#\" data-type=\"checklist\" data-pk=\"{$stud['id']}\" data-url=\"/plan/toggleTests\" data-title=\"\" data-value=\"{$stud['restored']}\" data-source=\"{1:'Включено'}\" data-emptytext=\"Выключено\"></a></td>";
            $html .=    "<td><a href=\"#\" data-type=\"select2\" data-pk=\"{$stud['id']}\" data-url=\"/plan/selectTests\" data-title=\"\" {$data_tests} data-emptytext=\"Список тестов\"></a></td>";
            $html .= '</tr>';
        }
        $html .= '</table>';

        header('Content-Type: application/json');
        echo json_encode(['res' => $html, 'opts' => $tests_str]);

        die;
    }

    public function toggleTestsAction() {
        $user = \R::load('users',$_POST['pk']);
        $user->restored = current($_POST['value']) ?: null;
        \R::store($user);
        dd2($_POST);
    }

    public function selectTestsAction() {
        $user = \R::load('users',$_POST['pk']);
        $user->restored_tests = $_POST['value'] ? trim($_POST['value'],','): null;
        \R::store($user);
        die;
    }

    public function selectTestsAllAction() {
        if (empty($_POST['pk'])) die();
        foreach (explode(',',$_POST['pk']) as $id) {
            $user = \R::load('users',$id);
            $user->restored_tests = $_POST['value'] ? trim($_POST['value'],','): null;
            \R::store($user);
        }
        die;
    }

}