<?php
$n = 0;
    $options = json_decode($poll->polls);
    $nav = $_nav = $polls[$poll->alias];
    $prev = $next = false;
    foreach ($_nav as $k => $el) {
        $n++;
        if ($k == $poll->id) break;
        $prev = key($nav);
        next($nav);
    }
//        if (isset($_GET['qwe'])) dump($prev);
    next($nav);
    $next = key($nav);
    if (isset($_GET['qwe'])) dump($prev, $next);
?>
<h2 style="display:inline;float:left;margin: 0;">Вопрос №<?= $n ?></h2>
<ul class="pager" style="float:right;margin: 0;">
    <li <?= $prev ?'':'class="disabled"'?>><a href="<?= $prev ? "?id={$prev}" : '#' ?>"><span aria-hidden="true">&larr;</span> Предыдущий</a></li>
    <li <?= $next ?'':'class="disabled"'?>><a href="<?= $next ? "?id={$next}" : '#' ?>">Следующий <span aria-hidden="true">&rarr;</span></a></li>
</ul>
<!--<div class="btn-group" style="float: right">-->
<!--    --><?php //if ($prev): ?>
<!--        <a class="btn btn-default" href="?id=--><?//= $prev ?><!--"><i class="glyphicon glyphicon-arrow-left"></i> Предыдущий</a>-->
<!--    --><?php //endif; ?>
<!--    --><?php //if ($next): ?>
<!--        <a class="btn btn-default" href="?id=--><?//= $next ?><!--">Следующий <i class="glyphicon glyphicon-arrow-right"></i></a>-->
<!--    --><?php //endif; ?>
<!--</div>-->
<div class="clearfix"></div>
<br>
<form action="/polls/save" method="post" class="panel panel-default">
    <div class="panel-heading">Редактирование опроса</div>
    <div class="panel-body">
        <div class="col-xs-12">
            <h4> </h4>
            <div class="form-group">
                <label for="title">Введите заголовок:</label>
                <input type="text" name="title" value="<?= $poll->title ?>" class="form-control">
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-sm-2">
                        <label for="type">Тип опроса:</label>
                        <select name="type">
                            <option <?= $poll->type==0?'selected':'' ?> value="0">Простой</option>
                            <option <?= $poll->type==2?'selected':'' ?> value="2">Мультивыбор</option>
                            <option <?= $poll->type==1?'selected':'' ?> value="1">Пьедестал</option>
                        </select>
                    </div>
                    <!--<div class="col-sm-3">
                        <label for="">Число вариантов:</label>
                        <input type="number" name="num" value="<?/*= count($options) */?>" min="<?/*= count($options) */?>" max="25" class="form-control">
                    </div>-->
                    <div class="col-sm-10">
                        <label for="">Введите алиас страницы (пр.: obrazovanie):</label>
                        <input type="text" name="url" value="<?= $poll->alias ?>" class="form-control">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="text">Перенаправить после ответа:</label>
                <input name="redirect" class="form-control" value="<?= @$poll->redirect ?>">
            </div>
            <div class="form-group">
                <label for="text">Введите текст:</label>
                <textarea name="text" rows="10" class="form-control" id="editor1"><?= @$poll->text ?></textarea>
            </div>

            <label style="width: 100%;">Варианты ответов (можно передвигать): <span class="add-option pull-right btn btn-link">добавить вариант...</span></label>
            <ul class="well well-sm" id="sortable">
                <?php foreach ($options as $k=>$option): ?>
                    <li class="form-group ui-state-default">
                        <div class="input-group">
                            <div class="input-group-addon"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span></div>
                            <input type="text" name="poll[]" value="<?= $option->poll ?>" class="form-control">
                            <div class="input-group-addon delete-option"><span class="glyphicon glyphicon-remove"></span></div>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <div class="panel-footer">
        <input type="hidden" name="id" value="<?= $poll->id ?>">
        <a href="/polls" class="btn btn-default">Назад</a>
        <button class="btn btn-success">Сохранить</button>
    </div>
</form>

<div class="form-group">
<form action="/polls/dub" method="post">
    <input type="hidden" name="id" value="<?= $poll->id ?>">
    <label>Скопировать варианты в:&nbsp;</label>
    <select name="dub" style="width: 300px; margin: 0">
        <option value="" selected disabled style="display: none;">Не выбрано</option>
        <?php foreach ($polls as $k=>$g): ?>
            <optgroup label="<?= $k ?>">
                <?php $nn=1;
                foreach ($g as $kk=>$item): ?>
                    <?php if ($kk == $poll->id) continue; ?>
                    <option value="<?= $kk ?>"><?= $nn++ ?>. <?= $item ?></option>
                <?php endforeach; ?>
            </optgroup>
        <?php endforeach; ?>
    </select>
    <button class="btn btn-warning">Скопировать</button>
</form>
</div>

<?php /*<script src="/js/ckeditor/ckeditor.js"></script>
 <script>
    CKEDITOR.replace( 'editor1', {
        'height': 600,
        'customConfig':'/js/ckeditor/config.js'
    });
</script>*/ ?>

<?php /*<script data-main="/js/elfinder/main.ckedialog.js" src="//cdnjs.cloudflare.com/ajax/libs/require.js/2.3.2/require.min.js"></script>*/ ?>
<script src="/js/ckeditor/ckeditor.js"></script>
<script src="/js/elfinder/js/elfinder.min.js"></script>
<script src="/js/elfinder/js/i18n/elfinder.ru.js"></script>
<script src="/js/jquery-ui/jquery-ui.min.js"></script>
<link rel="stylesheet" href="/js/jquery-ui/jquery-ui.min.css">
<link rel="stylesheet" href="/js/elfinder/css/elfinder.min.css ">
<script src="/js/ckeditor/load.js"></script>
<script>
     // setup CKEditor
    CKEDITOR.replace('editor1', {});

    $( function() {
        $( "#sortable" ).sortable({ placeholder: "ui-state-highlight" });
        $( "#sortable" ).disableSelection();
    } );

    $('.add-option').click(function () {
        $('#sortable').append('<li class="form-group ui-state-default">'+
            '<div class="input-group">'+
                '<div class="input-group-addon"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span></div>'+
                '<input type="text" name="poll[]" value="" class="form-control">'+
                '<div class="input-group-addon delete-option"><span class="glyphicon glyphicon-remove"></span></div>'+
            '</div>'+
        '</li>')
    });

    $('.delete-option').click(function () {
        $(this).parent().parent().remove()
    });
</script>
<style>
    #sortable { list-style-type: none; padding: 15px; }
    #sortable li { margin-bottom: 1em;}
    .ui-state-default { border: none; }
    .ui-state-highlight { height: 2em; line-height: 2em; }
    .delete-option { background-color: red; color: white; border: none; cursor: pointer }
</style>