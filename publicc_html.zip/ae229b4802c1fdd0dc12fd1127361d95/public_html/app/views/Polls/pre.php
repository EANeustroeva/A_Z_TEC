<form action="" class="panel panel-default">
    <div class="panel-heading">Подготовка опроса</div>
    <div class="panel-body">
        <div class="col-xs-12">
            <h4> </h4>
            <div class="row">
                <div class="col-sm-offset-3 col-sm-6">
                    <div class="form-group">
                        <label for="">Введите заголовок:</label>
                        <input type="text" name="title" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">Введите число вариантов:</label>
                        <input type="number" name="num" value="2" min="1" max="25" class="form-control">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="panel-footer">
        <a href="/polls" class="btn btn-default">Назад</a>
        <button class="btn btn-success">Далее</button>
    </div>
</form>