<a href="/polls/pre" class="btn btn-success"><i class="glyphicon glyphicon-plus-sign"></i> Новый опрос</a>
<div class="pull-right">
    <a href="/polls/resetAll" class="btn btn-danger">Начать опрос (сброс всей статистики)</a>
    <a href="/polls/end" class="btn btn-warning">Закончить опрос</a>
</div>
<hr class="clear">

<table class="table table-bordered table-hover">
<thead>
<tr>
    <th>#</th>
    <th>Заголовок</th>
<!--    <th>Ссылка</th>-->
<!--    <th>Результаты</th>-->
    <th style="width: 70px;">Вариантов</th>
    <th style="width: 70px;">Всего проголосовало</th>
    <th style="width: 70px;">Порядок</th>
    <th style="width: 100px;">Действие</th>
</tr>
</thead>
<tbody>
<?php foreach ($polls as $alias => $g): ?>
<?php
    $min=$max=0;
    $ord = [];
    $redirect = false;
    foreach ($g as $poll) {
        $ord[] = $poll->ordering;
        if (!$redirect && $poll->redirect) $redirect = $poll->redirect;
    }
    $min = min($ord);
    $max = max($ord);
?>
<tr class="success">
    <td colspan="6" class="text-left">
        <strong>Ссылка:</strong> <a target="_blank" href="/ask/<?= $alias ?>"><?= $alias ?></a>&nbsp;&nbsp;&nbsp;&nbsp;
        <strong>Результаты:</strong> <a target="_blank" href="/ask<?= !empty($alias)?'/'.$alias:'' ?>/results">ссылка</a>
        <?php if ($redirect): ?>
        &nbsp;&nbsp;&nbsp;&nbsp;<strong>Перенаправить:</strong> <a target="_blank" href="<?= (!parse_url($redirect, PHP_URL_SCHEME)?'http://':'').$redirect ?>">ссылка</a>
        <?php endif; ?>
        <?php if (!empty($alias)): ?>
        <span class="pull-right">
            <a class="btn btn-info btn-xs" target="_blank" href="/polls/results?id=<?= $alias ?>">Статистика</a>
            <a class="btn btn-info btn-xs" target="_blank" href="/polls/archive?id=<?= $alias ?>">Архив</a>
        </span>
        <?php endif; ?>
    </td>
</tr>
    <?php
    $ct=1;
    foreach ($g as $poll): ?>
<?php
    $total_votes = 0;
    $options = json_decode($poll->polls);

    foreach ($options as $key => $option) { $total_votes = $total_votes + $option->votes; }

?>
<tr>
    <td width="1"><?=$ct++?></td>
    <td class="text-left">
        <?php $text = trim(strip_tags(preg_replace("#math-tex\">(.+)\<\/span>#si",'',$poll->text))); ?>
        <a href="#" class="textarea_modal_widget" data-pk="<?= $poll->id ?>" data-emptytext="Пусто" data-value="<?= htmlentities($poll->text) ?>"><?= !empty($text)?$text:strip_tags($poll->text) ?></a>

        <?php if (!empty($poll->redirect)): ?>
            &nbsp;<span class="label label-success">редирект</span>
        <?php endif; ?>
    </td>
    <td class="text-left"><?= count($options) ?></td>
    <td class="text-left"><?= $total_votes ?></td>
    <td>
        <?php if ($poll->ordering>$min): ?>
        <a href="/polls/up?id=<?= $poll->id ?>" class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-arrow-up"></i></a>
        <?php endif; ?>
        <?php if ($poll->ordering<$max): ?>
        <a href="/polls/down?id=<?= $poll->id ?>" class="btn btn-primary btn-xs"><i class="glyphicon glyphicon-arrow-down"></i></a>
        <?php endif; ?>
    </td>
    <td>
        <a href="/polls/results?id=<?= $poll->id ?>" class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-eye-open"></i></a>
        <a href="/polls/edit?id=<?= $poll->id ?>" class="btn btn-primary btn-xs"><i class="glyphicon glyphicon-pencil"></i></a>
        <a href="/polls/delete?id=<?= $poll->id ?>" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-remove"></i></a>
    </td>
</tr>
    <?php endforeach; ?>
<?php endforeach; ?>
</tbody>
</table>

<?php /*<link href="/js/lib/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/js/wysihtml5/bootstrap-wysihtml5.css" rel="stylesheet" type="text/css">
<script src="/js/wysihtml5/wysihtml5-0.3.0.min.js"></script>
<script src="/js/wysihtml5/bootstrap-wysihtml5.js"></script>*/ ?>



<style>
.editable-container.editable-inline,
.editable-container.editable-inline .control-group.form-group,
.editable-container.editable-inline .control-group.form-group .editable-input,
.editable-container.editable-inline .control-group.form-group .editable-input textarea,
.editable-container.editable-inline .control-group.form-group .editable-input select,
.editable-container.editable-inline .control-group.form-group .editable-input input:not([type=radio]):not([type=checkbox]):not([type=submit])
{
    width: 100%!important;
}
.editable-buttons {
    float: left;
}
</style>
<script src="/js/ckeditor/ckeditor.js"></script>
<script src="/js/elfinder/js/elfinder.min.js"></script>
<script src="/js/elfinder/js/i18n/elfinder.ru.js"></script>
<script src="/js/jquery-ui/jquery-ui.min.js"></script>
<link rel="stylesheet" href="/js/jquery-ui/jquery-ui.min.css">
<link rel="stylesheet" href="/js/elfinder/css/elfinder.min.css ">
<script src="/js/ckeditor/load.js"></script>

<link rel="stylesheet" href="/js/x-editable/bootstrap3-editable/css/bootstrap-editable.css">
<script src="/js/x-editable/bootstrap3-editable/js/bootstrap-editable.js"></script>
<script src="/js/x-editable/bootstrap3-editable/bootstrap-editable.ckeditor.js"></script>

<script>
    $('.textarea_modal_widget').click(function () {
        var editor = CKEDITOR.instances.editor_input;
        if (editor) {
            console.log('instance exists');
            editor.destroy(true);
            console.log('destroyed');
            $('.editable-open').editableContainer('hide', 'cancel');
        }
    });

    $.fn.editable.defaults.mode = 'inline';
    $('.textarea_modal_widget').editable({
        type: 'ckeditor',
        url: '/polls/changeText',
        onblur: 'ignore',
        display: function(value, sourceData) {
            if (value === '') return;
            var html = value.replace( /math-tex\">(.+)\<\/span>/g, ":");
            var div = document.createElement("div");
            div.innerHTML = html;
            $(this).html(div.textContent || div.innerText || "");
       }
    });

</script>