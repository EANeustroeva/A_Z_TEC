<?php
            if (empty($docs)): echo '<h3 class="text-center" style="margin-bottom: 20px;">Документы отсутствуют</h3>';
            else: ?>
            <table class="table table-striped table-hover table-bordered">
                <thead>
                <tr>
                    <th>ИК</th>
                    <th>Имя</th>
                    <th>Дата</th>
                    <th>Размер</th>
                    <th>Тип</th>
                    <th>Изменить</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($docs as $item): ?>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td><a href="<?= BASE_URL . 'download?f=' .base64_encode('docs/'. $item['real'] . '.' . $item['type']) . '&c='.urlencode($item['name']).'.'.$item['type'] ?>" data-toggle="tooltip" title="<?= $item['name'].'.'.$item['type'] ?>"><?php echo mb_strimwidth($item['name'], 0, 15, '...'); ?></a></td>
                        <td><?php echo $item['date']; ?></td>
                        <td><?php echo $item['size']; ?></td>
                        <td><?php echo $item['type']; ?></td>
                        <td class="text-center">
                                <!--<a class='btn btn-info btn-xs' href="#">
                                    <span class="glyphicon glyphicon-edit"></span>&nbsp;<span
                                            class="hidden-xs">Изменить</span></a>-->
                                <form action="docs/delete" method="post">
                                <button class="btn btn-danger btn-xs">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <span class="glyphicon glyphicon-remove"></span>&nbsp;<span class="hidden-xs">Удалить</span></button>

                                </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>