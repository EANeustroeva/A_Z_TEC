<?php if ($cur_user->access == 4): ?>
    <ul class="nav nav-tabs">
        <li class="active"><a data-toggle="tab" href="#home">Успеваемость</a></li>
        <li class=""><a data-toggle="tab" href="#menu1">Достижения</a></li>
        <li class=""><a data-toggle="tab" href="#menu2">Резюме</a></li>
    </ul>

    <div class="tab-content">
        <div id="home" class="tab-pane fade in active">
<div class="panel-group" id="accordion">
<!--    --><?php //for ($i=1;$i<9;$i++): ?>
    <?php foreach ($port as $i => $sem): ?>
        <?php if (empty($sem)) continue ?>
     <div class="panel panel-default">
         <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?= $i ?>"><?= $i ?> семестр</a>
            </h4>
         </div>
         <div id="collapse<?= $i ?>" class="panel-collapse collapse">
            <div class="panel-body">
                <div class="row">
                <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                    <thead>
                    <tr>
                        <th style="width: 30%;">Предмет</th>
                        <th style="width: 30%;">Преподаватель</th>
                        <th style="width: 25%;">Оценки</th>
                        <th style="width: 15%;">Итоговая</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sem as $item): ?>
                            <?php if ($item['kurs']) continue; ?>
                            <tr<?php echo ($item['total_marks']=='')?' class=danger':'' ?>>
                                <td class="text-left">
                                    <?php if (count($item['ww']) || count($item['files'])): ?>
                                        <a href="#<?= $i. md5($item['disc']) ?>" data-toggle="collapse"><?= $item['disc'] ?></a>
                                    <?php else: ?>
                                        <?= $item['disc'] ?>
                                    <?php endif; ?>
                                    <?php if ($item['kurs']): ?>
                                        <span class="badge pull-right" style="background-color: #337ab7;">курсовая</span>
                                    <?php endif; ?>
<!--                                    <a href="/tasks?s=--><?//= $i ?><!--&disc=--><?//= $item['disc'] ?><!--" target="_blank" class="btn-link text-left pull-right" name="disc">-->
<!--                                        <i class="glyphicon glyphicon-share"></i>-->
<!--                                    </a>-->
                                </td>
                                <td class="text-left"><a href="<?= BASE_URL ?>?id=<?= $item['user_id'] ?>" target="_blank"><?= @$item['lektor'] ?></a></td>
                                <td class="text-left"><?= $item['marks'] ?></td>
                                <td class="text-left"><?= $item['total_marks'] ?></td>
                            </tr>
                        <?php if (count($item['ww']) || count($item['files'])): ?>
                            <tr class="collapse" id="<?= $i. md5($item['disc']) ?>"><td colspan="4" style="padding: 0;">
                                <?php if (count($item['ww'])): ?>
                                <table style="width: 100%;margin: 0;" class="table table-hover">
                                <?php foreach ($item['ww'] as $work): ?>
                                    <tr>
                                     <td><?= date("H:i d/m/Y", strtotime($work['created'])) ?></td>
                                     <td><?php if (!empty($work['file'])): ?>
                                        <a href="<?= 'upload/works/' . $work['file'] ?>" class="btn btn-warning btn-xs" target="_blank">
                                            <span class="glyphicon glyphicon-download"></span>&nbsp;<span class="hidden-xs">Скачать</span>
                                        </a>
                                        <?php endif; ?>
                                     </td>
                                     <td>
                                         <form action="/tasks/docs" data-blocked="<?= empty($work['perc']) ? 1 : 0 ?>" class="docgen" data-id="<?= $work['id'] ?>" target="_blank" method="post">
                                            <input type="hidden" name="sem" value="<?= $i ?>">
                                            <input type="hidden" name="disc" value="<?= $item['disc'] ?>">
                                            <input type="hidden" name="user_id" value="<?= $cur_user->id ?>">
                                            <button style="width: 100%;" type="submit" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-download"></span>&nbsp;Cправка</button>
                                        </form>
                                     </td>
                                     <td>
                                         <?php
                                            if ($work['status']==0) echo 'Ожидается проверка';
                                            elseif ($work['status']==1) echo 'Работа проверяется';
                                            elseif ($work['status']==2) echo 'Работа проверена';
                                        ?>
                                     </td>
                                     <td><?= $work['type'] ?></td>
                                     <td><?php
                                        if (@$work['mark']==6) echo 'зач';
                                        elseif (@$work['mark']==7) echo 'на дораб.';
                                        else echo @$work['mark'] ?>
                                     </td>
                                     <td>
                                        <?php /* if (!empty($work['perc'])): ?>
                                        <?= $work['perc'] . '%' ?>
                                            <a target="_blank" class="btn btn-xs btn-success pull-right" href="<?= $work['pdf'] ?>" title="Полный отчет">
                                                <i class="glyphicon glyphicon-download-alt"></i>
                                            </a>
                                        <?php endif; */?>
                                     </td>
                                     <td>
                                         <?php if (!empty($mark['comment'])): ?>
                <?php $comment = '<span style="white-space: normal">'. str_replace("\n",'<br>',$mark['comment']) .'</span>' ?>
                <span tabindex="0" data-html="true" data-toggle="popover"
                      data-content="<?= htmlentities($comment) ?>" class="btn btn-xs btn-primary" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></span><?php endif; ?>
                                     </td>
                                 </tr>
                                <?php endforeach; ?>
                                </table>
                                <?php endif; ?>
                                <?php if (count($item['files'])): ?>
                                 <table style="width: 100%;margin: 0;text-align: center;" class="table table-hover">
                                     <tr>
                                         <td style="text-align: left">РПД: <br>
                                             <?php if (count($item['files']['rpd'])): ?>
                                                <a tabindex="0" data-html="true" data-trigger="hover" data-toggle="popover" data-content="<?= htmlspecialchars(current($item['files']['rpd'])['descr'])  ?>" class="list-group-item" style="padding: 0;display:inline-block;" href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . current($item['files']['rpd'])['fname']) . '&c=' . urlencode(current($item['files']['rpd'])['ftitle']) ?>"><i class="glyphicon glyphicon-open-file"></i> <?= current($item['files']['rpd'])['ftitle'] ?></a>
                                             <?php endif; ?>
                                         </td>
                                         <td style="text-align: left">ФОС: <br>
                                             <?php if (count($item['files']['fos'])): ?>
                                                <a tabindex="0" data-html="true" data-trigger="hover" data-toggle="popover" data-content="<?= htmlspecialchars(current($item['files']['fos'])['descr'])  ?>" class="list-group-item" style="padding: 0;display:inline-block;" href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . current($item['files']['fos'])['fname']) . '&c=' . urlencode(current($item['files']['fos'])['ftitle']) ?>"><i class="glyphicon glyphicon-open-file"></i> <?= current($item['files']['fos'])['ftitle'] ?></a>
                                             <?php endif; ?>
                                         </td>
                                         <td style="text-align: left"> Доп.файлы: <br>
                                             <?php if (count($item['files']['add'])): ?>
                                                 <?php foreach ($item['files']['add'] as $file): ?>
                                                    <a tabindex="0" data-html="true" data-trigger="hover" data-toggle="popover" data-content="<?= htmlspecialchars($file['descr'])  ?>" class="list-group-item" style="padding: 0;display:inline-block;" href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $file['fname']) . '&c=' . urlencode($file['ftitle']) ?>"><i class="glyphicon glyphicon-open-file"></i> <?= $file['ftitle'] ?></a>
                                                 <?php endforeach; ?>
                                             <?php endif; ?>
                                         </td>
                                     </tr>
                                 </table>
                                <?php endif; ?>
                            </td></tr>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                    </div>
            </div>
         </div>
     </div>
    <?php endforeach; ?>

<?php if ($curs): ?>
<div class="row">
    <div class="col-sm-12">
        <h4 class="text-center">Курсовые работы</h4>
        <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
            <thead>
            <tr>
                <th style="width: 10%;">Семестр</th>
                <th style="width: 35%;">Предмет</th>
                <th style="width: 40%;">Руководитель</th>
                <th style="width: 15%;">Оценка</th>
            </tr>
            </thead>
            <tbody>
            <?php if (!$curs): ?>
                <tr><td colspan="4" style="padding: 10px 20px;">Ожидается распределение</td></tr>
            <?php else: ?>
                <?php foreach ($curs as $item): ?>
                <?php if (empty($item['sem'])) continue; ?>
                <tr>
                    <td><?= $item['sem'] ?></td>
                    <td><?= $item['disc'] ?></td>
<!--                    <td class="text-left">-->
<!--                        <form action="--><?//= BASE_URL ?><!--curstasks" method="post" target="_blank">-->
<!--                            <input type="hidden" name="sem" value="--><?//= $item['sem'] ?><!--">-->
<!--                            <button class="btn-link text-left" name="disc" value="--><?//= $item['disc'] ?><!--">--><?//= $item['disc'] ?><!--</button>-->
<!--                        </form>-->
<!--                    </td>-->
                    <td class="text-left"><?= $item['lektor'] ?></td>
                    <td class="text-center"><?= $item['marks'] ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php if ($vkr): ?>
    <div class="row">
        <div class="col-sm-12">
            <h4 class="text-center">Выпускная квалификационная работа</h4>
            <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                <thead>
                <tr>
                    <th style="width: 10%;">Семестр</th>
                    <th style="width: 35%;">Предмет</th>
                    <th style="width: 40%;">Руководитель</th>
                    <th style="width: 15%;">Оценка</th>
                </tr>
                </thead>
                <tbody>
                <?php if (!$vkr): ?>
                    <tr><td colspan="4" style="padding: 10px 20px;">Ожидается распределение</td></tr>
                <?php else: ?>
                    <?php foreach ($vkr as $item): ?>
                    <tr>
                        <td><?= $item['sem'] ?></td>
                        <td><?= $item['disc'] ?></td>
<!--                        <td class="text-left">-->
<!--                            <form action="--><?//= BASE_URL ?><!--vkrtasks" method="post" target="_blank">-->
<!--                                <input type="hidden" name="sem" value="--><?//= $item['sem'] ?><!--">-->
<!--                                <button class="btn-link text-left" name="disc" value="--><?//= $item['disc'] ?><!--">--><?//= $item['disc'] ?><!--</button>-->
<!--                            </form>-->
<!--                        </td>-->
                        <td class="text-left"><?= $item['lektor'] ?></td>
                        <td class="text-left"><?= $item['marks'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
<?php if ($pract): ?>
    <div class="row">
        <div class="col-sm-12">
            <h4 class="text-center">Практика</h4>
            <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                <thead>
                <tr>
                    <th style="width: 10%;">Семестр</th>
                    <th style="width: 35%;">Предмет</th>
                    <th style="width: 40%;">Руководитель</th>
                    <th style="width: 15%;">Оценка</th>
                </tr>
                </thead>
                <tbody>
                <?php if (!$pract): ?>
                    <tr><td colspan="4" style="padding: 10px 20px;">Ожидается распределение</td></tr>
                <?php else: ?>
                    <?php foreach ($pract as $item): ?>
                    <tr>
                        <td><?= $item['sem'] ?></td>
                        <td><?= $item['disc'] ?></td>
<!--                        <td class="text-left">-->
<!--                            <form action="--><?//= BASE_URL ?><!--practtasks" method="post" target="_blank">-->
<!--                                <input type="hidden" name="sem" value="--><?//= $item['sem'] ?><!--">-->
<!--                                <button class="btn-link text-left" name="disc" value="--><?//= $item['disc'] ?><!--">--><?//= $item['disc'] ?><!--</button>-->
<!--                            </form>-->
<!--                        </td>-->
                        <td class="text-left"><?= $item['lektor'] ?></td>
                        <td class="text-left"><?= $item['marks'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
</div>
        </div>
        <div id="menu1" class="tab-pane fade">
            <div style="position: relative;" class="uploader">
                <div style="margin-top: 5px" id="file-uploader"></div>
                <i data-toggle="tooltip" title="После загрузки файлов перезагрузите страницу" style="position: absolute; left: 50%; margin-left: 90px;top: 0px; color: #337ab7; font-size: 18px; cursor:pointer;" class="glyphicon glyphicon-info-sign"></i>
            </div>

             <?php
            if (empty($docs)): echo '<h3 class="text-center" style="margin-bottom: 20px;">Документы отсутствуют</h3>';
            else: ?>
            <table id="table_id" class="table table-striped table-hover table-bordered table-responsive" style="min-width:476px;overflow-x:auto">
                <thead>
                <tr>
                    <th>Грамота</th>
                    <th>Дата</th>
                    <th>Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($docs as $k=>$item): ?>
                    <tr>
                        <td><a href="<?= BASE_URL . 'download?f=' .base64_encode('docs/'. $item['real'] . '.' . $item['type']) . '&c='.urlencode($item['name']).'.'.$item['type'] ?>" data-toggle="tooltip" title="<?= $item['name'].'.'.$item['type'] ?>"><?php echo mb_strimwidth($item['name'], 0, 15, '...'); ?></a></td>
                        <td><?php echo $item['date']; ?></td>
                        <td class="text-center">
                            <form action="<?= BASE_URL ?>docs/delete" method="post">
                            <button class="btn btn-danger btn-xs">
                                <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                <span class="glyphicon glyphicon-remove"></span>&nbsp;<span class="hidden-xs">Удалить</span></button>

                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <div id="menu2" class="tab-pane fade">
            <blockquote>
              <p>Раздел находится в разработке...</p>
            </blockquote>
        </div>
    </div>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="<?= BASE_URL ?>css/fileuploader.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script src="<?= BASE_URL ?>js/fileuploader.js"></script>
<script type="text/javascript">
    $( document ).ready(function() {
        $(function () {
          $('[data-toggle="popover"]').popover()
        })
        var table = $('#table_id').DataTable({
            "columnDefs": [
                { "orderable": true }
            ],
            stateSave: true,
            "info":     false,
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            }
        });
        var uploader = new qq.FileUploader({
            element: document.getElementById('file-uploader'),
            action: 'docs/upload',
            params: {},
            allowedExtensions: [],
            template: '<div class="qq-uploader">' +
            '<div class="qq-upload-drop-area"><span>{dragText}</span></div>' +
            '<div class="qq-upload-button btn btn-success" style="margin: 0 auto">{uploadButtonText}</div>' +
            '<hr><ul class="qq-upload-list list-group"></ul>' +
            '</div>',
            fileTemplate: '<li class="list-group-item">' +
            '<span class="qq-progress-bar progress"></span>' +
            '<span class="qq-upload-file"></span>' +
            '<span class="qq-upload-spinner"></span>' +
            '<span class="qq-upload-size"></span>' +
            '<a class="qq-upload-cancel" href="#">{cancelButtonText}</a>' +
            '<span class="qq-upload-failed-text">{failUploadtext}</span>' +
            '</li>',
            dragText: 'Переместите файл в эту зону для загрузки',
            uploadButtonText: '<i class="glyphicon glyphicon-plus-sign"></i>&nbsp; Добавить грамоту...',
            cancelButtonText: 'Отмена',
            failUploadText: 'Ошибка',
            onComplete: function (id, fileName, responseJSON) {
                setInterval("$('.qq-upload-success').fadeOut(500)", 1000);
            },
            onProgress: function(id, fileName, loaded, total){
                console.log(total);
            },
        });

    });
</script>

<?php endif; ?>

<style>
    .qq-upload-button { width: 150px; }
    #accordion .area { border-left: 4px solid #f38787; }
    #accordion .equipamento { border-left: 4px solid #65c465; }
    #accordion .ponto { border-left: 4px solid #98b3fa; }
    #accordion .collapse.in { overflow: visible; }
    #accordion .panel-body { padding: 15px; }
    .panel-group .panel+.panel { margin-top: 0px; }
    #accordion .panel-default>.panel-heading { background-color: transparent; }

.tooltip-inner {
    max-width: 150px!important;
    /* If max-width does not work, try using width instead */
    width: 100px!important;
    background: #f60!important;
    color: white!important;
    font-size: 16px!important;
}
.tooltip-arrow {
    border-right-color: #f60!important;
}
</style>