<div class="modal fade" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="exampleModalLabel">Тема работы</h4>
            </div>
            <div class="modal-body">
<!--            <form action="--><?//= BASE_URL ?><!--curstasks/docstitle?disc=--><?//= $_POST['disc'] ?><!--" method="post">-->
                <input type="hidden" name="type" value="дист">
                <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
                <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
                <input type="hidden" name="user_id" value="<?= $cur_user->id ?>">
                <input type="hidden" name="form" value="">
                <div class="form-group">
                    <label>Укажите тему работы</label>
                    <input type="text" class="form-control" name="title" value="<?= @$curs['title'] ?>" placeholder="Тема курсовой">
                </div>
                <div class="form-group">
                    <input type="hidden" name="id" value="0">
                    <input type="hidden" name="prep_id" value="<?= @$_POST['prep_id'] ?>">
                    <span id="save" type="submit" class="btn btn-success"><span class="glyphicon glyphicon-eye-open"></span>
                        Сохранить
                    </span>
                </div>
<!--            </form>-->
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-8">
        <?php if (isset($plan['napr'])): ?>
            <h5>Направление: <?= isset($plan['napr']) ? $plan['napr'] . ' ('. $plan['napr_n'] . ')' : 'Не найдено'?></h5>
        <?php endif; ?>
        <?php if (isset($plan['dop'])): ?>
            <h5>Профиль:     <?= isset($plan['dop']) ? $plan['dop'] : 'Не найдено'?></h5>
        <?php endif; ?>
        <h4>Предмет:     <?= $_POST['disc'] ?></h4>
    </div>
<!--    --><?php //if (isset($plan['lektor'])): ?>
    <div class="col-sm-4">
        <form action="<?= BASE_URL ?>disttasks/view" method="post" style="display: inline" class="pull-right">
            <input type="hidden" name="id" value="0">
            <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
            <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
            <input type="hidden" name="prep_id" value="<?= isset($plan['user_id']) ? $plan['user_id'] : '' ?>">
<!--            <button type="submit" class="btn btn-success">-->
<!--                <span class="glyphicon glyphicon-eye-open"></span>&nbsp;Загрузить работу</button>-->
        </form>
    </div>
<!--    --><?php //endif; ?>
</div>

<?php
    if (empty($docs) && empty($rpd) && empty($fos)): echo '<div class="panel panel-default"><div class="panel-body"><h3 class="text-center" style="margin-bottom: 20px;">Документы по выбранному предмету не найдены</h3></div></div>';
else: ?>
<table class="table table-responsive table-bordered table-striped">

    <tbody>
        <?php if (!empty($rpd)): ?>
        <tr>
            <th>РПД:</th>
            <td colspan="2">
                <a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $rpd['fname']) . '&c=' . urlencode($rpd['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $rpd['ftitle'] ?></a>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($fos)): ?>
        <tr>
            <th>ФОС:</th>
            <td colspan="2">
                <a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $fos['fname']) . '&c=' . urlencode($fos['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $fos['ftitle'] ?></a>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($docs)): ?>
        <tr class="info"><th colspan="3">Задания:</th></tr>
        <tr>
            <th>Файл</th>
            <th>Комментарий</th>
            <th>Действие</th>
        </tr>
    <?php foreach ($docs as $i => $task): ?>
        <tr>
            <td><a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $task['fname']) . '&c=' . urlencode($task['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $task['ftitle'] ?></a></td>
            <td><?php
//                if (empty($task['descr']))  $task['descr']='-';
                if ($user->access==4)
                    if (!empty($task['descr'])) echo '<span tabindex="0" data-html="true" data-toggle="popover"
                      data-content="'. htmlspecialchars($task['descr']) .'" class="btn btn-xs btn-primary" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></span>';
//                mb_strimwidth($task['descr'], 0, 10, '..');
                else echo '<a href="tasks/workview?id='.$i.'">'.$task['descr'].'</a>' ?></td>
            <td>
                <?php if (!empty($task['taskfile'])): ?>
                <?php endif; ?>
                <?php if ($user->access!=4): ?>
                    <form action="<?= BASE_URL ?>tasks/edit" method="post" style="display: inline">
                        <input type="hidden" name="id" value="<?= $task['id'] ?>">
                        <input type="hidden" name="s" value="<?= $_GET['s'] ?>">
                        <button type="submit" class="btn btn-info btn-xs">
                            <span class="glyphicon glyphicon-edit"></span>&nbsp;<span
                                    class="hidden-xs">Изменить</span></button>
                    </form>
                <?php endif; ?>
<!--                --><?php //if (isset($plan['lektor'])): ?>
<!--                <form action="--><?//= BASE_URL ?><!--tasks/view?disc=--><?//= $_GET['disc'] ?><!--" method="post" style="display: inline">-->
<!--                    <input type="hidden" name="id" value="--><?//= $task['id'] ?><!--">-->
<!--                    <input type="hidden" name="s" value="--><?//= $_GET['s'] ?><!--">-->
<!--                    <input type="hidden" name="prep_id" value="--><?//= isset($plan['user_id']) ? $plan['user_id'] : '' ?><!--">-->
<!--                    <button type="submit" class="btn btn-success btn-xs">-->
<!--                        <span class="glyphicon glyphicon-eye-open"></span>&nbsp;<span-->
<!--                                class="hidden-xs">Загрузить ответ</span></button>-->
<!--                </form>-->
<!--                --><?php //endif; ?>
            </td>
        </tr>

    <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
<?php endif; ?>

<h4>Список работ</h4>
<table class="table table-bordered table-striped table-hover">

<?php $locked = false;
for ($i=1;$i<=$n;$i++):
$marks_ = array_filter($marks, function ($v) use ($i) { return $v['n']==$i; });
?>
<tr>
    <td width="1"><?= $i ?></td>
    <td>
        <?php if (!$locked): ?>
        <form action="<?= BASE_URL ?>disttasks/work?disc=<?= $_POST['disc'] ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="type" value="дист">
            <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
            <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
            <input type="hidden" name="user_id" value="<?= $cur_user->id ?>">
            <input type="hidden" name="id" value="0">
            <input type="hidden" name="n" value="<?= $i ?>">
            <input type="hidden" name="prep_id" value="<?= @$_POST['prep_id'] ?>">
            <input style="float: left;" type="file" name="userfile" required/>
            <div class="file-uploader"></div>
            <button type="submit" class="btn btn-success btn-xs pull-right"><span class="glyphicon glyphicon-eye-open"></span> Загрузить работу</button>
        </form>
        <div class="clearfix"></div>
        <?php endif; ?>
        <?php
            $locked = $locked || empty($marks_);

        if (!empty($marks_)): ?>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Дата</th>
                    <th>Работа</th>
                    <th>Преподаватель</th>
                    <th>Статус</th>
                    <th>Оценка</th>
                    <th>К-й</th>
                </tr>
                </thead>
                <tbody>

                <?php foreach ($marks_ as $mark): ?>
                    <tr>
                        <td><?= date("H:i d/m/Y", strtotime($mark['created'])) ?></td>
                        <td><?php if (!empty($mark['file'])): ?>
                                <a href="<?= 'upload/works/' . $mark['file'] ?>" class="btn btn-warning btn-xs" target="_blank">
                                    <span class="glyphicon glyphicon-download"></span>&nbsp;<span class="hidden-xs">Скачать</span>
                                </a>
                            <?php endif; ?></td>
                        <td><?= $mark['teacher'] ?></td>
                        <td><?php
                            if ($mark['status']==0) echo 'Ожидается проверка';
                            elseif ($mark['status']==1) echo 'Работа проверяется';
                            elseif ($mark['status']==2) echo 'Работа проверена';
                            ?></td>
                        <td><?php
                            if (@$mark['mark']==6) echo 'зач';
                            elseif (@$mark['mark']==7) echo 'на дораб.';
                            else echo @$mark['mark'] ?></td>
                        <td><?php if (!empty($mark['comment'])): ?>
                                <?php $comment = '<span style="white-space: normal">'. str_replace("\n",'<br>',$mark['comment']) .'</span>' ?>
                            <span tabindex="0" data-html="true" data-toggle="popover"
                                  data-content="<?= htmlentities($comment) ?>" class="btn btn-xs btn-primary" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></span><?php endif; ?></td>
                    </tr>
                <?php endforeach; ?>

                </tbody>
            </table>
        <?php endif; ?>
    </td>
</tr>
<?php endfor; ?>

</table>

<?php if ($_POST['disc'] && isset($plan['lektor'])): ?>
<h4>Диалог с преподавателем <?= $plan['lektor'] ?></h4>
<div class="chat"></div>
<script>
    $(document).ready(function () {
        $('.chat').html('<img src="/images/loader.gif" width="15">');
        $.ajax({
            url: '/im/widget',
            type: 'post',
            data: {id: <?= $plan['user_id'] ?>},
            success: function (res) {
                $('.chat').html(res)
            },
            error: function (e) {
                console.log(e);
            }
        });
    });
</script>
<?php endif; ?>

<script>
    $('#commentModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var modal = $(this);
        modal.find('input[name="form"]').val(button.data('form'));
    });
    $('#save').click(function () {
        var form = $('#commentModal input[name="form"]').val();
        $.ajax({
            url: base + 'disttasks/docstitle',
            type: 'post',
            data: {
                type: 'практ',
                sem:<?= $_POST['sem'] ?>,
                disc: '<?= $_POST['disc'] ?>',
                user_id:<?= $cur_user->id ?>,
                title: $('#commentModal input[name="title"]').val()
            },
            success: function (res) {
                $('.form1').find('a').remove();
                $('.form2').find('a').remove();
                $('.form1').append('<button style="width: 100%;" type="submit" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-download"></span>&nbsp;Справка</button>');
                $('.form2').append('<button style="width: 100%;" type="submit" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-download"></span>&nbsp;Отзыв</button>');
                $('#'+form).submit();
                $('#commentModal').modal('hide');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });
</script>

<style>
    .list-group-item {
        word-break: break-word;
    }
</style>

<script>
    var popOverSettings = {
    placement: 'left',
    container: 'body',
    trigger: 'focus',
    html: true,
    selector: '[data-toggle=popover]',
    content: function () {
        return $('#popover-content').html();
    }
};

$('body').popover(popOverSettings);

    $(document).ready(function () {

        $('.work').click(function () {
            var el = $(this);
            var id = el.data('id');
            $(this).html('<img src="/images/loader.gif" width="15">');

            $.ajax({
                url: '/tasks/test',
                type: 'get',
                data: {
                    id: id
                },
                success: function (res) {
//                    console.log(res);
                    if (res.success) {
                        el.parent().html(res.success + '%' +
                            '<a target="_blank" class="btn btn-xs btn-success pull-right" href="'+
                            res.pdf+ '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>');
                    }
                    else {
                        if (res.error) alert(res.error);
                        else alert('Антиплагиат временно отключен! ');
                        el.parent().html('')
                    }
                },
                error: function (res) {
                    el.parent().html('');
                    if (res.error) alert(res.error);
                    else alert('Произошла ошибка! ');
                    console.log(res);
                }
            })
        });

        $('.check-perc').click(function () {
            var el = $(this);
            var id = el.data('id');
            var btn = el.html();
            el.html('<img src="/images/loader.gif" width="15">');
            $.ajax({
                url: '/disttasks/testcheck',
                type: 'get',
                data: {
                    id: id
                },
                success: function (res) {
                    el.html(btn);
                    if (Number(res) < 50) {
                        el.parent().parent().addClass('danger');
                        el.attr('disabled',true);
                    } else {
                        el.parent().parent().removeClass('danger');
                        el.attr('disabled',false);
                    }
                },
                error: function (res) {
                    el.html(btn);
                    console.log(res);
                }
            });
        });

    });
</script>
