<div class="col-md-3">
    <div class="row">
        <div class="btn-group btn-group-justified">
            <a class="btn btn-info btn-xs" style="border-bottom-left-radius: 0;" title="Билеты по номерам">Билеты</a>
            <a class="btn btn-warning btn-xs" title="Билеты по темам">Темы</a>
            <a class="btn btn-danger btn-xs" style="border-bottom-right-radius: 0;" title="Ваши ошибки">Ошибки</a>
        </div>
        <div class="btn-group btn-group-justified">
            <a class="btn btn-success" style="border-top-left-radius: 0;border-top-right-radius: 0;"
               title="Сдать экзамен">Экзамен</a>
        </div>
    </div>
</div>
<div class="col-md-9">
    <div class="content">
        <div style="text-align:center;padding-top:3px;padding-bottom:3px;border-radius:5px;background-color:#337ab7;color:white;position: relative;">
            <h4 id="sQuestNumber">Вопрос 1</h4>
            <span id="dSpentTime" class="disappear"
                  style="background-color: rgb(238, 238, 238); display: inline-block; border-radius: 5px; float: right; padding: 0px 5px; margin-right: 3px; visibility: visible; position: absolute;right: 10px;top: 13px;">
            <span id="sSpentTime" style="color: rgb(0, 128, 0);"><b>19:39</b></span>
            </span>
        </div>
        <div name="mainForm">
            <div id="dMain">
                <div style="margin: 0 auto !important; float: none !important; display: block; width:auto; max-width:725px;">
                    <img name="questImages[0]" src="<?= BASE_URL . 'images/blank.jpg' ?>" class="img-responsive"
                         alt="Картинка к вопросу" style="width:100%; border:1px solid #ccc"></div>
                <div style="padding:5px; font-weight: bold;">Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Commodi, ex.?
                </div>

            </div>
            <div class="btn-group" data-toggle="buttons">
                <label class="btn btn-default btn-lg">
                    <input name="year" value=0 type="radio"><?= $q['Вопрос1'][0] ?>
                </label>
                <label class="btn btn-default btn-lg">
                    <input name="year" value=1 type="radio"><?= $q['Вопрос1'][1] ?>
                </label>
                <label class="btn btn-default btn-lg">
                    <input name="year" value=2 class="active"
                           type="radio"><?= $q['Вопрос1'][2] ?>
                </label>
            </div>
            <div class="clearfix"></div>
            <div class="btn-group" style="margin-top: 10px;">
                <button id="send" type="submit" class="btn btn-default">Подтвердить</button>
            </div>
            <input type="hidden" name="madeAnswers[0]" value="">
            </form>
        </div>
    </div>
</div>
<script>
    $(function () {
        $('#send').click(function () {
            $.ajax({
                url: 'tests/test',
                type: 'post',
                data: {'answ': $(".active > input").attr("value"),
                'id': $("#sQuestNumber").text()},
                success: function (res) {
                    $("label.active").removeClass("active");
                    $("#sQuestNumber").text('Вопрос '+res);
//                    console.log($(".active input").text('123'));
//                    console.log(res);
                },
                error: function () {
                    alert('Error!');
                }
            });
        });
    });
</script>