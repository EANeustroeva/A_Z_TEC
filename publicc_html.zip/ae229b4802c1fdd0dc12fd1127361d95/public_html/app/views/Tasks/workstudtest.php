<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#menu1">Основная</a></li>
    <li><a data-toggle="tab" disabled="disabled" href="#menu2">Инструкция</a></li>
</ul>

<div class="tab-content">
    <div id="menu1" class="tab-pane fade in active">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="col-sm-12">
                    <h4></h4>
                    <form action="<?= BASE_URL ?>tasks/workstudupluad" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="type">Тип работы*</label>
                            <select required class="selectpicker form-control" name="type" title="Тип работы">
                                <option selected value="кр">Контрольная работа</option>
                                <!--                        <option value="прр">проверочная</option>-->
                                <option value="кп">Курсовая работа</option>
                                <!--                        <option value="тр">типовой расчет</option>-->
                                <!--                        <option value="зач">зачет</option>-->
                                <!--                        <option value="экз">экзамен</option>-->
                            </select>
                        </div>
                        <div class="form-group">
                            <input type = "file" name = "userfile" required/>
                            <!--                    <input type="hidden" name="MAX_FILE_SIZE" value="30000" />-->
                            <div class="file-uploader"></div>
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="id" value="<?= $_POST['id'] ?>">
                            <button type="submit" class="btn btn-default">Загрузить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left" style="margin-right: 15px;">
                    <!--            <a href="--><?//= BASE_URL ?><!--tasks" class="btn btn-default"><i class="glyphicon glyphicon-chevron-left"-->
                    <!--                                                                      aria-hidden="true"></i> Назад</a>-->
                </div>
            </div>
            <div class="panel-body">
                <h4></h4>
                <?php
                if (empty($t['works'])): echo '<h3 class="text-center" style="margin-bottom: 20px;">Работы отсутствуют</h3>';
                else: ?>
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Дата</th>
                            <th>Название</th>
                            <th>Тип</th>
                            <th>% Ориг-ти</th>
                            <th>Скачать</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        foreach ($t['works'] as $work): ?>
                            <tr>
                                <td><?= $work['created'] ?></td>
                                <td><?= $work['ftitle'] ?></td>
                                <td><?= $work['type'] ?></td>
                                <td><?php if (!empty($work['perc'])): ?>
                                        <?= $work['perc'] . '%' ?>
                                        <a target="_blank" class="btn btn-xs btn-success pull-right" href="<?= $work['pdf'] ?>" title="Полный отчет">
                                            <i class="glyphicon glyphicon-download-alt"></i></a>
                                    <?php else: ?>
                                        <span data-id="<?= $work['id'] ?>" class="work btn btn-xs btn-default pull-right" title="Отправить на проверку"><i class="glyphicon glyphicon-check"></i></span>
                                    <?php endif; ?></td>
                                <td>
                                    <?php if (!empty($work['file'])): ?>
                                        <a href="<?= BASE_URL . 'upload/works/' . $work['file'] ?>" class="btn btn-warning btn-xs"
                                           target="_blank">
                                            <span class="glyphicon glyphicon-download"></span>&nbsp;<span
                                                    class="hidden-xs">Скачать</span></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div id="menu2" class="tab-pane fade">

    </div>
</div>


<!--
<div class="input-group date">
    <input id="datepicker_from2" type="text" class="form-control" value="<?/*= date('d/m/Y') */?>">
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div>-->
<script>
    $(function () {
        $('select').on('change', function () {
//            console.log( this.value );
//            console.log( this.getAttribute('id') );
            $.ajax({
                url: 'mark',
                type: 'post',
                data: {
                    'mark': this.value,
                    'id': this.getAttribute('id')
                },
                success: function (res) {
                    console.log(res);
                },
                error: function () {
                    console.log('Error!');
                }
            });
        })
    });
</script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script>
    function format ( d ) {
        // `d` is the original data object for the row
        return '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">'+
            '<tr>'+
            '<td>Full name:</td>'+
            '<td>'+d.name+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Extension number:</td>'+
            '<td>'+d.extn+'</td>'+
            '</tr>'+
            '<tr>'+
            '<td>Extra info:</td>'+
            '<td>And any further details here (images etc)...</td>'+
            '</tr>'+
            '</table>';
    }


    $(document).ready(function () {

        $('.work').click(function () {
            var el = $(this);
            var id = el.data('id');
            $(this).html('<img src="/images/loader.gif" width="15">');

            $.ajax({
                url: '/tasks/teststud',
                type: 'get',
                data: {
                    id: id
                },
                success: function (res) {
//                    console.log(res);
                    if (res.success) {
                        el.parent().html(res.success + '%' +
                            '<a target="_blank" class="btn btn-xs btn-success pull-right" href="' +
                            res.pdf + '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>');
                    }
                    else {
                        if (res.error) alert(res.error);
                        else alert('Антиплагиат временно отключен! ');
                        el.parent().html('')
                    }
                },
                error: function (res) {
                    el.parent().html('');
                    if (res.error) alert(res.error);
                    else alert('Произошла ошибка! ');
                    console.log(res);
                }
            })
        });

        var table = $('table').DataTable({
            "order": [],
           "columnDefs": [
                // { "orderable": false, "targets": [5,6] }
              ],
            // stateSave: true,
            "columns": [
                {
                    "className":      'details-control',
                    "orderable":      false,
                    "data":           null,
                    "defaultContent": ''
                },
                { "data": "name" },
                { "data": "position" },
                { "data": "office" },
                { "data": "salary" }
            ],
            "info":     false,
            "sDom": '<"row view-filter"<"col-sm-12"<"pull-left"l><"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"ip>>>',
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            }
        });

        $('table tbody').on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table.row( tr );

            if ( row.child.isShown() ) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                // Open this row
                row.child( format(row.data()) ).show();
                tr.addClass('shown');
            }
        } );

        $("#datepicker_from22").datepicker().on('changeDate', function(date) {
            table.search( $(this).val() ).draw();
        });
        // Date range filter
    });/*
        minDateFilter = "";
        maxDateFilter = "";
        $.fn.dataTableExt.afnFiltering.push(
            function(oSettings, aData, iDataIndex) {
                if (typeof aData._date == 'undefined')  aData._date = new Date(aData[1]).getTime();
                if (minDateFilter && !isNaN(minDateFilter)) if (aData._date < minDateFilter) return false;
                return true;
            }
        );*/



</script>