<div class="modal fade" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Рецензия к работе</h4>
      </div>
      <div class="modal-body">
          <div class="form-group">
            <textarea class="form-control" name="comment" id="comment" cols="30" rows="10"></textarea>
          </div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="id" name="id" value="">
        <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
        <button type="button" id="save" class="btn btn-success">Сохранить</button>
      </div>
    </div>
  </div>
</div>
<ul class="nav nav-tabs nav-justified">
    <li class="active"><a data-url="?kr&cr&vkr&pract" data-toggle="tab" href="#tab1">Все работы</a></li>
    <li><a data-url="?kr" data-toggle="tab" href="#tab2">Контрольные<span class="badge pull-right" style="margin-right: -5px"><?= $ct[0] ?></span></a></li>
    <li><a data-url="?cr" data-toggle="tab" href="#tab3">Курсовые<span class="badge pull-right" style="margin-right: -5px"><?= $ct[1] ?></span></a></li>
    <li><a data-url="?vkr" data-toggle="tab" href="#tab4">ВКР<span class="badge pull-right" style="margin-right: -5px"><?= $ct[2] ?></span></a></li>
    <li><a data-url="?pr" data-toggle="tab" href="#tab5">Практика<span class="badge pull-right" style="margin-right: -5px"><?= $ct[3] ?></span></a></li>
<!--    <li class="disabled"><a>Отчеты</a></li>-->
</ul>
<br>
<p>Проверено работ: <b id="cw">[загружается]</b></p>
<!--<div class="form-group">-->
<!--    <div class="row">-->
<!--        <div class="col-xs-6"><input class="form-control" type="text" name="student_filter" id="student_filter" value="" placeholder="Студент" /></div>-->
<!--        <div class="col-xs-6">-->
<!--            <div class="checkbox"><label><input type="checkbox" id="hide_works" >Скрыть проверенные работы</label></div>-->
<!--            <div class="checkbox" style="margin-top: 3px;"><label><input type="checkbox" checked id="sort_works" >Сначала непроверенные</label></div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->
<div class="clearfix"></div>
<div class="form-group">
    <div class="row">
        <div class="col-xs-2"><input class="form-control" type="text" name="date_filter" id="date_filter" value="" placeholder="01/01/2001"/></div>
        <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="class_filter" id="class_filter"><option value="">Группа</option></select></div>
        <div class="col-xs-3"><select style="margin-bottom:0; text-overflow: ellipsis;" class="form-control" name="disc_filter" id="disc_filter"><option value="">Предмет</option></select></div>
        <div class="col-xs-4">
            <div class="checkbox"><label><input type="checkbox" id="hide_works" >Скрыть проверенные работы</label></div>
            <div class="checkbox" style="margin-top: 3px;"><label><input type="checkbox" checked id="sort_works" >Сначала непроверенные</label></div>
        </div>
<!--                    <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="type_filter" id="type_filter"><option value="">Тип</option></select></div>-->
    </div>
    <div class="clearfix"></div>
</div>
<hr>
<table class="table table-striped table-hover table-bordered" style="width: 100%">
    <thead>
    <tr>
        <th>Студент</th>
        <th>Дата</th>
        <th>Группа</th>
    </tr>
    </thead>
    <tbody></tbody>
</table>

<style>
     .details-control {
         cursor: pointer;
     }
     tr.shown {
         font-weight: bold;
         font-size: 1.2em;
     }
    small {
        display: inline-block;
        line-height: 1;
        margin-top: 5px;
    }
    .dataTables_filter > label { width: 100%; }
    .dataTables_filter input[type="search"] { width: 90%!important; }
</style>
<link rel="stylesheet" type="text/css" href="/js/datatables/datatables.min.css">
<script type="text/javascript" charset="utf8" src="/js/datatables/datatables.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="/js/moment.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>
<script>
    $('#date_filter').mask("99/99/9999", {placeholder: " " });;

    function format ( d ) {
        // `d` is the original data object for the row
        var tt = '<table cellpadding="5" cellspacing="0" border="0" class="table table-striped table-hover table-bordered" style="padding-left:50px; width: 100%;border: 3px #f60 solid;">' +
            '<thead>' +
                '<tr>'+
                    '<th>Предмет</th>'+
                    '<th>Дата</th>'+
                    '<th>Тип</th>'+
                    '<th width="140">Скачать</th>'+
                    '<th title="% Оригинальности">%</th>'+
                    '<th>Оценка</th>'+
                    '<th></th>'+
                '</tr>'+
            '</thead><tbody style="">';
            d.forEach(function(item, i, arr) {
            tt +=
                '<tr'+(item.tstatus === 0 ? ' class="danger"':'')+'>'+
                    '<td>'+item.tdisc+'</td>'+
                    '<td>'+item.tdate+'</td>'+
                    '<td>'+item.ttype+'</td>'+
                    '<td>'+item.tdwnld+'</td>'+
                    '<td>'+item.tperc+'</td>'+
                    '<td>'+item.tmark+'<br><small>'+item.tmarked+'</small></td>'+
                    '<td>'+item.tcom+'</td>'+
                '</tr>';
            });
        tt += '</tbody></table>';
        return tt;
    }

    var set = {
        ajax: {
            url: "/tasks/prep?kr&cr&vkr&pr",
            type: "POST",
            data: function ( d ) {
                d.disc = $('#disc_filter').val();
            }
        },
        order: [1, 'desc'],
        pageLength: 25,
        info:     false,
        // sDom: '<"row view-filter"<"col-sm-12"<"pull-left"l><"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"ip>>>',
        sDom: '<"row view-filter"<"col-sm-12"f><"clearfix">>t<"row view-pager"<"col-sm-12"<"text-center"ip>>>',
        language: { url: "/js/datatables/Russian.json",searchPlaceholder: "Введите ФИО студента или название группы" },
        columns: [
            { "data": {'_': 'tname'}, "className":'details-control text-left'},
            { "data": {"_": "tdate", "sort": "tdate_", "display": "tdate"}},
            { "data": "tclass" },
            { "data": {'_': 'tstatus', 'filter' : 'tstatus' }, "visible": false},
            { "data": "tchild", "visible": false }
        ],
        orderFixed: [3, 'asc'],
        createdRow: function ( row, data, index ) { if ( data.tstatus === '0' ) { $(row).addClass('danger'); }}
    };

    var table = $('table').DataTable(set);
    table.on( 'init.dt', function () {
        var discs = {};
        table.column(2).data().unique().sort().each(function (d, j) { $('#class_filter').append('<option value="' + d + '">' + d + '</option>') });
        table.column(4).data().unique().sort().each(function (d, j) { d.forEach(function (d) { discs[d.tdisc] = true; }); });
        Object.keys(discs).forEach(function (d, j) { $('#disc_filter').append('<option value="' + d + '">' + d + '</option>') });
        $('#disc_filter').change(function () { table.ajax.reload(); });
    });
    table.on( 'draw', function () {
        var rows = table.rows().data();
        var count = 0;
        rows.each(function (d) {if (d.tstatus === '2') count++;});
        $('#cw').text(count+' из '+rows.length);
    });

    table.on('change', '.mark', function () {
        var id = $(this).data('id');
        var mark = this.value;
        var tr = $('.shown');
        try { var row = table.row( tr ).data().tchild; } catch (e){ return; }
        row.forEach(function(el) {
            if (el.tmark.search(id) !== -1) {
                el.tmark = el.tmark
                    .replace(' selected', '')
                    .replace('value="'+mark+'"', 'value="'+mark+'" selected');
            }
        });
        $.ajax({
            url: '/tasks/mark',
            type: 'post',
            data: {'mark': this.value, 'id': $(this).data('id')},
            success: function (res) {
                swal({
                    title: "Успешно сохранено!",
                    timer: 1500,
                    icon: 'success'
                });
                console.log(res);
            },
            error: function () {
                console.log('Error!');
            }
        });
    });
    table.on('click', 'td.details-control', function () {
        var tr = $(this).closest('tr');
        var row = table.row( tr );
        if ( row.child.isShown() ) { row.child.hide(); tr.removeClass('shown'); }
        else {
            table.rows().every(function() { var r =  this.nodes().to$(); table.row( r ).child.hide(); r.removeClass('shown') });
            row.child( format(row.data().tchild) ).show();
            tr.addClass('shown');
        }
    });
    table.on('click', '.work', function () {
        var el = $(this);
        var id = el.data('id');
        $(this).html('<img src="/images/loader.gif" width="15">');
        $.ajax({
            url: '/tasks/test',
            type: 'get',
            data: { id: id },
            success: function (res) {
                if (res.success) {
                    el.parent().html(res.success + '%' +
                    '<a target="_blank" class="btn btn-xs btn-success pull-right" href="'+
                        res.pdf+ '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>');
                }
                else { alert('Произошла ошибка! '); el.parent().html('') }
            },
            error: function (res) {
                el.parent().html('');
                alert('Произошла ошибка! ');
                console.log(res);
            }
        })
    });
    $('#commentModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var modal = $(this);
        $('#id').val(button.data('id'));
        $('#comment').val(button.data('title'));
    });
    $('#save').click(function () {
        var id = $('#id').val();
        var comment = $('#comment').val();
        $.ajax({
            url: base + 'tasks/comSet',
            type: 'post',
            data: {
                id: id,
                comment: comment
            },
            success: function (res) {
                var button = $('button[data-id='+id+']');
                button.data('title',comment);
                if (comment === '') button.removeClass('btn-success').addClass('btn-primary');
                else button.removeClass('btn-primary').addClass('btn-success');
                $('#commentModal').modal('hide');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    $('#hide_works').on( 'click', function () { table.columns(3).search( $(this).is(':checked') ? 0 : '' ).draw(); } );
    $('#sort_works').on( 'click', function () { table.order.fixed( { pre: $(this).is(':checked') ? [3, 'asc'] : [] } ); table.draw(); });
    $('#student_filter').on( 'keyup', function () { table.columns(0).search( this.value ).draw(); } );
    $('#date_filter').on( 'keyup', function () { table.columns(1).search( this.value ).draw(); } );
    $('#class_filter').on( 'change', function () { var val = $.fn.dataTable.util.escapeRegex( $(this).val() ); table.columns(2).search( val ? '^'+val+'$' : '', true, false ).draw(); });

    $('.nav-tabs a').on('shown.bs.tab', function(event){
        var x = $(event.target).data('url');
        table.rows().remove().draw();
        $('#cw').text('[загружается]');
        table.ajax.url( '/tasks/prep'+x ).load();
    });
</script>
