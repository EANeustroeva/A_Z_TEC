<div class="row">
    <div class="col-sm-6"><select class="selectpicker form-control" id="students" title="Студент">
</select></div>
    <div class="col-sm-6"><select class="selectpicker form-control" id="disc" title="Предмет">
</select></div>
</div>
<hr>

<table class="table table-striped table-hover table-bordered">
    <thead>
    <tr>
        <th>Дата</th>
        <th>Студент</th>
        <th>Группа</th>
        <th>Предмет</th>
        <th>Тип</th>
        <th>Скачать</th>
        <th>Оценка</th>
<!--        <th></th>-->
        <th>Действие</th>
    </tr>
    </thead>
    <tbody>

    </tbody>
</table>

<style>
    .panel-body { padding: 15px; }
</style>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).ready(function () {
        var table = $('dtable').DataTable({
            "order": [],
            "pageLength": 10,
            "columnDefs": [
                { "orderable": false, "targets": [5,6,7] }
              ],
            // stateSave: true,
            "info":     false,
            "sDom": '<"row view-filter"<"col-sm-12"<"pull-left"l><"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"ip>>>',
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            }
        });
        $('#course').val(1).selectpicker('refresh');
        get_class();

        $('#course').on('changed.bs.select', function (e) {
            $('#class').prop('disabled', false);
            get_class();
        });
        function get_class() {
            $.ajax({
                url: base+'profile/getListFilter',
                type: 'post',
                data: {'course': $('#course').val()},
                success: function (res) {
                    $('#class')
                        .html(res)
                        .selectpicker('refresh');
                },
                error: function () {
                    console.log('Error!');
                }
            });
        }
        $('#class').on('changed.bs.select', function (e) {
            // table.search( $(this).val() ).draw();
            $.ajax({
                url: base+'profile/getUserList',
                type: 'get',
                data: {'class': $(this).val()},
                success: function (res) {
                    $('#students')
                        .html(res)
                        .selectpicker('refresh');
                    update_table();
                },
                error: function () {
                    console.log('Error!');
                }
            });
            $.ajax({
                url: base+'tasks/getListDiscs',
                type: 'get',
                data: {'class': $(this).val()},
                success: function (res) {
                    $('#disc').html(res).selectpicker('refresh');
                },
                error: function () {
                    console.log('Error!');
                }
            });
            // update_table();
        });
        $('#students').on('changed.bs.select', function (e) {
            // table.search( $(this).val() ).draw();
            update_table();
        });
        $('#disc').on('changed.bs.select', function (e) {
            update_table();
        });

        $('body').on('click', '.remove', function() {
            console.log($(this).data('id'));
            $.ajax({
                url: base+'tasks/delTaskwork',
                type: 'get',
                data: {'id': $(this).data('id')},
                success: function (res) {
                    update_table();
                },
                error: function () {
                    console.log('Error!');
                }
            });
        });

        function update_table() {
            $.ajax({
                url: base+'tasks/getTasks',
                type: 'get',
                data: {'user': $('#students').val(), 'class': $('#class').val(), 'disc': $('#disc').val()},
                success: function (res) {
                    $('.table tbody')
                        .html(res);
                },
                error: function () {
                    console.log('Error!');
                }
            });
        }

    });
</script>