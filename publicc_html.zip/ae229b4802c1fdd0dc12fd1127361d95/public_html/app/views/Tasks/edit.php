<form action="<?= BASE_URL ?>tasks/save" method="post" enctype="multipart/form-data">
    <div class="col-sm-4">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="col-sm-12">
                    <h4></h4>
                    <div class="form-group">
                        <label for="dcourse">Курс: </label>
                        <select name="dcourse" id="course" class="selectpicker form-control" data-size="5">
                        <option value="">Не выбрано</option>
                        <?php foreach ($course as $k=>$item):
                            if (is_null($item['course'])) continue;
                            ?>
                            <option<?= ($item['course']==$tasks['course']) ? ' selected' : '' ?>><?= $item['course'] ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="dclass">Группа:</label>
                        <select name="dclass[]" id="class" class="selectpicker form-control" multiple data-size="8"
                                data-live-search="true"
                                data-selected-text-format="count > 2">
                            <?php foreach ($class as $item):
                                if (is_null($item['class'])) continue;
                            if (isset($tasks['class']))
                                $sel = (in_array($item['class'],json_decode($tasks['class'])) ) ? ' selected' : '';
                            else $sel = ''; ?>
                                <option<?= $sel ?>><?= $item['class'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="checkbox">
                            <label id="allstates"><input type="checkbox" name="personal" value="" <?= (!empty($personal)) ?'checked':'' ?>>Индивидуальное задание</label>
                        </div>
                        <select id="individ" name="usr_id[]" class="selectpicker form-control" multiple data-size="8" data-live-search="true" data-selected-text-format="count" <?= (empty($personal)) ?'disabled':'' ?>>
                            <?php foreach ($users as $k => $user): ?>
                                <!--img src='<?//= BASE_URL ?>assets/images/thumbs/no-image.jpg' width='30'-->
                                <?php if (!empty($personal)) $sel = in_array($user['id'],$personal) ? ' selected' : '';
                                else $sel = ''; ?>
                                <option data-content="<?= ucwords($user['name']) ?>" <?= $sel ?>><?= $user['id'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <a href="<?= BASE_URL ?>tasks" class="btn btn-default"><i class="glyphicon glyphicon-chevron-left"
                                                                              aria-hidden="true"></i> Назад</a>
                </div>
                <div style="line-height: 34px;padding-left: 95px;">Создание задания</div>
            </div>
            <div class="panel-body">
                <div class="col-sm-12">
                    <h4></h4>

                        <div class="form-group">
                            <input type="text" class="form-control" name="title" placeholder="Название задания"
                                   value="<?= @$tasks['title'] ?>">
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select id="ttype" name="ttype" class="selectpicker form-control" data-size="5" title="Вид работы">
                                    <option<?= ($tasks['type']==0) ? ' selected' : '' ?> value="0">Домашняя</option>
                                    <option<?= ($tasks['type']==1) ? ' selected' : '' ?> value="1">Контрольная</option>
                                    <option<?= ($tasks['type']==2) ? ' selected' : '' ?> value="2">Курсовая</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select id="predmet" name="predmet" class="selectpicker form-control" data-size="10" title="Предмет" data-live-search="true">
                                        <?php foreach ($predmet as $k=>$item): ?>
                                            <option<?= ($item['id']==$tasks['predmet']) ? ' selected' : '' ?> value="<?= $item['id'] ?>"><?= $k ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <textarea class="form-control" rows="3" name="comment" placeholder="Описание работы"><?= @$tasks['desc'] ?></textarea>
                        </div>
                        <div class="form-group">
                            <div id="preview"></div>
                            <?php if (!empty($files)): ?>
                                <div id="count">
                                    <p>Количество файлов: <b><?= count($files) ?></b></p>
                                </div>
                            <div id="finfo" class="well well-sm">
                                <ul class="list-group">
                                    <?php foreach ($files as $f): ?>
                                        <li class="list-group-item" id="<?= $f['id'] ?>"><span class="del" style="cursor: pointer;float: right;">&times;</span><a href="<?= BASE_URL . 'download?f=' .base64_encode('tasks/'. $f['fname'].'.'.$f['fext']).'&c='.$f['ftitle'].'.'.$f['fext'] ?>" target="_blank"><?= $f['ftitle'].'.'.$f['fext'] ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <div id="file-uploader"></div>
<!--                            <input id="file_upload" type="file" name="userfile"/>-->
<!--                            <span class="help-block">Прикрепить файл задания</span>-->
                            <input type="hidden" name="MAX_FILE_SIZE" value="30000"/>
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="id" value="<?= $tasks['id'] ?>">
                            <button type="submit" class="btn btn-default">Сохранить</button>
                        </div>

                </div>
            </div>
        </div>
    </div>
</form>
<link rel="stylesheet" type="text/css" href="<?= BASE_URL ?>css/uploadifive.css">
<script src="<?= BASE_URL ?>js/jquery.uploadifive.js"></script>
<script src="<?= BASE_URL ?>js/filter.js"></script>
<script>
    $('#allstates input').change(function () {
        if ($('#allstates input').is(':checked')) {
            $('#allstates input').addClass('checked');
            $('#individ').prop('disabled', false).selectpicker('refresh');
        } else {
            $('#allstates input').removeClass('checked');
            $('#individ').selectpicker('deselectAll').prop('disabled', true).selectpicker('refresh');
        }
    });
    /*$(function() {
        $('#file_upload').uploadifive({
            'uploadScript' : 'uploads',
            'onUploadComplete' : function(file, data) {
                console.log(file);
                $('#preview').append('<img src="'+ base + 'uploads/' + file.name + '" />');
            }

        });
    });*/
</script>

<link rel="stylesheet" href="<?= BASE_URL ?>css/fileuploader.css">
<script src="<?= BASE_URL ?>js/fileuploader.js"></script>
<script>
    $( document ).ready(function() {
        var uploader = new qq.FileUploader({
            element: document.getElementById('file-uploader'),
            action: 'uploadtask',
            params: {task: <?= !empty($_POST['id']) ?$_POST['id']: $task_id ?>},
            allowedExtensions: [],
            template: '<div class="qq-uploader">' +
            '<div class="qq-upload-drop-area"><span>{dragText}</span></div>' +
            '<div class="qq-upload-button btn btn-success">{uploadButtonText}</div>' +
            '<hr>'+
            '<ul class="qq-upload-list"></ul>' +
            '</div>',
            dragText: 'Переместите файл в эту зону для загрузки',
            uploadButtonText: '<i class="glyphicon glyphicon-plus-sign"></i>&nbsp; Загрузить...',
            cancelButtonText: 'Отмена',
            failUploadText: 'Ошибка',
            onComplete: function (id, fileName, responseJSON) {
//                location.reload();
            },
            onProgress: function(id, fileName, loaded, total){

            },


        });

        $('.del').click(function () {
            var id = this.parentNode.id;

            $.ajax({
                url: base + "tasks/deletefile",
                type: "post",
                data: {id: id, task: <?= !empty($_POST['id']) ?$_POST['id']: $task_id ?>},
                success: function (response) {
                    $("#"+id).remove();
                    var cnt = jQuery.parseJSON(response).count
                    $("#count").html('<p>Количество файлов: <b>'+cnt+'</b></p>');
                    if (cnt <= 0) $("#finfo").remove();
                }
            });

        });
    });
</script>