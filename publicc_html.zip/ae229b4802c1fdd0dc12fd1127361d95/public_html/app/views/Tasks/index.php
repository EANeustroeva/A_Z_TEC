   <div class="modal fade" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">Рецензия к работе</h4>
          </div>
          <div class="modal-body">
              <div class="form-group">
                <textarea class="form-control" name="comment" id="comment" cols="30" rows="10"></textarea>
              </div>
          </div>
          <div class="modal-footer">
            <input type="hidden" id="id" name="id" value="">
            <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
            <button type="button" id="save" class="btn btn-success">Сохранить</button>
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-12">
        <div class="bigger_" style="margin-left: -15px;">
            <div class="col-sm-12">
<!--    <ul class="nav nav-tabs">-->
<!--        <li class=active><a href="#mark" data-toggle="tab">Все задания</a></li>-->
<!--        <li><a href="#file" data-toggle="tab">Задания/Файлы</a></li>-->
<!--    </ul>-->

        <div class="tab-content" style="min-width: 476px;">
        <div style="display: none;" class="tab-pane" id="view">

            <div class="row">
                <div class="col-sm-12">
                    <h5>Направление: <?= $plan['napr'] ?> (<?= $plan['napr_n'] ?>)</h5>
                    <h5>Профиль:     <?= $plan['dop'] ?></h5>
                    <h4>Предмет:     <?= $_GET['disc'] ?></h4>
                </div>
                <?php if (isset($plan['lektor'])): ?>
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">Диалог с преподавателем <?= isset($plan['lektor']) ? "({$plan['lektor']})" : '' ?></div>
            <div class="panel-body">
                <div class="container-chat">
                    <ul class="list-unstyled">
                        <?php if (empty($msg->thread)) echo '<p class="text-center">Нет сообщений</p>'; ?>
                        <?php if ($msg->buddy->more): ?>
                            <li id="load-more-wrap" style="text-align:center;padding: 10px 0;"><a
                                        onclick="javascript: load_thread(<?= $msg->buddy->d_id . ',' . $msg->buddy->limit ?>)"
                                        class="btn btn-xs btn-default" style="width:100%">Старые сообщения
                                    (<?= $msg->buddy->remaining ?>)</a></li>
                        <?php endif; ?>
                        <?php if (!empty($msg->thread)) foreach ($msg->thread as $item): ?>
                            <?php if (isset($msg)): ?>
                                <a class="message-bubble row <?php if ($item->status == 0) echo 'unread'; ?>"
                                   style="padding: 3px 5px 3px 0px;font-size: 0.85em;">
                    <span class="chat-img pull-left" style="padding-right: 10px;">
						<img src="<?= $item->avatar ?>" class="avt " style="height: 30px;">
					</span>
                                    <div class="chat-body" style="padding-left: 0;">
                                        <strong class="primary-font"><?= $item->name ?></strong>
                                        <small class="text-muted pull-right ">
                                            <span class="glyphicon glyphicon-time"></span>
                                            <?= date('g:i a', strtotime($item->time)) ?>
                                        </small>
                                        <p style="margin:0;"><?= $item->msg ?></p>
                                    </div>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <div class="panel-footer">
                <form action="<?= BASE_URL ?>users/dialog" method="post" class="input-group">
                    <input type="text" name="msg" class="form-control" autocomplete="off" autofocus required>
                    <!-- glyphicon glyphicon-file -->
                    <input type="hidden" name="usr_name"
                           value="<?= $plan['lektor'] ?>">
                    <input type="hidden" name="usr_id" value="<?= $plan['user_id'] ?>">
                    <span class="input-group-btn">
                    <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-pencil"></i></button>
                </span>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
            </div>
        </div>
        <div class="tab-pane active" id="mark"><h4></h4>
            <p>Проверено работ: <b><?= $counter ?></b></p>
            <hr>
<!--            <div class="col-xs-12">-->
                <div class="form-group">
                    <div class="row">
                        <div class="col-xs-6"><input class="form-control" type="text" name="student_filter" id="student_filter" value="" placeholder="Студент" /></div>
                        <div class="col-xs-6"><div class="checkbox"><label><input type="checkbox" id="hide_works" >Скрыть проверенные работы</label></div></div>
                    </div>
                </div>
            <div class="clearfix"></div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-xs-3"><input class="form-control" type="text" name="date_filter" id="date_filter" value="" placeholder="Дата"/></div>
                        <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="class_filter" id="class_filter"><option value="">Группа</option></select></div>
                        <div class="col-xs-3"><select style="margin-bottom:0; text-overflow: ellipsis;" class="form-control" name="disc_filter" id="disc_filter"><option value="">Предмет</option></select></div>
                        <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="type_filter" id="type_filter"><option value="">Тип</option></select></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
<!--            </div>-->
            <hr>
            <table class="table table-striped table-hover table-bordered">
                <thead>
                <tr>
                    <th>№</th>
                    <th>Студент</th>
                    <th>Дата</th>
                    <th>Группа</th>
                    <th>Предмет</th>
                    <th>Тип</th>
                    <th>Скачать</th>
<!--                    <th title="% Оригинальности">%</th>-->
                    <th>Оценка</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php if (isset($zagr) && count($zagr)):  ?>
                    <?php $i=0; ?>
                    <?php foreach ($zagr as $item): ?>
                        <tr<?= ($item['status']==0) ? ' class="danger"' : (($item['status']==2) ? ' class="active"' : '') ?>>
                            <td data-filter="<?= $item['status'] ?>"><?= ++$i ?></td>
                            <td><?= $item['student'] ?></td>
                            <td data-order="<?= $item['created_'] ?>"><?= $item['created'] ?></td>
                            <td><?= $item['class'] ?></td>
                            <td style="word-break: break-all; text-align: left;"><?= $item['disc'] ?></td>
                            <td><?php switch ($item['type']) {
                                    case 'кр': echo 'Контр.раб.'; break;
                                    case 'зач': echo 'Зач.'; break;
                                    case 'прр': echo 'Пров.раб.'; break;
                                    case 'экз': echo 'Экз.раб.'; break;
                                    case 'кп': echo 'Курс.раб.'; break;
                                } ?></td>
                            <td>
                                <?php if (!empty($item['file'])): ?>
                                    <a href="<?= 'upload/works/' . $item['file'] ?>" class="btn btn-warning btn-xs"
                                       target="_blank">
                                        <span class="glyphicon glyphicon-download"></span>&nbsp;<span
                                                class="hidden-xs">Скачать</span></a>
                                <?php endif; ?>
                            </td>
                          <?php /*
                            <td width="94px"><?php if (!empty($item['perc'])): ?>
                <?= $item['perc'] . '%' ?>
                <a target="_blank" class="btn btn-xs btn-success pull-right" href="<?= $item['pdf'] ?>" title="Полный отчет">
                    <i class="glyphicon glyphicon-download-alt"></i></a>
                <?php else: ?>
                <span data-id="<?= $item['id'] ?>" class="work btn btn-xs btn-default pull-right" title="Отправить на проверку"><i class="glyphicon glyphicon-check"></i></span>
                <?php endif; ?></td> */?>
                            <td><?php if ($user->access==4): !empty($item['mark'])?$item['mark']:'';
                            else: ?>
                                <select id="mark<?= $item['id'] ?>" class="mark" style="height: 23px;padding: 0;margin-bottom: 0;">
                                    <option <?= $item['mark']==0 ? 'selected="selected"':'' ?>value="0">--</option>
                                    <option <?= $item['mark']==3 ? 'selected="selected"':'' ?>value="3">3</option>
                                    <option <?= $item['mark']==4 ? 'selected="selected"':'' ?>value="4">4</option>
                                    <option <?= $item['mark']==5 ? 'selected="selected"':'' ?>value="5">5</option>
                                    <option <?= $item['mark']==6 ? 'selected="selected"':'' ?>value="6">зач</option>
                                    <option <?= $item['mark']==7 ?' selected="selected"':'' ?>value="7">на дораб.</option>
                                </select>
                             <?php  endif; ?></td>
                            <td>
<!--                                <form action="--><?//= BASE_URL ?><!--tasks/comment" method="post" target="_blank">-->
<!--                                    <input type="hidden" name="id" value="--><?//= $item['id'] ?><!--">-->
                                    <button type="button" class="btn btn-xs btn-<?= !empty($item['comment'])?'success':'primary' ?>" data-toggle="modal" data-target="#commentModal" data-id="<?= $item['id'] ?>" data-title="<?= @$item['comment'] ?>" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></button>
<!--                                </form>-->
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div style="display: none;" class="tab-pane" id="file">
            <h4></h4>
            <?php if (empty($files)): echo '<h3 class="text-center" style="margin-bottom: 20px;">Файлы отсутствуют</h3>';
            else: ?>
                <table class="table table-striped table-hover table-bordered">
                    <thead>
                    <tr>
                        <th>Имя</th>
                        <th>Курс</th>
                        <th>Группа</th>
                        <th>Предмет</th>
                        <th>Действие</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($files as $f): ?>
                        <tr>
                            <td class="text-left"><?= mb_strimwidth($f['ftitle'], 0, 25, '..') ?></td>
                            <td><?= $f['course'] ?></td>
                            <td><?= implode(', ',explode('|',$f['class'])) ?></td>
                            <td style="word-break: break-all; text-align: left;"><?= $f['disc'] ?></td>
                            <td class="text-center">
                                <?php /*if ($user->access == 4): */?><!--
                                <form action="<?/*= BASE_URL */?>tasks/view" method="post" style="display: inline">
                                    <input type="hidden" name="id" value="<?/*= $f['id'] */?>">
                                    <button type="submit" class="btn btn-success btn-xs">
                                        <span class="glyphicon glyphicon-eye-open"></span>&nbsp;<span
                                                class="hidden-xs">Просмотреть</span></button>
                                </form>-->
                                <?php /*elseif (count($f['works']) > 0): */?><!--
                                    <form action="<?/*= BASE_URL */?>tasks/workview" method="get" style="display: inline">
                                        <input type="hidden" name="id" value="<?/*= $f['id'] */?>">
                                        <button type="submit" class="btn btn-success btn-xs">
                                            <span class="glyphicon glyphicon-eye-open"></span>&nbsp;<span
                                                    class="hidden-xs">Просмотреть</span></button>
                                    </form>
                                --><?php /*endif; */?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>
    </div>
</div>
<style>
    .no-border, .no-border > th {
        border: none!important;
    }
    @media (min-width: 1200px) {
        .bigger {
            /*margin-right: -215px;*/
        }
    }
</style>
<script>
    $(document).ready(function () {
        $('.work').click(function () {
            var el = $(this);
            var id = el.data('id');
            $(this).html('<img src="/images/loader.gif" width="15">');

            $.ajax({
                url: '/tasks/test',
                type: 'get',
                data: {
                    id: id
                },
                success: function (res) {
//                    console.log(res);
                    if (res.success) {
                        el.parent().html(res.success + '%' +
                        '<a target="_blank" class="btn btn-xs btn-success pull-right" href="'+
                            res.pdf+ '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>');
                    }
                    else {
                        if (res.error) alert(res.error);
                        else alert('Антиплагиат временно отключен! ');
                        el.parent().html('')
                    }
                },
                error: function (res) {
                    el.parent().html('');
                    if (res.error) alert(res.error);
                    else alert('Произошла ошибка! ');
                    console.log(res);
                }
            })
        });
    });
    $('#commentModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var modal = $(this);
        $('#id').val(button.data('id'));
        $('#comment').val(button.data('title'));
//        modal.find('.modal-body input').val('');
//        modal.find('.modal-body textarea').val('');
    });

    $('#save').click(function () {
        var id = $('#id').val();
        var comment = $('#comment').val();
        $.ajax({
            url: base + 'tasks/comSet',
            type: 'post',
            data: {
                id: id,
                comment: comment
            },
            success: function (res) {
                var button = $('button[data-id='+id+']');
                button.data('title',comment);
                if (comment === '') button.removeClass('btn-success').addClass('btn-primary');
                else button.removeClass('btn-primary').addClass('btn-success');
                $('#commentModal').modal('hide');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    $(function () {
        $('#mark .mark').on('change', function() {
            $.ajax({
                url: 'tasks/mark',
                type: 'post',
                data: {'mark': this.value,
                'id': this.getAttribute('id')},
                success: function (res) {
                    console.log(res);
                },
                error: function () {
                    console.log('Error!');
                }
            });
        })
    });
</script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).ready(function () {
        var table = $('#mark table').DataTable({
            "order": [],
            "pageLength": 25,
            "columnDefs": [
                { "orderable": false, "targets": [5,6,7,8,9] }
              ],
//            "bSortCellsTop": true,
            // stateSave: true,
            "info":     false,
            "sDom": '<"row view-filter"<"col-sm-12"<"pull-left"l><"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"ip>>>',
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            }
        });

        table.column(3).data().unique().sort().each( function ( d, j ) {
            $('#class_filter').append( '<option value="'+d+'">'+d+'</option>' )
        } );
        table.column(4).data().unique().sort().each( function ( d, j ) {
            $('#disc_filter').append( '<option value="'+d+'">'+d+'</option>' )
        } );
        table.column(5).data().unique().sort().each( function ( d, j ) {
            $('#type_filter').append( '<option value="'+d+'">'+d+'</option>' )
        } );

        $('#hide_works').on( 'click', function () { table.columns(0).search( $(this).is(':checked') ? 0 : '' ).draw(); } );
        $('#student_filter').on( 'keyup', function () { table.columns(1).search( this.value ).draw(); } );
        $('#date_filter').on( 'keyup', function () { table.columns(2).search( this.value ).draw(); } );
        $('#class_filter').on( 'change', function () {
            var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
            table.columns(3).search( val ? '^'+val+'$' : '', true, false ).draw();
        });
        $('#disc_filter').on( 'change', function () {
            var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
            table.columns(4).search( val ? '^'+val+'$' : '', true, false ).draw();
        });
        $('#type_filter').on( 'change', function () {
            var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
            table.columns(5).search( val ? '^'+val+'$' : '', true, false ).draw();
        });

        $('#course').on('changed.bs.select', function (e) {
            $('#class').prop('disabled', false);
            $.ajax({
                url: base+'profile/getListFilter',
                type: 'post',
                data: {'course': $(this).val()},
                success: function (res) {
                    $('#class')
                        .html(res)
                        .selectpicker('refresh');
                },
                error: function () {
                    console.log('Error!');
                }
            });
        });
        $('#class').on('changed.bs.select', function (e) {
            table.search( $(this).val() ).draw();
        });

    });
</script>