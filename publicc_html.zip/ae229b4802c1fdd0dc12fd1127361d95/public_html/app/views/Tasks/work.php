Загрузка...
<form id="myForm" action="/tasks" method="post">
    <?php
    foreach ($_POST as $a => $b) {
        echo '<input type="hidden" name="'.htmlentities($a).'" value="'.htmlentities($b).'">';
    }
    if (!count($_SESSION['info_msg'])) {
        $_SESSION['info_msg'][] = 'Успешно сохранено!';
    }
    ?>
</form>
<script type="text/javascript">
    document.getElementById('myForm').submit();
</script>