<div class="modal fade" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">Рецензия к работе</h4>
          </div>
          <div class="modal-body">
              <div class="form-group">
                <textarea class="form-control" name="comment" id="comment" cols="30" rows="10"></textarea>
              </div>
          </div>
          <div class="modal-footer">
            <input type="hidden" id="id" name="id" value="">
            <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
            <button type="button" id="save" class="btn btn-success">Сохранить</button>
          </div>
        </div>
      </div>
    </div>
<div class="col-sm-12">
    <div class="bigger_" style="margin-left: -15px;">
        <div class="col-sm-12">
            <div class="" id="mark"><h4></h4>
        <p>Проверено работ: <b><?= $counter ?></b></p>
        <hr>
<!--            <div class="col-xs-12">-->
            <div class="form-group">
                <div class="row">
                    <div class="col-xs-6"><input class="form-control" type="text" name="student_filter" id="student_filter" value="" placeholder="Студент" /></div>
                    <div class="col-xs-6"><div class="checkbox"><label><input type="checkbox" id="hide_works" >Скрыть проверенные работы</label></div></div>
                </div>
            </div>
        <div class="clearfix"></div>
            <div class="form-group">
                <div class="row">
                    <div class="col-xs-3"><input class="form-control" type="text" name="date_filter" id="date_filter" value="" placeholder="Дата"/></div>
                    <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="class_filter" id="class_filter"><option value="">Группа</option></select></div>
                    <div class="col-xs-3"><select style="margin-bottom:0; text-overflow: ellipsis;" class="form-control" name="disc_filter" id="disc_filter"><option value="">Предмет</option></select></div>
                    <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="type_filter" id="type_filter"><option value="">Тип</option></select></div>
                </div>
                <div class="clearfix"></div>
            </div>
<!--            </div>-->
        <hr>
        <table class="table table-striped table-hover table-bordered">
            <thead>
            <tr>
                <th>№</th>
                <th>Студент</th>
                <th>Дата</th>
                <th>Группа</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

        </div>
    </div>
</div>


<style>
     .details-control {
         cursor: pointer;
     }
</style>

<script>
    $(document).ready(function () {
        $('tbody').on('click', '.work', function () {
            var el = $(this);
            var id = el.data('id');
            $(this).html('<img src="/images/loader.gif" width="15">');

            $.ajax({
                url: '/tasks/test',
                type: 'get',
                data: {
                    id: id
                },
                success: function (res) {
//                    console.log(res);
                    if (res.success) {
                        el.parent().html(res.success + '%' +
                        '<a target="_blank" class="btn btn-xs btn-success pull-right" href="'+
                            res.pdf+ '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>');
                    }
                    else {
                        alert('Антиплагиат временно отключен! ');
                        el.parent().html('')
                    }
                },
                error: function (res) {
                    el.parent().html('');
                    alert('Произошла ошибка! ');
                    console.log(res);
                }
            })
        });
    });
    $('#commentModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var modal = $(this);
        $('#id').val(button.data('id'));
        $('#comment').val(button.data('title'));
//        modal.find('.modal-body input').val('');
//        modal.find('.modal-body textarea').val('');
    });

    $('#save').click(function () {
        var id = $('#id').val();
        var comment = $('#comment').val();
        $.ajax({
            url: base + 'tasks/comSet',
            type: 'post',
            data: {
                id: id,
                comment: comment
            },
            success: function (res) {
                var button = $('button[data-id='+id+']');
                button.data('title',comment);
                if (comment === '') button.removeClass('btn-success').addClass('btn-primary');
                else button.removeClass('btn-primary').addClass('btn-success');
                $('#commentModal').modal('hide');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    $(function () {

    });
</script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.2/css/responsive.dataTables.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/responsive/2.2.2/js/dataTables.responsive.min.js"></script>
<script>
    function format ( d ) {
    // `d` is the original data object for the row
    var tt = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px; width: 100%;">'+
        '<tr>'+
            '<td>Предмет</td>'+
            '<td>Тип</td>'+
            '<td>Скачать</td>'+
            '<td title="% Оригинальности">%</td>'+
            '<td>Оценка</td>'+
            '<td></td>'+
        '</tr>'+
        '<tr>'+
            '<td>'+d.tdisc+'</td>'+
            '<td>'+d.ttype+'</td>'+
            '<td>'+d.tdwnld+'</td>'+
            '<td>'+d.tperc+'</td>'+
            '<td>'+d.tmark+'</td>'+
            '<td>'+d.tcom+'</td>'+
        '</tr>'+
    '</table>';
    return tt;
}

    $(document).ready(function () {
        var table = $('#mark table').DataTable({
            "ajax": {
                "url": "/tasks?test",
                "type": "POST"
            },
            "order": [],
            "pageLength": 25,
            // "columnDefs": [
            //     { "orderable": false, "targets": [5,6,7,8,9] }
            //   ],
//            "bSortCellsTop": true,
            // stateSave: true,
            "info":     false,
            "sDom": '<"row view-filter"<"col-sm-12"<"pull-left"l><"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"ip>>>',
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            },
            "columns": [
                { "data": null, "render": {
                    '_': 'tid',
                    'filter' : 'tstatus'
                }},
                { "data": "tname",  "className":'details-control'},
                { "data": "tdate" },
                { "data": "tclass" },
                { "data": "tdisc",  "visible": false },
                { "data": "ttype",  "visible": false },
                { "data": "tdwnld", "visible": false },
                { "data": "tperc",  "visible": false },
                { "data": "tmark",  "visible": false },
                { "data": "tcom",   "visible": false }
            ],
            "createdRow": function ( row, data, index ) {
                if ( data.tstatus == 0 ) {
                    $(row).addClass('danger');
                }
            }
        });

        table.on( 'init.dt', function () {
            table.column(3).data().unique().sort().each( function ( d, j ) {
            $('#class_filter').append( '<option value="'+d+'">'+d+'</option>' )
            } );
            table.column(4).data().unique().sort().each( function ( d, j ) {
                $('#disc_filter').append( '<option value="'+d+'">'+d+'</option>' )
            } );
            table.column(5).data().unique().sort().each( function ( d, j ) {
                $('#type_filter').append( '<option value="'+d+'">'+d+'</option>' )
            } );
        } );

        $('tbody').on('change', '.mark', function () {
            $.ajax({
                url: '/tasks/mark',
                type: 'post',
                data: {'mark': this.value, 'id': this.getAttribute('id')},
                success: function (res) {
                    console.log(res);
                },
                error: function () {
                    console.log('Error!');
                }
            });
        });

        // Add event listener for opening and closing details
        $('tbody').on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table.row( tr );

            if ( row.child.isShown() ) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                // Open this row
                row.child( format(row.data()) ).show();
                tr.addClass('shown');
            }
        } );

        $('#hide_works').on( 'click', function () { table.columns(0).search( $(this).is(':checked') ? 0 : '' ).draw(); } );
        $('#student_filter').on( 'keyup', function () { table.columns(1).search( this.value ).draw(); } );
        $('#date_filter').on( 'keyup', function () { table.columns(2).search( this.value ).draw(); } );
        $('#class_filter').on( 'change', function () {
            var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
            table.columns(3).search( val ? '^'+val+'$' : '', true, false ).draw();
        });
        $('#disc_filter').on( 'change', function () {
            var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
            table.columns(4).search( val ? '^'+val+'$' : '', true, false ).draw();
        });
        $('#type_filter').on( 'change', function () {
            var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
            table.columns(5).search( val ? '^'+val+'$' : '', true, false ).draw();
        });

        $('#course').on('changed.bs.select', function (e) {
            $('#class').prop('disabled', false);
            $.ajax({
                url: base+'profile/getListFilter',
                type: 'post',
                data: {'course': $(this).val()},
                success: function (res) {
                    $('#class')
                        .html(res)
                        .selectpicker('refresh');
                },
                error: function () {
                    console.log('Error!');
                }
            });
        });
        $('#class').on('changed.bs.select', function (e) {
            table.search( $(this).val() ).draw();
        });

    });
</script>