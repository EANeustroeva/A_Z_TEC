<div class="panel panel-default">
    <div class="panel-heading clearfix">
        <div class="pull-left" style="margin-right: 15px;">
            <a href="<?= BASE_URL ?>tasks" class="btn btn-default"><i class="glyphicon glyphicon-chevron-left"
                                                                      aria-hidden="true"></i> Назад</a>
        </div>
        <h4><?= $t['ftitle'] ?></h4>
    </div>
    <div class="panel-body">
        <h4></h4>
        <?php
        if (empty($t['works'])): echo '<h3 class="text-center" style="margin-bottom: 20px;">Работы отсутствуют</h3>';
        else: ?>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Студент</th>
                    <th>Дата</th>
                    <th>Группа</th>
                    <th>Предмет</th>
                    <th>Тип</th>
                    <th>Скачать</th>
                    <th>Оценка</th>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach ($t['works'] as $work): ?>
                    <tr<?= ($work['status']==0) ? ' class="danger"' : (($work['status']==2) ? ' class="active"' : '') ?>>
                        <td><?= $work['name'] ?></td>
                        <td><?= $work['created'] ?></td>
                        <td><?= $work['stud']['class'] ?></td>
                        <td><?= $t['disc'] ?></td>
                        <td><?= $work['type'] ?></td>
                        <td>
                           <?php if (!empty($work['file'])): ?>
                                <a href="<?= BASE_URL . 'upload/works/' . $work['file'] ?>" class="btn btn-warning btn-xs"
                                   target="_blank">
                                    <span class="glyphicon glyphicon-download"></span>&nbsp;<span
                                            class="hidden-xs">Скачать</span></a>
                            <?php endif; ?>
                        </td>
                        <td><?php if ($cur_user->access == 4): !empty($work['mark']) ? $work['mark'] : '';
                            else: ?>
                                <select id="mark<?= $work['id'] ?>" style="height: 23px;padding: 0;margin-bottom: 0;">
                                    <option <?= $work['mark'] == 0 ? 'selected="selected"' : '' ?>value="0">--</option>
                                    <option <?= $work['mark'] == 3 ? 'selected="selected"' : '' ?>value="3">3</option>
                                    <option <?= $work['mark'] == 4 ? 'selected="selected"' : '' ?>value="4">4</option>
                                    <option <?= $work['mark'] == 5 ? 'selected="selected"' : '' ?>value="5">5</option>
                                    <option <?= $work['mark'] == 6 ? 'selected="selected"' : '' ?>value="6">зач</option>
                                    <option <?= $work['mark'] == 7 ? 'selected="selected"' : '' ?>value="7">на дораб.</option>
                                </select>
                            <?php endif; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div><!--
<div class="input-group date">
    <input id="datepicker_from2" type="text" class="form-control" value="<?/*= date('d/m/Y') */?>">
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div>-->
<script>
    $(function () {
        $('select').on('change', function () {
//            console.log( this.value );
//            console.log( this.getAttribute('id') );
            $.ajax({
                url: 'mark',
                type: 'post',
                data: {
                    'mark': this.value,
                    'id': this.getAttribute('id')
                },
                success: function (res) {
                    console.log(res);
                },
                error: function () {
                    console.log('Error!');
                }
            });
        })
    });
</script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).ready(function () {
        var table = $('table').DataTable({
            "order": [],
           "columnDefs": [
                { "orderable": false, "targets": [5,6] }
              ],
            // stateSave: true,
            "info":     false,
            "sDom": '<"row view-filter"<"col-sm-12"<"pull-left"l><"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"ip>>>',
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            }
        });

        $("#datepicker_from22").datepicker().on('changeDate', function(date) {
            table.search( $(this).val() ).draw();
        });
        // Date range filter
    });/*
        minDateFilter = "";
        maxDateFilter = "";
        $.fn.dataTableExt.afnFiltering.push(
            function(oSettings, aData, iDataIndex) {
                if (typeof aData._date == 'undefined')  aData._date = new Date(aData[1]).getTime();
                if (minDateFilter && !isNaN(minDateFilter)) if (aData._date < minDateFilter) return false;
                return true;
            }
        );*/



</script>