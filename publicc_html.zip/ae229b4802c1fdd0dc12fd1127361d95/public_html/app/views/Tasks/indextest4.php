<div class="modal fade" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Рецензия к работе</h4>
      </div>
      <div class="modal-body">
          <div class="form-group">
            <textarea class="form-control" name="comment" id="comment" cols="30" rows="10"></textarea>
          </div>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="id" name="id" value="">
        <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
        <button type="button" id="save" class="btn btn-success">Сохранить</button>
      </div>
    </div>
  </div>
</div>
<div id="info"></div>
<ul class="nav nav-tabs nav-justified">
    <li class="active"><a data-toggle="tab" href="#tab1">Все работы</a></li>
    <li><a data-toggle="tab" href="#tab2">Контрольные<span id="w2" class="badge pull-right" style="margin-right: -5px">0</span></a></li>
    <li><a data-toggle="tab" href="#tab3">Курсовые<span id="w3" class="badge pull-right" style="margin-right: -5px">0</span></a></li>
    <li><a data-toggle="tab" href="#tab4">ВКР<span id="w4" class="badge pull-right" style="margin-right: -5px">0</span></a></li>
    <li><a data-toggle="tab" href="#tab5">Практика<span id="w5" class="badge pull-right" style="margin-right: -5px">0</span></a></li>
<!--    <li class="disabled"><a>Отчеты</a></li>-->
</ul>
<div class="tab-content">
    <div id="tab1" class="tab-pane fade in active">
        <h3> </h3>
        <div class="col-sm-12">
            <div class="bigger_" style="margin-left: -15px;">
                <div class="col-sm-12">
                    <h4></h4>
<!--                    <hr>-->
                    <div class="form-group">
                            <div class="row">
                                <div class="col-xs-6"><input class="form-control" type="text" name="student_filter" id="student_filter" value="" placeholder="Студент" /></div>
                                <div class="col-xs-6">
                                    <div class="checkbox"><label><input type="checkbox" id="hide_works" >Скрыть проверенные работы</label></div>
                                    <div class="checkbox"><label><input type="checkbox" class="sort_works" checked id="sort_works" >Сначала непроверенные</label></div>
                                </div>
                            </div>
                        </div>
                    <div class="clearfix"></div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-xs-3"><input class="form-control" type="text" name="date_filter" id="date_filter" value="" placeholder="Дата"/></div>
                                <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="class_filter" id="class_filter"><option value="">Группа</option></select></div>
                                <div class="col-xs-3"><select style="margin-bottom:0; text-overflow: ellipsis;" class="form-control" name="disc_filter" id="disc_filter"><option value="">Предмет</option></select></div>
            <!--                    <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="type_filter" id="type_filter"><option value="">Тип</option></select></div>-->
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    <hr>
                    <table class="table table-striped table-hover table-bordered" style="width: 100%">
                        <thead>
                        <tr>
                            <th>№</th>
                            <th>Студент</th>
                            <th>Дата</th>
                            <th>Группа</th>
                        </tr>
                        </thead>
                        <tbody></tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
    <div id="tab2" class="tab-pane fade">
        <h3> </h3>
        <div class="col-sm-12">
            <div class="bigger_" style="margin-left: -15px;">
                <div class="col-sm-12">
                    <h4></h4>
<!--                    <hr>-->
                    <div class="form-group">
                            <div class="row">
                                <div class="col-xs-6"><input class="form-control" type="text" name="student_filter" id="student_filter2" value="" placeholder="Студент" /></div>
                                <div class="col-xs-6">
                                    <div class="checkbox"><label><input type="checkbox" id="hide_works2" >Скрыть проверенные работы</label></div>
                                    <div class="checkbox"><label><input type="checkbox" class="sort_works" checked id="sort_works2" >Сначала непроверенные</label></div>
                                </div>
                            </div>
                        </div>
                    <div class="clearfix"></div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-xs-3"><input class="form-control" type="text" name="date_filter" id="date_filter2" value="" placeholder="Дата"/></div>
                                <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="class_filter" id="class_filter2"><option value="">Группа</option></select></div>
                                <div class="col-xs-3"><select style="margin-bottom:0; text-overflow: ellipsis;" class="form-control" name="disc_filter" id="disc_filter2"><option value="">Предмет</option></select></div>
            <!--                    <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="type_filter" id="type_filter"><option value="">Тип</option></select></div>-->
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    <hr>
                    <table class="table table-striped table-hover table-bordered" style="width: 100%">
                        <thead>
                        <tr>
                            <th>№</th>
                            <th>Студент</th>
                            <th>Дата</th>
                            <th>Группа</th>
                        </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div id="tab3" class="tab-pane fade">
        <h3> </h3>
        <div class="col-sm-12">
            <div class="bigger_" style="margin-left: -15px;">
                <div class="col-sm-12">
                    <h4></h4>
<!--                    <hr>-->
                    <div class="form-group">
                            <div class="row">
                                <div class="col-xs-6"><input class="form-control" type="text" name="student_filter" id="student_filter3" value="" placeholder="Студент" /></div>
                                <div class="col-xs-6">
                                    <div class="checkbox"><label><input type="checkbox" id="hide_works3" >Скрыть проверенные работы</label></div>
                                    <div class="checkbox"><label><input type="checkbox" class="sort_works" checked id="sort_works3" >Сначала непроверенные</label></div>
                                </div>
                            </div>
                        </div>
                    <div class="clearfix"></div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-xs-3"><input class="form-control" type="text" name="date_filter" id="date_filter3" value="" placeholder="Дата"/></div>
                                <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="class_filter" id="class_filter3"><option value="">Группа</option></select></div>
                                <div class="col-xs-3"><select style="margin-bottom:0; text-overflow: ellipsis;" class="form-control" name="disc_filter" id="disc_filter3"><option value="">Предмет</option></select></div>
            <!--                    <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="type_filter" id="type_filter"><option value="">Тип</option></select></div>-->
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    <hr>
                    <table class="table table-striped table-hover table-bordered" style="width: 100%">
                        <thead>
                        <tr>
                            <th>№</th>
                            <th>Студент</th>
                            <th>Дата</th>
                            <th>Группа</th>
                        </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div id="tab4" class="tab-pane fade">
        <h3> </h3>
        <div class="col-sm-12">
            <div class="bigger_" style="margin-left: -15px;">
                <div class="col-sm-12">
                    <h4></h4>
<!--                    <hr>-->
                    <div class="form-group">
                            <div class="row">
                                <div class="col-xs-6"><input class="form-control" type="text" name="student_filter" id="student_filter4" value="" placeholder="Студент" /></div>
                                <div class="col-xs-6">
                                    <div class="checkbox"><label><input type="checkbox" id="hide_works4" >Скрыть проверенные работы</label></div>
                                    <div class="checkbox"><label><input type="checkbox" class="sort_works" checked id="sort_works4" >Сначала непроверенные</label></div>
                                </div>
                            </div>
                        </div>
                    <div class="clearfix"></div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-xs-3"><input class="form-control" type="text" name="date_filter" id="date_filter4" value="" placeholder="Дата"/></div>
                                <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="class_filter" id="class_filter4"><option value="">Группа</option></select></div>
                                <div class="col-xs-3"><select style="margin-bottom:0; text-overflow: ellipsis;" class="form-control" name="disc_filter" id="disc_filter4"><option value="">Предмет</option></select></div>
            <!--                    <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="type_filter" id="type_filter"><option value="">Тип</option></select></div>-->
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    <hr>
                    <table class="table table-striped table-hover table-bordered" style="width: 100%">
                        <thead>
                        <tr>
                            <th>№</th>
                            <th>Студент</th>
                            <th>Дата</th>
                            <th>Группа</th>
                        </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div id="tab5" class="tab-pane fade">
        <h3> </h3>
        <div class="col-sm-12">
            <div class="bigger_" style="margin-left: -15px;">
                <div class="col-sm-12">
                    <h4></h4>
<!--                    <hr>-->
                    <div class="form-group">
                            <div class="row">
                                <div class="col-xs-6"><input class="form-control" type="text" name="student_filter" id="student_filter5" value="" placeholder="Студент" /></div>
                                <div class="col-xs-6">
                                    <div class="checkbox"><label><input type="checkbox" id="hide_works5" >Скрыть проверенные работы</label></div>
                                    <div class="checkbox"><label><input type="checkbox" class="sort_works" checked id="sort_works5" >Сначала непроверенные</label></div>
                                </div>
                            </div>
                        </div>
                    <div class="clearfix"></div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-xs-3"><input class="form-control" type="text" name="date_filter" id="date_filter5" value="" placeholder="Дата"/></div>
                                <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="class_filter" id="class_filter5"><option value="">Группа</option></select></div>
                                <div class="col-xs-3"><select style="margin-bottom:0; text-overflow: ellipsis;" class="form-control" name="disc_filter" id="disc_filter5"><option value="">Предмет</option></select></div>
            <!--                    <div class="col-xs-3"><select style="margin-bottom:0" class="form-control" name="type_filter" id="type_filter"><option value="">Тип</option></select></div>-->
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    <hr>
                    <table class="table table-striped table-hover table-bordered" style="width: 100%">
                        <thead>
                        <tr>
                            <th>№</th>
                            <th>Студент</th>
                            <th>Дата</th>
                            <th>Группа</th>
                        </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<style>
     .details-control {
         cursor: pointer;
     }
     tr.shown {
         font-weight: bold;
         font-size: 1.2em;
     }
    small {
        display: inline-block;
        line-height: 1;
        margin-top: 5px;
    }
</style>

<script>
    $(document).ready(function () {
        $('tbody').on('click', '.work', function () {
            var el = $(this);
            var id = el.data('id');
            $(this).html('<img src="/images/loader.gif" width="15">');

            $.ajax({
                url: '/tasks/test',
                type: 'get',
                data: {
                    id: id
                },
                success: function (res) {
//                    console.log(res);
                    if (res.success) {
                        el.parent().html(res.success + '%' +
                        '<a target="_blank" class="btn btn-xs btn-success pull-right" href="'+
                            res.pdf+ '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>');
                    }
                    else {
                        alert('Антиплагиат временно отключен! ');
                        el.parent().html('')
                    }
                },
                error: function (res) {
                    el.parent().html('');
                    alert('Произошла ошибка! ');
                    console.log(res);
                }
            })
        });
    });
    $('#commentModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var modal = $(this);
        $('#id').val(button.data('id'));
        $('#comment').val(button.data('title'));
//        modal.find('.modal-body input').val('');
//        modal.find('.modal-body textarea').val('');
    });

    $('#save').click(function () {
        var id = $('#id').val();
        var comment = $('#comment').val();
        $.ajax({
            url: base + 'tasks/comSet',
            type: 'post',
            data: {
                id: id,
                comment: comment
            },
            success: function (res) {
                var button = $('button[data-id='+id+']');
                button.data('title',comment);
                if (comment === '') button.removeClass('btn-success').addClass('btn-primary');
                else button.removeClass('btn-primary').addClass('btn-success');
                $('#commentModal').modal('hide');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    $(function () {

    });
</script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.2/css/responsive.dataTables.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/responsive/2.2.2/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/plug-ins/1.10.19/sorting/absolute.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="/js/moment.js"></script>
<script>
    function format ( d ) {
    // `d` is the original data object for the row
    var tt = '<table cellpadding="5" cellspacing="0" border="0" class="table table-striped table-hover table-bordered" style="padding-left:50px; width: 100%;border: 3px #f60 solid;">' +
        '<thead>' +
            '<tr>'+
                '<th>Предмет</th>'+
                '<th>Дата</th>'+
                '<th>Тип</th>'+
                '<th>Скачать</th>'+
                '<th title="% Оригинальности">%</th>'+
                '<th>Оценка</th>'+
                '<th></th>'+
            '</tr>'+
        '</thead><tbody style="">';
        d.forEach(function(item, i, arr) {
        tt +=
            '<tr'+(item.tstatus === 0 ? ' class="danger"':'')+'>'+
                '<td>'+item.tdisc+'</td>'+
                '<td>'+item.tdate+'</td>'+
                '<td>'+item.ttype+'</td>'+
                '<td>'+item.tdwnld+'</td>'+
                '<td>'+item.tperc+'</td>'+
                '<td>'+item.tmark+'<br><small>'+item.tmarked+'</small></td>'+
                '<td>'+item.tcom+'</td>'+
            '</tr>';
        });
    tt += '</tbody></table>';
    return tt;
}

    $(document).ready(function () {
        var namesType = $.fn.dataTable.absoluteOrder( [ { value: '2', position: 'top' } ] );
        var settings = {
            "ajax": {
                "url": "/tasks/index?kr=1&cr=1&vkr=1&pract=1",
                "type": "POST",
                "data": function ( d ) { d.disc = $('#disc_filter').val(); d.sort = $('#sort_works').is(':checked'); }
            },
            "order": [],
            "pageLength": 25,
            "info":     false,
            "sDom": '<"row view-filter"<"col-sm-12"<"pull-left"l><"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"ip>>>',
            "language": { "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json" },
            "columns": [
                { "data": null, "render": {'_': 'tid', 'filter' : 'tstatus' }},
                { "data": "tname",  "className":'details-control text-left' },
                { "data": null,"render": {"_": "tdate", "sort": "tdate_" }},
                // { "data": "tdate",  "sort=tdate_" },
                { "data": "tclass" },
                { "data": "tchild",    "visible": false }
            ],
            "createdRow": function ( row, data, index ) { if ( data.tstatus === '0' ) { $(row).addClass('danger'); }},
            orderCellsTop: true
        };
        jQuery.fn.dataTable.Api.register('row.addByPos()', function(data, index) {
            var currentPage = this.page();
            this.row.add(data);
            var rowCount = this.data().length-1,
                insertedRow = this.row(rowCount).data(),
                tempRow;
            for (var i=rowCount;i>=index;i--) {
                tempRow = table1.row(i-1).data();
                this.row(i).data(tempRow);
                this.row(i-1).data(insertedRow);
            }
            this.page(currentPage).draw(false);
        });


        var table1 = $('#tab1 table').DataTable(settings);
        settings.ajax.url = '/tasks/index?kr=1';
        settings.ajax.data = function ( d ) { d.disc = $('#disc_filter2').val(); d.sort = $('#sort_works2').is(':checked'); };
        var table2 = $('#tab2 table').DataTable(settings);
        settings.ajax.url = '/tasks/index?cr=1';
        settings.ajax.data = function ( d ) { d.disc = $('#disc_filter3').val(); d.sort = $('#sort_works3').is(':checked'); };
        var table3 = $('#tab3 table').DataTable(settings);
        settings.ajax.url = '/tasks/index?vkr=1';
        settings.ajax.data = function ( d ) { d.disc = $('#disc_filter4').val(); d.sort = $('#sort_works4').is(':checked'); };
        var table4 = $('#tab4 table').DataTable(settings);
        settings.ajax.url = '/tasks/index?pract=1';
        settings.ajax.data = function ( d ) { d.disc = $('#disc_filter5').val(); d.sort = $('#sort_works5').is(':checked'); };
        var table5 = $('#tab5 table').DataTable(settings);

        table1.on( 'init.dt', function () {
            var discs = {};
            table1.column(3).data().unique().sort().each( function ( d, j ) { $('#class_filter').append( '<option value="'+d+'">'+d+'</option>' ) } );
            table1.column(4).data().unique().sort().each( function ( d, j ) { d.forEach( function (d) { discs[d.tdisc] = true; } ); } );
            Object.keys(discs).forEach( function ( d, j ) { $('#disc_filter').append( '<option value="'+d+'">'+d+'</option>' ) });
            $('#disc_filter').on( 'change', function () { table1.ajax.reload(); });
            $('#sort_works').on( 'click', function () { table1.ajax.reload(); });

            var indexes1 = table1.rows().indexes().filter( function ( value, index ) { return table1.row(value).data().tstatus !== '2'; });
            var data1 = table1.rows(indexes1).data();
            // for (var i = 0; i < data1.length; i++) { $(this).find('.second th').eq(i).html( data1[i] ); }
            table1.rows(indexes1).remove().draw(false);
            // data1.each(function (d) {
            //     table1.row.addByPos(d, 1);
            // });
            // table1.rows(indexes1).addByPos([data], 1);

            // table1.column(5).data().unique().sort().each( function ( d, j ) { $('#type_filter').append( '<option value="'+d+'">'+d+'</option>' ) } );
        } );
        table2.on( 'init.dt', function () {
            var discs = {};
            table2.column(3).data().unique().sort().each( function ( d, j ) { $('#class_filter2').append( '<option value="'+d+'">'+d+'</option>' ) } );
            table2.column(4).data().unique().sort().each( function ( d, j ) { d.forEach( function (d) { discs[d.tdisc] = true; } ); } );
            Object.keys(discs).forEach( function ( d, j ) { $('#disc_filter2').append( '<option value="'+d+'">'+d+'</option>' ) });
            $('#disc_filter2').on( 'change', function () { table2.ajax.reload(); });
            $('#sort_works2').on( 'click', function () { table2.ajax.reload(); });
            // table2.column(5).data().unique().sort().each( function ( d, j ) { $('#type_filter2').append( '<option value="'+d+'">'+d+'</option>' ) } );
        } );
        table3.on( 'init.dt', function () {
            var discs = {};
            table3.column(3).data().unique().sort().each( function ( d, j ) { $('#class_filter3').append( '<option value="'+d+'">'+d+'</option>' ) } );
            table3.column(4).data().unique().sort().each( function ( d, j ) { d.forEach( function (d) { discs[d.tdisc] = true; } ); } );
            Object.keys(discs).forEach( function ( d, j ) { $('#disc_filter3').append( '<option value="'+d+'">'+d+'</option>' ) });
            $('#disc_filter3').on( 'change', function () { table3.ajax.reload(); });
            $('#sort_works3').on( 'click', function () { table3.ajax.reload(); });
            // table3.column(5).data().unique().sort().each( function ( d, j ) { $('#type_filter3').append( '<option value="'+d+'">'+d+'</option>' ) } );
        } );
        table4.on( 'init.dt', function () {
            var discs = {};
            table4.column(3).data().unique().sort().each( function ( d, j ) { $('#class_filter4').append( '<option value="'+d+'">'+d+'</option>' ) } );
            table4.column(4).data().unique().sort().each( function ( d, j ) { d.forEach( function (d) { discs[d.tdisc] = true; } ); } );
            Object.keys(discs).forEach( function ( d, j ) { $('#disc_filter4').append( '<option value="'+d+'">'+d+'</option>' ) });
            $('#disc_filter4').on( 'change', function () { table4.ajax.reload(); });
            $('#sort_works4').on( 'click', function () { table4.ajax.reload(); });
            // table4.column(5).data().unique().sort().each( function ( d, j ) { $('#type_filter4').append( '<option value="'+d+'">'+d+'</option>' ) } );
        } );
        table5.on( 'init.dt', function () {
            var discs = {};
            table5.column(3).data().unique().sort().each( function ( d, j ) { $('#class_filter5').append( '<option value="'+d+'">'+d+'</option>' ) } );
            table5.column(4).data().unique().sort().each( function ( d, j ) { d.forEach( function (d) { discs[d.tdisc] = true; } ); } );
            Object.keys(discs).forEach( function ( d, j ) { $('#disc_filter5').append( '<option value="'+d+'">'+d+'</option>' ) });
            $('#disc_filter5').on( 'change', function () { table5.ajax.reload(); });
            $('#sort_works5').on( 'click', function () { table5.ajax.reload(); });
            // table5.column(5).data().unique().sort().each( function ( d, j ) { $('#type_filter5').append( '<option value="'+d+'">'+d+'</option>' ) } );
        } );

        // table1
        //     .on('xhr.dt', function ( e, settings, json, xhr ) { json.data.sort(function(a, b) { if (a.tstatus === 2 || b.tstatus == 2) { return -1; } return 1; }) })
        //     .on( 'order.dt', function () {
        //         // var order = table1.order();
        //         table1.data().sort(function(a, b) { if (a.tstatus === 2 || b.tstatus == 2) { return -1; } return 1; });
        //         // $('#orderInfo').html( 'Ordering on column '+order[0][0]+' ('+order[0][1]+')' );
        //     } );

        // console.log(table1.row(indexes1).data());
        // grab the data from the row
        // var data1 = table1.row(indexes1).data();
        // populate the .second header with the data
        // for (var i = 0; i < data1.length; i++) {
        //     $('.danger').find('th').eq(i).html( data1[i] );
        // }
        // remove the row from the table
        // table1.row(indexes1).remove().draw(false);

        table1.on( 'draw', function () {var rows = table1.rows().data();var count = 0;rows.each(function (d) {if (d.tstatus !== '0') count++;});$('#w1').text(rows.length-count);});
        table2.on( 'draw', function () {var rows = table2.rows().data();var count = 0;rows.each(function (d) {if (d.tstatus !== '0') count++;});$('#w2').text(rows.length-count);});
        table3.on( 'draw', function () {var rows = table3.rows().data();var count = 0;rows.each(function (d) {if (d.tstatus !== '0') count++;});$('#w3').text(rows.length-count);});
        table4.on( 'draw', function () {var rows = table4.rows().data();var count = 0;rows.each(function (d) {if (d.tstatus !== '0') count++;});$('#w4').text(rows.length-count);});
        table5.on( 'draw', function () {var rows = table5.rows().data();var count = 0;rows.each(function (d) {if (d.tstatus !== '0') count++;});$('#w5').text(rows.length-count);});

        $('tbody').on('change', '.mark', function () {
            var id = $(this).data('id');
            var mark = this.value;
            var tr = $('.tab-content .shown');
            [table1,table2,table3,table4,table5].forEach(function(table) {
                console.log(table);
                // var row = table.row( tr );//.data().tchild;
                try {
                    var row = table.row( tr ).data().tchild;
                } catch (e){
                    // console.log(e);
                    return;
                }
                // if (row.data() !== undefined) {
                //     console.log(row.length);
                // }
                row.forEach(function(el) {
                    if (el.tmark.search(id) !== -1) {
                        el.tmark = el.tmark
                            .replace(' selected', '')
                            .replace('value="'+mark+'"', 'value="'+mark+'" selected');
                            // .replace("#<small>(.*)<\/small>#si", moment().format('D.M H:mm'))
                        console.log(el.tmark);
                    }
                });
            });

            $.ajax({
                url: '/tasks/mark',
                type: 'post',
                data: {'mark': this.value, 'id': $(this).data('id')},
                success: function (res) {
                    swal({
                        title: "Успешно сохранено!",
                        timer: 1500,
                        icon: 'success'
                    });
                    console.log(res);
                },
                error: function () {
                    console.log('Error!');
                }
            });
        });

        // Add event listener for opening and closing details
        $('#tab1 tbody').on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table1.row( tr );

            if ( row.child.isShown() ) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                table1.rows().every(function() {
                    var r =  this.nodes().to$();
                    table1.row( r ).child.hide();
                    r.removeClass('shown')
                });
                row.child( format(row.data().tchild) ).show();
                tr.addClass('shown');
            }
        } );
        $('#tab2 tbody').on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table2.row( tr );

            if ( row.child.isShown() ) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                table2.rows().every(function() {
                    var r =  this.nodes().to$();
                    table2.row( r ).child.hide();
                    r.removeClass('shown')
                });
                row.child( format(row.data().tchild) ).show();
                tr.addClass('shown');
            }
        } );
        $('#tab3 tbody').on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table3.row( tr );

            if ( row.child.isShown() ) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                table3.rows().every(function() {
                    var r =  this.nodes().to$();
                    table3.row( r ).child.hide();
                    r.removeClass('shown')
                });
                row.child( format(row.data().tchild) ).show();
                tr.addClass('shown');
            }
        } );
        $('#tab4 tbody').on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table4.row( tr );

            if ( row.child.isShown() ) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                table4.rows().every(function() {
                    var r =  this.nodes().to$();
                    table4.row( r ).child.hide();
                    r.removeClass('shown')
                });
                row.child( format(row.data().tchild) ).show();
                tr.addClass('shown');
            }
        } );
        $('#tab5 tbody').on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table5.row( tr );

            if ( row.child.isShown() ) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                table5.rows().every(function() {
                    var r =  this.nodes().to$();
                    table5.row( r ).child.hide();
                    r.removeClass('shown')
                });
                row.child( format(row.data().tchild) ).show();
                tr.addClass('shown');
            }
        } );

        $('#hide_works').on( 'click', function () { table1.columns(0).search( $(this).is(':checked') ? 0 : '' ).draw(); } );
        $('#student_filter').on( 'keyup', function () { table1.columns(1).search( this.value ).draw(); } );
        $('#date_filter').on( 'keyup', function () { table1.columns(2).search( this.value ).draw(); } );
        $('#class_filter').on( 'change', function () { var val = $.fn.dataTable.util.escapeRegex( $(this).val() ); table1.columns(3).search( val ? '^'+val+'$' : '', true, false ).draw(); });

        $('#hide_works2').on( 'click', function () { table2.columns(0).search( $(this).is(':checked') ? 0 : '' ).draw(); } );
        $('#student_filter2').on( 'keyup', function () { table2.columns(1).search( this.value ).draw(); } );
        $('#date_filter2').on( 'keyup', function () { table2.columns(2).search( this.value ).draw(); } );
        $('#class_filter2').on( 'change', function () { var val = $.fn.dataTable.util.escapeRegex( $(this).val() ); table2.columns(3).search( val ? '^'+val+'$' : '', true, false ).draw(); });

        $('#hide_works3').on( 'click', function () { table3.columns(0).search( $(this).is(':checked') ? 0 : '' ).draw(); } );
        $('#student_filter3').on( 'keyup', function () { table3.columns(1).search( this.value ).draw(); } );
        $('#date_filter3').on( 'keyup', function () { table3.columns(2).search( this.value ).draw(); } );
        $('#class_filter3').on( 'change', function () { var val = $.fn.dataTable.util.escapeRegex( $(this).val() ); table3.columns(3).search( val ? '^'+val+'$' : '', true, false ).draw(); });

        $('#hide_works4').on( 'click', function () { table4.columns(0).search( $(this).is(':checked') ? 0 : '' ).draw(); } );
        $('#student_filter4').on( 'keyup', function () { table4.columns(1).search( this.value ).draw(); } );
        $('#date_filter4').on( 'keyup', function () { table4.columns(2).search( this.value ).draw(); } );
        $('#class_filter4').on( 'change', function () { var val = $.fn.dataTable.util.escapeRegex( $(this).val() ); table4.columns(3).search( val ? '^'+val+'$' : '', true, false ).draw(); });

        $('#hide_works5').on( 'click', function () { table5.columns(0).search( $(this).is(':checked') ? 0 : '' ).draw(); } );
        $('#student_filter5').on( 'keyup', function () { table5.columns(1).search( this.value ).draw(); } );
        $('#date_filter5').on( 'keyup', function () { table5.columns(2).search( this.value ).draw(); } );
        $('#class_filter5').on( 'change', function () { var val = $.fn.dataTable.util.escapeRegex( $(this).val() ); table5.columns(3).search( val ? '^'+val+'$' : '', true, false ).draw(); });

        // $('#type_filter').on( 'change', function () {
        //     var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
        //     table1.columns(5).search( val ? '^'+val+'$' : '', true, false ).draw();
        // });
        // $('#type_filter2').on( 'change', function () {
        //     var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
        //     table2.columns(5).search( val ? '^'+val+'$' : '', true, false ).draw();
        // });
        // $('#type_filter3').on( 'change', function () {
        //     var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
        //     table3.columns(5).search( val ? '^'+val+'$' : '', true, false ).draw();
        // });
        // $('#type_filter4').on( 'change', function () {
        //     var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
        //     table4.columns(5).search( val ? '^'+val+'$' : '', true, false ).draw();
        // });
        // $('#type_filter5').on( 'change', function () {
        //     var val = $.fn.dataTable.util.escapeRegex( $(this).val() );
        //     table5.columns(5).search( val ? '^'+val+'$' : '', true, false ).draw();
        // });

        $('#course').on('changed.bs.select', function (e) {
            $('#class').prop('disabled', false);
            $.ajax({
                url: base+'profile/getListFilter',
                type: 'post',
                data: {'course': $(this).val()},
                success: function (res) {
                    $('#class')
                        .html(res)
                        .selectpicker('refresh');
                },
                error: function () {
                    console.log('Error!');
                }
            });
        });
        $('#class').on('changed.bs.select', function (e) { table1.search( $(this).val() ).draw(); });
        $('#class2').on('changed.bs.select', function (e) { table2.search( $(this).val() ).draw(); });
        $('#class3').on('changed.bs.select', function (e) { table3.search( $(this).val() ).draw(); });
        $('#class4').on('changed.bs.select', function (e) { table4.search( $(this).val() ).draw(); });
        $('#class5').on('changed.bs.select', function (e) { table5.search( $(this).val() ).draw(); });

    });
</script>