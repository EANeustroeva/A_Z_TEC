<form action="<?= BASE_URL ?>tasks/comSet" method="post">
    <input type="hidden" name="id" value="<?= $id ?>">
    <div class="panel panel-default">
        <div class="panel-heading">Написать комментарий</div>
        <div class="panel-body">
            <h4></h4>
            <div class="col-sm-12">
                <textarea class="form-control" name="comment" id="comment" cols="30" rows="10"><?= @$comment ?></textarea>
            </div>
            <h4></h4>
        </div>
        <div class="panel-footer">
            <button class="btn btn-success">Сохранить</button>
            <a class="btn btn-warning" href="<?= $_SERVER['HTTP_REFERER'] ?>">Назад</a>
        </div>
    </div>

</form>
