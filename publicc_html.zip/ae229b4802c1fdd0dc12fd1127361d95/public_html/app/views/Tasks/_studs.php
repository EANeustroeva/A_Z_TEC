<div class="alert alert-warning fade in" role="alert">
    <?php $text = '<h2 style="margin: 0">Внимание, уважаемые студенты!</h2> <hr> Данный раздел находится в стадии активного обновления, приносим свои извинения за возможные доставленные неудобства!<br> Штатная работа раздела возобновится 20.12.17г. в 23.00' ?>
    <div class="row">
        <div class="col-xs-3"><img src="http://eskirf.ru/sites/default/files/u2487/remont.png" class="img-responsive" alt=""></div>
        <div class="col-xs-9"><?= $text ?><br>
            <!--<h3 id="sSpentTime" style="color: rgb(0, 128, 0);">Осталось:
                <b><span class="hours"></span>:<span class="minutes"></span>:<span class="seconds"></span></b>
            </h3>-->
        </div>
    </div>
    <div class="row text-center">

    </div>
    <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>
</div>

<div class="col-sm-12">
    <h5>Направление: <?= $plan['napr'] ?> (<?= $plan['napr_n'] ?>)</h5>
    <h5>Профиль:     <?= $plan['dop'] ?></h5>
    <h4>Предмет:     <?= $_GET['disc'] ?></h4>
</div>

<?php if ($_GET['disc'] && isset($plan['lektor'])): ?>
<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">Диалог с преподавателем <?= isset($plan['lektor']) ? "({$plan['lektor']})" : '' ?></div>
            <div class="panel-body">
                <div class="container-chat" style="min-height: 100px;
    max-height: 600px;">
                    <ul class="list-unstyled">
                        <?php if (empty($msg->thread)) echo '<p class="text-center">Нет сообщений</p>'; ?>
                        <?php if ($msg->buddy->more): ?>
                            <li id="load-more-wrap" style="text-align:center;padding: 10px 0;"><a
                                        onclick="javascript: load_thread(<?= $msg->buddy->d_id . ',' . $msg->buddy->limit ?>)"
                                        class="btn btn-xs btn-default" style="width:100%">Старые сообщения
                                    (<?= $msg->buddy->remaining ?>)</a></li>
                        <?php endif; ?>
                        <?php if (!empty($msg->thread)) foreach ($msg->thread as $item): ?>
                            <?php if (isset($msg)): ?>
                                <a class="message-bubble row <?php if ($item->status == 0) echo 'unread'; ?>"
                                   style="padding: 3px 5px 3px 0px;font-size: 0.85em;">
                    <span class="chat-img pull-left" style="padding-right: 10px;">
						<img src="<?= $item->avatar ?>" class="avt " style="height: 30px;">
					</span>
                                    <div class="chat-body" style="padding-left: 0;">
                                        <strong class="primary-font"><?= $item->name ?></strong>
                                        <small class="text-muted pull-right ">
                                            <span class="glyphicon glyphicon-time"></span>
                                            <?= date('g:i a', strtotime($item->time)) ?>
                                        </small>
                                        <p style="margin:0;"><?= $item->msg ?></p>
                                    </div>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <div class="panel-footer">
                <div class="input-group">
                    <input type="text" name="msg" id="msg" class="form-control" autocomplete="off" autofocus required>
                    <!-- glyphicon glyphicon-file -->
                    <input type="hidden" name="usr_name" id="usr_name"
                           value="<?= $plan['lektor'] ?>">
                    <input type="hidden" name="usr_id" value="<?= $plan['user_id'] ?>" id="usr_id">
                    <span class="input-group-btn">
                        <span class="btn btn-default" id="send"><i class="glyphicon glyphicon-pencil"></i></span>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
    $(function () {
        $('#send').click(function () {
            $.ajax({
                url: base + 'users/dialog',
                type: 'post',
                data: {
                    msg: $("#msg").val(),
                    usr_id: $("#usr_id").attr("value"),
                    usr_name: $("#usr_name").attr("value")
                },
                success: function (res) {
//                    console.log($(".active input").text('123'));
                   console.log(res);
                },
                error: function () {
                    alert('Error!');
                }
            });
        });
    });
</script>


<?php
    if (empty($docs)): echo '<div class="panel panel-default"><div class="panel-body"><h3 class="text-center" style="margin-bottom: 20px;">Документы по выбранному предмету не найдены</h3></div></div>';
else: ?>
<table class="table table-responsive table-bordered table-striped">
    <thead>
    <tr>
        <th>Файл</th>
        <th>Комментарий</th>
        <th>Действие</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($docs as $i => $task): ?>
        <tr>
            <td><a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $task['fname']) . '&c=' . urlencode($task['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $task['ftitle'] ?></a></td>
            <td><?php
                if (empty($task['descr']))  $task['descr']='-';
                if ($user->access==4) echo mb_strimwidth($task['descr'], 0, 10, '..');
                else echo '<a href="tasks/workview?id='.$i.'">'.$task['descr'].'</a>' ?></td>
            <td>
                <?php if (!empty($task['taskfile'])): ?>
                <?php endif; ?>
                <?php if ($user->access!=4): ?>
                    <form action="<?= BASE_URL ?>tasks/edit" method="post" style="display: inline">
                        <input type="hidden" name="id" value="<?= $task['id'] ?>">
                        <button type="submit" class="btn btn-info btn-xs">
                            <span class="glyphicon glyphicon-edit"></span>&nbsp;<span
                                    class="hidden-xs">Изменить</span></button>
                    </form>
                <?php endif; ?>
                <?php if (isset($plan['lektor'])): ?>
                <form action="<?= BASE_URL ?>tasks/view?disc=<?= $_GET['disc'] ?>" method="post" style="display: inline">
                    <input type="hidden" name="id" value="<?= $task['id'] ?>">
                    <button type="submit" class="btn btn-success btn-xs">
                        <span class="glyphicon glyphicon-eye-open"></span>&nbsp;<span
                                class="hidden-xs">Загрузить ответ</span></button>
                </form>
                <?php endif; ?>
            </td>
        </tr>

    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>


<?php if (!empty($marks)): ?>
<table class="table table-striped table-hover table-bordered">
    <thead>
        <tr>
            <th>Дата</th>
            <th>Задание</th>
            <th>Преподаватель</th>
            <th>Тип</th>
            <th>Статус</th>
            <th>Оценка</th>
        </tr>
    </thead>
    <tbody>
<?php //dump($marks) ?>
    <?php foreach ($marks as $mark): ?>
        <tr>
            <td><?= $mark['created'] ?></td>
            <td><?= $mark['task']['ftitle'] ?></td>
            <td><?= $mark['teacher'] ?></td>
            <td><?= $mark['type'] ?></td>
            <td><?php
                    if ($mark['status']==0) echo 'Ожидается проверка';
                    elseif ($mark['status']==1) echo 'Работа проверяется';
                    elseif ($mark['status']==2) echo 'Работа проверена';
                ?></td>
            <td><?php
                if (@$mark['mark']==6) echo 'зач';
                elseif (@$mark['mark']==7) echo 'на дораб.';
                else echo @$mark['mark'] ?></td>
        </tr>
    <?php endforeach; ?>

    </tbody>
</table>
<?php endif; ?>