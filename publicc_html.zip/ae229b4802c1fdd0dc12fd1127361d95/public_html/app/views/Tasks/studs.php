<!--<div class="alert alert-warning fade in" role="alert">
    <?php /*$text = '<h2 style="margin: 0">Внимание, уважаемые студенты!</h2> <hr> Данный раздел находится в стадии активного обновления, приносим свои извинения за возможные доставленные неудобства!<br> Штатная работа раздела возобновится 20.12.17г. в 23.00' */?>
    <div class="row">
        <div class="col-xs-3"><img src="http://eskirf.ru/sites/default/files/u2487/remont.png" class="img-responsive" alt=""></div>
        <div class="col-xs-9"><?/*= $text */?><br></b>

        </div>
    </div>
    <div class="row text-center">

    </div>
    <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>
</div>
-->
<div class="row">
    <div class="col-sm-8">
        <h5>Направление: <?= isset($plan['napr']) ? $plan['napr'] . ' ('. $plan['napr_n'] . ')' : 'Не найдено'?></h5>
        <h5>Профиль:     <?= isset($plan['dop']) ? $plan['dop'] : 'Не найдено'?></h5>
        <h4>Предмет:     <?= $_POST['disc'] ?></h4>
        <h4>Семестр:     <?= $_POST['s'] ?></h4>
    </div>
    <?php if ($plan['enabled']): ?>
    <div class="col-sm-4">
        <form action="<?= BASE_URL ?>tasks/view" method="post" style="display: inline" class="pull-right">
            <input type="hidden" name="id" value="0">
            <input type="hidden" name="prep_id" value="<?= isset($plan['user_id']) ? $plan['user_id'] : '' ?>">
            <input type="hidden" name="s" value="<?= $_POST['s'] ?>">
            <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
            <?= !empty($_POST['dolg'])?'<input type="hidden" name="dolg" value="1">':'' ?>
            <button type="submit" class="btn btn-success">
                <span class="glyphicon glyphicon-eye-open"></span>&nbsp;Загрузить работу</button>
        </form>
    </div>
    <?php endif; ?>
</div>


<?php
    if (empty($docs) && empty($rpd) && empty($fos)): echo '<div class="panel panel-default"><div class="panel-body"><h3 class="text-center" style="margin-bottom: 20px;">Документы по выбранному предмету не найдены</h3></div></div>';
else: ?>
<table class="table table-responsive table-bordered table-striped">

    <tbody>
        <?php if (!empty($rpd)): ?>
        <tr>
            <th>РПД:</th>
            <td colspan="2">
                <a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $rpd['fname']) . '&c=' . urlencode($rpd['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $rpd['ftitle'] ?></a>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($fos)): ?>
        <tr>
            <th>ФОС:</th>
            <td colspan="2">
                <a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $fos['fname']) . '&c=' . urlencode($fos['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $fos['ftitle'] ?></a>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($docs)): ?>
        <tr class="info"><th colspan="3">Задания:</th></tr>
        <tr>
            <th>Файл</th>
            <th>Комментарий</th>
            <th>Действие</th>
        </tr>
    <?php foreach ($docs as $i => $task): ?>
        <tr>
            <td><a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $task['fname']) . '&c=' . urlencode($task['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $task['ftitle'] ?></a></td>
            <td><?php
//                if (empty($task['descr']))  $task['descr']='-';
                if ($user->access==4)
                    if (!empty($task['descr'])) echo '<span tabindex="0" data-html="true" data-toggle="popover"
                      data-content="'. htmlspecialchars($task['descr']) .'" class="btn btn-xs btn-primary" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></span>';
//                mb_strimwidth($task['descr'], 0, 10, '..');
                else echo '<a href="tasks/workview?id='.$i.'">'.$task['descr'].'</a>' ?></td>
            <td>
                <?php if (!empty($task['taskfile'])): ?>
                <?php endif; ?>
                <?php if ($user->access!=4): ?>
                    <form action="<?= BASE_URL ?>tasks/edit" method="post" style="display: inline">
                        <input type="hidden" name="id" value="<?= $task['id'] ?>">
                        <input type="hidden" name="s" value="<?= $_POST['s'] ?>">
                        <button type="submit" class="btn btn-info btn-xs">
                            <span class="glyphicon glyphicon-edit"></span>&nbsp;<span
                                    class="hidden-xs">Изменить</span></button>
                    </form>
                <?php endif; ?>
                <?php if ($plan['enabled']): ?>
                <form action="<?= BASE_URL ?>tasks/view" method="post" style="display: inline">
                    <input type="hidden" name="id" value="<?= $task['id'] ?>">
                    <input type="hidden" name="s" value="<?= $_POST['s'] ?>">
                    <input type="hidden" name="prep_id" value="<?= isset($plan['user_id']) ? $plan['user_id'] : '' ?>">
                    <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
                    <?= !empty($_POST['dolg'])?'<input type="hidden" name="dolg" value="1">':'' ?>
                    <button type="submit" class="btn btn-success btn-xs">
                        <span class="glyphicon glyphicon-eye-open"></span>&nbsp;<span
                                class="hidden-xs">Загрузить ответ</span></button>
                </form>
                <?php endif; ?>
            </td>
        </tr>

    <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
<?php endif; ?>

<?php if (!empty($marks)): ?>
<table class="table table-striped table-hover table-bordered">
    <thead>
        <tr>
            <th>Дата</th>
            <th>Работа</th>
            <th>Преподаватель</th>
            <th>Тип</th>
            <th>Статус</th>
            <th>% Ориг-ти</th>
            <th>Оценка</th>
            <th>К-й</th>
        </tr>
    </thead>
    <tbody>
<?php //dump($marks) ?>
    <?php foreach ($marks as $mark): ?>
        <tr>
            <td><?= date("H:i d/m/Y", strtotime($mark['created'])) ?></td>
            <td><?php if (!empty($mark['file'])): ?>
                    <a href="<?= 'upload/works/' . $mark['file'] ?>" class="btn btn-warning btn-xs"
                       target="_blank">
                        <span class="glyphicon glyphicon-download"></span>&nbsp;<span
                                class="hidden-xs">Скачать</span></a>
                <?php endif; ?></td>
            <td><?= $mark['teacher'] ?></td>
            <td><?= $mark['type'] ?></td>
            <td><?php
                    if ($mark['status']==0) echo 'Ожидается проверка';
                    elseif ($mark['status']==1) echo 'Работа проверяется';
                    elseif ($mark['status']==2) echo 'Работа проверена';
                ?><div class="clear"></div>
                <form action="/tasks/docs" data-blocked="<?= empty($mark['perc']) ? 1 : 0 ?>" class="docgen" data-id="<?= $mark['id'] ?>" target="_blank" method="post" style="width: 50%;float:left;">
                    <input type="hidden" name="sem" value="<?= $_POST['s'] ?>">
                    <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
                    <input type="hidden" name="user_id" value="<?= $cur_user->id ?>">
                    <button style="width: 100%;" type="submit" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-download"></span>&nbsp;Cправка</button>
                </form>
            </td>
            <td><?php if (!empty($mark['perc'])): ?>
                <?= $mark['perc'] . '%' ?>
                    <a target="_blank" class="btn btn-xs btn-success pull-right" href="<?= $mark['pdf'] ?>" title="Полный отчет">
                        <i class="glyphicon glyphicon-download-alt"></i></a>
                <?php else: ?>
                <span data-id="<?= $mark['id'] ?>" class="work btn btn-xs btn-default pull-right" title="Отправить на проверку"><i class="glyphicon glyphicon-check"></i></span>
                <?php endif; ?>
            </td>
            <td><h3 style="margin: 0;"><?php
                if (@$mark['mark']==6) echo 'зач';
                elseif (@$mark['mark']==7) echo 'на дораб.';
                else echo @$mark['mark'] ?></h3>
                <?= !empty($mark['marked'])?"<code>".date("d.m.Y H:i", strtotime($mark['marked']))."</code>":'' ?>
                <?= !empty($mark['teacher'])?"<br><code>{$mark['teacher']}</code>":'' ?></td>
            <td><?php if (!empty($mark['comment'])): ?>
                <?php $comment = '<span style="white-space: normal">'. str_replace("\n",'<br>',$mark['comment']) .'</span>' ?>
                <span tabindex="0" data-html="true" data-toggle="popover"
                      data-content="<?= htmlentities($comment) ?>" class="btn btn-xs btn-primary" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></span><?php endif; ?></td>
        </tr>
    <?php endforeach; ?>

    </tbody>
</table>
<?php endif; ?>


<?php if ($video): ?>
<link href="http://vjs.zencdn.net/7.0/video-js.min.css" rel="stylesheet">
<script src="http://vjs.zencdn.net/7.0/video.min.js"></script>
<script src="/js/sweetalert2.all.min.js"></script>
<script src="/js/moment.js"></script>
<video id="example_video_1" class="video-js vjs-default-skin" controls preload="none" width="640" height="264" data-setup="{controlBar: {fullscreenToggle: false}}">
    <source src="<?= (!parse_url($video->fname, PHP_URL_SCHEME)?'/ino_videos/':'') . $video->fname ?>">
    <p class="vjs-no-js">To view this video please enable JavaScript, and consider upgrading to a web browser that <a href="http://videojs.com/html5-video-support/" target="_blank">supports HTML5 video</a></p>
</video>
<hr>
<?php if ($video->dop): ?>
    <form action="tests/test" method="post">
        <div class="form-group">
        <button class="btn btn-success btn-lg">
            <input type="hidden" name="id" value="<?= $video->dop ?>">
            <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Перейти к тесту</span></button>
        </div>
        <h4>&nbsp;</h4>
    </form>
<?php endif; ?>
<?php endif; ?>

<?php if ($_POST['disc'] && isset($plan['lektor'])): ?>
<h4>Диалог с преподавателем <?= $plan['lektor'] ?></h4>
<div class="chat"></div>
<script>
    $(document).ready(function () {
       load_chat(<?= $plan['user_id'] ?>)
    });
</script>
<?php endif; ?>
<div class="clear"></div>


<style>
    .list-group-item {
        word-break: break-word;
    }
</style>

<script>
    function load_chat(id) {
        $('.chat').html('<img src="/images/loader.gif" width="15">');
        $.ajax({
            url: '/im/widget',
            type: 'post',
            data: {id: id},
            success: function (res) {
                $('.chat').html(res)
            },
            error: function (e) {
                console.log(e);
            }
        });
    }

    $('.docgen').submit(function (e) {
        var form = $(this);
        var url = form.attr('action');
        var status = 0;
        if (form.data('blocked') === 1) {
            // alert('Справка будет доступна после проверки работы в сервисе антиплагиат');
            e.preventDefault();
        }
    });
</script>

<script>
    var popOverSettings = {
    placement: 'left',
    container: 'body',
    trigger: 'focus',
    html: true,
    selector: '[data-toggle=popover]',
    content: function () {
        return $('#popover-content').html();
    }
};

$('body').popover(popOverSettings);

    $(document).ready(function () {
        $('body').on('click','.work',function () {
            var el = $(this);
            var id = el.data('id');
            $(this).html('<img src="/images/loader.gif" width="15">');

            $.ajax({
                url: '/tasks/test',
                type: 'get',
                data: {
                    id: id
                },
                success: function (res) {
//                    console.log(res);
                    if (res.success) {
                        el.parent().html(res.success + '%' +
                            '<a target="_blank" class="btn btn-xs btn-success pull-right" href="'+
                            res.pdf+ '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>');
                        $('form[data-id='+id+'].docgen').data('blocked',0)
                    }
                    else {
                        if (res.error) alert(res.error);
                        else alert('Антиплагиат временно отключен! ');
                        el.parent().html('<span data-id="'+id+'" class="work btn btn-xs btn-default pull-right" title="Отправить на проверку"><i class="glyphicon glyphicon-check"></i></span>')
                    }
                },
                error: function (res) {
                    el.parent().html('<span data-id="'+id+'" class="work btn btn-xs btn-default pull-right" title="Отправить на проверку"><i class="glyphicon glyphicon-check"></i></span>');
                    if (res.error) alert(res.error);
                    else alert('Произошла ошибка! ');
                    console.log(res);
                }
            })
        });
    })
</script>
