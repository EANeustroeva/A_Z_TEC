Admin Panel
<?php debug($posts) ?>