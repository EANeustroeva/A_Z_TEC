<code><?=__FILE__;?></code>
<br>
<?=$test;?>
<br>
<?php debug($data); ?>
