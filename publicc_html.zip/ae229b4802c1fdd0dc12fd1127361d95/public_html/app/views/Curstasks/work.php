Загрузка...
<form id="myForm" action="/curstasks" method="post">
    <?php
    foreach ($_POST as $a => $b) {
        echo '<input type="hidden" name="'.htmlentities($a).'" value="'.htmlentities($b).'">';
    }
    $_SESSION['info_msg'][] = 'Успешно сохранено!';
    ?>
</form>
<script type="text/javascript">
    document.getElementById('myForm').submit();
</script>