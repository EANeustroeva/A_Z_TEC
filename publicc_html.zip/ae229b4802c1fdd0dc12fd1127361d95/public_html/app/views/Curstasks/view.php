<div class="panel panel-default">
    <div class="panel-heading clearfix">
        <div class="pull-left">
            <form action="<?= BASE_URL ?>curstasks" method="post">
                <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
                <button class="btn btn-default" name="disc" value="<?= $_POST['disc'] ?>"><i class="glyphicon glyphicon-chevron-left" aria-hidden="true"></i> Назад</button>
            </form>
        </div>
        <div style="line-height: 34px;padding-left: 95px;"><?= current($files)['ftitle'] ?></div>
    </div>
    <div class="panel-body">
        <div class="col-sm-12">
            <?php if ($_POST['id']!=0): ?>
            <h4>Комментарий:</h4>

                <div class="well">
                    <?= current($files)['descr'] ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($files)): ?>
<!--                <p>Количество файлов: <b>--><?//= count($files) ?><!--</b></p>-->
                <div class="well well-sm">
                    <ul class="list-group">
                        <?php foreach ($files as $f): ?>
                            <li class="list-group-item" id="<?= $f['id'] ?>"><a href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $f['fname']) . '&c=' . urlencode($f['ftitle']) ?>" target="_blank">Скачать: <b><?= $f['ftitle'] ?></b></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
                <div class="form-group">
                    <?php if (!empty($task['taskfile'])): ?>
                        <a href="<?= 'upload/tasks/'.$task['taskfile'] ?>" class="btn btn-warning" target="_blank">
                            <span class="glyphicon glyphicon-download"></span>&nbsp;Скачать</a>
                    <?php endif; ?>
                </div>
<!--            --><?php //if ($user->access==4 && (intval($user->pay_status)>0 || $user->master_pay == 1)): ?>
            <form action="<?= BASE_URL ?>curstasks/work?disc=<?= $_POST['disc'] ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="type" value="кп">
                <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
                <div class="form-group">
                    <input type = "file" name = "userfile" required/>
                    <span class="help-block">Прикрепить файл ответа</span>
                    <div class="file-uploader"></div>
                </div>
                <div class="form-group">
                    <input type="hidden" name="id" value="<?= $_POST['id'] ?>">
                    <input type="hidden" name="prep_id" value="<?= @$_POST['prep_id'] ?>">
                    <button type="submit" class="btn btn-default">Отправить</button>
                </div>
            </form>
<!--            --><?php //endif; ?>
            <?php if (false && $user->access==4 && (!is_null($user->pay_status)&&$user->pay_status!=1 || $user->master_pay == 0)): ?>
                <div class="alert alert-warning" role="alert">
                    У вас имеется финансовая задолженность на <b><?= date("d.m.Y") ?></b>. Пожалуйста, перейдите в раздел <a href="/oplata" style="text-underline: #0A246A">Оплата</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<link rel="stylesheet" href="<?= BASE_URL ?>css/fileuploader.css">
<script src="<?= BASE_URL ?>js/fileuploader.js"></script>
<script>
    $( document ).ready(function() {
        var uploader = new qq.FileUploader({
            element: document.getElementById('file-uploader'),
            action: 'uploadtask',
            params: {task: <?= $_POST['id'] ?>},
            allowedExtensions: [],
            template: '<div class="qq-uploader">' +
            '<div class="qq-upload-drop-area"><span>{dragText}</span></div>' +
            '<div class="qq-upload-button btn btn-success">{uploadButtonText}</div>' +
            '<hr>' +
            '<ul class="qq-upload-list"></ul>' +
            '</div>',
            dragText: 'Переместите файл в эту зону для загрузки',
            uploadButtonText: '<i class="glyphicon glyphicon-plus-sign"></i>&nbsp; Загрузить...',
            cancelButtonText: 'Отмена',
            failUploadText: 'Ошибка',
            onComplete: function (id, fileName, responseJSON) {},
            onProgress: function (id, fileName, loaded, total) {},
        });
    });
</script>