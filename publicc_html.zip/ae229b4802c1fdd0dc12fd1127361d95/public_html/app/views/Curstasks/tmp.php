<!--<div class="panel panel-default">-->
<!--    <div class="panel-heading">Получить справки</div>-->
<!--    <div class="panel-body">-->
<!--        <div class="col-xs-12">-->
<!--            <h4> </h4>-->
<!--            <div class="form-group">-->
<!--                <div class="col-xs-6" style="border-right: 1px solid #bebebe;">-->
<!--                <form action="/curstasks/docs" target="_blank" method="post" style="display: inline" class="row">-->
<!--                    <input type="hidden" name="sem" value="--><?//= $_POST['sem'] ?><!--">-->
<!--                    <input type="hidden" name="disc" value="--><?//= $_POST['disc'] ?><!--">-->
<!--                    <input type="hidden" name="user_id" value="--><?//= $cur_user->id ?><!--">-->
<!--                    <input type="hidden" name="title" value="--><?//= @$curs['title'] ?><!--">-->
<!--                    <label>Справка о публикации</label>-->
<!--                    <button type="submit" class="btn btn-default  pull-right"><span class="glyphicon glyphicon-download"></span>&nbsp;Получить</button>-->
<!--                </form>-->
<!--                </div>-->
<!--                <div class="col-xs-6">-->
<!--                    <form action="/curstasks/docsb" target="_blank" method="post" style="display: inline" class="row">-->
<!--                        <input type="hidden" name="sem" value="--><?//= $_POST['sem'] ?><!--">-->
<!--                        <input type="hidden" name="disc" value="--><?//= $_POST['disc'] ?><!--">-->
<!--                        <input type="hidden" name="user_id" value="--><?//= $cur_user->id ?><!--">-->
<!--                        <input type="hidden" name="title" value="--><?//= @$curs['title'] ?><!--">-->
<!--                        <label>Отзыв о работе</label>-->
<!--                        <button type="submit" class="btn btn-default pull-right"><span class="glyphicon glyphicon-download"></span>&nbsp;Получить</button>-->
<!--                    </form>-->
<!--                </div>-->
<!--            </div>-->
<!--           <div class="clear">&nbsp;</div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->