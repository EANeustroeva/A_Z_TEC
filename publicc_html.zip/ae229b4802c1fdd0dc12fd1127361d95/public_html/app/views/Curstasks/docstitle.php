<div class="panel panel-default">
    <div class="panel-heading">Загрузить работу</div>
    <div class="panel-body">
        <div class="col-xs-12">
            <h4> </h4>
            <form action="<?= BASE_URL ?>curstasks/work?disc=<?= $_POST['disc'] ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="type" value="кп">
                <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
                <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
                <input type="hidden" name="user_id" value="<?= $cur_user->id ?>">
                <div class="form-group">
                    <label>Тема курсовой</label>
                    <input type="text" class="form-control" name="title" value="<?= @$curs['title'] ?>" placeholder="Тема курсовой">
                </div>
                <div class="form-group">
                    <input type = "file" name = "userfile" required/>
                    <span class="help-block">Прикрепить файл курсовой</span>
                    <div class="file-uploader"></div>
                </div>
                <div class="form-group">
                    <input type="hidden" name="id" value="0">
                    <input type="hidden" name="prep_id" value="<?= @$_POST['prep_id'] ?>">
                    <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-eye-open"></span> Загрузить работу</button>
                </div>
            </form>
        </div>
    </div>
</div>