<?php
//foreach ($polls as $poll):
    $votes = 0;
    foreach (json_decode($poll->polls) as $key => $value) $votes += $value->votes;

    $cookie_key = 'sp_poll_voted_' . $poll->id;
    $vote = !empty($_COOKIE[$cookie_key]) ? $_COOKIE[$cookie_key] : null;
    if($votes > 0 && !is_null($vote)) $vote = base64_decode($vote);
//    if (isset($_GET['test'])) dump($poll);
//dump($poll->id);
//dump($vote);
?>
<div class="mod-sppoll">
	<?php if(isset($poll) && ($poll->published || isset($_GET['test']))): ?>
<div class="panel panel-default">
    <div class="panel-heading">
		<h4><?php echo $poll->title; ?></h4>
    </div>
    <div class="panel-body">
        <?php if (!empty($poll->text)): ?>
            <div style="font-size: 1.6em; color: #f60; text-shadow: white 2px 1px 1px; margin-bottom: -10px;"><?= html_entity_decode($poll->text) ?></div>
        <?php endif; ?>
        <div class="clearfix"></div>
        <hr>
		<?php $polls = json_decode($poll->polls); ?>
		<form method="post" action="/ask<?= !empty($alias)?'/'.$alias:'' ?><?= isset($_GET['test'])?'?test':'' ?>" class="form-sppoll" data-id="<?php echo $poll->id; ?>">
			<?php foreach ($polls as $key=>$value):?>
            <?php if(empty($value->poll)) continue; ?>
                <?php
                    $type = $poll['type'] == 2 ? 'checkbox' : 'radio';
                ?>
			<div class="<?= $type ?>">
				<label style="font-size: 1.2em; width: 100%">
					<input type="<?= $type ?>" name="<?= $poll['type'] == 2 ?'vote[]':'vote' ?>" value="<?php echo $key; ?>" <?php echo !is_null($vote) && ($value->poll == $vote) ? 'checked': ($key==0 ? 'checked': ''); ?>> <!--random-->
					<?php
                        if (strpos($value->poll,'_')!== false) {
                            echo '<input type="text" class="form-control" id="behalfid" name="value">';
                            echo "<script>$('#behalfid').click(function(){ $(this).prev().trigger('click'); });</script>";
                        }
                        $value->poll = preg_replace("/(\(.*\))/",'<small><i>$1</i></small>', $value->poll);
                        echo str_replace('_','', $value->poll);
                    ?>
				</label>
			</div>
			<?php endforeach; ?>
            <input type="hidden" name="id" value="<?= $poll->id ?>">
			<input type="submit" class="btn btn-default" value="<?= is_null($vote)?'Голосовать':'Далее' ?>">
			<?php /*if (!is_null($vote)): */?><!--
			    <input type="button" class="btn btn-success btn-poll-result" data-result_id="<?php /*echo $poll->id; */?>" value="Результат">
			--><?php /*endif; */?>
		</form>
		<div class="sppoll-results"></div>
    </div>
</div>
	<?php else: ?>
		<h4 class="alert alert-warning">Опрос завершен! <a class="btn btn-success" style="margin-left: 30px;" href="/ask<?= !empty($alias)?'/'.$alias:'' ?>/results">Посмотреть результаты</a></h4>
	<?php endif; ?>
</div>
<!--    <hr>-->
<?php //endforeach; ?>

<script src="/js/sweetalert2.all.min.js"></script>
<script src="/js/moment.js"></script>
 <?php if(false && isset($poll) && $poll->type == 1): ?>
     <script>
         Swal({
            title: '<strong>Обратите внимание!</strong>',
            type: 'info',
            html:
            '<b>Приёмная компания:</b> <br>г. Екатеринбург Ул. 8 марта 62<br>с 20 июня 2019 года<br>Аудитория 155<br>+7 (343) 221-17-91<br>' +
            '<a target="_blank" href="mailto:ino@usue.ru">ino@usue.ru</a> ',
            showCloseButton: true,
            // showCancelButton: true,
            // focusConfirm: false,
            confirmButtonText:
            '<i class="fa fa-thumbs-up"></i> Ok',
            confirmButtonAriaLabel: 'Thumbs up, great!',
            cancelButtonText:
            '<i class="fa fa-thumbs-down"></i>',
            cancelButtonAriaLabel: 'Thumbs down',
        })
     </script>
    <?php endif; ?>
<script>
jQuery(function($) {
	$('.form-sppoll_000').on('submit', function(event) {
		event.preventDefault();
		var self = $(this);

		var values = { id: self.data('id'), vote: self.find('input[type="radio"]:checked').val() };
		$.ajax({
			type: 'POST',
			url: "/ask/ajax",
			data: values,
			beforeSend: function () {
			},
			success: function (response) {
				self.hide();
				self.parent().find('.sppoll-results').html(response);
			}
		});
	});

	$('.btn-poll-result').on('click', function(event) {
		event.preventDefault();
		var parent = $(this).parent();

		var values = {
			id: $(this).data('result_id'),
			subtask: 'result'
		};
		$.ajax({
			type: 'POST',
			url: "/ask/ajax",
			data: values,
			format: 'json',
			success: function (response) {
				parent.hide();
				parent.parent().find('.sppoll-results').html(response);
			}
		});

	});
});
</script>
<style>
body > .container {
    padding: 50px;
    background-color: white;
    box-shadow: 0 0 20px #ccc;
    min-height: 650px;
}
.sp-poll-result {
	padding-top: 10px;
}

.sp-poll-result .poll-info {
	margin-bottom: 5px;
}

.sp-poll-result .poll-info > span {
	display: inline-block;
}

.sp-poll-result .poll-info > span:last-child {
	float: right;
	font-size: 13px;
	color: #888;
}

.sp-poll-result .progress {
	box-shadow: none;
	-webkit-box-shadow: none;
	background-color: #e5e5e5;
}

.sp-poll-result .progress-bar {
	box-shadow: none;
	-webkit-box-shadow: none;
}

.sp-poll-result .progress-bar.progress-bar-default {
	background-color: #999;
}

</style>


