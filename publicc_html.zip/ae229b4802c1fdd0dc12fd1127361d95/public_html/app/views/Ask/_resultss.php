<!-- <script src="https://www.google.com/jsapi"></script> -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script>
    // google.load("visualization", "1", {packages:["corechart"]});
    google.charts.load('current', {'packages':['corechart']});
</script>
<?php
$poll = $polls;
    $total_votes = 0;
    $options = json_decode($poll->polls);
    $v = [];
    foreach ($options as $key => $option) {
        $v[$key] = $option->votes;
        $total_votes = $total_votes + $option->votes;
    }
arsort($v);
$v = array_slice(array_flip($v),0,3);

    $data = '';
    $place = 0;
    foreach ($options as $key => $value) {
        if (!in_array($key,$v)) continue;
        $place++;
        if($total_votes) { $percentage = round($value->votes/$total_votes, 2)*100;
        } else { $percentage = 0; }

        $progress = '#ccc';
        if($percentage>60) { $progress = '#d9534f'; }
        elseif($percentage>50) { $progress = '#f0ad4e'; }
        elseif($percentage>40) { $progress = '#5cb85c'; }
        elseif($percentage>30) { $progress = '#5bc0de'; }
        elseif($percentage>20) { $progress = '#337ab7'; }

        $data .= '["' . $value->poll . '", ' . $value->votes . ', "' . $progress . '"],';

        $total_vote[] = $value->votes;
    }
//    echo $output;
    ?>
    <script>
    google.setOnLoadCallback(drawChart<?= $poll->id ?>);

    function drawChart<?= $poll->id ?>() {
        var data = google.visualization.arrayToDataTable([
            ["Element", "Голосов", {role: "style"}],
            <?= $data ?>
        ]);
        var view = new google.visualization.DataView(data);
        view.setColumns([0, 1,
            {
                calc: "stringify",
                sourceColumn: 1,
                type: "string",
                role: "annotation"
            }, 2]);

        var options = {
            title: "<?= $poll->title ?>",
            width: 600,
            height: 400,
            bar: {groupWidth: "95%"},
            legend: {position: "none"},
        };
        var chart = new google.visualization.ColumnChart(document.getElementById("air<?= $poll->id ?>"));
        chart.draw(view, options);
        var a = $('svg > g > g:last > g > g > text[text-anchor="middle"]');
        a.each(function (index) {
            $(this).text(123);
        });
    }
</script>
<div id="air<?= $poll->id ?>"></div>
<!--<text text-anchor="middle" x="177" y="91.05" font-family="Arial" font-size="13" stroke="none" stroke-width="0" fill="#ffffff">5</text>-->

<script>
jQuery(function($) {
	$('.form-sppoll').on('submit', function(event) {
		event.preventDefault();
		var self = $(this);

		var values = { id: self.data('id'), vote: self.find('input[type="radio"]:checked').val() };
		$.ajax({
			type: 'POST',
			url: "/qwerty/ajax",
			data: values,
			beforeSend: function () {
			},
			success: function (response) {
				self.hide();
				self.parent().find('.sppoll-results').html(response);
			}
		});
	});

	$('.btn-poll-result').on('click', function(event) {
		event.preventDefault();
		var parent = $(this).parent();

		var values = {
			id: $(this).data('result_id'),
			subtask: 'result'
		};
		$.ajax({
			type: 'POST',
			url: "/qwerty/ajax",
			data: values,
			format: 'json',
			success: function (response) {
				parent.hide();
				parent.parent().find('.sppoll-results').html(response);
			}
		});

	});
});
</script>
<style>
body > .container {
    padding: 50px;
    background-color: white;
    box-shadow: 0 0 20px #ccc;
    min-height: 650px;
}
.sp-poll-result {
	padding-top: 10px;
}

.sp-poll-result .poll-info {
	margin-bottom: 5px;
}

.sp-poll-result .poll-info > span {
	display: inline-block;
}

.sp-poll-result .poll-info > span:last-child {
	float: right;
	font-size: 13px;
	color: #888;
}

.sp-poll-result .progress {
	box-shadow: none;
	-webkit-box-shadow: none;
	background-color: #e5e5e5;
}

.sp-poll-result .progress-bar {
	box-shadow: none;
	-webkit-box-shadow: none;
}

.sp-poll-result .progress-bar.progress-bar-default {
	background-color: #999;
}
</style>


