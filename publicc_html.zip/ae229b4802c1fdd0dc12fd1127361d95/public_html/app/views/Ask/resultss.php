<?php
//if (!isset($_GET['qwe'])) die;
$poll = $polls;
    $total_votes = 0;
    $options = json_decode($poll->polls,1);
    $vv = [];
    foreach ($options as $key => $option) {
//        $v[$key] = $option->votes;
        $total_votes = $total_votes + $option['votes'];
    }
//arsort($v);
//$v = array_slice(array_flip($v),0,3);
//dd($v);
//$vv = array_flip($v);
    uasort($options, function($a, $b) { return $b['votes'] <=> $a['votes']; });
    $options = array_values(array_slice($options,0,3));
    $data = '';
    $place = 0;
    foreach ($options as $key => $value) {
//        if (!in_array($key,$v)) continue;
        $place++;
        if($total_votes) { $percentage = round($value['votes']/$total_votes, 2)*100;
        } else { $percentage = 0; }

        $progress = '#ccc';
        if($percentage>60) { $progress = '#d9534f'; }
        elseif($percentage>50) { $progress = '#f0ad4e'; }
        elseif($percentage>40) { $progress = '#5cb85c'; }
        elseif($percentage>30) { $progress = '#5bc0de'; }
        elseif($percentage>20) { $progress = '#337ab7'; }

        $vv[$key] = [
            'perc' => $percentage,
            'name' => $value['poll'],
            'votes' => $value['votes']
        ];

        $data .= '["' . $value['poll'] . '", ' . $value['votes'] . ', "' . $progress . '"],';

        $total_vote[] = $value['votes'];
    }
//    uksort($vv, function($a, $b) { return $a['votes'] <=> $b['votes']; });
//$vv = array_values($vv);

foreach ($vv as $k=>$item) {
    if ($k==0) continue;
    if ($item['perc'] == 0) {
        $vv[$k]['name'] = 'Нет участника';
        $vv[$k]['perc'] = 35;
    } elseif ($vv[0]['perc'] > 0) {
        $vv[$k]['perc'] = 80*$item['perc']/$vv[0]['perc'] - 5;
    } //{unset($vv[$k]); continue;}
}
if ($vv[0]['perc'] > 0) $vv[0]['perc'] = 90;
if ($vv[0]['perc'] == 0) {
    $vv[0]['name'] = 'Нет участника';
    $vv[0]['perc'] = 35;
}

$vv[0]['perc'] = 90;
$vv[1]['perc'] = 70;
$vv[2]['perc'] = 50;
if (isset($_GET['qwe'])) dd($vv);
?>

<div class="layout">
    <span class="btn btn-success btn-lg">ПОСМОТРЕТЬ РЕЗУЛЬТАТЫ</span>
</div>
<div class="row">
<div class="pedestal">
    <div id="two"   class="item second"><b><?= $vv[1]['name']; ?></b><span class="num">2</span> <span class="votes"><?= $vv[1]['votes']>0?'голосов: '.$vv[1]['votes']:'' ?></span></div>
    <div id="one"   class="item first" ><b><?= $vv[0]['name']; ?></b><span class="num">1</span> <span class="votes"><?= $vv[0]['votes']>0?'голосов: '.$vv[0]['votes']:'' ?></span></div>
    <div id="three" class="item third" ><b><?= $vv[2]['name']; ?></b><span class="num">3</span> <span class="votes"><?= $vv[2]['votes']>0?'голосов: '.$vv[2]['votes']:'' ?></span></div>
    <div class="footer"></div>
    <?php if (!empty($vv) && count($vv)>2): ?>
    <span id="know" class="btn btn-success btn-lg" style="right: 0;">УЗНАТЬ ПОБЕДИТЕЛЕЙ</span>
    <?php else: ?>
    <div class="btn btn-warning btn-lg" style="right: 0;">ПОБЕДИТЕЛЕЙ НЕ НАБРАЛОСЬ</div>
    <?php endif; ?>
</div>
</div>
<script>
    $('.layout span').click(function () {
        $(this).parent().remove();
        $('.pedestal').show()
    })


    $('.pedestal span').click(function () {
        // $('#one,#two,#three').show();
        if ($('#three').is(':hidden')) $('#three').animate({ height: "toggle" }, 1000, function() {$('#three').css('height',"<?= $vv[2]['perc'] ?>%");});
        else if ($('#two').is(':hidden')) $('#two').animate({ height: "toggle" }, 1000, function() {$('#two').css('height',"<?= $vv[1]['perc'] ?>%");});
        else {
            $('#know').hide();
            $('#one').animate({ height: "toggle" }, 1000, function() {$('#one').css('height',"<?= $vv[0]['perc'] ?>%");});
        }
        //$('#two').animate({ height: "toggle" }, 1000, function() {$('#two').css('height',"<?//= $vv[1]['perc'] ?>//%");});
        <!--$('#three').animate({ height: "toggle" }, 1000, function() {$('#three').css('height',"<?= $vv[2]['perc'] ?>%");});-->

        // $('#two').animate({ height: 'toggle' }, 2000, function() {$('#two').css('height','80%');});
        // $('#three').animate({ height: 'toggle' }, 3000, function() {$('#three').css('height','80%');});

         //window.requestAnimationFrame(function(){ document.getElementById("one").setAttribute("style", "display:block; height: <?//= $vv[0]['perc'] ?>//%"); });
         //window.requestAnimationFrame(function(){ document.getElementById("two").setAttribute("style", "display:block; height: <?//= $vv[1]['perc'] ?>//%"); });
         //window.requestAnimationFrame(function(){ document.getElementById("three").setAttribute("style", "display:block; height: <?//= $vv[2]['perc'] ?>//%"); });
    });

    $('#three').on('show',function () {
        window.requestAnimationFrame(function(){ $(this).css('height',<?= $vv[2]['perc'] ?>+'%'); });
    });


    function setHeiHeight(el) {
        $('.pedestal').css({
            height: ($(window).height() - 150) + 'px'
        });
    }
    setHeiHeight();
    $(window).resize(setHeiHeight);
</script>

<style>
    .layout {
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        /*height: 700px;*/
        width: 100%;
        text-align: center;
    }
    .layout span {
        display: inline-block;
        /*position: absolute;*/
        /*left: 38%;*/
        top: 30%;
        width: 300px;
    }
    .pedestal {
        display: none;
        width: 100%;
        /*height: 750px;*/
        position: relative;
        /*padding: 15px;*/
        /*margin-top: 100px;*/
        overflow: hidden;
        padding-top:20px;
        text-align: center;
    }
    .footer {
        height: 3em;
        position: absolute;
        width: 110%;
        bottom: -2em;
        left: 0;
        right: 0;
        background: #337ab7;
        box-shadow: 1px 2px 1px black;
    }
    .pedestal #know {
        display: inline-block;
        /*position: absolute;*/
        top: 1em;
        width: 300px;
    }
    .item {
        height: 0;
        display: none;
        float: left;
        width: 33%;
        background-color: #0A246A;
        position: absolute;
        bottom: 0;
        text-align: center;
        font-size: 2em;
        color: white;
        box-shadow: 1px 2px 1em grey;
        -webkit-transition: height ease-in-out 3s;
        -moz-transition: height ease-in-out 3s;
        -o-transition: height ease-in-out 3s;
        transition: height ease-in-out 3s;
        text-align:center;
    }
    .item b {
        padding: 0 5px;
        font-size: 1.2em;
        position: absolute;
        top: .2em;
        left: 0;
        color: white;
        width: 100%;
        text-shadow: 1px 1px 0 black;
    }
    .item .num {
        font-size: 2.8em;

        font-weight: bolder;
        position: absolute;
        bottom: 1em;

        width: 100%;
        left: 0;
    }
    .item .votes {
        font-size: 1em;
        font-weight: bold;
        position: absolute;
        bottom: .4em;
        right: 1em;
    }
    .first  { left:34%; height: 10px; background-color: #d9534f }
    .second { left:0;   height: 10px; background-color: #5cb85c }
    .third  { left:68%; height: 10px; background-color: #5bc0de }

    @media only screen and (max-width : 480px) {
        .item b {
            font-size: .7em;
            /*top: -2.7em;*/
            /*line-height: 1;*/
        }
        .item .num {
            font-size: 1.5em;
            bottom: 1em;
        }
        .item .votes {
            font-size: .5em;
            bottom: 1em;
        }
    }
</style>