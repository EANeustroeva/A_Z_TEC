<div class="col-sm-12" style="overflow-x: auto">
    <div class="row">
        <div class="top-bar-days">
            <div class="col-sm-4"><h4 style="padding-left: 40px">Май 01 - 08. 2017</h4></div>
            <div class="col-sm-8">
                <ul class="nav nav-pills pull-right">
                    <li role="presentation"><a href="#">День</a></li>
                    <li role="presentation" class="active"><a href="#">Неделя</a></li>
                    <li role="presentation"><a href="#">Месяц</a></li>
                    <li role="presentation"><a href="#">Сессия</a></li>
                </ul>
            </div>
        </div>
        <table class="table table-striped table-hover table-bordered table-responsive table-condensed table-days">
        <thead>
        <tr>
            <th>Пара</th>
            <th>Пн 01</th>
            <th>Вт 02</th>
            <th>Ср 03</th>
            <th>Чт 04</th>
            <th>Пт 05</th>
            <th>Сб 06</th>
            <th>Вс 07</th>
        </tr>
        </thead>
        <tbody>
        <?php for ($i = 1; $i <= 8; $i++): ?>
            <tr>
                <td><?= $i ?></td>
                <td><?= isset($rasp[$i]['понедельник']) ? @$rasp[$i]['понедельник'] : '' ?></td>
                <td><?= isset($rasp[$i]['вторник']) ? $rasp[$i]['вторник'] : '' ?></td>
                <td><?= isset($rasp[$i]['среда']) ? $rasp[$i]['среда'] : '' ?></td>
                <td><?= isset($rasp[$i]['четверг']) ? $rasp[$i]['четверг'] : '' ?></td>
                <td><?= isset($rasp[$i]['пятница']) ? $rasp[$i]['пятница'] : '' ?></td>
                <td><?= isset($rasp[$i]['суббота']) ? $rasp[$i]['суббота'] : '' ?></td>
                <td><?= isset($rasp[$i]['воскресенье']) ? $rasp[$i]['воскресенье'] : '' ?></td>
            </tr>
        <?php endfor; ?>
        </tbody>
    </table>
    </div>
</div>