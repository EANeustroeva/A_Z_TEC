<link rel='stylesheet' href='<?= BASE_URL ?>js/fullcalendar/fullcalendar.min.css'/>
<script src='<?= BASE_URL ?>js/fullcalendar/moment.min.js'></script>
<script src='<?= BASE_URL ?>js/fullcalendar/fullcalendar.min.js'></script>
<script src='<?= BASE_URL ?>js/fullcalendar/ru.js'></script>
<script src="<?= BASE_URL ?>js/fullcalendar/customcal.js?r=<?= rand(0, 100) ?>"></script>

<?php //if(!($rasp)): ?>
<!--<h2 class="header">Расписание для вашей группы отсутствует</h2>-->
<?php //else: ?>
<?php //endif ?>
<div class="row">
    <div class="col-xs-12">
        <span class="label label-success">1 подгруппа</span>
        <span class="label label-danger">2 подгруппа</span>
        <span class="label label-warning">3 подгруппа</span>
        <span class="label label-primary">все подгруппы</span>
    </div>
</div>
<hr>
<div id='calendar'></div>
<!-- Modal -->
<div class="modal fade" id="modalevent" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Добавить в расписание</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Дисциплина</label>
                    <select class="form-control" id="disc">
                    </select>
                </div>
                <div class="form-group row">
                    <div class="col-sm-6">
                        <label>Лектор</label>
                        <select class="form-control" id="lekt"></select>
                    </div>
                    <div class="col-sm-3">
                        <label>Тип</label>
                        <select class="form-control" id="type">
                                <option>Лек</option>
                                <option>Практ</option>
                                <option>Лаб</option>
                                <option>зач</option>
                                <option>экз</option>
                                <option>диф.зач</option>
                            </select>
                    </div>
                    <div class="col-sm-3">
                        <label>Аудитория</label>
                        <select class="form-control" id="aud"></select>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Отмена</button>
                <button type="button" class="btn btn-primary" id="save_event">Сохранить</button>
            </div>
        </div>
    </div>
</div>

<style>
    .fc-time-grid .fc-slats td {
        height: 6.0em;
    }
    .fc .fc-axis {
        padding: 0 22px 0 2px;
    }
    .fc-event {
        font-size: .74em;
    }
</style>


<script>
    $('#save_event').click(function () {
        var start = $('#save_event').data('start'),
            end = $('#save_event').data('end');
        var title = $('#disc').val() +
        ' (' + $('#type').val() + ') ' +
        $('#lekt').val() + ', ' + $('#aud').val();
        var eventData;
        if (title) {
            eventData = {
                title: title,
                start: start,
                end: end
            };
            $('#calendar').fullCalendar('renderEvent', eventData, true); // stick? = true
        }
        $('#calendar').fullCalendar('unselect');
        $('#modalevent').modal('hide');
    });
    $(document).ready(function () {


        //.append('<p>123</p>')

        $('#course').on('changed.bs.select', function (e) {
            $('#class').prop('disabled', false);
            $.ajax({
                url: base+'profile/getListFilter',
                type: 'post',
                data: {'course': $(this).val()},
                success: function (res) {
                    $('#class')
                        .html(res)
                        .selectpicker('refresh');
//                get_user_list('4');
                },
                error: function () {
                    console.log('Error!');
                }
            });
        });
        $('#class').on('changed.bs.select', function (e) {
            $('#calendar').fullCalendar('refetchEvents');
            $.ajax({
                url: 'events/getlistmodal',
                type: 'post',
                data: {class: $('#class').val()},
                success: function (res) {
                    var data = JSON.parse(res);
                    $('select#disc').html(data.disc);
                    $('select#lekt').html(data.lekt);
                    $('select#aud').html(data.aud);
                },
                error: function () {
                    console.log('Error!');
                }
            });
        });
        $('#podgr').on('changed.bs.select', function (e) {
            $('#calendar').fullCalendar('refetchEvents');
        });
    });
</script>



