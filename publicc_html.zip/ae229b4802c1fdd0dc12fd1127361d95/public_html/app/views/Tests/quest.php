<form action="<?= BASE_URL ?>tests/saveQuest" method="post" enctype="multipart/form-data">
<div class="panel panel-default">
    <div class="panel-heading clearfix">
        <div class="pull-left">
            <a href="<?= BASE_URL ?>tests/edit?id=<?= $id ?>" class="btn btn-default"><i class="glyphicon glyphicon-chevron-left"
                                                                      aria-hidden="true"></i> Назад</a>
        </div>
        <div style="line-height: 34px;padding-left: 95px;"><?= empty($_GET['id'])?'Создание':'Редактирование' ?> вопроса</div>
    </div>
    <div class="panel-body">
        <h4></h4>
        <div class="col-sm-12">
            <div class="form-group">
                <textarea class="form-control" id="editor1" name="title" required placeholder="Вопрос"><?= @$quest['title'] ?></textarea>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="type">Тип вопроса</label>
                         <select id="type" name="type" class="selectpicker form-control" title="Тип вопроса">
                            <?php echo $type; ?>
                        </select>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label for="img">Число вариантов</label>
                        <select id="ct" name="ct" class="selectpicker form-control" title="Число вариантов">
                            <?php for ($i=2;$i<6;$i++): ?>
                            <option<?= @$quest['ct']==$i ? ' selected':'' ?>><?= $i ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
<!--                <div class="col-sm-6">-->
<!--                    <div class="form-group">-->
<!--                        <label for="diff">Сложность</label>-->
<!--                         <select name="diff" class="selectpicker form-control" title="Сложность">-->
<!--                            --><?php //echo $diff; ?>
<!--                        </select>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="col-sm-6">-->
<!--                    <div class="form-group">-->
<!--                        <label for="img">Картинка</label>-->
<!--                        <input type="file" name="img">-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="col-sm-6">-->
<!--                    <div class="form-group">-->
<!--                        --><?php //if ($quest['img']): ?>
<!--                        <img src="--><?//= BASE_URL . 'img/tests/' . $quest['img']?><!--" alt="" class="img-thumbnail">-->
<!--                        --><?php //endif; ?>
<!--                    </div>-->
<!--                </div>-->

            </div>

             <label for="">Варианты ответов</label>
            <div id="addform">
            <?php echo $type_form; ?>
            </div>
         </div>
    </div>
    <div class="panel-footer">
        <input type="hidden" name="diff" value="0">
        <input type="hidden" name="id" value="<?= $quest['id'] ?>">
        <input type="hidden" name="t" value="<?= $_GET['t'] ?>">
        <button type="submit" class="btn btn-default">Сохранить</button>
    </div>
</div>
</form>

<script src="/js/ckeditor/ckeditor.js"></script>
<script src="/js/elfinder/js/elfinder.min.js"></script>
<script src="/js/elfinder/js/i18n/elfinder.ru.js"></script>
<script src="/js/jquery-ui/jquery-ui.min.js"></script>
<link rel="stylesheet" href="/js/jquery-ui/jquery-ui.min.css">
<link rel="stylesheet" href="/js/elfinder/css/elfinder.min.css ">
<script src="/js/ckeditor/load.js"></script>
<script>
    CKEDITOR.replace( 'editor1', {

    });
</script>
<script>
    $('#type').on('changed.bs.select', function (e) {
        refresh_form();
    });
    $('#ct').on('changed.bs.select', function (e) {
        refresh_form();
    });
    function refresh_form() {
        $('#addform').html('<div class="text-center"><img src="'+base+'images/loader.gif" ></div><hr>');
        $.ajax({
            url: 'quest?t=<?= $_GET['t'] ?>&id=<?= $quest['id'] ?>',
            type: 'post',
            data: {ct: $('#ct').val(),type: $('#type').val()},
            success: function (res) {
                $('#addform').html(res);
                $('.selectpicker').selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }
</script>
