
<ul class="nav nav-tabs nav-justified">
    <li class="active"><a data-toggle="tab" href="#menu3">По компетенции</a></li>
    <li><a data-toggle="tab" href="#menu4">ЭОК</a></li>
    <li><a data-toggle="tab" href="#menu2">По дисциплине</a></li>
    <li><a data-toggle="tab" href="#menu1">Перезачет</a></li>

    <li><a data-toggle="tab" href="#menu0" style="background-color: #d9534f; color: white; font-weight: 600;">НЕ РАСПРЕДЕЛЕНО</a></li>
    <li class="form-group">
        <form action="<?= BASE_URL ?>tests/edit" method="post">
        <button class="btn btn-success" style="width: 100%;"><i class="glyphicon glyphicon-plus-sign"></i> Новый тест</button>
        </form>
    </li>
</ul>
<div class="tab-content">
    <?php foreach ($tests as $type=>$g): ?>
    <div id="menu<?= $type ?>" class="tab-pane fade <?= ($type == 3)?'in active':'' ?>">
        <?php switch ($type) {
            case 0: $title = ''; break;
            case 1: $title = 'Общие'; break;
            case 2: $title = 'Тесты по дисциплине'; break;
            case 3: $title = 'Тесты по компетенции'; break;
            case 4: $title = 'ЭОК'; break;
        } ?>
        <h3><?= $title ?></h3>
        <?php if (!count($g)): echo "<h4>Тесты отсутствуют</h4>"; else:?>
            <table class="table table-striped table-hover table-bordered table-responsive">
                <thead>
                <tr>
                    <th>Название</th>
                    <?php if ($cur_user->access == 1 && $type==2) echo "<th>Преподаватель</th>";?>
                    <?php if ($type==3) echo '<th>Компетенции</th>'; elseif ($type==2) echo '<th>Дисциплина</th>'; ?>
                    <th style="width: 1px;">Длина&nbsp;теста</th>
                    <th style="width: 1px;">Всего</th>
                    <th style="width: 1px;">Время,&nbsp;м</th>
                    <?php if ($cur_user->access==1): ?>
                        <th style="width: 1px;">Виден</th>
                    <?php endif; ?>
                    <th style="width: 110px;">Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($g as $k=>$item):?>
                    <tr>
                        <td class="text-left"><a href="<?= BASE_URL ?>tests/edit?id=<?=$item['id']?>"><i class="glyphicon glyphicon-log-in"></i> <?= $item['title'] ?></a></td>
                        <?php if ($cur_user->access == 1 && $type==2) echo '<td>'.$item['prepod'].'</td>';?>
                        <?php if ($type==3 || $type==2) echo '<td>'.$item['disc'].'</td>'; ?>
                        <td><?= $item['qcount'] ?></td>
                        <td><?= $item['count'] ?></td>
                        <td><?= $item['timer'] ?></td>
                        <?php if ($cur_user->access==1): ?>
                        <td>
                            <?=$item['visible']? '<span class="btn btn-xs btn-success check" data-id="'.$item['id'].'">Да</span>' :
                                '<span class="btn btn-xs btn-danger check" data-id="'.$item['id'].'">Нет</span>'?>
                        </td>
                        <?php endif; ?>
                        <td class="text-center">
                            <?php if ($item['count']-$item['qcount'] >= 0): ?>
                                <form action="<?= BASE_URL ?>tests/test" method="post" style="width: 100%;">
                                    <button class="btn btn-success btn-xs" style="width: 100%;">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-play-circle"></span>&nbsp;Пройти
                                    </button>
                                </form>
                            <div style="margin: 5px 0;"></div>
                            <?php endif; ?>
                            <?php if ($item['status']): ?>
                                <form action="<?= BASE_URL ?>tests/results" method="post" style="width: 100%;">
                                    <button class="btn btn-warning btn-xs" style="width: 100%;">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;Результаты</button>
                                </form>
                            <div style="margin: 5px 0;"></div>
                            <?php endif; ?>
                            <form action="<?= BASE_URL ?>tests/delete" method="post" style="width: 100%;">
                                <button class="btn btn-danger btn-xs" style="width: 100%;">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <span class="glyphicon glyphicon-remove"></span>&nbsp;Удалить
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>



<style>
    .nav-tabs>li>form > button {
        position: relative;
        display: block;
        padding: 10px 15px!important;
    }
</style>
<script>
    $('body').on('click', '.check', function () {
        let btn = $(this).parent();
        $.ajax({
            url: '/tests/togglevisible',
            type: 'get',
            data: {'id': $(this).data('id')},
            success: function (res) {
                btn.html(res);
            },
            error: function (er) {
                console.log(er);
            }
        });
    })
</script>
