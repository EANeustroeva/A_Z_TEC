<div class="form-group">
    <a class="btn btn-default" href="<?= BASE_URL ?>tests">Назад</a>
</div>
<form action="<?= BASE_URL ?>tests/prepare" method="post" class="pull-right">
    <input type="hidden" name="id" value="<?= $test['id'] ?>">
    <button class="btn btn-warning"><i class="fa fa-print"> В печать</i></button>
</form>
<h4>Результаты теста - <?= $test['title'] ?></h4>
<p>Всего вопросов - <?= $test['qcount'] ?></p>
<table class="table table-bordered table-stripped">
    <thead>
        <th>Студент</th>
        <th>Группа</th>
        <th>Правильных ответов</th>
        <th>Процент успешности</th>
        <th>Дата теста</th>
        <th>Действие</th>
    </thead>
    <tbody>
    <?php foreach ($res as $item): ?>
        <tr>
            <td class="text-left"><?= $item['user']->name ?></td>
            <td><?= $item['user']->class ?></td>
            <td><?= $item['pos'] ?></td>
            <td><?= $item['total'] ?>%</td>
            <td><?= date("H:i, d.m.Y",strtotime($item['created'])) ?></td>
            <td><form action="/tests/deleteres" method="post">
                <input type="hidden" name="id" value="<?= $test['id'] ?>">
                <input type="hidden" name="res_id" value="<?= $item['id'] ?>">
                <button class="btn btn-danger btn-xs" type="submit">удалить</button>
            </form></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
