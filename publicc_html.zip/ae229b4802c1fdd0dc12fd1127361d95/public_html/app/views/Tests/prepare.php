<div class="panel panel-default">
    <div class="panel-heading">Подготовка перед выводом</div>
    <div class="panel-body">
        <form action="<?= BASE_URL ?>tests/print" method="post">
            <div class="col-xs-12">
                <div class="form-group">
                    <label for="">Выберите компетенции:</label>
                    <select class="selectpicker form-control" name="comp[]" id="" multiple>
                        <?php foreach ($list as $k => $item): ?>
                            <option value="<?= $k ?>"><?= $k ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"></div>
                <input type="hidden" name="id" value="<?= $id ?>">
                <div class="form-group"><button class="btn btn-success">Генерировать</button></div>
            </div>
        </form>
    </div>
</div>