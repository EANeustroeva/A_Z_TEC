<div class="form-group">
    <a href="<?= BASE_URL ?>tests" class="btn btn-default">Вернуться</a>
</div>
<form action="<?= BASE_URL ?>tests/uploadsave" method="post" enctype="multipart/form-data">
<div class="panel panel-primary">
    <div class="panel-heading">
        <h4><?= $test['title'] ?> | Загрузить файл с вопросами</h4>
    </div>
    <div class="panel-body">
        <h4></h4>
        <div class="col-sm-12">
            <div class="form-group">
                <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
                <input type="file" name="xls">
            </div>
        </div>
    </div>
    <div class="panel-footer">
        <button class="btn btn-success">Загрузить</button>
    </div>
</div>
</form>