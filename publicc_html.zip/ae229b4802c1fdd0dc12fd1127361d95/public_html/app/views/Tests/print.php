<!--<style>
        <!--
        /* Font Definitions */
        @font-face {
            font-family: "Cambria Math";
            panose-1: 2 4 5 3 5 4 6 3 2 4;
        }

        /* Style Definitions */
        p.MsoNormal, li.MsoNormal, div.MsoNormal {
            margin: 0cm;
            margin-bottom: .0001pt;
            font-size: 13.0pt;
            font-family: "Times New Roman", "serif";
        }

        p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph {
            margin-top: 0cm;
            margin-right: 0cm;
            margin-bottom: 0cm;
            margin-left: 36.0pt;
            margin-bottom: .0001pt;
            font-size: 13.0pt;
            font-family: "Times New Roman", "serif";
        }

        p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst {
            margin-top: 0cm;
            margin-right: 0cm;
            margin-bottom: 0cm;
            margin-left: 36.0pt;
            margin-bottom: .0001pt;
            font-size: 13.0pt;
            font-family: "Times New Roman", "serif";
        }

        p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle {
            margin-top: 0cm;
            margin-right: 0cm;
            margin-bottom: 0cm;
            margin-left: 36.0pt;
            margin-bottom: .0001pt;
            font-size: 13.0pt;
            font-family: "Times New Roman", "serif";
        }

        p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast {
            margin-top: 0cm;
            margin-right: 0cm;
            margin-bottom: 0cm;
            margin-left: 36.0pt;
            margin-bottom: .0001pt;
            font-size: 13.0pt;
            font-family: "Times New Roman", "serif";
        }

        .MsoChpDefault {
            font-family: "Calibri", "sans-serif";
        }

        .MsoPapDefault {
            margin-bottom: 10.0pt;
            line-height: 115%;
        }

        @page WordSection1 {
            size: 841.9pt 595.3pt;
            margin: 3.0cm 2.0cm 42.5pt 2.0cm;
        }

        div.WordSection1 {
            page: WordSection1;
        }

        /* List Definitions */
        ol {
            margin-bottom: 0cm;
        }

        ul {
            margin-bottom: 0cm;
        }

        -->
    </style>-->
<div class=WordSection1>
    <p class=MsoNormal align=center style="text-align:center"><b>Протокол оценки </b></p>
    <p class=MsoNormal align=center style="text-align:center"><b>сформированности
            компетенций у студентов направления <span style="background:yellow">38.03.05«Бизнес-информатика»</span>
        </b></p>
    <p class=MsoNormal align=center style="text-align:center"><b><span
                    style="background:yellow">от 12 января 2017г</span></b></p>
    <p class=MsoNormal>Компетенции подлежащие оценке:</p>
    <p class=MsoNormal><b><i><u>Общекультурные компетенции:</u></i></b></p>
    <p class=MsoNormal><i>&nbsp;</i></p>
    <p class=MsoNormal><span style="background:yellow">ОК-1-способность
использовать основы философских знаний для формирования мировоззренческой
позиции</span></p>
    <p class=MsoNormal><span style="background:yellow">ОК-7-способность к
самоорганизации и самообразованию</span></p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal><b><i><u>Общепрофессиональные компетенции:</u></i></b></p>
    <p class=MsoNormal align=right style="text-align:right">&nbsp;</p>
    <p class=MsoNormal><span style="background:yellow">ОПК-1-способность решать
стандартные задачи профессиональной деятельности на основе информационной и
библиографической культуры с применением информационно-коммуникационных
технологий и с учетом основных требований информационной безопасности</span></p>
    <p class=MsoNormal><span style="color:#333333;background:yellow">ОПК-3 способен
работать с компьютером как средством управления информацией, работать с
информацией из различных источников, в том числе в глобальных компьютерных
сетях</span><span style="color:#333333"><br>
<br>
</span></p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal><b><i><u>Профессиональные компетенции:</u></i></b></p>
    <p class=MsoNormal><b><i><u><span style="text-decoration:none">&nbsp;</span></u></i></b></p>
    <p class=MsoNormal><span style="color:#333333;background:yellow">ПК-16 умение
разрабатывать контент и ИТ-сервисы предприятия и Интернет-ресурсов</span><span
                style="color:#333333;background:yellow">&nbsp;</span></p>
    <p class=MsoNormal><span style="background:yellow">ПК-17-способность 
использовать основные методы естественнонаучных дисциплин в профессиональной
деятельности  для теоретического и экспериментального исследования </span></p>
    <p class=MsoNormal><span style="background:yellow">ПК-18-способность использовать 
соответствующий  математический  аппарат и инструментальные средства для
обработки, анализа  и систематизации информации по теме исследования</span></p>
    <p class=MsoNormal><span style="background:yellow">ПК-19- умение готовить 
научно-технические отчеты ,презентации, научные публикации по результатам 
выполненных исследований</span></p>
    <p class=MsoNormal><span style="background:yellow">&nbsp;</span></p>
    <p class=MsoNormal><span style="background:yellow">&nbsp;</span></p>
    <p class=MsoNormal><span style="background:yellow">&nbsp;</span></p>
    <p class=MsoNormal><span style="background:yellow">&nbsp;</span></p>
    <p class=MsoNormal><span style="background:yellow"> </span></p>
    <p class=MsoNormal><span style="background:yellow">      В результате оценки
сформированности компетенций по фондам оценочных средств дисциплин основной
образовательной программы обучающиеся  направления 38.03.05 «Бизнес-информатика»
показали сформированность следующих компетенций:</span></p>
    <p class=MsoNormal>Гр. БИ-15-2</p>
    <p class=MsoNormal>&nbsp;</p>
    <table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
           style="border-collapse:collapse;border:none">
        <tr>
            <td valign=top style="border:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal><b><span style="color:black">№ п\п</span></b></p>
            </td>
            <td valign=top style="border:solid windowtext 1.0pt;border-left:none;
  padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal><b><span style="color:black">ФИО</span></b></p>
            </td>
            <td colspan=10 valign=top style="border:solid windowtext 1.0pt;border-left:
  none;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal align=center style="text-align:center"><b><span
                                style="color:black">Результат сформированности компетенций</span></b></p>
            </td>
        </tr>
        <tr>
            <td valign=top style="border:solid windowtext 1.0pt;border-top:none;
  padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal style="margin-left:18.0pt">&nbsp;</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal><span style="background:yellow">ОК-1</span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal><span style="background:yellow">ОК-7</span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal><span style="background:yellow">ПК-16</span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal><span style="background:yellow">ПК-17</span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal><span style="background:yellow">ПК-18</span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal><span style="background:yellow">ПК-19</span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal><span style="background:yellow">ОПК-1</span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal><span style="background:yellow">ОПК-1</span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
        </tr>
        <tr>
            <td valign=top style="border:solid windowtext 1.0pt;border-top:none;
  padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoListParagraph style="text-indent:-18.0pt">1.<span
                            style="font:7.0pt "Times New Roman"">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>&nbsp;</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal style="margin-top:3.25pt;text-autospace:none"><span
                            style="color:black;background:yellow">        Андреев Павел Геннадьевич</span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>85%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
        </tr>
        <tr>
            <td valign=top style="border:solid windowtext 1.0pt;border-top:none;
  padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoListParagraph style="text-indent:-18.0pt">2.<span
                            style="font:7.0pt "Times New Roman"">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>&nbsp;</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal style="margin-top:.35pt;text-autospace:none"><span
                            style="background:yellow">        <span style="color:black">Буглова Илона
  Сергеевна</span></span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>85%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>85%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
        </tr>
        <tr>
            <td valign=top style="border:solid windowtext 1.0pt;border-top:none;
  padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoListParagraph style="text-indent:-18.0pt">3.<span
                            style="font:7.0pt "Times New Roman"">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>&nbsp;</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal style="margin-top:.35pt;text-autospace:none"><span
                            style="background:yellow">        <span style="color:black">Кузнецов Роман
  Михайлович</span></span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>85%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
        </tr>
        <tr>
            <td valign=top style="border:solid windowtext 1.0pt;border-top:none;
  padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoListParagraph style="text-indent:-18.0pt">4.<span
                            style="font:7.0pt "Times New Roman"">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>&nbsp;</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal style="margin-top:.35pt;text-autospace:none"><span
                            style="background:yellow">        <span style="color:black">Кулимина Ксения
  Игоревна</span></span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>85%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
        </tr>
        <tr>
            <td valign=top style="border:solid windowtext 1.0pt;border-top:none;
  padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoListParagraph style="text-indent:-18.0pt">5.<span
                            style="font:7.0pt "Times New Roman"">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>&nbsp;</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal style="margin-top:.35pt;text-autospace:none"><span
                            style="background:yellow">        <span style="color:black">Марышев Никита
  Васильевич</span></span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
        </tr>
        <tr>
            <td valign=top style="border:solid windowtext 1.0pt;border-top:none;
  padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoListParagraph style="text-indent:-18.0pt">6.<span
                            style="font:7.0pt "Times New Roman"">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>&nbsp;</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal style="margin-top:.35pt;text-autospace:none"><span
                            style="background:yellow">        <span style="color:black">Меньшиков Олег
  Евгеньевич</span></span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>85%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
        </tr>
        <tr>
            <td valign=top style="border:solid windowtext 1.0pt;border-top:none;
  padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoListParagraph style="text-indent:-18.0pt">7.<span
                            style="font:7.0pt "Times New Roman"">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>&nbsp;</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal style="margin-top:.35pt;text-autospace:none"><span
                            style="background:yellow">        <span style="color:black">Осипов Николай
  Владимирович</span></span></p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>85%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>80%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt">
                <p class=MsoNormal>70%</p>
            </td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
            <td valign=top style="border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
  border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt"></td>
        </tr>
    </table>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>Компетенции считаются сформированными по уровням:</p>
    <p class=MsoNormal style="margin-left:241.0pt">50 – 70 % - Пороговый уровень;</p>
    <p class=MsoNormal style="margin-left:241.0pt">70 – 90 % - Базовый уровень;</p>
    <p class=MsoNormal style="margin-left:241.0pt">90 – 100% - Повышенный уровень;</p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>&nbsp;</p>
    <span style="font-size:13.0pt;line-height:115%;font-family:"Times New Roman","serif""><br
                clear=all style="page-break-before:always">
</span>
    <p class=MsoNormal style="margin-bottom:10.0pt;line-height:115%"><span
                style="line-height:115%">&nbsp;</span></p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal><b>Решение Аттестационной комиссии:</b></p>
    <p class=MsoNormal><b>&nbsp;</b></p>
    <p class=MsoNormal>   В соответствии с показателями сформированности
        общекультурных, профессиональных и  общепрофессиональных компетенций комиссия
        считает возможным аттестовать вышеперечисленным обучающимся следующие
        дисциплины учебного плана по направлению <span style="background:yellow">38.03.05
«Бизнес-информатика»</span></p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>1. Объектно-ориентированный анализ и программирование,<span
                style="background:yellow">5 зач. ед.экз--ОПК-1,ОПК-3,ПК-16.</span></p>
    <p class=MsoNormal>2. Общая теория систем,<span style="background:yellow">3
зач.ед,диф. зач – ОК-1,ПК-17,ПК-18,ПК-19,</span></p>
    <p class=MsoNormal> 3. Дискретная математика,<span style="background:yellow">4
зач. ед,экз – ОК-7,ПК-18</span></p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>Оценка по предмету формируется на основании уровня
        сформированности компетенций :</p>
    <p class=MsoNormal style="margin-left:1.0cm">пороговый уровень – соответствует
        оценке 3 «удовлетворительно»;</p>
    <p class=MsoNormal style="margin-left:1.0cm">базовый уровень соответствует
        оценке 4 «хорошо»;</p>
    <p class=MsoNormal style="margin-left:1.0cm">повышенный уровень соответствует
        оценке 5 «отлично»;</p>
    <p class=MsoNormal style="margin-left:1.0cm">оценка зачтено соответствует –
        уровню сформированности компетенций  на пороговом уровне и выше.</p>
    <p class=MsoNormal><b>Члены комиссии: </b></p>
    <p class=MsoNormal><b>&nbsp;</b></p>
    <p class=MsoNormal>Директор Института непрерывного образования
        :                                               Е.Н.Ялунина</p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>Зам директора института непрерывного
        образования:                                        П.А.Новожилов</p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>Руководитель направления от кафедры</p>
    <p class=MsoNormal><span style="background:yellow">«Бизнес-информатики»               
                                                                                  Бегичева
С.В.</span></p>
    <p class=MsoNormal>&nbsp;</p>
    <p class=MsoNormal>&nbsp;</p>

</div>H
