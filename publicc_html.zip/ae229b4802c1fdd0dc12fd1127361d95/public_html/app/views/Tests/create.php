<form action="<?= BASE_URL ?>tests/create" method="post">
    <div class="col-sm-8">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <a href="<?= BASE_URL ?>tests" class="btn btn-default"><i class="glyphicon glyphicon-chevron-left" aria-hidden="true"></i> Назад</a>
                </div>
                <div style="line-height: 34px;padding-left: 95px;">Создание теста</div>
            </div>
            <div class="panel-body">
                <div class="col-sm-12">
                    <h4></h4>
                    <div class="form-group">
                        <input type="text" class="form-control" name="title" required placeholder="Название теста" value="<?= @$tasks['title'] ?>">
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                               <!-- <select id="predmet" name="predmet" class="selectpicker form-control" data-size="10" title="Предмет" data-live-search="true">
                                    <?php /*foreach ($predmet as $k=>$item): */?>
                                        <option<?/*= ($item['id']==$tasks['predmet']) ? ' selected' : '' */?> value="<?/*= $item['id'] */?>"><?/*= $k */?></option>
                                    <?php /*endforeach; */?>
                                </select>-->
                                <input type="text" class="form-control" name="title" required placeholder="Предмет"
                                       value="<?= @$tasks['disc'] ?>">
                            </div>
                        </div>
                    </div>
                   <!--  <div class="row">
                       <div class="col-sm-8">
                           <label for="">Варианты ответов</label>
                           <div class="form-group">
                               <input class="form-control" name="var1" required placeholder="Вариант 1"
                                      value="<?= @$tasks['var1'] ?>">
                           </div>
                           <div class="form-group">
                               <input class="form-control" name="var2" placeholder="Вариант 2"
                                      value="<?= @$tasks['var2'] ?>">
                           </div>
                           <div class="form-group">
                               <input class="form-control" name="var3" placeholder="Вариант 3"
                                      value="<?= @$tasks['var3'] ?>">
                           </div>
                           <div class="form-group">
                               <input class="form-control" name="var4" placeholder="Вариант 4"
                                      value="<?= @$tasks['var4'] ?>">
                           </div>
                   
                           <div class="form-group">
                               <label for="">Верный вариант:&nbsp;</label>
                               <select name="success" required>
                                   <option>1</option>
                                   <option>2</option>
                                   <option>3</option>
                                   <option>4</option>
                               </select>
                           </div>        
                       </div>
                       <div class="col-sm-4">
                           <label for="">Верный вариант</label>
                           <label class="form-check-label">
          <input class="form-check-input" type="checkbox"> Remember me
        </label>
        <label class="form-check-label">
          <input class="form-check-input" type="checkbox"> Remember me
        </label>
                        </div>
                    </div>
                     -->
                    <!--<div class="form-group">
                        <textarea class="form-control" rows="3" name="comment" placeholder="Описание работы"><?/*= @$tasks['desc'] */?></textarea>
                    </div>-->
                    <div class="form-group">
                        <input type="hidden" name="id" value="<?= $tasks['id'] ?>">
                        <button type="submit" class="btn btn-default">Сохранить</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</form>