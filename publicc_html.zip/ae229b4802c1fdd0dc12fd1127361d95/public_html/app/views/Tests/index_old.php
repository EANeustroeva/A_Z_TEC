<?php /*if (empty($tests)): echo "<h4>Тесты отсутствуют</h4>"; else:*/?><!--
<table id="table_id" class="table table-striped table-hover table-bordered table-responsive">
    <thead>
    <tr>
        <th>Преподаватель</th>
        <th>Название</th>
        <th>Предмет</th>
        <th style="width: 1px;">Вопросов</th>
        <th style="width: 1px;">Время,&nbsp;м</th>
        <th style="width: 1px;">Действие</th>
    </tr>
    </thead>
    <tbody>
    <?php /*foreach ($tests as $k=>$item):
        if ($item['count'] == 0) continue;*/?>
        <tr>
            <td><?/*= $item['prepod'] */?></td>
            <td><?/*= $item['title'] */?></td>
            <td><?/*= $item['disc'] */?></td>
            <td><?/*= $item['qcount'] */?></td>
            <td><?/*= $item['timer'] */?></td>
            <td class="text-center">
                <?php /*if (!$item['status'] && $item['count'] > 0): */?>
                <form action="tests/test" method="post">
                    <button class="btn btn-success btn-xs">
                        <input type="hidden" name="id" value="<?/*= $item['id'] */?>">
                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Пройти тест</span></button>
                </form>
                <?php /*else: */?>
                    <form action="tests/results" method="post">
                        <button class="btn btn-warning btn-xs">
                            <input type="hidden" name="id" value="<?/*= $item['id'] */?>">
                            <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Результаты</span></button>
                    </form>
                <?php /*endif; */?>
            </td>
        </tr>
    <?php /*endforeach; */?>
    </tbody>
</table>
--><?php /*endif; */?>

 <?php if (isset($test_msg) && !empty($test_msg)): ?>
    <div class="alert alert-warning" role="alert">
        <?= /*htmlentities*/($test_msg) ?>
    </div>
<?php endif; ?>

<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#menu1">Общие</a></li>
<!--    <li><a data-toggle="tab" href="#home">Персональные</a></li>-->
    <li><a data-toggle="tab" href="#menu2">По дисциплине</a></li>
    <li><a data-toggle="tab" href="#menu3">Вступительное тестирование</a></li>

</ul>

<div class="tab-content">
    <div id="menu1" class="tab-pane fade in active">
        <h3>Общие</h3>
        <?php if (empty($tests)): echo "<h4>Тесты отсутствуют</h4>"; else:?>
            <table class="table table-striped table-hover table-bordered table-responsive">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Тип теста</th>
                    <th style="width: 1px;">Длина&nbsp;теста</th>
                    <th style="width: 1px;">Всего</th>
                    <th style="width: 1px;">Время,&nbsp;м</th>
                    <th style="width: 1px;">Результаты</th>
                    <th style="width: 1px;">Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($tests as $k=>$item):
                    if ($item['type']!=1) continue; ?>
                    <tr>
                        <?php if ($cur_user->access == 1): ?>
                        <td><a href="tests/edit?id=<?=$item['id']?>"><?= $item['title'] ?></a></td>
                        <?php else: ?>
                        <td><?= $item['title'] ?></td>
                        <?php endif; ?>
                        <td><?= $item['prepod'] ?></td>
                        <td><?= $item['qcount'] ?></td>
                        <td><?= $item['count'] ?></td>
                        <td><?= $item['timer'] ?></td>
                        <td>
<!--                            --><?php //if ($item['status']): ?>
                                <form action="tests/results" method="post">
                                    <button class="btn btn-warning btn-xs">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Посмотреть</span></button>
                                </form>
<!--                            --><?php //endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if (!$item['status'] && ($item['count']-$item['qcount']) >= 0): ?>
<!--                            --><?php //if (($item['count']-$item['qcount']) >= 0): ?>
                                <form action="tests/test" method="post">
                                    <button class="btn btn-success btn-xs">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Пройти тест</span></button>
                                </form>
                            <?php elseif ($item['status']): ?>
                                    <span class="btn btn-info btn-xs">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Тест пройден на <?= $item['status']['total'] ?>%</span></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <div id="home" class="tab-pane fade">
        <h3>Персональные тесты</h3>
        <?php if (empty($tests)): echo "<h4>Тесты отсутствуют</h4>"; else:?>
            <table class="table table-striped table-hover table-bordered table-responsive">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Преподаватель</th>
                    <th style="width: 1px;">Длина&nbsp;теста</th>
                    <th style="width: 1px;">Время,&nbsp;м</th>
                    <th style="width: 1px;">Результат</th>
                    <th style="width: 1px;">Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($tests as $k=>$item):
                    if ($item['type']!=0) continue; ?>
                    <tr>
                        <td><?= $item['title'] ?></td>
                        <td><?= $item['prepod'] ?></td>
                        <td><?= $item['qcount'] ?></td>
                        <td><?= $item['timer'] ?></td>
                        <td>
                            <?php if ($item['status']): ?>
                                <form action="tests/results" method="post">
                                    <button class="btn btn-warning btn-xs">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Посмотреть</span></button>
                                </form>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if (!$item['status'] && ($item['count']-$item['qcount']) >= 0): ?>
                                <form action="tests/test" method="post">
                                    <button class="btn btn-success btn-xs">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Пройти тест</span></button>
                                </form>
                            <?php elseif ($item['status']): ?>
                                    <span class="btn btn-info btn-xs">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Тест пройден</span></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <div id="menu2" class="tab-pane fade">
        <h3>Тесты по дисциплине</h3>
        <?php if (empty($tests)): echo "<h4>Тесты отсутствуют</h4>"; else:?>
            <table class="table table-striped table-hover table-bordered table-responsive">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Преподаватель</th>
                    <th>Предмет</th>
                    <th style="width: 1px;">Длина&nbsp;теста</th>
                    <th style="width: 1px;">Время,&nbsp;м</th>
                    <th style="width: 1px;">Результаты</th>
                    <th style="width: 1px;">Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($tests as $k=>$item):
                    if ($item['type']!=2) continue; ?>
                    <tr>
                        <td><?= $item['title'] ?></td>
                        <td><?= $item['prepod'] ?></td>
                        <td><?= $item['disc'] ?></td>
                        <td><?= $item['qcount'] ?></td>
                        <td><?= $item['timer'] ?></td>
                        <td>
                            <?php if ($item['status']): ?>
                                <form action="tests/results" method="post">
                                    <button class="btn btn-warning btn-xs">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Посмотреть</span></button>
                                </form>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                             <?php if (!$item['status'] && ($item['count']-$item['qcount']) >= 0): ?>
                                <form action="tests/test" method="post">
                                    <button class="btn btn-success btn-xs">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Пройти тест</span></button>
                                </form>
                            <?php elseif ($item['status']): ?>
                                    <span class="btn btn-info btn-xs">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Тест пройден</span></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <div id="menu3" class="tab-pane fade">
        <h3>Вступительное тестирование</h3>
        <?php if (empty($tests)): echo "<h4>Тесты отсутствуют</h4>"; else:?>
            <table class="table table-striped table-hover table-bordered table-responsive">
                <thead>
                <tr>
                    <th>Название</th>
                    <?php if ($cur_user->access == 1) echo "<th>Преподаватель</th>";?>
                    <th>Предмет</th>
                    <th style="width: 1px;">Длина&nbsp;теста</th>
                    <th style="width: 1px;">Время,&nbsp;м</th>
                    <th style="width: 1px;">Результаты</th>
                    <th style="width: 1px;">Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($tests as $k=>$item): if ($item['type']!=3) continue; ?>
                    <tr>
                        <td><?= $item['title'] ?></td>
                        <?php if ($cur_user->access == 1) echo '<td>'.$item['prepod'].'</td>';?>
                        <td><?= $item['disc'] ?></td>
                        <td><?= $item['qcount'] ?></td>
                        <td><?= $item['timer'] ?></td>
                        <td>
                            <?php if ($item['status']): ?>
                                <form action="tests/results" method="post">
                                    <button class="btn btn-warning btn-xs">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Посмотреть</span></button>
                                </form>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if (!$item['status'] && ($item['count']-$item['qcount']) >= 0): ?>
                                <form action="tests/test" method="post">
                                    <button class="btn btn-success btn-xs">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Пройти тест</span></button>
                                </form>
                            <?php elseif ($item['status']): ?>
                                    <span class="btn btn-info btn-xs">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Тест пройден</span></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>