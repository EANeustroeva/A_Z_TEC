<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<div class="row">
    <div class="col-sm-6">
        <div class="panel panel-default">
            <div class="panel-heading">Подготовка перед выводом</div>
            <div class="panel-body">
                <form action="<?= BASE_URL ?>tests/generate" method="post" target="_blank">
                    <div class="col-xs-12">
                        <h4></h4>
                        <div class="form-group">
                            <label for="">Выберите группу:</label>
                            <select class="selectpicker form-control" data-live-search="true"
                                    name="class" id="classs" data-size="10" >
                                <?= $list_class ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Название кафедры (в род. падеже):</label>
                            <textarea class="form-control" type="text" name="caftext" id="caftext"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="">Фамилия зав. кафедры:</label>
                            <input class="form-control" type="text" name="cafname" id="cafname" value="">
                        </div>
                        <div class="form-group">
                            <label for="">Добавить студентов (ФИО)<br>(каждый студент с новой строки):</label>
                            <textarea class="form-control" rows="5" type="text" name="addstuds" id="addstuds"></textarea>
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="studs" id="studs" value="">
                            <div class="checkbox"><label><input type="checkbox" name="byone" >Индивидуально для каждого</label></div>
                        </div>
                        <div class="form-group">
                            <div class="btn-group">
                                <button class="btn btn-success" name="gen" value="1">Отчет в файл</button>
                                <button class="btn btn-success" name="gen" value="2">Отчет в браузер</button>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="btn-group">
                                <button class="btn btn-warning" name="gen" value="3">Ведомость в файл</button>
                                <button class="btn btn-warning" name="gen" value="4">Ведомость в браузер</button>
                            </div>
                        </div>
                        <span class="text-danger">Если не выбраны студенты, то генерируется для всех</span>
                    </div>
                </form>
            </div>
        </div>
        <div id="comps"></div>
    </div>
    <div class="col-sm-6">
        <div class="well" style="max-height: 750px; overflow: auto;">
            <div class="row">
                <div class="col-sm-6"><button class="btn btn-primary form-control" id="get-checked-data">Выбрать все</button></div>
                <div class="col-sm-6"><button class="btn btn-default form-control" id="get-checked-data-cancel">Отменить</button></div>
            </div>
            <hr>
            <ul id="check-list-box" class="list-group checked-list-box"></ul>
            <br />
        </div>
    </div>
</div>

<style>
    /* CSS REQUIRED */
    .state-icon {
        left: -5px;
    }
    .list-group-item-primary {
        color: rgb(255, 255, 255);
        background-color: rgb(66, 139, 202);
    }

    /* DEMO ONLY - REMOVES UNWANTED MARGIN */
    .well .list-group {
        margin-bottom: 0px;
    }
    .list-group-item {
        padding: 1px 15px;
    }
</style>
<script>
    function lalala() {
//        $(function () {
            $('.list-group.checked-list-box .list-group-item').each(function () {

                // Settings
                var $widget = $(this),
                    $checkbox = $('<input type="checkbox" class="hidden" />'),
                    color = ($widget.data('color') ? $widget.data('color') : "primary"),
                    style = ($widget.data('style') == "button" ? "btn-" : "list-group-item-"),
                    settings = {
                        on: {
                            icon: 'glyphicon glyphicon-check'
                        },
                        off: {
                            icon: 'glyphicon glyphicon-unchecked'
                        }
                    };

                $widget.css('cursor', 'pointer')
                $widget.append($checkbox);

                // Event Handlers
                $widget.on('click', function () {
                    $checkbox.prop('checked', !$checkbox.is(':checked'));
                    $checkbox.triggerHandler('change');
                    updateDisplay();
                });
                $checkbox.on('change', function () {
                    updateDisplay();
                });


                // Actions
                function updateDisplay() {
                    var isChecked = $checkbox.is(':checked');

                    // Set the button's state
                    $widget.data('state', (isChecked) ? "on" : "off");

                    // Set the button's icon
                    $widget.find('.state-icon')
                        .removeClass()
                        .addClass('state-icon ' + settings[$widget.data('state')].icon);

                    // Update the button's color
                    if (isChecked) {
                        $widget.addClass(style + color + ' active');
                    } else {
                        $widget.removeClass(style + color + ' active');
                    }

                    var checkedItems = {}, counter = 0;
                    $("#check-list-box li.active").each(function(idx, li) {
                        checkedItems[$(li).data('value')] = $(li).data('value');
                        counter++;
                    });
                    $('#studs').val(Object.keys(checkedItems));
                }

                // Initialization
                function init() {

                    if ($widget.data('checked') == true) {
                        $checkbox.prop('checked', !$checkbox.is(':checked'));
                    }

                    updateDisplay();

                    // Inject the icon if applicable
                    if ($widget.find('.state-icon').length == 0) {
                        $widget.prepend('<span class="state-icon ' + settings[$widget.data('state')].icon + '"></span>');
                    }
                }
                $('#get-checked-data').on('click', function(event) {
                    $checkbox.prop('checked', true);
                    updateDisplay();
                });
                $('#get-checked-data-cancel').on('click', function(event) {
                    $checkbox.prop('checked', false);
                    updateDisplay();
                });
                init();
            });

//             $('#get-checked-data').on('click', function(event) {
//                 event.preventDefault();
//                 // $widget.data('state', (isChecked) ? "on" : "off");
//                 // var checkedItems = {}, counter = 0;
//                 // $("#check-list-box li.active").each(function(idx, li) {
//                 //     checkedItems[$(li).data('value')] = $(li).data('value');
//                 //     counter++;
//                 // });
//                 // $('#studs').val(Object.keys(checkedItems));
//
// //                start_import(Object.keys(checkedItems));
//                 // $('#display-json').html(JSON.stringify(checkedItems, null, '\t'));
//             });
//        });
    };
//    lalala();
    $('#napr').on('changed.bs.select', function (e) {
        $.ajax({
            url: '/tests/getclasslist',
            type: 'post',
            data: {napr: $('#napr').val()},
            success: function (res) {
                $('#classs').html(res).val('').selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });
    $('#classs').on('changed.bs.select', function (e) {
        $.ajax({
            url: '/tests/getstudslist',
            type: 'get',
            data: {classs: $('#classs').val()},
            success: function (res) {
                res = JSON.parse(res);
                $('#check-list-box').html(res.list);
                $('#caftext').text(res.caftext);
                $('#cafname').val(res.cafname);
                $('#comps').html(res.complist);
                lalala();
            },
            error: function () {
                console.log('Error!');
            }
        });
    });
    function start_import(qwe) {
        console.log('aaa');
        $.ajax({
            url: base + 'tests/generate',
             method: 'post',
             data: {
                napr: $('#napr').val()
             },
            success: function (res) {
//                window.open('')
//                $('#classs').html(res).selectpicker('refresh');;
                // d = JSON.parse(res);
//                $('#req').html(res.ls);
//                $('#check-list-box').html('\
//                      <li class="list-group-item" data-value="0">Студенты</li>\
//                      <li class="list-group-item" data-value="1">Преподаватели</li>\
//                      <li class="list-group-item" data-value="2">Оценки</li>\
//                      <li class="list-group-item" data-value="3">Планы</li>\
//                      <li class="list-group-item" data-value="4">Расписание</li>\
//                ');
//                lalala();
            },
            error: function () {
                console.log('Error!');
            }
        });

    }
</script>