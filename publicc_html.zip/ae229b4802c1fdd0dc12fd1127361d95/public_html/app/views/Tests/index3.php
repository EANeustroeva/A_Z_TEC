<?php
/*<ul class="nav nav-tabs">
    <li class="form-group">
        <form action="<?= BASE_URL ?>tests/edit" method="post">
        <button class="btn btn-success"><i class="glyphicon glyphicon-plus-sign"></i> Новый тест</button>
        </form>
    </li>
<!--    <li class="form-group">-->
<!--        <a class="btn btn-warning" href="--><?//= BASE_URL ?><!--tests/prints">Распечатать отчет</a>-->
<!--    </li>-->
    <?php if ($cur_user->access < 4): ?>
<!--        <li class="active"><a data-toggle="tab" href="#home">Персональные</a></li>-->
    <?php endif; ?>
    <?php if ($cur_user->access == 1): ?>
        <li><a data-toggle="tab" href="#menu1">Общие</a></li>
    <?php endif; ?>
    <li class="active"><a data-toggle="tab" href="#menu2">По дисциплине</a></li>
    <?php if ($cur_user->access == 1): ?>
<!--        <li><a data-toggle="tab" href="#menu3">Базовые тесты</a></li>-->
<!--        <li><a data-toggle="tab" href="#menu4">По компетенции</a></li>-->
    <?php endif; ?>
</ul>
<div class="tab-content">
    <div id="home" class="tab-pane fade <?= ($cur_user->access < 4)?'in active':'' ?>">
        <h3>Персональные тесты</h3>
        <?php if (empty($tests)): echo "<h4>Тесты отсутствуют</h4>"; else:?>
            <table class="table table-striped table-hover table-bordered table-responsive">
                <thead>
                <tr>
                    <th>Название</th>
                    <?php if ($cur_user->access == 1) echo "<th>Преподаватель</th>";?>
                    <th>Студент</th>
                    <th style="width: 1px;">Длина&nbsp;теста</th>
                    <th style="width: 1px;">Всего</th>
                    <th style="width: 1px;">Время,&nbsp;м</th>
                    <?php if ($cur_user->access==1): ?>
                        <th style="width: 1px;">Виден</th>
                    <?php endif; ?>
                    <th style="width: 110px;">Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($tests as $k=>$item): if ($item['type']!=0) continue; ?>
                    <tr>
                        <td><a href="<?= BASE_URL ?>tests/edit?id=<?=$item['id']?>"><?= $item['title'] ?></a></td>
                        <?php if ($cur_user->access == 1) echo '<td>'.$item['prepod'].'</td>';?>
                        <td><?= $item['disc'] ?></td>
                        <td><?= $item['qcount'] ?></td>
                        <td><?= $item['count'] ?></td>
                        <td><?= $item['timer'] ?></td>
                        <?php if ($cur_user->access==1): ?>
                        <td>
                            <?=$item['visible']? '<span class="btn btn-xs btn-success check" data-id="'.$item['id'].'">Да</span>' :
                                '<span class="btn btn-xs btn-danger check" data-id="'.$item['id'].'">Нет</span>'?>
                        </td>
                        <?php endif; ?>
                        <td class="text-center">
                            <?php if ($item['count']-$item['qcount'] >= 0): ?>
                                <form action="<?= BASE_URL ?>tests/test" method="post" style="width: 100%;">
                                    <button class="btn btn-success btn-xs" style="width: 100%;">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-play-circle"></span>&nbsp;Пройти
                                    </button>
                                </form>
                            <div style="margin: 5px 0;"></div>
                            <?php endif; ?>
                            <?php if ($item['status']): ?>
                                <form action="<?= BASE_URL ?>tests/results" method="post" style="width: 100%;">
                                    <button class="btn btn-warning btn-xs" style="width: 100%;">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;Результаты</button>
                                </form>
                            <div style="margin: 5px 0;"></div>
                            <?php endif; ?>
                            <form action="<?= BASE_URL ?>tests/delete" method="post" style="width: 100%;">
                                <button class="btn btn-danger btn-xs" style="width: 100%;">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <span class="glyphicon glyphicon-remove"></span>&nbsp;Удалить
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <div id="menu1" class="tab-pane fade <?= ($cur_user->access == 4)?'in active':'' ?>">
        <h3>Общие</h3>
        <?php if (empty($tests)): echo "<h4>Тесты отсутствуют</h4>"; else:?>
            <table class="table table-striped table-hover table-bordered table-responsive">
                <thead>
                    <tr>
                    <th>Название</th>
                    <th>Предмет</th>
                    <th style="width: 1px;">Длина&nbsp;теста</th>
                    <th style="width: 1px;">Всего</th>
                    <th style="width: 1px;">Время,&nbsp;м</th>
                    <?php if ($cur_user->access==1): ?>
                        <th style="width: 1px;">Виден</th>
                    <?php endif; ?>
                    <th style="width: 110px;">Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($tests as $k=>$item):
                    if ($item['type']!=1) continue; ?>
                    <tr>
                        <td><a href="<?= BASE_URL ?>tests/edit?id=<?=$item['id']?>"><?= $item['title'] ?></a></td>
                        <td><?= $item['disc'] ?></td>
                        <td><?= $item['qcount'] ?></td>
                        <td><?= $item['count'] ?></td>
                        <td><?= $item['timer'] ?></td>
                        <?php if ($cur_user->access==1): ?>
                         <td>
                            <?=$item['visible']? '<span class="btn btn-xs btn-success check" data-id="'.$item['id'].'">Да</span>' :
                                '<span class="btn btn-xs btn-danger check" data-id="'.$item['id'].'">Нет</span>'?>
                        </td>
<!--                            <td>--><?//= $item['visible'] ? 'Да' : ' Нет' ?><!--</td>-->
                        <?php endif; ?>
                        <td class="text-center">
                            <?php if ($item['count']-$item['qcount'] >= 0): ?>
                                <form action="<?= BASE_URL ?>tests/test" method="post" style="width: 100%;">
                                    <button class="btn btn-success btn-xs" style="width: 100%;">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-play-circle"></span>&nbsp;Пройти
                                    </button>
                                </form>
                            <div style="margin: 5px 0;"></div>
                            <?php endif; ?>
                            <?php if ($item['status']): ?>
                                <form action="<?= BASE_URL ?>tests/results" method="post" style="width: 100%;">
                                    <button class="btn btn-warning btn-xs" style="width: 100%;">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-list-alt"></span>&nbsp;Результаты</button>
                                </form>
                            <div style="margin: 5px 0;"></div>
                            <?php endif; ?>
                            <form action="<?= BASE_URL ?>tests/delete" method="post" style="width: 100%;">
                                <button class="btn btn-danger btn-xs" style="width: 100%;">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <span class="glyphicon glyphicon-remove"></span>&nbsp;Удалить
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <div id="menu2" class="tab-pane fade">
  */ ?>
<form action="<?= BASE_URL ?>tests/edit" method="post">
<button class="btn btn-success"><i class="glyphicon glyphicon-plus-sign"></i> Новый тест</button>
</form>
  <h3>Тесты по дисциплине</h3>
  <?php if (empty($tests)): echo "<h4>Тесты отсутствуют</h4>"; else:?>
      <table class="table table-striped table-hover table-bordered table-responsive">
          <thead>
          <tr>
              <th>Название</th>
              <?php if ($cur_user->access == 1) echo "<th>Преподаватель</th>";?>
              <th>Предмет</th>
              <th style="width: 1px;">Длина&nbsp;теста</th>
              <th style="width: 1px;">Всего</th>
              <th style="width: 1px;">Время,&nbsp;м</th>
              <?php if ($cur_user->access==1): ?>
                  <th style="width: 1px;">Виден</th>
              <?php endif; ?>
              <th style="width: 110px;">Действие</th>
          </tr>
          </thead>
          <tbody>
          <?php foreach ($tests as $k=>$item):
              if ($item['type']!=2) continue; ?>
              <tr>
                  <td><a href="<?= BASE_URL ?>tests/edit?id=<?=$item['id']?>"><?= $item['title'] ?></a></td>
                  <?php if ($cur_user->access == 1) echo '<td>'.$item['prepod'].'</td>';?>
                  <td><?= $item['disc'] ?></td>
                  <td><?= $item['qcount'] ?></td>
                  <td><?= $item['count'] ?></td>
                  <td><?= $item['timer'] ?></td>
                  <?php if ($cur_user->access==1): ?>
                  <td>
                      <?=$item['visible']? '<span class="btn btn-xs btn-success check" data-id="'.$item['id'].'">Да</span>' :
                          '<span class="btn btn-xs btn-danger check" data-id="'.$item['id'].'">Нет</span>'?>
                  </td>
                  <?php endif; ?>
                  <td>
                      <?php if ($item['count']-$item['qcount'] >= 0): ?>
                          <form action="<?= BASE_URL ?>tests/test" method="post" style="width: 100%;">
                              <button class="btn btn-success btn-xs" style="width: 100%;">
                                  <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                  <span class="glyphicon glyphicon-play-circle"></span>&nbsp;Пройти
                              </button>
                          </form>
                      <div style="margin: 5px 0;"></div>
                      <?php endif; ?>
                      <?php if ($item['status']): ?>
                          <form action="<?= BASE_URL ?>tests/results" method="post" style="width: 100%;">
                              <button class="btn btn-warning btn-xs" style="width: 100%;">
                                  <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                  <span class="glyphicon glyphicon-list-alt"></span>&nbsp;Результаты</button>
                          </form>
                      <div style="margin: 5px 0;"></div>
                      <?php endif; ?>
                      <form action="<?= BASE_URL ?>tests/delete" method="post" style="width: 100%;">
                          <button class="btn btn-danger btn-xs" style="width: 100%;">
                              <input type="hidden" name="id" value="<?= $item['id'] ?>">
                              <span class="glyphicon glyphicon-remove"></span>&nbsp;Удалить
                          </button>
                      </form>
                  </td>
              </tr>
          <?php endforeach; ?>
          </tbody>
      </table>
  <?php endif; ?>
<?php /*
</div>
    <div id="menu3" class="tab-pane fade">
        <h3>Базовые тесты (для тестов по компетенции)</h3>
        <?php if (empty($tests)): echo "<h4>Тесты отсутствуют</h4>"; else:?>
            <table class="table table-striped table-hover table-bordered table-responsive">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Компетенции</th>
                    <th>Направление</th>
                    <th style="width: 1px;">Длина&nbsp;теста</th>
                    <th style="width: 1px;">Всего</th>
                    <th style="width: 1px;">Время,&nbsp;м</th>
                    <?php if ($cur_user->access==1): ?>
                        <th style="width: 1px;">Виден</th>
                    <?php endif; ?>
                    <th style="width: 110px;">Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($tests as $k=>$item):
                    if ($item['type']!=3) continue; ?>
                    <tr>
                        <td><a href="<?= BASE_URL ?>tests/edit?id=<?=$item['id']?>"><?= $item['title'] ?></a></td>
                        <td><?= $item['comp'] ?></td>
                        <td><?= $item['napr'] ?></td>
                        <td><?= $item['qcount'] ?></td>
                        <td><?= $item['count'] ?></td>
                        <td><?= $item['timer'] ?></td>
                        <?php if ($cur_user->access==1): ?>
                        <td>
                            <?=$item['visible']? '<span class="btn btn-xs btn-success check" data-id="'.$item['id'].'">Да</span>' :
                                '<span class="btn btn-xs btn-danger check" data-id="'.$item['id'].'">Нет</span>'?>
                        </td>
                        <?php endif; ?>
                        <td class="text-center">
                            <?php if ($item['count']-$item['qcount'] >= 0): ?>
                                <form action="<?= BASE_URL ?>tests/test" method="post" style="width: 100%;">
                                    <button class="btn btn-success btn-xs" style="width: 100%;">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-play-circle"></span>&nbsp;Пройти
                                    </button>
                                </form>
                            <div style="margin: 5px 0;"></div>
                            <?php endif; ?>
                            <form action="<?= BASE_URL ?>tests/delete" method="post" style="width: 100%;">
                                <button class="btn btn-danger btn-xs" style="width: 100%;">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <span class="glyphicon glyphicon-remove"></span>&nbsp;Удалить
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <div id="menu4" class="tab-pane fade">
        <h3>Тесты по компетенции</h3>
        <?php if (empty($tests)): echo "<h4>Тесты отсутствуют</h4>"; else:?>
            <table class="table table-striped table-hover table-bordered table-responsive">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Тесты</th>
<!--                    <th>Направление</th>-->
                    <th style="width: 1px;">Длина&nbsp;теста</th>
                    <th style="width: 1px;">Всего</th>
                    <th style="width: 1px;">Время,&nbsp;м</th>
                    <?php if ($cur_user->access==1): ?>
                        <th style="width: 1px;">Виден</th>
                    <?php endif; ?>
                    <th style="width: 110px;">Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($tests as $k=>$item):
                    if ($item['type']!=4) continue; ?>
                    <tr>
                        <td><a href="<?= BASE_URL ?>tests/edit?id=<?=$item['id']?>"><?= $item['title'] ?></a></td>
                        <td><?= $item['comp'] ?></td>
<!--                        <td>--><?//= $item['napr'] ?><!--</td>-->
                        <td><?= $item['qcount'] ?></td>
                        <td><?= $item['count'] ?></td>
                        <td><?= $item['timer'] ?></td>
                        <?php if ($cur_user->access==1): ?>
                        <td>
                            <?=$item['visible']? '<span class="btn btn-xs btn-success check" data-id="'.$item['id'].'">Да</span>' :
                                '<span class="btn btn-xs btn-danger check" data-id="'.$item['id'].'">Нет</span>'?>
                        </td>
                        <?php endif; ?>
                        <td class="text-center">
                            <?php if ($item['count']-$item['qcount'] >= 0): ?>
                                <form action="<?= BASE_URL ?>tests/test" method="post" style="width: 100%;">
                                    <button class="btn btn-success btn-xs" style="width: 100%;">
                                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                        <span class="glyphicon glyphicon-play-circle"></span>&nbsp;Пройти
                                    </button>
                                </form>
                            <div style="margin: 5px 0;"></div>
                            <?php endif; ?>
                            <form action="<?= BASE_URL ?>tests/delete" method="post" style="width: 100%;">
                                <button class="btn btn-danger btn-xs" style="width: 100%;">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <span class="glyphicon glyphicon-remove"></span>&nbsp;Удалить
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

*/ ?>

<style>
    .nav-tabs>li>form > button {
        position: relative;
        display: block;
        padding: 10px 15px!important;
    }
</style>
<script>
    $('body').on('click', '.check', function () {
        let btn = $(this).parent();
        $.ajax({
            url: '/tests/togglevisible',
            type: 'get',
            data: {'id': $(this).data('id')},
            success: function (res) {
                btn.html(res);
            },
            error: function (er) {
                console.log(er);
            }
        });
    })
</script>
