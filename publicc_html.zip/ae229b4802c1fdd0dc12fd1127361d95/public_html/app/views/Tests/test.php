<form action="test" method="post" class="form-group">
    <input type="hidden" name="id" value="<?= $test['id'] ?>">
    <input type="hidden" name="cur" value="<?= $cur-2 ?>">
    <?php if ($cur>1): ?>
    <button class="btn btn-info">Вернуться на предыдущий вопрос</button>
    <?php endif; ?>
</form>
<div style="text-align:left;padding:3px 15px;border-top-left-radius:5px;border-top-right-radius:5px;background-color:#337ab7;color:white;position: relative;">
    <h4 id="sQuestNumber"><span class="hidden-xs"><?= $test['title'] ?> |</span> Вопрос <?= $cur ?> из <?= $count ?></h4>
    <?php if ($test['timer']>0):  ?>
    <span id="dSpentTime" class="disappear"
          style="background-color: rgb(238, 238, 238); display: inline-block; border-radius: 5px; float: right; padding: 0px 5px; margin-right: 3px; visibility: visible; position: absolute;right: 10px;top: 13px;">
            <span id="sSpentTime" style="color: rgb(0, 128, 0);"><b><span class="hours"></span>:<span class="minutes"></span>:<span class="seconds"></span></b></span>
            </span>
    <?php endif; ?>
</div>
<div class="panel panel-default">
    <form action="test" method="post">
        <div class="panel-body">
            <h4></h4>
            <div class="col-xs-12">
                <div class="well well-sm">
                    <h4 style="padding:5px; font-weight: bold;">
                        <?= $quest['title'] ?>
                    </h4>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <?php if ($type == 'text'): ?>
                            <div class="btn-group-vertical" data-toggle="buttons">
                                <?php for($i=1; $i<=$quest['ct']; $i++): ?>
                                    <div class="row">
                                        <div class="col-xs-2">
                                            <span class="text-right btn"><?= $i ?>.</span>
                                        </div>
                                        <div class="col-xs-6">
                                            <label class="btn btn-default btn-md">
                                                <?= $quest['vars'][$i] ?>
                                            </label>
                                        </div>
                                        <div class="col-xs-4">
                                            <input class="form-control" value="" name="ans[]" type="<?= $type ?>">
                                        </div>
                                    </div>

                                <?php endfor; ?>
                            </div>
                            <?php else: ?>
                            <div class="btn-group-vertical" data-toggle="buttons">
                                <?php for($i=1; $i<=$quest['ct']; $i++): ?>
                                    <label class="btn btn-default btn-md">
                                        <input value="<?= $i ?>" name="ans[]" type="<?= $type ?>"><?= $quest['vars'][$i] ?>
                                    </label>
                                <?php endfor; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
<!--                    <div class="col-sm-6">-->
<!--                        <div style="margin: 0 auto !important; float: none !important; display: block; width:auto;padding-bottom: 15px;">-->
<!--                        --><?php //if ($quest['img']): ?>
<!--                            <img src="--><?//= BASE_URL . 'img/tests/' . $quest['img']?><!--" alt="" class="img-thumbnail">-->
<!--                        --><?php //else: ?>
<!--                            <img src="--><?//= BASE_URL . 'images/blank.jpg' ?><!--" class="img-thumbnail"-->
<!--                             alt="Картинка к вопросу">-->
<!--                        --><?php //endif; ?>
<!--                        </div>-->
<!--                    </div>-->
                </div>
            </div>
        </div>
        <?php if ($type=='checkbox'): ?>
            <div class="alert alert-info" role="alert">Внимание! Вопрос с выбором нескольких вариантов.</div>
        <?php elseif ($type=='text'): ?>
            <div class="alert alert-info" role="alert">Внимание! Необходимо ввести соответствующие вариантом номера</div>
        <?php endif; ?>
        <div class="panel-footer">
            <input type="hidden" name="id" value="<?= $test['id'] ?>">
            <input type="hidden" name="cur" value="<?= $cur ?>">
            <button id="send" class="btn btn-success">Подтвердить</button>
        </div>
    </form>
</div>
<style>
    .btn {
        text-align: left;
        white-space: normal;
    }
    .btn-default.active, .btn-default:active{
                outline: none!important;
        color: #fff!important;
        background-color: #449d44!important;
        border-color: #398439!important;
    }
</style>
<script type="text/x-mathjax-config">
MathJax.Hub.Config({
    showMathMenu: false,
    extensions: ["tex2jax.js"],
    jax: ["input/TeX", "output/HTML-CSS"],
});
</script>
<script src="/js/MathJax/latest.js"></script>
<script>
    $(document).ready(function () {
        function getTimeRemaining(endtime){
            var t = Date.parse(endtime) - Date.parse(new Date());
            var seconds = Math.floor( (t/1000) % 60 );
            var minutes = Math.floor( (t/1000/60) % 60 );
            var hours = Math.floor( (t/(1000*60*60)) % 24 );
            var days = Math.floor( t/(1000*60*60*24) );
            return {
                'total': t,
                'days': days,
                'hours': hours,
                'minutes': minutes,
                'seconds': seconds
            };
        }
        function initializeClock(id, endtime){
            var clock = document.getElementById(id);
            var daysSpan = clock.querySelector('.days');
            var hoursSpan = clock.querySelector('.hours');
            var minutesSpan = clock.querySelector('.minutes');
            var secondsSpan = clock.querySelector('.seconds');
            function updateClock(){
                var t = getTimeRemaining(endtime);
//                daysSpan.innerHTML = t.days;
                hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
                minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
                secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);
                if(t.total<=0){
                    clearInterval(timeinterval);
                    window.location.href = base+'tests/end';
                }
            }
            updateClock();
            var timeinterval = setInterval(updateClock,1000);
        }
//        var deadline = 'December 31 2018 23:59:59 GMT+02:00';
//        var deadline = '<?//= date("D d M Y H:i:s O") + 10000 ?>//';
        var deadline = '<?= $_SESSION['timer'] ?>';
        <?= $timer_start ?>
    });
    $(function () {
        /*$('#send').click(function () {
            $.ajax({
                url: 'test',
                type: 'post',
                data: {
                    'answ': $(".active > input").attr("value"),
                    'id': $("#sQuestNumber").text()
                },
                success: function (res) {
                    $("label.active").removeClass("active");
                    $("#sQuestNumber").text('Вопрос ' + res);
//                    console.log($(".active input").text('123'));
//                    console.log(res);
                },
                error: function () {
                    alert('Error!');
                }
            });
        });*/
    });
</script>