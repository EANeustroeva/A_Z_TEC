<div class="panel panel-primary">
    <div class="panel-heading">
        <div class="pull-left">
            <a href="<?= BASE_URL ?>tests" class="btn btn-default">Вернуться</a>
        </div>
        <div class="col-sm-9">
        <h4><?= $test['title'] ?> | Тестирование завершено!</h4>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="panel-body">
        <div id="air" style="width: 100%; min-height: 400px;"></div>
    </div>
    <div class="panel-footer text-center">
        <?= $answers ?>
    </div>
</div>

<!-- <script src="https://www.google.com/jsapi"></script> -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script>
    // google.load("visualization", "1", {packages:["corechart"]});
    google.charts.load('current', {'packages':['corechart']});
    google.setOnLoadCallback(drawChart);
    function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['Ответы', 'Проценты'],
            ['Ошибки', <?=$test['qcount']-$score?>],
            ['Верные ответы', <?=$score?>],
        ]);
        var options = {
            title: 'Результаты тестирования:',
            // is3D: true,
            pieHole: 0.4,
            slices: {
                0: { color: 'red' },
                1: { color: '#5cb85c' }
            },
            legend: {
                position: 'bottom', textStyle: {fontSize: 18}
            },
            pieSliceTextStyle: {fontSize: 20},
            titleTextStyle: {fontSize: 20,fontName: 'Roboto Condensed'},

            // pieResidueSliceLabel: 'Остальное'
        };
        var chart = new google.visualization.PieChart(document.getElementById('air'));
        chart.draw(data, options);
    }
</script>