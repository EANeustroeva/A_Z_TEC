<form action="<?= BASE_URL ?>tests/save" method="post" enctype="multipart/form-data" class="form-horizontal">
<div class="panel panel-default">
    <div class="panel-heading clearfix">
        <div class="row">
            <div class="col-sm-2">
                <a href="<?= BASE_URL ?>tests" class="btn btn-default"><i class="glyphicon glyphicon-chevron-left"
                                                                          aria-hidden="true"></i> Назад</a>
            </div>
                <div style="line-height: 34px;padding-left: 15px; float: left;"><?= empty($_GET['id'])?'Создание':'Редактирование' ?> теста</div>
            <div class="col-sm-4 pull-right">
              <?php if ($cur_user->access == 3): ?>
              <input type="hidden" id="type" name="type" value="2">
              <?php else: ?>
                <select class="selectpicker form-control" id="type" name="type" placeholder="Название теста">
                <option <?= ($type==0 || is_null($type))?'selected ':'' ?>value="0">Распределить</option>
                <?php if ($cur_user->access == 1): ?>
                    <option <?= ($type==1)?'selected ':'' ?>value="1">Перезачет</option>
                <?php endif; ?>
                    <option <?= ($type==2)?'selected ':'' ?>value="2">По дисциплине</option>
                <?php if ($cur_user->access == 1): ?>
                    <option <?= ($type==3)?'selected ':'' ?>value="3">По компетенции</option>
                    <option <?= ($type==4)?'selected ':'' ?>value="4">Для ЭОК</option>
                <?php endif; ?>
                </select>
              <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="panel-body">
         <div class="col-sm-12">
            <h4></h4>
            <div class="form-group">
                <label class="control-label col-sm-2" for="title">Название</label>
                <div class="col-sm-7">
                    <input type="text" class="form-control" name="title" required placeholder="Название теста"
                       value="<?= @$test['title'] ?>">
                </div>
                <div class="col-sm-3">
                     <div class="checkbox">
                         <label><input type="checkbox" name="visible" <?= @$test['visible']?'checked':'' ?>>Виден</label>
                     </div>
                 </div>
            </div>
            <!-- <div class="row"> -->
                <!-- <div class="col-sm-12"> -->
             <div class="form-group">
                 <label class="control-label col-sm-2" for="title">Вопросов</label>
                 <div class="col-sm-2">
                     <input class="form-control" name="qcount" placeholder="Вопросов в варианте"
                            value="<?= @$test['qcount'] ?>">
                 </div>
                 <div class="col-sm-6">
                     <div class="checkbox">
                         <label><input type="checkbox" name="rand" <?= @$test['rand']?'checked':'' ?>>Вопросы в случайном порядке</label>
                     </div>
                 </div>
             </div>
             <div class="form-group">
                 <label class="control-label col-sm-2" for="">Время, м</label>
                 <div class="col-sm-2">
                     <input type="text" class="form-control pull-right" name="timer" placeholder="Время, м" value="<?=$test['timer']?>" required data-toggle="tooltip" data-trigger="focus" title="Для отключения таймера установите значение в 0">
                 </div>
             </div>
             <?php if ($cur_user->access == 1): ?>
             <div class="form-group">
                 <label class="control-label col-sm-2" for="title">Разброс</label>
                 <div class="col-sm-2">
                     <input class="form-control" name="porogrnd" placeholder="Вопросов"
                            value="<?= @$test['porogrnd'] ?>" data-toggle="tooltip" title="Разброс по добору верных ответов (количество ответов)">
                 </div>
                 <div class="col-sm-6">
                     <div class="checkbox">
                         <label><input type="checkbox" name="porogchk" <?= @$test['porogchk']?'checked':'' ?>>Проходной порог (указывать в %):</label>
                     </div>
                 </div>
                 <div class="col-sm-2">
                     <input class="form-control" name="porog" value="<?= @$test['porog'] ?>">
                 </div>
             </div>
             <?php endif; ?>
             <hr>
             <div id="addform">
                <?= $form ?>
             </div>
             <a class="btn btn-link" data-toggle="collapse" data-target="#addquests">Добавить вопросы из другого теста</a>
             <div id="addquests" class="collapse">
                 <div class="form-group">
                     <div class="col-sm-6">
                         <select class="selectpicker form-control" name="tests[]" title="Выберите тест/ы для добавления"
                                 data-size="8" data-live-search="true" multiple>
                             <?php foreach ($tests as $item): ?>
                                 <option value="<?= $item['id'] ?>"><?= $item['title'] ?></option>
                             <?php endforeach; ?>
                         </select>
                     </div>
                     <div class="col-sm-6"></div>

                 </div>
             </div>

             <a class="btn btn-link pull-right" id="resetfilters" href="#">Сбросить фильтры</a>
                <!-- </div> -->
            <!-- </div> -->

            <!--<div class="form-group">
                <textarea class="form-control" rows="3" name="comment" placeholder="Описание работы"><?/*= @$test['desc'] */?></textarea>
            </div>-->
            

         </div>
    </div>
    <div class="panel-footer">
        <input type="hidden" name="id" value="<?= $test['id'] ?>">
            <button type="submit" class="btn btn-default">Сохранить</button>
    </div>
</div>
</form>
<?php if (!empty($_GET['id'])): ?>
<div class="panel panel-default">
    <div class="panel-heading clearfix"><h5 class="pull-left">Вопросы</h5>
    <?php if (count($quest) > 0): ?>
        <form action="<?= BASE_URL ?>tests/test" method="post" class="pull-left" style="margin-left: 15px;">
            <button class="btn btn-success">
                <input type="hidden" name="id" value="<?= $test['id'] ?>">
                <span class="glyphicon glyphicon-list-alt"></span>&nbsp;<span class="hidden-xs">Пройти тест</span></button>
        </form>
    <?php endif; ?>
        <div class="pull-right">
            <a class="btn btn-default" href="quest?t=<?=$_GET['id']?>"><i class="glyphicon glyphicon-plus"></i> Добавить вопрос</a>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="upload?id=<?=$_GET['id']?>"><i class="glyphicon glyphicon-upload"></i> Загрузить из файла</a>
        </div>
        <div class="pull-right">
            <a class="btn btn-warning" href="exportquests?id=<?=$_GET['id']?>"><i class="glyphicon glyphicon-download"></i> Выгрузить в файл</a>
        </div>
    </div>
    <div class="panel-body">
    <?php if(empty($quest)): echo '<h4></h4><p class="text-center">Записи отсутствуют</p>'; 
    else:?>
        <table id="table_idq" class="table table-bordered table-condensed table-hover table-striped" style="margin: 0;">
            <thead>
                <th>№</th>
                <th>Вопрос</th>
                <th>Тип</th>
<!--                <th>Сложность</th>-->
                <th>Число вариантов</th>
                <th width="1">Действие</th>
            </thead>
            <tbody>
                <?php foreach($quest as $k=>$item): ?>
                    <tr>
                        <td style="width: 1px"><?= $k+1 ?></td>
                        <td class="text-left"><a href="quest?t=<?=$_GET['id']?>&id=<?=$item['id']?>"><?= $item['title'] ?></a></td>
                        <td><?php switch ($item['type']) {
                            case '0':echo 'Обычный';break;
                            case '1':echo 'Мультивыбор';break;
                            case '2':echo 'Соответствие';break;
                            case '3':echo 'Письменный ответ';break;
                        } ?></td>
<!--                        <td>--><?php //switch ($item['diff']) {
//                            case '0':echo 'Легкий';break;
//                            case '1':echo 'Обычный';break;
//                            case '2':echo 'Сложный';break;
//                        } ?><!--</td>-->
                        <td><?= $item['ct'] ?></td>
                        <td><form action="<?= BASE_URL ?>tests/deleteq" method="post" style="width: 100%;margin: 3px;">
                            <button class="btn btn-danger btn-xs" style="width: 100%;">
                                <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                <span class="glyphicon glyphicon-remove"></span>&nbsp;Удалить
                            </button>
                        </form></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>

<link rel="stylesheet" type="text/css" href="<?= BASE_URL ?>css/uploadifive.css">
<script src="<?= BASE_URL ?>js/jquery.uploadifive.js"></script>
<script>
    function load_add_form() {
        $('#addform').html('<div class="text-center"><img src="'+base+'images/loader.gif" ></div><hr>');
        $.ajax({
            url: 'edit',
            type: 'post',
            data: {type: $('#type').val()},
            success: function (res) {
                $('#addform').html(res);
                $('.selectpicker').selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    $( document ).ready(function() {
        $('#table_id').DataTable({
            // stateSave: true,
            "paging": false,
            // "pageLength": 10,
            "searching": false,
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            }
        });
        <?php if (empty($_GET['id'])) echo 'load_add_form();' ?>
    });
    $('#type').on('changed.bs.select', function (e) { load_add_form() });
    $('#allstates input').change(function () {
        if ($('#allstates input').is(':checked')) {
            $('#allstates input').addClass('checked');
            $('#individ').prop('disabled', false).selectpicker('refresh');
        } else {
            $('#allstates input').removeClass('checked');
            $('#individ').selectpicker('deselectAll').prop('disabled', true).selectpicker('refresh');
        }
    });
    $('#resetfilters').click(function () {
        $('#napr').val('').selectpicker('deselectAll').selectpicker('refresh');
        $('#course').val('').selectpicker('deselectAll').selectpicker('refresh');
        $('#class').val('').selectpicker('deselectAll').selectpicker('refresh');
        $('#stud').val('').selectpicker('deselectAll').selectpicker('refresh');
        $('#predmet').val('').selectpicker('deselectAll').selectpicker('refresh');
    });
    /*$(function() {
        $('#file_upload').uploadifive({
            'uploadScript' : 'uploads',
            'onUploadComplete' : function(file, data) {
                console.log(file);
                $('#preview').append('<img src="'+ base + 'uploads/' + file.name + '" />');
            }

        });
    });*/
</script>

<link rel="stylesheet" href="<?= BASE_URL ?>css/fileuploader.css">
<script src="<?= BASE_URL ?>js/fileuploader.js"></script>
<script>
    $( document ).ready(function() {

    });
</script>