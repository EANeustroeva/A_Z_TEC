<div class="form-group">
    <a class="btn btn-default" href="<?= BASE_URL ?>tests">Назад</a>
</div>
<!--<form action="print" method="post" class="pull-right">
    <input type="hidden" name="id" value="<?/*= $test['id'] */?>">
    <button class="btn btn-warning" type="submit"><i class="fa fa-print"> В печать</i></button>
</form>-->
<table class="table table-bordered table-stripped">
    <tr><td>Название теста</td><td><?= $test['title'] ?></td></tr>
    <tr><td>Всего вопросов</td><td><?= $res['qcount'] ?></td></tr>
    <tr><td>Правильных ответов</td><td><?= $res['pos'] ?></td></tr>
    <tr><td>Процент успешности</td><td><?= $res['total'] ?>%</td></tr>
    <tr><td>Дата теста</td><td><?= date("H:i, d.m.Y",strtotime($res['created']))?></td></tr>
</table>