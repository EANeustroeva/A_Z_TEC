<div class="panel panel-default">
    <div class="panel-body" style="padding: 15px;">
        <form class="form-inline" action="/spravki/obhodnoymanager" method="post">

            <div class="form-group">
                <select class="selectpicker form-control" data-selected-text-format="count > 2" data-size="8" data-live-search="true" name="class[]" id="class2" multiple>
                    <?php foreach ($classes as $y => $group): ?>
                        <optgroup label="<?= $y ?> год поступления">
                            <?php foreach ($group as $k => $class): ?>
                                <option><?= $class ?></option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <select name="users[]" class="selectpicker form-control" id="studs" data-selected-text-format="count > 1" data-live-search="true" data-actions-box="true" data-size="15" multiple>
                    <option value="">Загрузка...</option>
                </select>
            </div>

            <!--      <label for="">Получить обходной лист</label>-->
            <button class="btn btn-success pull-right">Получить обходной лист</button>
        </form>
    </div>
</div>


<script>

    $(document).ready(function () {
        // get_studs();
        // get_disc2();
    });

    $('#class2').on('changed.bs.select', function (e) {
        get_studs()
        $('#table').html('');
    });

    $('#disc').on('changed.bs.select', function (e) {
        get_studs()
    });

    function get_studs() {
        $('#table').html('<h4>Загрузка...</h4>');
        $.ajax({
            url: '/spravki/getStudlist',
            data: {class: $('#class2').val()},
            success: function (res) {
                $('#studs').html(res).selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function get_disc2() {
        $('#disc').html('<option value="">Загрузка...</option>').selectpicker('refresh');
        $.ajax({
            url: '/sheets/getDiscsxDist',
            type: 'get',
            data: {'class': $('#class2').val()},
            success: function (res) {
                $('#disc').html(res).val('').selectpicker('refresh');
                if ($('#disc option:not(:disabled)').length === 1) {
                    $('#disc').val($('#disc option:not(:disabled)').attr('value')).selectpicker('refresh');
                    get_studs()
                }
            },
            error: function () {
                $('#disc').html('').selectpicker('refresh');
                console.log('Error!');
            }
        });
    }
</script>
