<div class="panel panel-default">
  <div class="panel-heading">Получение справок/ведомостей</div>
  <div class="panel-body" style="padding: 15px;">
    <form action="/spravki/obhodnoy" method="get">
      <label for="">Получить обходной лист</label>
      <button class="btn btn-success pull-right">Получить</button>
    </form>
  </div>
</div>
