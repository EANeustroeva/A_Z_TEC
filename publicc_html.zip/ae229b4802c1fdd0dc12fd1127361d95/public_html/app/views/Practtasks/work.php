Загрузка...
<?php $url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '/'; ?>
<form id="myForm" action="<?= $url ?>" method="post">
    <?php
    foreach ($_POST as $a => $b) {
        echo '<input type="hidden" name="'.htmlentities($a).'" value="'.htmlentities($b).'">';
    }
    $_SESSION['info_msg'][] = 'Успешно сохранено!';
    ?>
</form>
<script type="text/javascript">
    document.getElementById('myForm').submit();
</script>