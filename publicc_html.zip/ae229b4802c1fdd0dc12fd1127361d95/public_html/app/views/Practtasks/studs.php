<div class="modal fade" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="exampleModalLabel">Тема работы</h4>
            </div>
            <div class="modal-body">
<!--            <form action="--><?//= BASE_URL ?><!--curstasks/docstitle?disc=--><?//= $_POST['disc'] ?><!--" method="post">-->
                <input type="hidden" name="type" value="кп">
                <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
                <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
                <input type="hidden" name="user_id" value="<?= $cur_user->id ?>">
                <input type="hidden" name="form" value="">
                <div class="form-group">
                    <label>Укажите тему работы</label>
                    <input type="text" class="form-control" name="title" value="<?= @$curs['title'] ?>" placeholder="Тема курсовой">
                </div>
                <div class="form-group">
                    <input type="hidden" name="id" value="0">
                    <input type="hidden" name="prep_id" value="<?= @$_POST['prep_id'] ?>">
                    <span id="save" type="submit" class="btn btn-success"><span class="glyphicon glyphicon-eye-open"></span>
                        Сохранить
                    </span>
                </div>
<!--            </form>-->
            </div>
        </div>
    </div>
</div>
<!--<div class="alert alert-warning fade in" role="alert">-->
<!--    <h3 style="margin: 0">Внимание, уважаемые студенты!</h3>-->
<!--    <hr> Работы с процентом оригинальности меньше 50% преподавателю отправлены не будут.-->
<!--</div>-->
<div class="alert alert-warning fade in" role="alert">Антиплагиат временно отключен!</div>

<div class="row">
    <div class="col-sm-8">
        <h5>Направление: <?= isset($plan['napr']) ? $plan['napr'] . ' ('. $plan['napr_n'] . ')' : 'Не найдено'?></h5>
        <h5>Профиль:     <?= isset($plan['dop']) ? $plan['dop'] : 'Не найдено'?></h5>
        <h4>Предмет:     <?= $_POST['disc'] ?></h4>
    </div>
<!--    --><?php //if (isset($plan['lektor'])): ?>
    <div class="col-sm-4">
        <form action="<?= BASE_URL ?>practtasks/view" method="post" style="display: inline" class="pull-right">
            <input type="hidden" name="id" value="0">
            <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
            <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
            <input type="hidden" name="prep_id" value="<?= isset($plan['user_id']) ? $plan['user_id'] : '' ?>">
<!--            <button type="submit" class="btn btn-success">-->
<!--                <span class="glyphicon glyphicon-eye-open"></span>&nbsp;Загрузить работу</button>-->
        </form>
    </div>
<!--    --><?php //endif; ?>
</div>

<?php
    if (empty($docs) && empty($rpd) && empty($fos)): echo '<div class="panel panel-default"><div class="panel-body"><h3 class="text-center" style="margin-bottom: 20px;">Документы по выбранному предмету не найдены</h3></div></div>';
else: ?>
<table class="table table-responsive table-bordered table-striped">

    <tbody>
        <?php if (!empty($rpd)): ?>
        <tr>
            <th>РПД:</th>
            <td colspan="2">
                <a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $rpd['fname']) . '&c=' . urlencode($rpd['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $rpd['ftitle'] ?></a>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($fos)): ?>
        <tr>
            <th>ФОС:</th>
            <td colspan="2">
                <a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $fos['fname']) . '&c=' . urlencode($fos['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $fos['ftitle'] ?></a>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($docs)): ?>
        <tr class="info"><th colspan="3">Задания:</th></tr>
        <tr>
            <th>Файл</th>
            <th>Комментарий</th>
            <th>Действие</th>
        </tr>
    <?php foreach ($docs as $i => $task): ?>
        <tr>
            <td><a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $task['fname']) . '&c=' . urlencode($task['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $task['ftitle'] ?></a></td>
            <td><?php
//                if (empty($task['descr']))  $task['descr']='-';
                if ($user->access==4)
                    if (!empty($task['descr'])) echo '<span tabindex="0" data-html="true" data-toggle="popover"
                      data-content="'. htmlspecialchars($task['descr']) .'" class="btn btn-xs btn-primary" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></span>';
//                mb_strimwidth($task['descr'], 0, 10, '..');
                else echo '<a href="tasks/workview?id='.$i.'">'.$task['descr'].'</a>' ?></td>
            <td>
                <?php if (!empty($task['taskfile'])): ?>
                <?php endif; ?>
                <?php if ($user->access!=4): ?>
                    <form action="<?= BASE_URL ?>tasks/edit" method="post" style="display: inline">
                        <input type="hidden" name="id" value="<?= $task['id'] ?>">
                        <input type="hidden" name="s" value="<?= $_GET['s'] ?>">
                        <button type="submit" class="btn btn-info btn-xs">
                            <span class="glyphicon glyphicon-edit"></span>&nbsp;<span
                                    class="hidden-xs">Изменить</span></button>
                    </form>
                <?php endif; ?>
<!--                --><?php //if (isset($plan['lektor'])): ?>
                <form action="<?= BASE_URL ?>tasks/view?disc=<?= $_GET['disc'] ?>" method="post" style="display: inline">
                    <input type="hidden" name="id" value="<?= $task['id'] ?>">
                    <input type="hidden" name="s" value="<?= $_GET['s'] ?>">
                    <input type="hidden" name="prep_id" value="<?= isset($plan['user_id']) ? $plan['user_id'] : '' ?>">
                    <button type="submit" class="btn btn-success btn-xs">
                        <span class="glyphicon glyphicon-eye-open"></span>&nbsp;<span
                                class="hidden-xs">Загрузить ответ</span></button>
                </form>
<!--                --><?php //endif; ?>
            </td>
        </tr>

    <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
<?php endif; ?>


<?php if ($_POST['disc'] && isset($plan['lektor'])): ?>
<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">Диалог с преподавателем <?= isset($plan['lektor']) ? "({$plan['lektor']})" : '' ?></div>
            <div class="panel-body">
                <div class="container-chat" style="min-height: 100px;
    max-height: 600px;">
                    <ul class="list-unstyled">
                        <?php if (empty($msg->thread)) echo '<p class="text-center">Нет сообщений</p>'; ?>
                        <?php if ($msg && $msg->buddy->more): ?>
                            <li id="load-more-wrap" style="text-align:center;padding: 10px 0;"><a
                                        onclick="javascript: load_thread(<?= $msg->buddy->d_id . ',' . $msg->buddy->limit ?>)"
                                        class="btn btn-xs btn-default" style="width:100%">Старые сообщения
                                    (<?= $msg->buddy->remaining ?>)</a></li>
                        <?php endif; ?>
                        <?php if (!empty($msg->thread)) foreach ($msg->thread as $item): ?>
                            <?php if (isset($msg)): ?>
                                <a class="message-bubble row <?php if ($item->status == 0) echo 'unread'; ?>"
                                   style="padding: 3px 5px 3px 0px;font-size: 0.85em;">
                    <span class="chat-img pull-left" style="padding-right: 10px;">
						<img src="<?= $item->avatar ?>" class="avt " style="height: 30px;">
					</span>
                                    <div class="chat-body" style="padding-left: 0;">
                                        <strong class="primary-font"><?= $item->name ?></strong>
                                        <small class="text-muted pull-right ">
                                            <span class="glyphicon glyphicon-time"></span>
                                            <?= date('g:i a', strtotime($item->time)) ?>
                                        </small>
                                        <p style="margin:0;"><?= $item->msg ?></p>
                                    </div>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <div class="panel-footer">
                <form action="<?= BASE_URL ?>users/dialog" method="post" class="input-group">
                    <input type="text" name="msg" class="form-control" autocomplete="off" autofocus required>
                    <!-- glyphicon glyphicon-file -->
                    <input type="hidden" name="usr_name"
                           value="<?= $plan['lektor'] ?>">
                    <input type="hidden" name="usr_id" value="<?= $plan['user_id'] ?>">
                    <span class="input-group-btn">
                    <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-pencil"></i></button>
                </span>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($marks)): ?>
<table class="table table-striped table-hover table-bordered">
    <thead>
        <tr>
            <th>Дата</th>
            <th>Работа</th>
            <th>Преподаватель</th>
            <th>Статус</th>
<!--            <th>% Ориг-ти</th>-->
            <th>Оценка</th>
            <th>К-й</th>
        </tr>
    </thead>
    <tbody>
<?php //dump($marks) ?>
    <?php foreach ($marks as $mark): ?>
        <tr>
            <td><?= date("H:i d/m/Y", strtotime($mark['created'])) ?></td>
            <td><?php if (!empty($mark['file'])): ?>
                    <a href="<?= 'upload/works/' . $mark['file'] ?>" class="btn btn-warning btn-xs"
                       target="_blank">
                        <span class="glyphicon glyphicon-download"></span>&nbsp;<span
                                class="hidden-xs">Скачать</span></a>
                <?php endif; ?></td>
            <td><?= $mark['teacher'] ?></td>
            <td><?php
                    if ($mark['status']==0) echo 'Ожидается проверка';
                    elseif ($mark['status']==1) echo 'Работа проверяется';
                    elseif ($mark['status']==2) echo 'Работа проверена';
                ?><div class="clear"></div>
                <form id="form1" class="form1" action="/practtasks/docs" target="_blank" method="post" style="width: 50%;float:left;">
                    <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
                    <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
                    <input type="hidden" name="user_id" value="<?= $cur_user->id ?>">
                    <?php if (empty($curs['title'])): ?>
                    <a style="width: 100%;" class="btn btn-default btn-xs" href="#commentModal" data-form="form1" data-toggle="modal"><span class="glyphicon glyphicon-download"></span>&nbsp;Cправка</a>
                    <?php else: ?>
                    <button style="width: 100%;" type="submit" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-download"></span>&nbsp;Cправка</button>
                    <?php endif; ?>
                </form>
                <form id="form2" class="form2" action="/practtasks/docsb" target="_blank" method="post" style="width: 50%;float:left;">
                    <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
                    <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
                    <input type="hidden" name="user_id" value="<?= $cur_user->id ?>">
                    <?php if (empty($curs['title'])): ?>
                    <a style="width: 100%;" class="btn btn-default btn-xs" href="#commentModal" data-form="form2" data-toggle="modal"><span class="glyphicon glyphicon-download"></span>&nbsp;Отзыв</a>
                    <?php else: ?>
                    <button style="width: 100%;" type="submit" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-download"></span>&nbsp;Отзыв</button>
                    <?php endif; ?>
                </form></td>
            <td><?php
                if (@$mark['mark']==6) echo 'зач';
                elseif (@$mark['mark']==7) echo 'на дораб.';
                else echo @$mark['mark'] ?></td>
            <td><?php if (!empty($mark['comment'])): ?>
                <?php $comment = '<span style="white-space: normal">'. str_replace("\n",'<br>',$mark['comment']) .'</span>' ?>
                <span tabindex="0" data-html="true" data-toggle="popover"
                      data-content="<?= htmlentities($comment) ?>" class="btn btn-xs btn-primary" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></span><?php endif; ?></td>
        </tr>
    <?php endforeach; ?>

    </tbody>
</table>
<?php endif; ?>

<div class="panel panel-default">
    <div class="panel-heading">Загрузить работу</div>
    <div class="panel-body">
        <div class="col-xs-12">
            <h4> </h4>
            <form action="<?= BASE_URL ?>practtasks/work?disc=<?= $_POST['disc'] ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="type" value="кп">
                <input type="hidden" name="sem" value="<?= $_POST['sem'] ?>">
                <input type="hidden" name="disc" value="<?= $_POST['disc'] ?>">
                <input type="hidden" name="user_id" value="<?= $cur_user->id ?>">
                <div class="form-group">
                    <label>Тема</label>
                    <input type="text" class="form-control" name="title" value="<?= @$curs['title'] ?>" placeholder="Тема">
                </div>
                <div class="form-group">
                    <input type = "file" name = "userfile" required/>
                    <span class="help-block">Прикрепить файл</span>
                    <div class="file-uploader"></div>
                </div>
                <div class="form-group">
                    <input type="hidden" name="id" value="0">
                    <input type="hidden" name="prep_id" value="<?= @$_POST['prep_id'] ?>">
                    <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-eye-open"></span> Загрузить работу</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $('#commentModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var modal = $(this);
        modal.find('input[name="form"]').val(button.data('form'));
    });
    $('#save').click(function () {
        var form = $('#commentModal input[name="form"]').val();
        $.ajax({
            url: base + 'practtasks/docstitle',
            type: 'post',
            data: {
                type: 'практ',
                sem:<?= $_POST['sem'] ?>,
                disc: '<?= $_POST['disc'] ?>',
                user_id:<?= $cur_user->id ?>,
                title: $('#commentModal input[name="title"]').val()
            },
            success: function (res) {
                $('.form1').find('a').remove();
                $('.form2').find('a').remove();
                $('.form1').append('<button style="width: 100%;" type="submit" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-download"></span>&nbsp;Справка</button>');
                $('.form2').append('<button style="width: 100%;" type="submit" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-download"></span>&nbsp;Отзыв</button>');
                $('#'+form).submit();
                $('#commentModal').modal('hide');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });
</script>

<style>
    .list-group-item {
        word-break: break-word;
    }
</style>

<script>
    var popOverSettings = {
    placement: 'left',
    container: 'body',
    trigger: 'focus',
    html: true,
    selector: '[data-toggle=popover]',
    content: function () {
        return $('#popover-content').html();
    }
};

$('body').popover(popOverSettings);

    $(document).ready(function () {

        $('.work').click(function () {
            var el = $(this);
            var id = el.data('id');
            $(this).html('<img src="/images/loader.gif" width="15">');

            $.ajax({
                url: '/tasks/test',
                type: 'get',
                data: {
                    id: id
                },
                success: function (res) {
//                    console.log(res);
                    if (res.success) {
                        el.parent().html(res.success + '%' +
                            '<a target="_blank" class="btn btn-xs btn-success pull-right" href="'+
                            res.pdf+ '" title="Полный отчет"><i class="glyphicon glyphicon-download-alt"></i></a>');
                    }
                    else {
                        if (res.error) alert(res.error);
                        else alert('Антиплагиат временно отключен! ');
                        el.parent().html('')
                    }
                },
                error: function (res) {
                    el.parent().html('');
                    if (res.error) alert(res.error);
                    else alert('Произошла ошибка! ');
                    console.log(res);
                }
            })
        });

        $('.check-perc').click(function () {
            var el = $(this);
            var id = el.data('id');
            var btn = el.html();
            el.html('<img src="/images/loader.gif" width="15">');
            $.ajax({
                url: '/practtasks/testcheck',
                type: 'get',
                data: {
                    id: id
                },
                success: function (res) {
                    el.html(btn);
                    if (Number(res) < 50) {
                        el.parent().parent().addClass('danger');
                        el.attr('disabled',true);
                    } else {
                        el.parent().parent().removeClass('danger');
                        el.attr('disabled',false);
                    }
                },
                error: function (res) {
                    el.html(btn);
                    console.log(res);
                }
            });
        });

    });
</script>
