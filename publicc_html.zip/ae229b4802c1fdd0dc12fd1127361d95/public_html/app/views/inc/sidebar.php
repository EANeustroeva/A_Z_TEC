<?php new \fw\widgets\language\Language(); ?>
<br><br>
<div class="recent">
    <h3><?php __('recent_posts');?></h3>
    <ul>
        <li><a href="#">Aliquam tincidunt mauris</a></li>
        <li><a href="#">Vestibulum auctor dapibus  lipsum</a></li>
        <li><a href="#">Nunc dignissim risus consecu</a></li>
        <li><a href="#">Cras ornare tristiqu</a></li>
    </ul>
</div>
<div class="categories">
    <h3><?php __('categories');?></h3>
    <ul>
        <li><a href="#">Vivamus vestibulum nulla</a></li>
        <li><a href="#">Integer vitae libero ac risus e</a></li>
        <li><a href="#">Vestibulum commo</a></li>
        <li><a href="#">Cras iaculis ultricies</a></li>
    </ul>
</div>
<div class="clearfix"></div>