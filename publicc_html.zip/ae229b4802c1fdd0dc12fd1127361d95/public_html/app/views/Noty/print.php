<table>
    <thead>
        <tr>
            <th>Студент</th>
            <th>Группа</th>
            <th>Профиль</th>
            <th>Направление</th>
            <?php if (!isset($_GET['id'])): ?>
                <th title="Номер уведомления">№</th>
            <?php endif; ?>
            <th>Ознакомлен</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($nys as $item): ?>
        <?php if (!empty($_GET['id']) && $item['noty_id']!=$_GET['id']) continue ?>
        <tr>
            <td><?=$users[$item['user_id']]['name']?></td>
            <td><?=$users[$item['user_id']]['class']?></td>
            <td><?=$users[$item['user_id']]['profile']?></td>
            <td><?=$users[$item['user_id']]['napr_post']?></td>
            <?php if (!isset($_GET['id'])): ?>
                <td><?=$item['noty_id']?></td>
            <?php endif; ?>
            <td><?=!empty($item['created']) ? date("d.m.Y H:i",strtotime($item['created'])):''?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>