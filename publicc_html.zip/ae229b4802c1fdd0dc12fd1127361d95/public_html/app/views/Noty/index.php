<a href="/noty//edit" class="btn btn-primary">Новое уведомление</a>
<a href="/noty/report" class="btn btn-warning">Полный отчет</a>
<a href="/noty/print" target="_blank" class="btn btn-warning">Печать полного отчета</a>
<hr>
<table class="table table-striped table-hover table-bordered table-responsive">
    <thead>
        <tr>
            <th>№</th>
            <th>Курсы</th>
            <th>Направления</th>
            <th>Группы</th>
            <!--            <th>Профили</th>-->
            <th>Студенты</th>
            <th>Заголовок</th>
            <th>Создан</th>
            <th>Действие</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($q as $item): ?>
        <tr class="<?= !$item['enabled'] ? 'warning' : '' ?>">
            <td><?= $item['id'] ?></td>
            <?php $ss = json_decode($item['course'],1); foreach ($ss as &$i) $i = $i+1;?>
            <td><?=implode(', ',$ss)?></td>
            <td><?=implode(', ',array_intersect_key($napr_list,array_flip(json_decode($item['napr'],1))))?></td>
            <td><?=implode(', ',json_decode($item['class'],1))?></td>
            <td><?=implode(', ',json_decode($item['users'],1))?></td>
            <td><?=$item['header']?></td>
            <td><?=date("d.m.Y H:i",strtotime($item['created']))?></td>
            <td>
                <a href="/noty/edit?id=<?= $item['id'] ?>" class="btn btn-primary btn-xs" style="margin-bottom: 5px;"><i class="glyphicon glyphicon-pencil"></i></a>
                <form action="/noty/delete" style="display:inline-block;" method="post">
                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                    <button class="btn btn-danger btn-xs" style="margin-bottom: 5px;"><i class="glyphicon glyphicon-remove"></i></button>
                </form>
                <a href="/noty/report?id=<?= $item['id'] ?>" class="btn btn-warning btn-xs" style="width: 100%;margin-bottom: 5px;">Отчет</a>
                <a href="/noty/print?id=<?= $item['id'] ?>" target="_blank" class="btn btn-warning btn-xs" style="width: 100%;margin-bottom: 5px;">Печать</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/select/1.2.5/css/select.dataTables.min.css">

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script>
    table = $('table').DataTable({
        stateSave: true,
        // "info":     false,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
        }
    });
</script>