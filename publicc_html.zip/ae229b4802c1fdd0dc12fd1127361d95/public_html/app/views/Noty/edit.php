<div id="mod" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body"></div>
            <div class="modal-footer">
                <a href="#" class="btn btn-success" data-dismiss="modal">Ознакомлен</a>
            </div>
        </div>
    </div>
</div>
<form action="<?= BASE_URL ?>noty/save" method="post" class="form-horizontal">
    <div class="panel panel-default">
        <div class="panel-heading">
            Редактирование уведомления
            <div class="checkbox pull-right" style="padding: 0;line-height: 1;">
                <label><input type="checkbox" name="enabled" <?= @$q['enabled'] ? 'checked' : '' ?>>Активно</label>
            </div>
        </div>
        <div class="panel-body" style="padding: 15px;">
            <h4></h4>

            <div class="form-group">
                <div class="col-xs-6">
                    <div class="row">
                        <label for="" class="col-xs-5">Преподаватель</label>
                        <div class="col-xs-7">
                            <select class="selectpicker form-control" name="users[]" id="prep" title="Преподаватель" multiple
                                    data-live-search="true" data-actions-box="true" data-size="10">
                            </select>
                        </div>
<!--                        <label for="" class="col-xs-5">Кому показывать</label>-->
<!--                        <div class="col-xs-7">-->
<!--                            <select id="type" class="form-control selectpicker">-->
<!--                                <option value="4">Студент</option>-->
<!--                                <option value="3">Преподаватель</option>-->
<!--                            </select>-->
<!--                        </div>-->
                    </div>
                </div>
                <div class="col-xs-6">
                    <div class="row">
                        <label for="type" class="col-xs-5">Тип уведомления</label>
                        <div class="col-xs-7">
                            <select id="type" name="type" class="selectpicker form-control ">
                                <option value="1" <?= !empty($q['type']) ? 'selected' : '' ?>>Одноразовое</option>
                                <option value="0" <?= empty($q['type']) ? 'selected' : '' ?>>Пока включено</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <hr style="margin: 10px -15px;">

            <div id="relation">
                <div class="form-group">
                    <div class="col-xs-6">
                        <div class="row">
                            <label for="" class="col-xs-4">Направление</label>
                            <div class="col-xs-8">
                            <select name="napr[]" id="napr" class="selectpicker form-control" multiple>
                                <?php foreach ($napr_list as $k => $item): ?>
                                    <?php $s = '';
                                    if (isset($q) && !empty($q['napr'])) {
                                        $s = in_array($k, json_decode($q['napr'], 1)) ? ' selected' : '';
                                    } ?>
                                    <option <?= $s ?> value="<?= $k ?>"><?= $item ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        </div>
                    </div>
                    <div class="col-xs-6">
                        <div class="row">
                            <label for="" class="col-xs-4">Группа</label>
                            <div class="col-xs-8">
                            <select class="selectpicker form-control" name="class[]" id="class" title="Группа" multiple
                                    data-live-search="true" data-actions-box="true" data-size="10">
                            </select>
                        </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-xs-6">
                        <div class="row">
                            <label for="" class="col-xs-4">Год зачисления</label>
                            <div class="col-xs-8">
                            <?php $arr = @json_decode($q['course'], 1) ?>
                            <select name="course[]" id="course" class="selectpicker form-control" multiple>
                                <option <?= in_array(0, $arr) ? 'selected ' : '' ?>value="0">2018</option>
                                <option <?= in_array(1, $arr) ? 'selected ' : '' ?>value="1">2017</option>
                                <option <?= in_array(2, $arr) ? 'selected ' : '' ?>value="2">2016</option>
                                <option <?= in_array(3, $arr) ? 'selected ' : '' ?>value="3">2015</option>
                                <option <?= in_array(4, $arr) ? 'selected ' : '' ?>value="4">2014</option>
                            </select>
                        </div>
                        </div>
                    </div>

                    <div class="col-xs-6">
                        <div class="row">
                            <label for="" class="col-xs-4">Студент</label>
                            <div class="col-xs-8">
                                <select class="selectpicker form-control" name="users[]" id="users" title="Студент" multiple
                                        data-live-search="true" data-actions-box="true" data-size="10">
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <hr style="margin: 10px -15px;">

            <div class="form-group">
                <div class="col-xs-12">
                    <label for="msgd">Заголовок:</label>
                    <input type="text" class="form-control" name="header" value="<?= @$q['header'] ?>">
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12">
                    <label for="msgd">Сообщение:</label>
                    <textarea class="form-control" id="editor1" name="msg" rows="10"><?= @$q['msg'] ?></textarea>
                </div>
            </div>

        </div>
        <div class="panel-footer">
            <input type="hidden" name="id" value="<?= @$_GET['id'] ?>">
            <button type="submit" class="btn btn-success">Сохранить</button>
            <a href="/noty" class="btn btn-default">Назад</a>
            <a href="#" data-toggle="modal" data-target="#mod" class="btn btn-warning pull-right">Показать</a>
        </div>
    </div>
</form>

<div id="tmp" style="display: none">

</div>

<?php
/*
  <script type="text/javascript" src="/js/tinymce/tinymce.min.js?apiKey=skjd0gy9vnw43ubn4q52n9w7bv6hskiw9yfchm9pdi30nfum"></script>
<!-- TinyMCE -->
<script>
tinymce.init({
    selector: '#editor1',
    language:"ru",
    height: 400
});
</script>
<!-- /TinyMCE -->
 */
?>
<script src="/js/ckeditor/ckeditor.js"></script>
<script src="/js/elfinder/js/elfinder.min.js"></script>
<script src="/js/elfinder/js/i18n/elfinder.ru.js"></script>
<script src="/js/jquery-ui/jquery-ui.min.js"></script>
<link rel="stylesheet" href="/js/jquery-ui/jquery-ui.min.css">
<link rel="stylesheet" href="/js/elfinder/css/elfinder.min.css ">
<script src="/js/ckeditor/load.js"></script>
<script>
    // setup CKEditor
    let editor = CKEDITOR.replace('editor1', {});

    $('#mod').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var modal = $(this);
        modal.find('.modal-title').text($('input[name=header]').val());
        modal.find('.modal-body').html(editor.getData());
        modal.find('.modal-footer a').text($('#type').val()==="1"? 'Ознакомлен' : 'OK')
    });

    function get_classes() {
        $.ajax({
            url: '/noty/getclasslist',
            type: 'post',
            data: {'course': $('#course').val()},
            success: function (res) {
                $('#class').html(res).selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function get_studs() {
        $.ajax({
            url: '/noty/getstudlist',
            type: 'post',
            data: {'class': $('#class').val()},
            success: function (res) {
                $('#users').html(res).selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function get_preps() {
        $.ajax({
            url: '/noty/getpreplist',
            type: 'post',
            success: function (res) {
                $('#prep').html(res).selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    $('#course').on('changed.bs.select', function (e) {
        get_classes()
    });
    $('#class').on('changed.bs.select', function (e) {
        get_studs()
    });

    $('#type').on('changed.bs.select', function (e) {
        exchange()
    });

    function exchange() {
        // let element = $('#relation > *').detach();
        // let prev = $('#tmp > *').detach();
        // $('#tmp').append(element);
        // $('#relation').append(prev);
    }

    // let user_type = $('#type').val();
    // if (user_type == 3) exchange();

    $(document).ready(function () {
        $.ajax({
            url: '/noty/getpreplist',
            type: 'post',
            success: function (res) {
                let selected = <?=@$q['users'] ?: '""'?>;
                $('#prep').html(res).val(selected).selectpicker('refresh');
                if ($('#prep').val()!==null && $('#prep').val().length > 0) {
                    $('#type').val(3).selectpicker('refresh');
                    exchange()
                }
            },
            error: function () {
                console.log('Error!');
            }
        });
        // if (user_type == 4) {
            let selected = <?=@$q['class'] ?: '""'?>;
            $.ajax({
                url: '/noty/getclasslist',
                type: 'post',
                data: {'course': $('#course').val()},
                success: function (res) {
                    $('#class').html(res).val(selected).selectpicker('refresh');
                    selected = <?=@$q['users'] ?: '""'?>;
                    $.ajax({
                        url: '/noty/getstudlist',
                        type: 'post',
                        data: {'class': $('#class').val()},
                        success: function (res) {
                            $('#users').html(res).val(selected).selectpicker('refresh');
                        },
                        error: function () {
                            console.log('Error!');
                        }
                    });
                },
                error: function () {
                    console.log('Error!');
                }
            });
        // }
    });
</script>