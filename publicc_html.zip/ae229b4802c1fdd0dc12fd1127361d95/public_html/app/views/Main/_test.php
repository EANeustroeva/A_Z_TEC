<h1><?= $post['title'] ?></h1>
<div><?= $post['text'] ?></div>