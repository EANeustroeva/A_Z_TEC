<form action="<?= BASE_URL ?>docsnext/uploaduch" method="post" enctype="multipart/form-data">

<div class="col-sm-4">
    <div class="panel panel-success">
        <div class="panel-body">
            <!--<div class="form-group">
                <select class="selectpicker form-control" id="asgmt" title="Назначение">
                    <option selected value="1">Группа</option>
                    <option value="2">Курс</option>
                </select>
            </div>-->
            <?php if ($cur_user->access == 1 || $cur_user->access == 3): ?>
            <div class="form-group">
                <select class="selectpicker form-control" name="course" id="course" title="Год поступления">
                    <?php for ($i=0; $i < 6; $i++): ?>
                    <?php $sel = $event ? ($event->course == $i ? 'selected' : '') : '' ?>
                    <option <?= $sel ?> value="<?= $i ?>"><?= (2018 - $i) ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="form-group">
                <select class="selectpicker form-control" name="sem" id="sem" title="Семестр">
                    <?php for ($i=1; $i < 9; $i++): ?>
                    <?php $sel = $event ? ($event->sem == $i ? 'selected' : '') : '' ?>
                    <option <?= $sel ?> value="<?= $i ?>"><?= $i ?>  семестр</option>
                    <?php endfor; ?>
                </select>
            </div>
            <?php endif; ?>

            <div class="form-group">
                <select required class="selectpicker form-control" name="class" id="class" title="Группа"
                        data-live-search="true">
                </select>
            </div>

            <div class="form-group">
                <select required class="selectpicker form-control" name="disc" id="disc" title="Предмет" data-live-search="true">
                </select>
            </div>
            <button class="btn btn-success" type="submit">Сохранить</button>
            <a href="/docsnext" class="btn btn-default" type="submit">Назад</a>
        </div>
    </div>
</div>
<div class="col-sm-8">
    <div class="panel panel-default">
        <div class="panel-body">
            <div class="form-group">
                <label for="">Ранее загруженный файл</label>
                <select class="selectpicker form-control" name="fileb" title="Ранее загруженный файл" data-live-search="true">
                    <?php foreach ($fileb as $item): ?>
                    <?php $sel = $event ? ($event->id == $item->id ? 'selected' : '') : '' ?>
                    <option <?= $sel ?> value="<?= $item->id ?>"><?= $item->ftitle ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <input type="file" name="file" >
            <input type="hidden" name="id" value="<?= $event ? $event->id : '' ?>">
            <hr>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                    <label for="">Дата начала события</label>
                    <div class="input-group date">
                        <?php $start = $event && $event->napr ? explode('|', $event->napr)[0] : date('d.m.Y') ?>
                        <input type="text" class="datepicker form-control" name="start" value="<?= $start ?>">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                    </div>
                </div>
                </div>
                <div class="col-sm-6">
                <div class="form-group">
                    <label for="">Дата конца события</label>
                    <div class="input-group date">
                        <?php $end = $event && $event->napr ? explode('|', $event->napr)[1] : date('d.m.Y') ?>
                        <input type="text" class="datepicker form-control" name="end" value="<?= $end ?>">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                    </div>
                </div>
            </div>
            </div>
            <div class="form-group">
                <label for="">Цвет события</label>
                <div class="bfh-colorpicker" data-color="<?= $event->descr ?: '#3a87ad' ?>" data-name="color">
                </div>
            </div>
            <hr>
            <div class="form-group">
                <label for="">Связанные тесты</label>
                <select class="selectpicker form-control" name="test[]" title="Тесты" data-live-search="true" data-multipleSeparator="|" multiple>
                    <?php foreach ($tests as $test): ?>
                    <?php $sel = $event ? (in_array($test->id,explode('|',$event->dop)) ? 'selected' : '') : '' ?>
                    <option <?= $sel ?> value="<?= $test->id ?>"><?= $test->title ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>
</div>

</form>

<script src="/bootstrap/js/bootstrap-formhelpers.min.js"></script>
<link rel="stylesheet" href="/bootstrap/css/bootstrap-formhelpers.min.css">
<style>
    .panel-body { padding: 15px; }
</style>
<script>
    $(document).ready(function () {
        $('.datepicker').datepicker({
            language: 'ru',
            format: 'dd.mm.yyyy',
            todayHighlight: true,
            autoclose: true
        });

        $('#sem').val('<?= $event ? $event->sem : '' ?>').selectpicker('refresh');

        get_list();

    });

    $('#sem').on('changed.bs.select', function (e) { get_discs() });
    $('#class').on('changed.bs.select', function (e) { get_discs() });

    function get_discs() {
        var cl = '<?= $event ? $event->class : '' ?>';
        $.ajax({
            url: 'getListDisc',
            type: 'get',
            data: {'class': cl === '' ? $('#class').val() : cl ,'sem': $('#sem').val()},
            success: function (res) {
                $('#disc').html(res.res4).val('').selectpicker('refresh');
                $('#disc').val('<?= $event ? $event->disc : '' ?>').selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function get_list() {
        $.ajax({
            url: 'getList',
            type: 'get',
            data: {'course': $('#course').val()},
            success: function (res) {
                $('#class').html(res).selectpicker('refresh');
                var cl = '<?= $event ? @$event->class : '' ?>';
                if (cl) $('#class').val(cl).selectpicker('refresh');
                get_discs()
            },
            error: function () {
                $('#class').html('').selectpicker('refresh');
                console.log('Error!');
            }
        });
    }
</script>