<!--<a class="btn btn-success" href="--><?//= BASE_URL ?><!--docs/edit">Загрузить новый файл</a>-->
<!--<hr>-->
<?php
if (empty($mfiles)):
	echo '<div class="panel panel-default"><div class="panel-body"><h3 class="text-center" style="margin-bottom: 20px;">Документы отсутствуют</h3></div></div>';
            else: 
                echo $mfiles;
            endif; ?>
<style>
.menu .accordion-heading {  position: relative; }
.menu .accordion-heading .edit {
    position: absolute;
    top: 8px;
    right: 30px; 
}
#collapse0 .area { border-left: 4px solid #f38787; }
#collapse0 .equipamento { border-left: 4px solid #65c465; }
#collapse0 .ponto { border-left: 4px solid #98b3fa; }
#collapse0 .collapse.in { overflow: visible; }
#collapse0 .panel-body { padding: 15px; }
.panel-group .panel+.panel { margin-top: 0px; }
#collapse0 .panel-default>.panel-heading { background-color: transparent; }
</style>