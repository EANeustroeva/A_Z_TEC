<?php

$cal_month = $this_month = date( 'm');
$cal_year = date( 'Y');

	$next = true;

	if( intval( $cal_year . $cal_month ) >= date( 'Ym' )) $next = false;

	$cur_date=date( 'Ymj', time());
	$cal_date = $cal_year.$cal_month;

	$cal_month = intval( $cal_month );
	$cal_year = intval( $cal_year );

	if( $cal_month < 0 ) $cal_month = 1;
	if( $cal_year < 0 ) $cal_year = 2018;

	$first_of_month = mktime( 0, 0, 0, $cal_month, 7, $cal_year );
	$maxdays = date( 't', $first_of_month ) + 1; // 28-31
	$prev_of_month = mktime( 0, 0, 0, ($cal_month - 1), 7, $cal_year );
	$next_of_month = mktime( 0, 0, 0, ($cal_month + 1), 7, $cal_year );
	$cal_day = 1;
	$weekday = date( 'w', $first_of_month ) + 1; // 0-6

?>
<div class="col-sm-9">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="form-inline">
                    <div class="form-group">
                        <select required class="selectpicker form-control" name="course" id="course" title="Год поступления">
                            <option selected value="0">2018</option>
                            <option value="1">2017</option>
                            <option value="2">2016</option>
                            <option value="3">2015</option>
                            <option value="4">2014</option>
                            <option value="5">2013</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <select required class="selectpicker form-control" name="sem" id="sem" title="Семестр">
                            <option selected value="1">1 семестр</option>
                            <option value="2">2 семестр</option>
                            <option value="3">3 семестр</option>
                            <option value="4">4 семестр</option>
                            <option value="5">5 семестр</option>
                            <option value="6">6 семестр</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <select required class="selectpicker form-control" name="class" id="class" title="Группа" data-live-search="true">
                        </select>
                    </div>

                    <div class="form-group">
                        <select required class="selectpicker form-control" name="disc" id="disc" title="Предмет" data-live-search="true">
                        </select>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <table id="edTableCalendar"><tr>
                    <td class="edMonthLink edPrevMonth" rowspan="2" data-month="<?= date( 'm', $prev_of_month ) ?>" data-year="<?= date( 'Y', $prev_of_month ) ?> " title="Предыдущий месяц"></td>
<?php

$trueColpsan = $maxdays - 1;

?>
                    <td class="edMonth" colspan="<?= $trueColpsan ?>"><?= /*date( 'F', $first_of_month )*/ 'Август'  . ' ' . $cal_year?></td>
                    <td class="edMonthLink edNextMonth <?= ( !$next ? ' edNo' : '' ) ?>" rowspan="2" data-month="<?= date( 'm', $next_of_month ) ?>" data-year="<?= date( 'Y', $next_of_month ) ?>" title="Следующий месяц"></td></tr><tr>
                <?php while ( $maxdays > $cal_day ): ?>
                    <?php
                        if($weekday > 6 ) $weekday = 0;
                        $wd = $cal_day . '<span>' . '' . '</span>'; // weekdays
		                $cal_pos = $cal_date.$cal_day;
                    ?>
                    <td class="<?= (($weekday == '6' || $weekday == '0') ? 'edWeekEnd ' : '' ) . (($cal_pos==$cur_date) ? 'edCurrentDay' : '') ?>"><?= $wd ?></td>
                    <?php $cal_day ++; $weekday ++; ?>
                <?php endwhile; ?>
                    </tr>
                </table>

                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            </div>
        </div>
    </div>
</div>
<div class="col-sm-3">
    <h4>Пулл видео</h4>
    <div class="well well-sm">
        <h4> </h4>
    </div>

    <h4>Пулл тестов</h4>
    <div class="well well-sm">
        <h4> </h4>
    </div>
</div>

<script src="<?= BASE_URL?>js/filter.js?r=5"></script>
<link rel="stylesheet" href="/edCalendar/style.css">
<script>
    $(document).ready(function () {
        get_list();
    });

    /*$("#edTableCalendar .edMonthLink:not(.edNo)").live("click", function(){
        $(this).parent().find(".edMonth").addClass("edLoading");
        $.get(dle_root + "engine/modules/edCalendar/ajaxHorizontal.php", { month: $(this).data('month'), year: $(this).data('year') }, function(data){
            $(this).parent().find(".edMonth").removeClass("edLoading");
            $("#edTableCalendar").html(data);
        });
    });*/
</script>