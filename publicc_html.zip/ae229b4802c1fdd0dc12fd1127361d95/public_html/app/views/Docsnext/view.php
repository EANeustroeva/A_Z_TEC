<div class="row">

    <div class="col-sm-12">
        <h2>Направление: <?= $plan['napr'] ?> <?= $plan['napr_n'] ?></h2>
        <h3>Профиль:     <?= $plan['dop'] ?></h3>
        <h4>Предмет:     <?= $_POST['disc'] ?></h4>
        <?php
        if (empty($docs)): echo '<div class="panel panel-default"><div class="panel-body"><h3 class="text-center" style="margin-bottom: 20px;">Документы по выбранному предмету не найдены</h3></div></div>';
        else: ?>
            <ul class="list-group">
                <?php foreach ($docs as $item): ?>
                    <a class="list-group-item"
                       href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $item['fname']) . '&c=' . urlencode($item['ftitle']) ?>"><i
                                class="glyphicon glyphicon-open-file"></i> <?= $item['ftitle'] ?> <?php if (!empty($item['dop'])): ?>
                            <small style="float: right;">(Профиль - <?= $item['dop'] ?>)</small><?php endif; ?></a>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    <?php if (isset($plan['lektor'])): ?>
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">Диалог с преподавателем <?= isset($plan['lektor']) ? "({$plan['lektor']})" : '' ?></div>
            <div class="panel-body">
                <div class="container-chat">
                    <ul class="list-unstyled">
                        <?php if (empty($msg->thread)) echo '<p class="text-center">Нет сообщений</p>'; ?>
                        <?php if ($msg->buddy->more): ?>
                            <li id="load-more-wrap" style="text-align:center;padding: 10px 0;"><a
                                        onclick="javascript: load_thread(<?= $msg->buddy->d_id . ',' . $msg->buddy->limit ?>)"
                                        class="btn btn-xs btn-default" style="width:100%">Старые сообщения
                                    (<?= $msg->buddy->remaining ?>)</a></li>
                        <?php endif; ?>
                        <?php if (!empty($msg->thread)) foreach ($msg->thread as $item): ?>
                            <?php if (isset($msg)): ?>
                                <a class="message-bubble row <?php if ($item->status == 0) echo 'unread'; ?>"
                                   style="padding: 3px 5px 3px 0px;font-size: 0.85em;">
                    <span class="chat-img pull-left" style="padding-right: 10px;">
						<img src="<?= $item->avatar ?>" class="avt " style="height: 30px;">
					</span>
                                    <div class="chat-body" style="padding-left: 0;">
                                        <strong class="primary-font"><?= $item->name ?></strong>
                                        <small class="text-muted pull-right ">
                                            <span class="glyphicon glyphicon-time"></span>
                                            <?= date('g:i a', strtotime($item->time)) ?>
                                        </small>
                                        <p style="margin:0;"><?= $item->msg ?></p>
                                    </div>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <div class="panel-footer">
                <form action="<?= BASE_URL ?>users/dialog" method="post" class="input-group">
                    <input type="text" name="msg" class="form-control" autocomplete="off" autofocus required>
                    <!-- glyphicon glyphicon-file -->
                    <input type="hidden" name="usr_name"
                           value="<?= $plan['lektor'] ?>">
                    <input type="hidden" name="usr_id" value="<?= $plan['user_id'] ?>">
                    <span class="input-group-btn">
                    <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-pencil"></i></button>
                </span>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<script>
     $(document).ready(function () {
        function setHeiHeight() {
            newheight = $(window).height() - 1070;
            if (newheight < 100) newheight = 100;
            $('.container-chat').css({
                height: newheight + 'px'
            });
        }

        setHeiHeight();
        $(window).resize(setHeiHeight);
    });
</script>