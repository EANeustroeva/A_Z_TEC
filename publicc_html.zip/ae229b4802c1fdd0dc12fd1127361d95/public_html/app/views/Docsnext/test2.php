<div class="row" style="margin-left: 0">
    <div class="panel panel-default">
        <div class="panel-heading">
            <div class="form-inline">
                <div class="form-group">
                    <select required class="selectpicker form-control" name="course" id="course" title="Год поступления">
                        <option value="0" selected>2018</option>
                        <option value="1">2017</option>
                        <option value="2">2016</option>
                        <option value="3">2015</option>
                        <option value="4">2014</option>
                        <option value="5">2013</option>
                    </select>
                </div>

                <div class="form-group">
                    <select required class="selectpicker form-control" name="sem" id="sem" title="Семестр">
                        <option selected value="1">1 семестр</option>
                        <option value="2">2 семестр</option>
                        <option value="3">3 семестр</option>
                        <option value="4">4 семестр</option>
                        <option value="5">5 семестр</option>
                        <option value="6">6 семестр</option>
                    </select>
                </div>

                <div class="form-group">
                    <select required class="selectpicker form-control" name="class" id="class" title="Группа" data-live-search="true">
                    </select>
                </div>

                <div class="form-group">
                    <select required class="selectpicker form-control" name="disc" id="disc" title="Предмет" data-live-search="true">
                    </select>
                </div>
                <div class="form-group pull-right">
                    <a href="/docsnext/instruct" class="btn btn-default" ><i class="glyphicon glyphicon-question-sign"></i> Инструкция</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-9">
        <div id="calendar" style="padding-bottom: 15px"></div>
    </div>
    <div class="col-sm-3">
        <div class="row">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="col-xs-12">
                        <div id="event-info">

                            <h4> </h4>
                <div class="form-group">
                    Для группы: <span class="text-danger"> </span><hr>
                    По предмету: <span class="text-danger"> </span><hr>
                    Выбран файл: <span class="text-danger"> </span><hr>
                    Семестр: <span class="text-danger"> </span><hr>
                    Дата начала события: <span class="text-danger"> </span><hr>
                    Дата конца события: <span class="text-danger"> </span>

                    <hr>
                <b class="text-danger" style="font-size: 1.3em;">Выберите событие</b>
            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div id="external-events" style="margin-bottom: 15px;">
            <h4>Пулл событий</h4>
                <?php if (empty($docs)) echo '<span class="text-muted">Пусто</span>'?>
            <?php foreach ($docs as $doc): ?>
                <a href="/docsnext/edit?id=<?= $doc->id ?>" class="btn-xs fc-event" data-toggle="tooltip" title="" data-original-title=""><span class="del" data-id="<?= $doc->id ?>" style="cursor:pointer;float:right;"> ×</span><?= $doc->ftitle ?></a>
            <?php endforeach; ?>
            </div>
            <div class="form-group">
                <a class="btn btn-success form-control" href="/docsnext/edit">Добавить событие</a>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-9">
        <iframe src="https://view.officeapps.live.com/op/embed.aspx?src=<?= urlencode('http://lib.wbstatic.usue.ru/video/Video.xlsx') ?>&embedded=true" style="width:100%;height:400px" frameborder="0"></iframe>
    </div>
    <div class="col-sm-3">
        <?php if (!empty($missed)): ?>
            <div class="row">
                <div style="max-height: 400px;overflow-y: auto;">
                <table class="table table-bordered table-condensed table-striped" style="margin: 0;">
                <?php foreach ($missed as $k=>$item): ?>
                    <tr <?= empty($item)?'class="danger"':'' ?>>
                        <td><a href="#" data-toggle="modal" data-target="#exampleModal" data-whatever="<?= $k ?>"><?= $k ?></a></td>
                        <td style="font-size: .7em; text-align: left;"><?= implode(', ',$item) ?></td>
                    </tr>
                <?php endforeach; ?>
                </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="/js/sweetalert2.all.min.js"></script>
<script src="/js/moment.js"></script>
<link href="https://vjs.zencdn.net/7.6.5/video-js.css" rel="stylesheet">
<script src='https://vjs.zencdn.net/7.6.5/video.js'></script>

<script>
var player;

function videoHTML(videoNumber) {
    return '<video id="video-js" class="video-js vjs-default-skin" ' +
        'controls preload="auto" width="600" height="300" ' +
        'data-setup=\'{"example_option":true}\'>' +
        '\t<source src="http://lib.wbstatic.usue.ru/video/' + videoNumber + '.mp4" type="video/mp4" /> \n' +
        '\t\t<p class="vjs-no-js">To view this video please enable JavaScript, and consider upgrading to a web browser that <a href="http://videojs.com/html5-video-support/" target="_blank">supports HTML5 video</a></p>\n' +
        '</video>';
}

$('#exampleModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var modal = $(this);
    player.dispose();
    var html = videoHTML(button.data('whatever'));
    modal.find('.modal-body').html(html);
    player = videojs('#video-js');
})

$('#exampleModal').on('hide.bs.modal', function (event) {
    player.dispose();
    $('#exampleModal .modal-body').html(videoHTML('usue_6'));
    player = videojs('#video-js');
})
$(document).ready(function () {
    $('#exampleModal .modal-body').html(videoHTML('usue_6'));
    player = videojs('#video-js');
});
</script>
<style>
#video-js {
    margin: 0 auto;
}
.video-js .vjs-big-play-button {
    top: 40%;
    left: 40%;
}
/* video container */
.video-background {
    width: 600px;
    height: 300px;
    background-color: black;
    float:left;
}

/* captions/subtitles container */
.vjs-text-track-display {
    position: absolute !important;
    left: 600px !important;
    top: 10px !important;
    width: 600px;
    display: block;
    z-index: 10000000 !important;
}

/* actual captions/subtitles. The text can be styled here.  */
.text-background {
    width: 600px;
    height: 300px;
    background-color: black;
    float:left;
}
</style>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
<!--      <div class="modal-header">-->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<!--      </div>-->
      <div class="modal-body text-center">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
      </div>
    </div>
  </div>
</div>
<style>
  #external-events {
    float: left;
    width: 100%;
    padding: 0 10px;
    border: 1px solid #ccc;
    background: #eee;
    text-align: left;
  }

  #external-events h4 {
    font-size: 16px;
    margin-top: 0;
    padding-top: 1em;
  }

  #external-events .fc-event {
    margin: 10px 0;
    cursor: pointer;
  }

  /*#external-events p {*/
    /*margin: 1.5em 0;*/
    /*font-size: 11px;*/
    /*color: #666;*/
  /*}*/

  #external-events p input {
    margin: 0;
    vertical-align: middle;
  }
</style>
<script src="<?= BASE_URL?>js/filter.js?r=5"></script>
<link rel='stylesheet' href='<?= BASE_URL ?>js/fullcalendar/fullcalendar.min.css'/>
<script src='<?= BASE_URL ?>js/fullcalendar/moment.min.js'></script>
<script src='<?= BASE_URL ?>js/jquery-ui.js'></script>
<script src='<?= BASE_URL ?>js/fullcalendar/fullcalendar.min.js'></script>
<script src='<?= BASE_URL ?>js/fullcalendar/ru.js'></script>
<link rel="stylesheet" href="/edCalendar/style.css">
<script>
    $(document).ready(function () {
        get_list();

        // initialize();

        $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,agendaWeek'
            },
            height: 'auto',
            editable: true,
            droppable: true,
            businessHours: true,
            events: {
                url: '/docsnext',
                type: 'get',
                cache: false,
                data: function() {
                    return {
                        course: $('#course').val(),
                        sem: $('#sem').val(),
                        class: $('#class').val(),
                        disc: $('#disc').val(),
                        view: $('#calendar').fullCalendar('getView').name
                    };
                }
            },
            eventClick: function(calEvent, jsEvent, view) {
                // alert('Event: ' + calEvent.id);
                $.ajax({
                    url: base + "docsnext/getinfo",
                    type: "post",
                    data: {id: calEvent.id},
                    success: function (response) {
                        update();
                        // alert(response.id)
                        $('#event-info').html(response)
                    }
                });
            },
            viewRender: function (view, element) {
                var b = $('#calendar').fullCalendar('getDate');
                $.ajax({
                    url: base + "docsnext/getsem",
                    type: "get",
                    data: {
                        date: b.format('L'),
                        class: $('#class').val()
                    },
                    success: function (response) {
                        $('#sem').val(response).selectpicker('refresh');
                        $('#calendar').fullCalendar('refetchEvents');
                        update();
                    },
                    error: function () {
                        $('#sem').val(1).selectpicker('refresh');
                    }
                });

                update();
                // alert(b.format('L'));

            }
        });

        $('.selectpicker').on('changed.bs.select', function (e) {
            $('#calendar').fullCalendar('refetchEvents');
            update();
        });

        $('#class').on('changed.bs.select', function (e) {
            var b = $('#calendar').fullCalendar('getDate');
            $.ajax({
                url: base + "docsnext/getsem",
                type: "get",
                data: {
                    date: b.format('L'),
                    class: $(this).val()
                },
                success: function (response) {
                    $('#sem').val(response).selectpicker('refresh');
                    $('#calendar').fullCalendar('refetchEvents');
                    update();
                },
                error: function () {
                    $('#calendar').fullCalendar('refetchEvents');
                    $('#sem').val(1).selectpicker('refresh');
                }
            });
        });

        $('body').on('click','.del',function () {
           var id = $(this).data('id');
           // var id = this.parentNode.id;

            $.ajax({
                url: base + "docsnext/delete",
                type: "post",
                data: {id: id},
                success: function (response) {
                    $('#calendar').fullCalendar('refetchEvents');
                    $('#event-info').html('');
                    update();
                }
            });

        });
    });

    function update() {
        $.ajax({
            url: '/docsnext/getvideos',
            type: 'get',
            data: {
                course: $('#course').val(),
                sem: $('#sem').val(),
                class: $('#class').val(),
                disc: $('#disc').val()
            },
            success: function (res) {
                if (res) $('#external-events').html('<h4>Пулл видео</h4>' + res);
                else $('#external-events').html('<h4>Пусто</h4>');
                // initialize();
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function initialize() {
        /* initialize the external events
    -----------------------------------------------------------------*/

        $('#external-events .fc-event').each(function() {

          // store data so the calendar knows to render an event upon drop
          $(this).data('event', {
            title: $.trim($(this).text()), // use the element's text as the event title
            stick: true // maintain when user navigates (see docs on the renderEvent method)
          });

          // make the event draggable using jQuery UI
          $(this).draggable({
            zIndex: 999,
            revert: true,      // will cause the event to go back to its
            revertDuration: 0  //  original position after the drag
          });

        });
    }

</script>