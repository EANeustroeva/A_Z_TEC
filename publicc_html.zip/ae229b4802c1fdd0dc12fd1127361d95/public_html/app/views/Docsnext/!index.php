<div class="col-sm-12">
    <ul class="nav nav-tabs">
        <li class="active"><a href="#private" data-toggle="tab">Личные</a></li>
        <li><a href="#mfiles" data-toggle="tab">Учебные документы</a></li>
        <li><a href="#norm" data-toggle="tab">Нормативные документы</a></li>
        <li><a href="#plan" data-toggle="tab">Учебный план</a></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane fade in active" id="private">
            <div style="position: relative;" class="uploader">
                <div style="margin-top: 5px" id="file-uploader"></div>
                <i data-toggle="tooltip" title="Инструкция" style="position: absolute; left: 50%; margin-left: 60px;top: 0px; color: #337ab7; font-size: 18px; cursor:pointer;" class="glyphicon glyphicon-info-sign"></i>
                <div class="progress">
                    <div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" aria-valuenow="<?= $full_size ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?= $full_size ?>%">
                        <span style="width: 100%;"><?= $full_size ?>%</span>
                    </div>
                    <span class="pull-right" style="padding-right: 15px;">1 Гб</span>
                </div>
            </div>
            <?php
            if (empty($docs)): echo '<h3 class="text-center" style="margin-bottom: 20px;">Документы отсутствуют</h3>';
            else: ?>
            <table id="table_id" class="table table-striped table-hover table-bordered table-responsive" style="min-width:476px;overflow-x:auto">
                <thead>
                <tr>
<!--                    <th>ИК</th>-->
                    <th>Имя</th>
                    <th>Дата</th>
                    <th>Размер</th>
                    <th>Формат</th>
                    <th>Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($docs as $k=>$item): ?>
                    <tr>
<!--                        <td><input type="checkbox"></td>-->
                        <td><a href="<?= BASE_URL . 'download?f=' .base64_encode('docs/'. $item['real'] . '.' . $item['type']) . '&c='.urlencode($item['name']).'.'.$item['type'] ?>" data-toggle="tooltip" title="<?= $item['name'].'.'.$item['type'] ?>"><?php echo mb_strimwidth($item['name'], 0, 15, '...'); ?></a></td>
                        <td><?php echo $item['date']; ?></td>
                        <td data-order="<?= "000".str_replace(" Кб",'',$item['size']) ?>"><?php echo $item['size']; ?></td>
                        <td><?php echo $item['type']; ?></td>
                        <td class="text-center">
                                <!--<a class='btn btn-info btn-xs' href="#">
                                    <span class="glyphicon glyphicon-edit"></span>&nbsp;<span
                                            class="hidden-xs">Изменить</span></a>-->
                                <form action="docs/delete" method="post">
                                <button class="btn btn-danger btn-xs">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <span class="glyphicon glyphicon-remove"></span>&nbsp;<span class="hidden-xs">Удалить</span></button>

                                </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <div class="tab-pane" id="mfiles">
        <?php if($cur_user->access < 4): ?>
        <a class="btn btn-success" style="margin-top: 5px;" href="<?= BASE_URL ?>docs/edit">Загрузить новый файл</a>
<hr>
        <?php endif; ?>
        <?php
            if (empty($mfiles)):
                echo '<div class="panel panel-default"><div class="panel-body"><h3 class="text-center" style="margin-bottom: 20px;">Документы отсутствуют</h3></div></div>';
            else: 
                echo $mfiles;
            endif; ?>
        </div>
        <div class="tab-pane" id="norm">
            <ul class="list-group">
                <a href="http://ino.usue.ru/images/Docs1/Normativka Docs/Normativ doki/FZ-ob-obrazovanii-v-RF.pdf" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i>
                    Федеральный закон об образовании
                    <small>(добавлено 25.01.2016)</small>
                </a>
                <a href="http://ino.usue.ru/images/Docs1/Normativka Docs/Normativ doki/Pologenie_o_lizenzirovanii_obraz_deiyatelnosti_966.pdf" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i>
                    Положение о лицензировании образовательной деятельности
                    <small>(добавлено 25.01.2016)</small>
                </a>
                <a href="http://ino.usue.ru/images/Docs1/Normativka Docs/Normativ doki/Pologenie_o_gos_akkreditacii_1039.pdf" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i>
                    Положение о государственной аккредитации образовательной деятельности
                    <small>(добавлено 25.01.2016)</small>
                </a>
                <a href="http://ino.usue.ru/images/Docs1/Normativka Docs/Normativ doki/Poriadok_org_obraz_deiyatelnosti_1367.pdf" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i>
                    Порядок организации и осуществлении образовательной деятельности по образовательным программам
                    высшего образования - программам бакалавриата, программ специалитета и программ магистратуры
                    <small>(добавлено 25.01.2016)</small>
                </a>
                <a href="http://ino.usue.ru/images/Docs1/Normativka Docs/Normativ doki/Postanovlenie_o_platnih_uslugah_706.pdf" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i>
                    Правила оказания платных образовательных услуг
                    <small>(добавлено 25.01.2016)</small>
                </a>
                <a href="http://ino.usue.ru/images/Docs1/Normativka Docs/Normativ doki/Poriadok_priema_na_obuchenie_1147.pdf" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i>
                    Порядок приема на обучение по образовательным программам высшего образования - программам
                    бакалавриата, программ специалитета и программ магистратуры
                    <small>(добавлено 25.01.2016)</small>
                </a>
                <a href="http://ino.usue.ru/images/Docs1/Normativka Docs/Normativ doki/Prikaz-ob-utvergdenii-poriyadka-predostavleniya-akademicheskovo-otpuska.pdf" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i>
                    Положение об утверждении порядка и оснований предоставления академического отпуска обучающимся"
                    <small>(добавлено 25.01.2016)</small>
                </a>
                <a href="http://ino.usue.ru/images/Docs1/Normativka Docs/Normativ doki/Prikaz_ob_utvergden_Pologeniya_o_praktike _1383.pdf" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i>
                    Положение о практике обучающихся, осваивающих основные профессиональные образовательные программы
                    высшего образования
                    <small>(добавлено 25.01.2016)</small>
                </a>
                <a href="http://ino.usue.ru/images/Docs1/Normativka Docs/Normativ doki/prikaz-ob-utverg-GIA.pdf" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i>
                    Порядок проведения ГИА по образовательным программам высшего образования - программам бакалавриата,
                    программ специалитета и программ магистратуры
                    <small>(добавлено 25.01.2016)</small>
                </a>
                <a href="http://ino.usue.ru/images/Docs1/Normativka Docs/Normativ doki/Prikaz_ob_utver_obrazcov_i_opis_doc_ o_kvalifikazii_1100.pdf" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i> Приказ
                    об утверждении образцов и описаний документов о высшем образовании и о квалификации и приложений к
                    ним
                    <small>(добавлено 25.01.2016)</small>
                </a>
            </ul>
        </div>
        <div class="tab-pane" id="plan">
            <ul class="list-group">
                <?php
                if (empty($sem)): echo '<div class="panel panel-default"><div class="panel-body"><h3 class="text-center" style="margin-bottom: 20px;">Документы отсутствуют</h3></div></div>';
                else:
                    foreach ($sem as $item):?>
                    <a href="<?= BASE_URL . $plan . '/' . $item ?>" class="list-group-item" target="_blank"><i class="glyphicon glyphicon-open-file"></i><?=
                        preg_replace('/\.\w+$/', '', ' '.$item) . ' семестр';
                        ?>
                    </a>
                <?php
                    endforeach;
                endif; ?>
            </ul>
        </div>
    </div>

</div>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="<?= BASE_URL ?>css/fileuploader.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script src="<?= BASE_URL ?>js/fileuploader.js"></script>
<script type="text/javascript">
    $( document ).ready(function() {
        var table = $('#table_id').DataTable({
            "columnDefs": [
                { "orderable": false, "targets": 4 }
            ],
            stateSave: true,
            "info":     false,
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            }
        });
        var uploader = new qq.FileUploader({
            element: document.getElementById('file-uploader'),
            action: 'docs/upload',
            params: {},
            allowedExtensions: [],
            template: '<div class="qq-uploader">' +
            '<div class="qq-upload-drop-area"><span>{dragText}</span></div>' +
            '<div class="qq-upload-button btn btn-success" style="margin: 0 auto">{uploadButtonText}</div>' +
            '<hr><ul class="qq-upload-list list-group"></ul>' +
            '</div>',
            fileTemplate: '<li class="list-group-item">' +
            '<span class="qq-progress-bar progress"></span>' +
            '<span class="qq-upload-file"></span>' +
            '<span class="qq-upload-spinner"></span>' +
            '<span class="qq-upload-size"></span>' +
            '<a class="qq-upload-cancel" href="#">{cancelButtonText}</a>' +
            '<span class="qq-upload-failed-text">{failUploadtext}</span>' +
            '</li>',
            dragText: 'Переместите файл в эту зону для загрузки',
            uploadButtonText: '<i class="glyphicon glyphicon-plus-sign"></i>&nbsp; Загрузить...',
            cancelButtonText: 'Отмена',
            failUploadText: 'Ошибка',
            onComplete: function (id, fileName, responseJSON) {
                setInterval("$('.qq-upload-success').fadeOut(500)", 1000);
            },
            onProgress: function(id, fileName, loaded, total){
                console.log(total);
            },
        });

    });
</script>

<style>
.menu .accordion-heading {  position: relative; }
.menu .accordion-heading .edit {
    position: absolute;
    top: 8px;
    right: 30px; 
}
#collapse0 .area { border-left: 4px solid #f38787; }
#collapse0 .equipamento { border-left: 4px solid #65c465; }
#collapse0 .ponto { border-left: 4px solid #98b3fa; }
#collapse0 .collapse.in { overflow: visible; }
#collapse0 .panel-body { padding: 15px; }
.panel-group .panel+.panel { margin-top: 0px; }
#collapse0 .panel-default>.panel-heading { background-color: transparent; }
</style>