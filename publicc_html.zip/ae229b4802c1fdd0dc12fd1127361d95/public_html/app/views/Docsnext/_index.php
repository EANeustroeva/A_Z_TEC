<div class="col-sm-12">
    <hr>
    <form class="form-inline">
        <div class="form-group">
            <h4 class="form-control-static">Сортировать...</h4>
            <select class="form-control">
                <option>По названию</option>
                <option>По дате</option>
                <option>По назначению</option>
                <option>По размеру</option>
            </select>
            <select class="form-control">
                <option>Группировка</option>
            </select>
        </div>
    </form>
    <hr>
    <ul class="nav nav-tabs">
        <div id="uploadBtn" class="btn btn-success pull-right"><i class="glyphicon glyphicon-plus-sign"></i>&nbsp;<span class="hidden-xs">Загрузить...</span></div>
        <li role="presentation" class=""><a data-toggle="tab" href="#private">Личные</a></li>
        <li role="presentation" class="active"><a data-toggle="tab" href="#school">Учебные</a></li>
        <li role="presentation" class=""><a data-toggle="tab" href="#extra">Внеучебные</a></li>
    </ul>



    <div class="tab-content">
        <div id="private" class="tab-pane">
            <table class="table table-striped table-hover table-bordered">
                <thead>
                <tr>
                    <th>ИК</th>
                    <th>Имя</th>
                    <th>Дата</th>
                    <th>Размер</th>
                    <th>Тип</th>
                    <th>Изменить</th>
                </tr>
                </thead>
                <tbody>
                <?php for ($i = 0; $i < 10; $i++): ?>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td><?php if (isset($docs[$i])) echo $docs[$i]['name']; ?></td>
                        <td><?php if (isset($docs[$i])) echo $docs[$i]['date']; ?></td>
                        <td><?php if (isset($docs[$i])) echo $docs[$i]['size']; ?></td>
                        <td><?php if (isset($docs[$i])) echo $docs[$i]['type']; ?></td>
                        <td class="text-center">
                            <?php if (isset($docs[$i])): ?>
                                <a class='btn btn-info btn-xs' href="#">
                                    <span class="glyphicon glyphicon-edit"></span>&nbsp;<span class="hidden-xs">Изменить</span></a> <a href="#"
                                                                                                   class="btn btn-danger btn-xs">
                                    <span class="glyphicon glyphicon-remove"></span>&nbsp;<span class="hidden-xs">Удалить</span></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endfor; ?>
                </tbody>
            </table>
        </div>
        <div id="school" class="tab-pane fade in active">
            <table class="table table-striped table-hover table-bordered">
                <thead>
                <tr>
                    <th></th>
                    <th>Название</th>
                    <th>Дата</th>
                    <th>Тип работы</th>
                    <th>Предмет</th>
                    <th>Преподаватель</th>
                    <th>Оценка</th>
                </tr>
                </thead>
                <tbody>
                <?php for ($i = 0; $i < 10; $i++): ?>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                <?php endfor; ?>

                </tbody>
            </table>
        </div>
        <div id="extra" class="tab-pane">
            <table class="table table-striped table-hover table-bordered">
                <thead>
                <tr>
                    <th></th>
                    <th>Название</th>
                    <th>Дата</th>
                    <th>Назначение</th>
                    <th>Кол-во шт.</th>
                </tr>
                </thead>
                <tbody>
                <?php for ($i = 0; $i < 10; $i++): ?>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<script src="<?= BASE_URL ?>js/fileuploader.js"></script>
<script type="text/javascript" src="<?= BASE_URL ?>js/image-uploader.js"></script>
<script type="text/javascript">
    $(function () {
        var img = new ImageUploader({
            img: $("#img"),
            loaderURL: "images/loader.gif",

            targetWidth: 210,
            targetHeight: 297,

            hidden: $("#url"), //для сохранения ссылки на картинку

//            cropURL: "crop.php",
            cropParams: {},

            uploadURL: "docs/upload",
            uploadParams: {},

            allowedExtensions: ["jpg", "jpeg", "gif", "png",
                "doc", "docs", "xls", "xlsx", "txt", "pdf", "rar", "zip"],

            uploadBtn: $("#uploadBtn"),
//            deleteBtn: $("#deleteBtn"),
//            cropBtn: $("#cropBtn")
        });

        img.remove();
    });
</script>