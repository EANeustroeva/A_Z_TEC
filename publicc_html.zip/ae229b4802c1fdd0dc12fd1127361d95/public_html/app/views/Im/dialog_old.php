<div class="col-sm-12">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <a href="<?= BASE_URL ?>im" class="btn btn-default"><i class="glyphicon glyphicon-chevron-left" aria-hidden="true"></i> Назад</a>
                </div>
                <span class="pull-left buddy">
            <a href="<?= BASE_URL ?>?id=<?= $msg->buddy->id ?>"><?= $msg->buddy->name ?></a>
        </span>
<!--                <div class="pull-right">-->
<!--                    <button class="btn btn-default dropdown-toggle" type="button">-->
<!--                        <span class="glyphicon glyphicon-search" aria-hidden="true"></span>-->
<!--                    </button>-->
<!---->
<!--                    <div class="dropdown pull-right">-->
<!--                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1"-->
<!--                                data-toggle="dropdown"-->
<!--                                aria-haspopup="true" aria-expanded="false">-->
<!--                            <span class="glyphicon glyphicon-option-horizontal"></span>-->
<!--                        </button>-->
<!--                        <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu1">-->
<!--                            <li><a href="#">Action</a></li>-->
<!--                            <li><a href="#">Profile</a></li>-->
<!--                        </ul>-->
<!--                    </div>-->
<!--                </div>-->
            </div>
            <div class="panel-body">
                <?php //dd($msg) ?>
                <div class="container-chat" id="containerchat">
                    <ul class="list-unstyled chat-box-body">
                        <?php if($msg->buddy->more): ?>
                            <li id="load-more-wrap" style="text-align:center;padding: 10px 0;"><a onclick="javascript: load_thread(<?= $msg->buddy->d_id . ',' . $msg->buddy->limit ?>)" class="btn btn-xs btn-default" style="width:100%">Показать старые сообщения (<?= $msg->buddy->remaining ?>)</a></li>
                        <?php endif; ?>
                        <?php foreach ($msg->thread as $item): ?>
                            <?php if (isset($msg)): ?>
                                <a class="message-bubble row <?php if ($item->status == 0) echo 'unread'; ?>">
                                <span class="chat-img pull-left" style="padding-right: 10px;">
                                    <img src="<?= $item->avatar ?>" class="avt ">
                                </span>
                                    <div class="chat-body">
                                        <strong class="primary-font"><?= $item->name ?></strong>
                                        <small class="text-muted pull-right ">
                                            <span class="glyphicon glyphicon-time"></span>
                                            <?= $item->time ?>
                                        </small>
                                        <p><?= $item->msg ?></p>
                                    </div>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                    <p id="scroll"></p>
                </div>
                <? //= dump($users) ?>

                <div class="panel-footer">
                    <form action="<?= BASE_URL ?>im/save<?= '?id=' . $_GET['id'] ?>" method="post" class="input-group">
                        <input type="text" name="message" class="form-control" autocomplete="off" autofocus>
                        <!-- glyphicon glyphicon-file -->
                        <span class="input-group-btn">
                    <button class="btn btn-default" type="submit">Отправить</button>
                </span>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-sm-3" style="display: none;">
    <div class="panel panel-info">
        <div class="panel-heading"><h3 class="panel-title">Участники</h3></div>
        <div class="panel-body list-group">
            <?php foreach ($users as $k => $user):
                if ($user->id == $cur_user['id']) continue; ?>
                <a href="<?= BASE_URL ?>?id=<?= $user->id ?>"
                   class="list-group-item"><?php echo ucwords($user['firstname'] . ' ' . $user['surname']); ?></a>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
//        document.getElementById('scroll').scrollIntoView()
//        $('#scroll').scrollIntoView();
        function setHeiHeight() {
            $('.container-chat').css({
                height: ($(window).height() - 210) + 'px'
            });
        }

        setHeiHeight();
        $(window).resize(setHeiHeight);
//        $('#scroll').scrollIntoView();

    });
</script>