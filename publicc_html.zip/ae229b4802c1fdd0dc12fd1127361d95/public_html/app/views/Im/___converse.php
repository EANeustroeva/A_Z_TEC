<div class="col-sm-6">
    <div class="panel panel-default">
        <div class="panel-heading">Создание Беседы</div>
        <div class="panel-body">
            <div class="col-sm-12">
                <h4></h4>
                <form action="<?= BASE_URL ?>users/dialog" method="post">
                    <div class="form-group">
                        <input class="form-control" placeholder="Название беседы" type="text" name="name" required
                               style="margin-bottom: 20px;">
                    </div>

                    <div class="form-group">
                        <label for="dusers">Студенты:</label>
                        <select name="usr_id[]" class="selectpicker form-control" multiple data-size="8" data-live-search="true"
                                data-selected-text-format="count">
                            <?php foreach ($users as $k => $user): ?>
                                <?php $ava = !empty($user['photo'])?BASE_URL.'order/'.$user['photo']:BASE_URL.'assets/images/thumbs/no-image.jpg' ?>
                                <option data-content="<img src='<?=$ava ?>' width='30'> <?= ucwords($user['name']) ?>"><?= $user['id'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="msg">Сообщение:</label>
                        <textarea class="form-control" name="msg" id="msg" rows="2" required></textarea>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-block" type="submit">Создать</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php if($cur_user['access']!=4): ?>
<div class="col-sm-6">
    <div class="panel panel-default">
        <div class="panel-heading">Создание рассылки</div>
        <div class="panel-body">
            <div class="col-sm-12">
                <h4></h4>
                <form action="<?= BASE_URL ?>users/dispatch" method="post">
                    <div class="form-group">
                        <input class="form-control" placeholder="Тема рассылки" type="text" name="name" required
                               style="margin-bottom: 20px;">
                    </div>
                    <!--<div class="form-group">
                        <label for="fac">Факультет: </label>
                        <select id="fac" name="dfac" class="selectpicker form-control" data-size="5"">
                        <option value="">Не выбрано</option>
                        <option>Бизнес-информатика</option>
                        <option>Гостиничное дело</option>
                        <option>Государственное и муниципальное упр</option>
                        <option>Землеустройство и кадастры</option>
                        <option>Информационная безопасность</option>
                        <option>Менеджмент</option>
                        <option>Прикладная информатика</option>
                        <option>Продукты питания из раст сырья</option>
                        <option>Сервис</option>
                        <option>Технология продукции и орг общ пит</option>
                        <option>Товароведение</option>
                        <option>Торговое дело</option>
                        <option>Туризм</option>
                        <option>Управление качеством</option>
                        <option>Управление персоналом</option>
                        <option>Экономика</option>
                        <option>Юриспруденция</option>

                        </select>
                    </div>-->
                    <div class="form-group">
                        <label for="course">Курс: </label>
                        <select name="dcourse" id="course" class="selectpicker form-control" data-size="5"">
                        <option value="">Не выбрано</option>
                        <?php foreach ($course as $item):
                            if (is_null($item['course'])) continue; ?>
                            <option><?= $item['course'] ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="caf">Кафедра: </label>
                        <select name="dcaf" id="caf" class="selectpicker form-control" disabled data-size="5"">
                        <option value="">Не выбрано</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="class">Группа:</label>
                        <select name="dclass[]" id="class" class="selectpicker form-control" multiple data-size="8"
                                data-live-search="true"
                                data-selected-text-format="count > 2">
                            <?php foreach ($class as $item):
                                if (is_null($item['class'])) continue; ?>
                                <option<?php if (!empty($_GET['class'])) if ($_GET['class'] == $item['class']) echo ' selected'; ?>><?= $item['class'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="msgd">Сообщение:</label>
                        <textarea class="form-control" name="msg" id="msgd" rows="2" required></textarea>
                    </div>

                    <div class="form-group">
                        <button class="btn btn-primary btn-block" type="submit">Отправить</button>
                    </div>
                    <!-- <?php /* ?>
        <div class="col-sm-8">
            <div class="row">
                <div class="all_contacts">
                    <?php foreach ($users as $k => $user) {
                        if ($user->id != $cur_user['id']) { ?>
                            <a href="?id=<?= $user->id ?>"
                               class="user_main<?= (isset($sel[$k]) and $sel[$k]) ? ' active' : '' ?>">
                                <div class="contact-wrap">
                                    <?php if (isset($sel[$k]) and $sel[$k]): ?>
                                        <input type="hidden" value="<?php echo $user['id']; ?>" name="usr_id[]"/>
                                    <?php endif; ?>
                                    <div class="contact-profile-img">
                                        <div class="profile-img">
                                            <?php $avatar = $user['avatar'] != '' ? $user['avatar'] : 'no-image.jpg'; ?>
                                            <img src="<?= BASE_URL ?>assets/images/thumbs/<?php echo $avatar; ?>"
                                                 class="img-responsive">
                                        </div>
                                    </div>
                                    <span class="contact-name">
								<small class="user-name"><?php echo ucwords($user['surname'] . ' ' . $user['firstname'] . ' ' . $user['lastname']); ?></small>
								<span class="badge progress-bar-danger"
                                      rel="<?php echo $user['id']; ?>"><?php echo $user['unread']; ?></span>
							</span>
                                    <span style="display: table-cell;vertical-align: middle;" class="user_status">
								<?php $status = $user['online'] == 1 ? 'is-online' : 'is-offline'; ?>
                                        <span class="user-status <?php echo $status; ?>"></span>
							</span>
                                </div>
                            </a>
                        <?php }
                    } ?>
                </div>
            </div>
        </div>
        <?php */ ?> -->
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<script src="<?= BASE_URL ?>js/filter.js"></script>