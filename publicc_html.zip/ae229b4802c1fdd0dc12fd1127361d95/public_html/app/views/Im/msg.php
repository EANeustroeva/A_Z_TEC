<div class="col-sm-6">
    <div class="panel panel-default">
        <div class="panel-heading">Написать</div>
        <div class="panel-body">
            <div class="col-sm-12">
                <h4></h4>
                <form action="<?= BASE_URL ?>im/dialog" method="post">
                    <div class="form-group">
                        <div class="well well-sm"><?= $name ?></div>
                    </div>
                    <div class="form-group">
                        <label for="msg">Сообщение:</label>
                        <textarea class="form-control" name="msg" id="msg" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-block" type="submit">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>