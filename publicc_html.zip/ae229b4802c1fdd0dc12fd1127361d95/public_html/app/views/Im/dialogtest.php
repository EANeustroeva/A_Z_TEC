<!--<div class="col-sm-12">-->
<!--    <div class="row">-->
        <div class="panel panel-default">
            <?php if (!isset($_GET['widget'])): ?>
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <a href="<?= BASE_URL ?>im" class="btn btn-default"><i class="glyphicon glyphicon-chevron-left" aria-hidden="true"></i> Назад</a>
                </div>
                <span class="pull-left buddy">
                    <a href="<?= BASE_URL ?>?id=<?= $msg->buddy->id ?>"><?= $msg->buddy->name . $msg->buddy->class ?></a>
                </span>
            </div>
            <?php endif; ?>
            <div class="panel-body">
                <!-- ***************************** -->
                <div class="comments-app">
                    <!-- Comments List -->
                    <div class="comments">
                        <?php if($msg->buddy->more): ?>
                        <div class="comment">
                            <div id="load-more-wrap" style="text-align:center;padding: 10px 0;"><a onclick="javascript: load_thread(<?= $msg->buddy->d_id . ',' . $msg->buddy->limit ?>)" class="btn btn-xs btn-default" style="width:100%">Показать старые сообщения (<?= $msg->buddy->remaining ?>)</a></div>
                        </div>
                        <?php endif; ?>
                        <!-- Comment -->
<!--                        --><?php //$flag = true; $type = false ?>
                        <?php foreach ($msg->thread as $item): ?>
                        <?php
                            if ($item->type == 'system') {
                                echo '<div class="clearfix" style="font-size: .9em;padding:.2em"><div class="text-center"><i>'.$item->msg.'</i><small class="pull-right">'.$item->time.'</small></div></div>';
                                continue;
                            }
                        ?>
                        <?php
                            $flag = !isset($old_type) ? true : ($old_type!=$item->type ? true : false);
                            $flag2 = !isset($old_time)||$flag ? true : ($old_time!=$item->time ? true : false);
                            $old_time = $item->time;
                            $old_type = $item->type;
                        ?>
                        <div class="comment<?= $item->type=='out' ? ' right' : '' ?><?= $flag ? ' first':'' ?><?= ($item->status == 0) ? ' unread' : ''; ?>">
                            <?php if ($flag || $flag2): ?>
                            <div class="comment-info clearfix">
                                <?php if ($flag): ?><span class="comment-name"><?= $item->type=='out' ? 'Вы' : $item->name ?></span><?php endif; ?>
                                <?php if ($flag2): ?><span class="comment-timestamp"><?= $item->time ?></span><?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <?php if ($flag): ?>
                                <!-- Comment Avatar -->
                                <div class="comment-avatar">
                                    <img src="<?= @getimagesize('https://ino-online.usue.ru'. $item->avatar) ? $item->avatar : '/img/no_photo/no-image.jpg' ?>" alt="">
                                </div>
                            <?php endif; ?>
                            <div class="comment-text<?= $flag ? ' first':'' ?>">
                                <?php if ($item->file): ?>
<!--                                <div class="well well-sm">-->
                                <div><i>Прикрепленный файл:</i></div>
                                    <a class="btn btn-success" href="/download?f=<?= base64_encode('im/' . $item->file) . '&c=' . urlencode($item->msg) ?>"><i class="glyphicon glyphicon-open-file"></i> <?= $item->msg ?></a>
<!--                                </div>-->
                                <?php
                                    else:
                                        echo $item->msg;
                                    endif;
                                ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <p id="scroll" style="margin: 0;"></p>
                    </div>
                </div>
                <!-- ***************************** -->
            </div>
<!--            <div style="position: relative;" class="uploader">-->
<!--                <div style="margin-top: 5px" id="file-uploader"></div>-->
<!--            </div>-->
            <div class="panel-footer">
                <form action="<?= BASE_URL ?>im/save<?= '?id=' . $_GET['id'] ?><?= isset($_GET['widget'])?'&widget=1':'' ?>" method="post" class="input-group">
                    <input type="text" name="message" class="form-control" autocomplete="off" autofocus>
                    <!-- glyphicon glyphicon-file -->
                    <span class="input-group-btn">
                        <div id="file-uploader" style="display: inline-block"></div>
                        <button class="btn btn-default" type="submit">Отправить</button>
                    </span>
                </form>
            </div>
        </div>
<!--    </div>-->
<!--</div>-->
<link rel="stylesheet" href="/js/fileuploader/fileuploader-3.3.1.css">

<script src="/js/fileuploader/jquery.fileuploader-3.3.1.js"></script>
<script type="text/javascript">
    function setHeiHeight() {
        $('.comments-app').css({
            <?php if (!isset($_GET['widget'])): ?>
                height: ($(window).height() - 260) + 'px'
            <?php else: ?>
                height: ($(window).height() - $('.panel-footer').outerHeight()-2) + 'px'
            <?php endif; ?>
        });
    }

    $(document).ready(function() {
        $('#file-uploader').fineUploader({
            multiple: true,
            request: {
                endpoint: '/im/upload',
                params: {
                    d_id: '<?= $_GET['id'] ?>'
                },
            },
            deleteFile: {
                enabled: false, // defaults to false
                endpoint: '/im/upload',
                deletingStatusText: "Удаление...",
                deletingFailedText: "Ошибка удаления"
            },
            text: {
                uploadButton: 'Загрузить файл',
                cancelButton: 'Отменить',
                retryButton: 'Повторить',
                deleteButton: 'Удалить',
                failUpload: 'Сбой загрузки',
                dragZone: 'Переместите файл в эту зону для загрузки',
                dropProcessing: 'Обработка файлов...',
                formatProgress: "{percent}% из {total_size}",
                waitingForResponse: "Обработка..."
            },
        }).on('complete', function(event, id, name, response) {
            console.log(event, id, name, response);
            $('.qq-upload-success').fadeOut(1000);
            location.reload();
        });

        setHeiHeight();
        $(window).resize(setHeiHeight);
        document.getElementById('scroll').scrollIntoView()
    });
</script>
<style>
    .qq-upload-button {
        display: inline-block;
        width: 110px;
        padding: 6px;
        font-size: 14px;
        font-weight: 400;
        line-height: 1.42857143;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        color: #fff;
        background-color: #337ab7;
        border-color: #2e6da4;
        border: 1px solid transparent;
        /*border-radius: 4px;*/
    }
</style>

<?php if (isset($_GET['widget'])): ?>
<style>
    .panel {
        /*position: fixed;*/
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        margin-bottom: 0;
    }
    .panel .panel-body { padding: 0; }
    /*.comments-app { margin-bottom: 54px!important; }*/
    /*.panel-footer { position: fixed; bottom: 0; left: 0; right: 0;}*/
    body{
       font-size: .5em!important;
    }

    #file-uploader {
         /*position: fixed;*/
        /*bottom: 55px;*/
        /*font-size: 13px;*/
        /*width: 120px;*/
    }
</style>
<?php endif; ?>
<style>
    .comments-app{
        margin: 0 auto;
        /*padding: 0 10px;*/
        width: 100%;
        line-height: 1.6;
        overflow-y: auto;
    }
    .comment-form{  }
    .comment-form .comment-avatar{  }
    .comment-form .form .form-row{ margin-bottom: 10px; }
    .comment-form .form .form-row:last-child{ margin-bottom: 0; }
    .comment-form .form .input{
        background-color: #fcfcfc;
        border: none;
        border-radius: 4px;
        box-shadow: 0 1px 1px rgba(0, 0, 0, .15);
        color: #555f77;
        font-family: inherit;
        font-size: 14px;
        padding: 5px 10px;
        outline: none;
        width: 100%;

        -webkit-transition: 350ms box-shadow;
        -moz-transition: 350ms box-shadow;
        -ms-transition: 350ms box-shadow;
        -o-transition: 350ms box-shadow;
        transition: 350ms box-shadow;
    }
    .comment-form .form textarea.input{
        height: 100px;
        padding: 15px;
    }
    .comment-form .form label{
        color: #555f77;
        font-family: inherit;
        font-size: 14px;
    }
    .comment-form .form input[type=submit]{
        background-color: #555f77;
        border: none;
        border-radius: 4px;
        box-shadow: 0 1px 1px rgba(0, 0, 0, .15);
        color: #fff;
        cursor: pointer;
        display: block;
        margin-left: auto;
        outline: none;
        padding: 6px 15px;

        -webkit-transition: 350ms box-shadow;
        -moz-transition: 350ms box-shadow;
        -ms-transition: 350ms box-shadow;
        -o-transition: 350ms box-shadow;
        transition: 350ms box-shadow;
    }
    .comment-form .form .input:focus,
    .comment-form .form input[type=submit]:focus,
    .comment-form .form input[type=submit]:hover{
        box-shadow: 0 2px 6px rgba(121, 137, 148, .55);
    }
    .comment-form .form.ng-submitted .input.ng-invalid,
    .comment-form .form .input.ng-dirty.ng-invalid{
        box-shadow: 0 2px 6px rgba(212, 47, 47, .55) !important;
    }
    .comment-form .form .input.disabled {
        background-color: #E8E8E8;
    }

    .comments{
        overflow-y: auto;
        /*padding-right: 5px;*/
    }
    .comment-form,
    .comment{
        /*margin-bottom: 10px;*/
        position: relative;
        z-index: 0;
        padding: 0 10px 10px;
    }
    .comment.unread,.comment.right.unread {
        background-color: #f0f2f5;
    }
    .comment:last-child{
        margin-bottom: 0!important;
    }

    .comment .comment-avatar{
        border: 2px solid #fff;
        /*border-radius: 50%;*/
        border-radius: 4px;
        float: left;
        box-shadow: 0 1px 2px rgba(0, 0, 0, .2);
        height: 60px;
        width: 60px;
        overflow: hidden;
    }
    .comment .comment-avatar img{
        display: block;
        /*height: auto;*/
        /*width: 100%;*/
        height: 100%;
        width: auto;
        margin: 0 auto;
    }

    .comment .comment-footer a{
        color: #acb4c2;
        text-decoration: none;

        -webkit-transition: 350ms color;
        -moz-transition: 350ms color;
        -ms-transition: 350ms color;
        -o-transition: 350ms color;
        transition: 350ms color;
    }

    .comment-info {
        display: block;
        margin-bottom: 2px;
        font-size: 12px
    }
    .comment-name {
        font-weight: 600;
        float: left;
        font-size: 14px;
    }
    .comment-timestamp {
        color: #999;
        float: right;
    }

    .right .comment-name {
        float: right;
    }
    .right .comment-timestamp {
        float: left;
    }

    .comment, .comment-text {
        display: block
    }

    .comment:before, .comment:after {
        content: " ";
        display: table
    }
    .comment:after {
        clear: both
    }
    .comment-text {
        border-radius: 5px;
        position: relative;
        padding: 5px 10px;
        background: #d2d6de;
        border: 1px solid #d2d6de;
        /*margin: 5px 0 0 70px;*/
        margin: 0 0 0 70px;
        color: #444;
        font-size: 13px;
        /*white-space: pre-line;*/
    }
    .comment-text:after, .comment-text:before {
        position: absolute;
        right: 100%;
        top: 15px;
        border: solid transparent;
        /*border-right-color: #d2d6de;*/
        content: ' ';
        height: 0;
        width: 0;
        pointer-events: none
    }
    .comment-text.first:after, .comment-text.first:before {
        border-right-color: #d2d6de;
    }
    .right .comment-text.first:after, .right .comment-text.first:before {
        border-left-color: #0085D1;
    }
    .comment-text:after {
        border-width: 5px;
        margin-top: -5px
    }
    .comment-text:before {
        border-width: 6px;
        margin-top: -6px
    }

    .right .comment-text {
        margin-right: 70px;
        margin-left: 0;
        background: #0085D1;
        border-color: #0085D1;
        color: #fff;
    }
    .right .comment-text:after, .right .comment-text:before {
        right: auto;
        left: 100%;
        border-right-color: transparent;
        /*border-left-color: #0085D1;*/
    }
    .right .comment-avatar {
        float: right
    }
    .btn-box-tool {
        position: absolute;
        right: 0;
        top: 0;
    }

    /* Scrollbar Attributes */
    .comment::-webkit-scrollbar {
        width: 12px;
    }
    ::-webkit-scrollbar {
        width: 6px;
    }
    ::-webkit-scrollbar-track {
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    }
    ::-webkit-scrollbar-thumb {
        background: #ddd;
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.5);
    }

</style>