<div class="col-sm-12" id="chat">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="input-group">
                    <?php if ($cur_user->access<4): ?>
<!--                    <div class="input-group-addon btn" id="btnfilter" style="padding: 0;display: none;">-->
<!--                        <span class="glyphicon glyphicon-filter" style="padding: 6px 12px;"></span></div>-->
<!--                    <input type="text" class="form-control" placeholder="Поиск">-->
                    <div class="input-group-btn">
                        <a href="im/converce" class="btn btn-default" type="button">
                            <i class="glyphicon glyphicon-plus"></i> Добавить
                        </a>
                        <span data-toggle="tooltip" data-html="true" data-placement="right" title="" data-original-title="Создание групповых диалогов, рассылок"><i style="color: #5cb85c; font-size: 18px; cursor:pointer;padding-left: 10px;" class="glyphicon glyphicon-info-sign"></i></span>
                    </div>
                    <?php else: ?>
                    Список диалогов
                    <?php endif; ?>
                </div>
                <div id="filter" style="display: none;position: absolute;width: 300px;">
                    <div class="panel panel-info">
                        <div class="panel-heading"><h3 class="panel-title">Группы рассылки</h3></div>
                        <div class="panel-body list-group">
                            <div class="col-sm-12">
                                <h4></h4>
                                <form action="<?= BASE_URL ?>users/dialog" method="post">
                                    <div class="form-group">
                                        <label for="dfac">Факультет: </label>
                                        <select id="dfac" class="selectpicker form-control" data-size="5"">
                                        <option value="">Не выбрано</option>
                                        <option>Бизнес-информатика</option>
                                        <option>Гостиничное дело</option>
                                        <option>Государственное и муниципальное упр</option>
                                        <option>Землеустройство и кадастры</option>
                                        <option>Информационная безопасность</option>
                                        <option>Менеджмент</option>
                                        <option>Прикладная информатика</option>
                                        <option>Продукты питания из раст сырья</option>
                                        <option>Сервис</option>
                                        <option>Технология продукции и орг общ пит</option>
                                        <option>Товароведение</option>
                                        <option>Торговое дело</option>
                                        <option>Туризм</option>
                                        <option>Управление качеством</option>
                                        <option>Управление персоналом</option>
                                        <option>Экономика</option>
                                        <option>Юриспруденция</option>

                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="dcourse">Курс: </label>
                                        <select id="dcourse" class="selectpicker form-control" data-size="5">
                                            <option value="">Не выбрано</option>
                                            <?php /*foreach (@$course as $item):
                                                if (is_null($item['course'])) continue; ?>
                                                <option><?= $item['course'] ?></option>
                                            <?php endforeach;*/ ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="dcaf">Кафедра: </label>
                                        <select id="dcaf" class="selectpicker form-control" disabled data-size="5">
                                            <option value="">Не выбрано</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="dclass">Группа:</label>
                                        <select id="dclass" class="selectpicker form-control" multiple data-size="8"
                                                data-live-search="true" data-actions-box="true"
                                                data-selected-text-format="count > 2">
                                            <?php /*foreach ($class as $item):
                                                if (is_null($item['class'])) continue; ?>
                                                <option><?= $item['class'] ?></option>
                                            <?php endforeach; */?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <!--                        <button class="btn btn-primary btn-block" type="submit">Создать</button>-->
                                    </div>
                                    <!-- <?php /* ?>
        <div class="col-sm-8">
            <div class="row">
                <div class="all_contacts">
                    <?php foreach ($users as $k => $user) {
                        if ($user->id != $cur_user['id']) { ?>
                            <a href="?id=<?= $user->id ?>"
                               class="user_main<?= (isset($sel[$k]) and $sel[$k]) ? ' active' : '' ?>">
                                <div class="contact-wrap">
                                    <?php if (isset($sel[$k]) and $sel[$k]): ?>
                                        <input type="hidden" value="<?php echo $user['id']; ?>" name="usr_id[]"/>
                                    <?php endif; ?>
                                    <div class="contact-profile-img">
                                        <div class="profile-img">
                                            <?php $avatar = $user['avatar'] != '' ? $user['avatar'] : 'no-image.jpg'; ?>
                                            <img src="<?= BASE_URL ?>assets/images/thumbs/<?php echo $avatar; ?>"
                                                 class="img-responsive">
                                        </div>
                                    </div>
                                    <span class="contact-name">
								<small class="user-name"><?php echo ucwords($user['surname'] . ' ' . $user['firstname'] . ' ' . $user['lastname']); ?></small>
								<span class="badge progress-bar-danger"
                                      rel="<?php echo $user['id']; ?>"><?php echo $user['unread']; ?></span>
							</span>
                                    <span style="display: table-cell;vertical-align: middle;" class="user_status">
								<?php $status = $user['online'] == 1 ? 'is-online' : 'is-offline'; ?>
                                        <span class="user-status <?php echo $status; ?>"></span>
							</span>
                                </div>
                            </a>
                        <?php }
                    } ?>
                </div>
            </div>
        </div>
        <?php */ ?> -->
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="panel-body">
                <div class="container-chat">
                    <ul class="list-unstyled row">
                        <?php if (!empty($dlgs)): ?>
                            <?php foreach ($dlgs as $dlg): ?>
                                <a class="message-bubble <?= (!$dlg['unread']) ?: 'unread' ?>"
                                   href="im/dialog<?php echo '?id=' . $dlg['id']; ?>">
                                    <li>
<!--                                        --><?php //if ($dlg['public'] == '0'): ?>
<!--                                            <span class="chat-img pull-left" style="padding-right: 10px;">-->
<!--                                                <img src="--><?//= $dlg['avatar'] ?><!--" class="img-responsive" alt>-->
<!--                                            </span>-->
                                        <div class="chat-img pull-left">
                                            <img src="<?= $dlg['avatar'] ?>" alt>
                                        </div>
<!--                                        --><?php //endif; ?>
                                        <div class="chat-body clearfix">
                                            <div class="row-fluid">
                                                <div class="row-1 clearfix" style="height: 25px">
                                                    <h5 class="primary-font pull-left"
                                                        style="margin: 0; font-weight: bold"><?= $dlg['name'] ?></h5>
                                                    <small class="text-muted pull-right ">
                                                        <span class="glyphicon glyphicon-time">
                                                        </span>&nbsp;<?= $dlg['time'] ?>
                                                    </small>
                                                </div>
                                                <div class="row-2 clearfix<?= $dlg['is_read'] == 0 ? ' unread' : '' ?>"
                                                     style="line-height: 25px">
                                                    <?php if (!empty($dlg['msg'])): ?>
                                                        <?php if ($dlg['public'] == '1' || $dlg['msg_from'] == $cur_user['id']): ?>
                                                            <span class="chat-img-last pull-left">
                                             <img src="<?= $avatar ?>" class="img-responsive" alt>
                                         </span>
                                                        <?php endif; ?>
                                                        <div class="text-left pull-left"><?php echo mb_strimwidth($dlg['msg'], 0, 30, '...'); ?></div>
                                                    <?php endif; ?>
                                                    <span class="badge progress-bar-danger pull-right"
                                                          rel="<?= $dlg['id'] ?>"><?= $dlg['unread'] ?></span>
                                                </div>
                                            </div>
                                        </div>

                                    </li>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>

                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?= BASE_URL ?>js/filter.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        function setHeiHeight() {
            $('.container-chat').css({
                height: ($(window).height() - 170) + 'px'
            });
        }

        setHeiHeight();
        $(window).resize(setHeiHeight);
    });
    $('#resf').click(function () {
        $('.selectpicker').selectpicker('refresh');
    });
    $('#btnfilter').click(function () {
        $('#btnfilter').toggleClass('active');
        if ($('#btnfilter').hasClass('active')) {
            $('#filter').show();
//            $('#chat').removeClass('col-sm-12').addClass('col-sm-8');
        } else {
            $('#filter').hide();
//            $('#chat').removeClass('col-sm-8').addClass('col-sm-12');
        }

    })
</script>
<style>
    .chat-img {
        border: 2px solid #fff;
        /*border-radius: 50%;*/
        border-radius: 4px;
        float: left;
        box-shadow: 0 1px 2px rgba(0, 0, 0, .2);
        height: 60px;
        width: 60px;
        overflow: hidden;
        margin-right: 10px;
    }
    .chat-img img{
        display: block;
        /*height: auto!important;*/
        /*width: 100%!important;*/
        height: 100%!important;
        width: auto;
        margin: 0 auto;
    }
</style>