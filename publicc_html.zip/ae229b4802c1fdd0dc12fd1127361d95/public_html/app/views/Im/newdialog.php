<div class="panel panel-default" style="margin: 0;">
    <div class="panel-body">
        <form action="/users/dialog?widget=1" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="msg">Написать сообщение:</label>
                <textarea class="form-control" name="msg" id="msg" rows="3" required=""></textarea>
            </div>
            <div class="form-group">
                <label for="exampleInputFile">Прикрепить файл</label>
                <input type="file" name="file" id="exampleInputFile">
            </div>
            <div class="form-group">
                <input type="hidden" name="usr_name" value="<?= $user->name ?>">
                <input type="hidden" name="usr_id" value="<?= $user->id ?>">
                <button class="btn btn-primary btn-block" type="submit">Отправить</button>
            </div>
        </form>
    </div>
</div>