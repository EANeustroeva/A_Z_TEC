<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel2">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel2">Просмотр файла</h4>
      </div>
      <div class="modal-body">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Скачать файл:</label>
              <span id="filename"></span>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="control-label">Тип файла:</label>
              <select class="selectpicker form-control" id="ftype" disabled>
                  <option value="1">РПД</option>
                  <option value="2">ОС</option>
                  <option value="0">Доп. файл</option>
              </select>
          </div>
          <div class="form-group">
            <label for="message-text" class="control-label">Комментарий:</label>
            <textarea class="form-control" id="comment2" disabled rows="8"></textarea>
          </div>
      </div>
      <div class="modal-footer" style="text-align: left">
          <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
      </div>
    </div>
  </div>
</div>
<h3>Группа: <?= $_GET['class'] ?></h3>
<?php $i = 0 ?>

<?php if (empty($discs)): ?>
<i>Студентов в группе не найдено</i><br>
<?php else: ?>

<?php foreach ($discs as $sem => $disc_): ?>
<?php if(empty($disc_)) {
    echo '<i>Предметов на <b>'.$sem.'</b> семестр не найдено</i><br>';
    continue;
}?>
    <hr>
<h4>Семестр: <?= $sem ?></h4>
<?php foreach ($disc_ as $k => $disc): ?>
<?php
    $docs = $disc['docs'];
    $rpd = $disc['rpd'];
    $fos = $disc['fos'];
    $i++;
//    dump($disc);
?>
    <div class="panel-group" id="help-accordion-1">
    <div class="panel <?= $disc['is_d'] ? 'panel-danger' : 'panel-primary' ?>  panel-help">
        <a href="#sect<?=$i?>" data-toggle="collapse" data-parent="#help-accordion-1">
          <div class="panel-heading">
            <h2>Предмет: <b><?= $k ?></b><?= $disc['is_d'] ? ' (предмет из распределения)' : '' ?></h2>
          </div>
        </a>
        <div id="sect<?=$i?>" class="collapse">
            <div class="panel-body">
                <h3> </h3>
                <div class="col-xs-12">
                    <h4><b>По выбранной дисциплине присутствуют следующие документы:</b></h4>

                    <?php if (empty($docs) && empty($rpd) && empty($fos)): echo '<h3 class="text-center" style="margin-bottom: 20px;">Документы по выбранному предмету не найдены</h3>';
                    else: ?>
                    <table class="table table-responsive table-bordered table-striped">
                        <tr class="info">
                            <th>РПД</th>
                            <th>ФОС</th>
                            <th>Метод. указания</th>
                        </tr>
                        <tbody>
                            <tr>
                                <td>
                                    <?php if (!empty($rpd)): ?>
                                        <span style='cursor: pointer' data-id='<?= $rpd['id'] ?>' title='<?= $rpd['ftitle'] ?>' class='label label-success'>
                                            <i class='glyphicon glyphicon-file'></i>
                                        </span>
        <!--                                <a class="list-group-item" style="padding: 0"-->
        <!--                           href="--><?//= BASE_URL . 'download?f=' . base64_encode('../ino/' . $rpd['fname']) . '&c=' . urlencode($rpd['ftitle']) ?><!--"><i-->
        <!--                                    class="glyphicon glyphicon-open-file"></i> --><?//= $rpd['ftitle'] ?><!--</a>-->
                                    <?php else: ?>
                                        <i>файл отсутствует</i>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($fos)): ?>
                                        <span style='cursor: pointer' data-id='<?= $fos['id'] ?>' title='<?= $fos['ftitle'] ?>' class='label label-success'>
                                            <i class='glyphicon glyphicon-file'></i>
                                        </span>
        <!--                            <a class="list-group-item" style="padding: 0"-->
        <!--                           href="--><?//= BASE_URL . 'download?f=' . base64_encode('../ino/' . $fos['fname']) . '&c=' . urlencode($fos['ftitle']) ?><!--"><i-->
        <!--                                    class="glyphicon glyphicon-open-file"></i> --><?//= $fos['ftitle'] ?><!--</a>-->
                                    <?php else: ?>
                                        <i>файл отсутствует</i>
                                    <?php endif; ?>
                                </td>
                                <td class="text-left" style="line-height: 1; padding: 10px 5px; ">
                                    <?php if (!empty($docs)): ?>
                                        <?php foreach ($docs as $i => $task): ?>
                                            <span style='cursor: pointer' data-id='<?= $task['id'] ?>' title='<?= $task['ftitle'] ?>' class='label label-success'>
                                                <?= mb_strimwidth($task['ftitle'], 0, 25, '..') ?>
                                            </span>
        <!--                                        <a class="list-group-item" style="padding: 0"-->
        <!--                                           href="--><?//= BASE_URL . 'download?f=' . base64_encode('../ino/' . $task['fname']) . '&c=' . urlencode($task['ftitle']) ?><!--"><i-->
        <!--                                                    class="glyphicon glyphicon-open-file"></i> --><?//= $task['ftitle'] ?><!--</a></td>-->
        <!--                                        <td><a href="/tasks/workview?id="--><?//= $i ?><!--">--><?//= $task['descr'] ?><!--</a></td>-->

                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <i>файлы отсутствуют</i>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <?php endif; ?>

                    <!--<hr style="margin: 1em -15px; border-color: <?/*=$disc['is_d']?'#FF8C00':'#337ab7'*/?>;">-->

                    <!--<h4><b>По выбранной дисциплине доступны следующие тесты:</b>
                        <select name="" id="" style="width: 300px;float: right;margin: 0;">
                            <option value="" disabled selected>Ничего не выбрано</option>
                            <?php /*foreach ($tests as $test): */?>
                             docs   <option value="<?/*= $test->id */?>"><?/*= $test->title */?></option>
                            <?php /*endforeach; */?>
                        </select>
                        <div class="clearfix"></div>
                    </h4>-->

                    <hr style="margin: 1em -15px; border-color: <?=$disc['is_d']?'#FF8C00':'#337ab7'?>;">

                    <h4><b>По выбранной дисциплине сформирована следующая рабочая ведомость:</b></h4>
                    <table class="table table-responsive table-bordered table-condensed table-striped">
                        <tr class="info">
                            <th>ФИО студента</th>
                            <th>Дата ознакомления</th>
                            <th>Оценка</th>
                            <th>Тест</th>
                        </tr>
                        <tbody>
                            <?php foreach ($disc['users'] as $user): ?>
                            <tr>
                                <td class="text-left"><?= $user['name'] ?></td>
                                <td class="text-left">
                                    <?php if ($user['rpd']): ?>РПД: <small>[<?= $user['rpd'] ?>]</small><br><?php endif; ?>
                                    <?php if ($user['fos']): ?>ФОС: <small>[<?= $user['fos'] ?>]</small><br><?php endif; ?>
                                    <?php if ($user['docs']) foreach ($user['docs'] as $k=>$doc): ?>
                                        Доп.мат.<?= $k+1 ?>: <small>[<?= $doc ?>]</small><br>
                                    <?php endforeach; ?>
                                </td>
                                <td class="text-left"><?= $user['marks'] ?></td>
                                <td class="text-left"></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>
<?php endforeach; ?>

<?php endif; ?>

<script>
    var popOverSettings = {
        placement: 'right',
        container: 'body',
        trigger: 'hover',
        html: true,
        selector: '[data-toggle=popover]'
    };

    function get_file(id) {
        $.ajax({
            url: base + 'docs/getFileById',
            type: 'get',
            data: {'id': id},
            success: function (res) {
                res = JSON.parse(res);
                $('#filename').html(res.link);
                $('#comment2').val(res.descr);
                $('#file_id').val(res.id);
                $('#ftype').val(res.type).selectpicker('refresh');
                $('#exampleModal2').modal('show');
                // $('#table').html(res);
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    $(document).ready(function () {
        $('body').popover(popOverSettings);
        // $('[data-toggle=popover]').popover();
    });

    $(document.body).on('click', '.label' ,function(event) {
        var button = $(this);
        var id = button.data('id');
        get_file(id);
    });
</script>

<style>
.tooltip-inner {
    max-width: 150px!important;
    /* If max-width does not work, try using width instead */
    width: auto!important;
    background: #f60!important;
    color: white!important;
    font-size: 16px!important;
}
.tooltip-arrow {
    border-right-color: #f60!important;
}
    .panel.panel-help {
  box-shadow: 0 1px 5px rgba(85, 85, 85, 0.15);
  padding-bottom: 0;
  border-radius: 2px;
  overflow: hidden;
  background-color: #fff;
  margin: 0 0 16px;
}
.panel.panel-help a[href^="#"],
.panel.panel-help a[href^="#"]:hover,
.panel.panel-help a[href^="#"]:focus {
  outline: none;
  cursor: pointer;
  text-decoration: none;
}
.panel.panel-help .panel-heading {
  background-color: #f6f6f6;
  padding: 0 16px;
  line-height: 48px;
  border-top-right-radius: 2px;
  border-top-left-radius: 2px;
  color: rgba(0, 0, 0, 0.87);
}
.panel.panel-help .panel-heading h2 {
  margin: 0;
  padding: 14px 0 14px;
  font-size: 18px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: 0;
  text-transform: none;
}
.panel.panel-help .panel-body {
  background-color: #fff;
  border-top: 1px solid #ddd;
  border-radius: 2px;
  border-top-right-radius: 0;
  border-top-left-radius: 0;
  margin-top: 0;
}
.panel.panel-help .panel-body p {
  margin: 0 0 16px;
}
.panel.panel-help .panel-body p:last-of-type {
  margin: 0;
}

.panel.panel-danger .panel-heading{
    color:white;
    background-color: #FF8C00;
}
.panel.panel-primary .panel-heading{
    color:white;
    background-color: #337ab7;
}

</style>