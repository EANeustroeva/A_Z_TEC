<blockquote>
  <p>Раздел находится в разработке...</p>
</blockquote>