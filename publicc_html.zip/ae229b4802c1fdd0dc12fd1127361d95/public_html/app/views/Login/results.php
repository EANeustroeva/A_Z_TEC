<?php
$colors = [
    'г. Екатеринбург' => 'midnight-blue',
    'г. В. Пышма' => 'green', //17,7
    'г. Первоуральск' => 'nephritis', //44,2
    'г. Ревда' => 'emerald', //47,1
    'р.п. Белоярский' => 'teal', //53,5
    'г. Полевской' => 'peter-river', //53,6
    'г. В.Серги' => 'blue', //98,5
    'г. К-Уральский' => 'pomegra', //102,7
    'г. Н. Тагил' => 'belize-hole', //139,5
    'г. Камышлов' => 'purple', //144,6
    'г. В. Салда' => 'amethyst', //174,1
    'г. Кушва' => 'wisteria', //192,3
    'г. Красноуфимск' => 'magenta', //198,6
    'г. Ирбит' => 'sun-flower', //199,7
    'г. В. Тура' => 'orange', //202,3
    'г. Шадринск' => 'carrot', //227,7
    'г. Копейск' => 'pumpkin', //233,9
    'г. Туринск' => 'alizarin', //259,5
    'г. Краснотурьинск' => 'red', //382,6
]
?>
<h1 class="text-center" style="font-size: 5em;margin-bottom: .5em; font-weight: bolder;">РЕЗУЛЬТАТЫ КОНКУРСА</h1>

<ul class="nav nav-pills nav-justified" style="font-size: 3em;">
    <li><a href="#pre" role="tab" data-toggle="tab">ПРЕДВАРИТЕЛЬНЫЙ</a></li>
    <li class="active"><a href="#home" role="tab" data-toggle="tab">1 ЭТАП</a></li>
    <li><a href="#profile" role="tab" data-toggle="tab">2 ЭТАП</a></li>
    <li><a href="#sum" role="tab" data-toggle="tab">ИТОГИ</a></li>
</ul>

<div class="tab-content">
    <div role="tabpanel" class="tab-pane fade" id="sum">
        <div class="grid">
            <ul class="row col-md-12" id="myUL-sum">
                <?php foreach ($users4 as $id=>$user): ?>
                    <li class="tile tile-<?= $colors[$user['city']] ?> col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <h1 style="font-size: 4em;"><?= $user['sum'] ?></h1>
                        <h1><?= $user['fio'] ?></h1>
                        <h4 class="tile-text"><?= $user['name'] ?></h4>
                        <span class="tile-label"><?= $user['city'] ?></span>
                        <span class="badge">№<?= $user['n'] ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <div role="tabpanel" class="tab-pane fade" id="pre">
        <div class="grid">
            <ul class="row col-md-12" id="myUL-pre">
                <?php foreach ($users3 as $id=>$user): ?>
                    <li class="tile tile-<?= $colors[$user['city']] ?> col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <h1 style="font-size: 4em;"><?= $user['pre'] ?></h1>
                        <h1><?= $user['fio'] ?></h1>
                        <h4 class="tile-text"><?= $user['name'] ?></h4>
                        <span class="tile-label"><?= $user['city'] ?></span>
                        <span class="badge">№<?= $user['n'] ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <div role="tabpanel" class="tab-pane fade in active" id="home">
        <div class="grid">
            <ul class="row col-md-12" id="myUL">
                <?php foreach ($users as $id=>$user): ?>
                    <li class="tile tile-<?= $colors[$user['city']] ?> col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <h1 style="font-size: 4em;"><?= count($user['votes']) ? round($user['sum'] / count($user['votes']),2) : 0 ?></h1>
                        <h1><?= $user['fio'] ?></h1>
                        <h4 class="tile-text"><?= $user['name'] ?></h4>
                        <span class="tile-label"><?= $user['city'] ?></span>
                        <span class="tile-label" style="right: 20px; left: inherit; top: 10px;">Проголосовало: <?= count($user['votes']) ?></span>
                        <span class="badge">№<?= $user['n'] ?></span>
                        <?php if (isset($_GET['v2'])): ?>
                            <?php foreach ($user['votes'] as $vote):?>
                                <span class="btn btn-default" style="margin-top: 3px;"><?= $vote['votes'] ?></span>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <div role="tabpanel" class="tab-pane" id="profile">
        <div class="grid">
            <ul class="row col-md-12" id="myUL2">
                <?php foreach ($users2 as $id=>$user): ?>
                    <li class="tile tile-<?= $colors[$user['city']] ?> col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <h1 style="font-size: 4em;"><?= $user['votes'] ?></h1>
                        <h1><?= $user['fio'] ?></h1>
                        <h4 class="tile-text"><?= $user['name'] ?></h4>
                        <span class="tile-label"><?= $user['city'] ?></span>
                        <span class="badge">№<?= $user['n'] ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>

<style>
    .tile .badge {
        background: #f0f0f0;
        font-size: 2em;
        color: black;
        position:absolute;
        left: 0;
        top: 0;
    }
    .tile h1:nth-child(2) {
        font-size: 28px;
    }

    .tile .tile-text {
        margin: 0!important;
        font-size: 16px;
    }
    .tile:hover .tile-text {
        display: block;
    }

    /*col-sm-6 col-md-4 col-lg-3*/
    .grid .row {
        background-color: transparent;
        border: 0;
        height: 50px;
        padding-right: 0;

    }
    <?php if (isset($_GET['v2'])): ?>
    .grid .row .col-lg-3, .grid .row .col-md-6 {
        min-height: 400px;
    }
    <?php else: ?>
    .grid .row .col-lg-3, .grid .row .col-md-6 {
        min-height: 300px;
    }
    <?php endif; ?>

    /*.grid .row .col-md-6 {*/
    /*    min-height: 300px;*/
    /*}*/
</style>