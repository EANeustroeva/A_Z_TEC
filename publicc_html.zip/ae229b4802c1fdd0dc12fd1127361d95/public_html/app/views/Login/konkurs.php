<?php
$colors = [
    'г. Екатеринбург' => 'midnight-blue',
    'г. В. Пышма' => 'green', //17,7
    'г. Первоуральск' => 'nephritis', //44,2
    'г. Ревда' => 'emerald', //47,1
    'р.п. Белоярский' => 'teal', //53,5
    'г. Полевской' => 'peter-river', //53,6
    'г. В.Серги' => 'blue', //98,5
    'г. К-Уральский' => 'pomegra', //102,7
    'г. Н. Тагил' => 'belize-hole', //139,5
    'г. Камышлов' => 'purple', //144,6
    'г. В. Салда' => 'amethyst', //174,1
    'г. Кушва' => 'wisteria', //192,3
    'г. Красноуфимск' => 'magenta', //198,6
    'г. Ирбит' => 'sun-flower', //199,7
    'г. В. Тура' => 'orange', //202,3
    'г. Шадринск' => 'carrot', //227,7
    'г. Копейск' => 'pumpkin', //233,9
    'г. Туринск' => 'alizarin', //259,5
    'г. Краснотурьинск' => 'red', //382,6
]
?>
<?php if (!isset($_GET['id'])): ?>

    <?php if (!empty($_SESSION['info_msg'])):?>
        <div class="alert alert-success fade in" role="alert">
            <?= array_shift($_SESSION['info_msg']) ?>
            <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>
        </div>
    <?php endif; ?>

<div class="row">
    <div class="col-xs-12">
    <?php foreach ($colors as $city=>$color):?>
        <span onclick="document.getElementById('myInput').value='<?= $city ?>';myFunction()" class="tile tile-<?= $color ?>" style="min-height: inherit; padding: 3px 5px;"><?= $city ?></span>
    <?php endforeach;?>
    </div>
</div>
<br>
<div class="row">
    <div class="col-sm-6 col-sm-offset-3">
        <div class="input-group">
            <input id="myInput" type="text" class="form-control input-lg" onkeyup="myFunction()" placeholder="Найти участника..">
            <span class="input-group-btn">
            <span class="btn btn-danger btn-lg" type="button" title="Очистить поле для ввода" onclick="$('#myInput').val('');myFunction()"><i class="fa fa-times"></i></span>
          </span>
        </div>
    </div>
</div>
<br>
<div class="grid">
    <ul class="row col-md-12" id="myUL">
        <?php foreach ($users as $user): ?>
            <li class="tile tile-<?= $colors[$user['city']] ?> col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <a href="?id=<?= $user['id'] ?>">
                    <h1 class="" title="<?= $user['name'] ?>"><?= $user['fio'] ?></h1>
                    <h3 class="tile-text"><?= $user['name'] ?></h3>
                    <span class="tile-label"><?= $user['city'] ?></span>
                    <span class="badge" style="background: #f0f0f0; font-size: 1.4em; color: black; position:absolute; right: 0;top: 0;">№<?= $user['n'] ?></span>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

<script>
    function myFunction() {
        var input, filter, ul, li, a, i, txtValue;
        input = document.getElementById('myInput');
        filter = input.value.toUpperCase();
        ul = document.getElementById("myUL");
        li = ul.getElementsByTagName('li');

        for (i = 0; i < li.length; i++) {
            a = li[i].getElementsByTagName("a")[0];
            txtValue = a.textContent || a.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                li[i].style.display = "";
            } else {
                li[i].style.display = "none";
            }
        }
    }
</script>

<style>
    .tile a {
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        padding: 5px;
    }

    .tile h1 {
        font-size: 28px;
    }

    .tile:hover h1 {
        font-size: 12px;
        margin-top: 5px;
        text-align: left;
    }
    .tile:hover .tile-label {
        /*font-size: 8px;*/
    }
    .tile .tile-text {
        display: none;
        margin: 0!important;
        font-size: 18px;
    }
    .tile:hover .tile-text {
        display: block;
    }

    /*col-sm-6 col-md-4 col-lg-3*/
    .grid .row {
        background-color: transparent;
        border: 0;
        height: 50px;
        padding-right: 0;

    }

    .grid .row .col-lg-3 {
        min-height: 150px;
    }

    .grid .row .col-md-6 {
        min-height: 150px;
    }

    /*.grid .row .col-md-6 {*/
    /*    min-height: 300px;*/
    /*}*/
</style>

<?php else:?>

<div class="row">
    <div class="col-xs-12 tile tile-<?= $colors[$user['city']] ?>">
        <h1 class="" title="<?= $user['name'] ?>"><?= $user['fio'] ?></h1>
        <h3 class="tile-text"><?= $user['name'] ?></h3>
        <p style="text-align:left;"><?= $user['city'] ?></p>
        <span class="badge" style="background: #f0f0f0; font-size: 1.4em; color: black; position:absolute; right: 0;top: 0;">№<?= $user['n'] ?></span>
    </div>
</div>

<a href="/konkurs" class="btn btn-danger btn-lg"><i class="fa fa-chevron-left"></i> НАЗАД</a>
<br>
<div class="container">
    <h1>Предварительный этап</h1>
    <span class="btn btn-default btn-lg">БАЛЛОВ: <b><?= $user['pre'] ?></b></span>
    <hr>

    <h1>1 этап</h1>
    <h4>Как вы оцениваете выступление:</h4>
    <div class="btn-group">
        <?php for ($i=1; $i<6; $i++): ?>
            <a class="btn btn-<?= $voted&&$voted->votes==$i || isset($_GET['m'])&&$_GET['m']==$i?'primary':'default' ?> btn-lg" href="?id=<?= $_GET['id'] ?>&m=<?= $i ?>" <?= true||$voted&&$voted->votes?'disabled':'' ?>><?= $i ?></a>
        <?php endfor; ?>
    </div>
    <?php if (isset($_GET['m'])): ?>
        <a href="?id=<?= $_GET['id'] ?>&m=<?= $_GET['m'] ?>&fix" class="btn btn-success btn-lg" <?= isset($_GET['m'])?'':'disabled' ?>><i class="fa fa-lock"></i> ПОДТВЕРДИТЬ</a>
    <?php endif; ?>
    <hr>

    <h1>2 этап</h1>
    <span class="btn btn-default btn-lg">БАЛЛОВ: <b><?= $user['votes'] ?></b></span>
</div>
<?php endif; ?>

