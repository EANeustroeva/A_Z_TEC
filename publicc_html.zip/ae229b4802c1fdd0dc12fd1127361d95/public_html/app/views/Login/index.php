<?php if (!empty($_SESSION['errors'])):?>
    <div class="alert alert-danger fade in" role="alert">
        <?= array_shift($_SESSION['errors']) ?>
        <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>
    </div>
<?php endif; ?>
<div class="text-center">
    <div class="row">
        <form style="padding: 0;" class="form-signin" action="<?= BASE_URL ?>konkurs" method="post">
            <div class="panel panel-default panel-warning">
                <div class="panel-heading">Вход для пользователей</div>
                <div class="panel-body" style="padding-bottom: 0;">
                    <div class="form-group">
                        <div class="input-group">
                            <input type="text" name="login" value="" class="form-control" placeholder="Логин" required
                                   autofocus>
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <input type="password" name="password" value="" class="form-control" placeholder="Пароль" required>
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        </div>
                    </div>
                </div>
                <div class="panel-footer">
                    <h4></h4>
                    <button class="btn btn-lg btn-primary btn-block" type="submit" name="do_login">Войти</button>
                </div>
            </div>
        </form>
    </div>
    <?php if (!empty($data['text'])): ?>
        <div class="panel panel-default panel-warning">
            <div class="panel-body text-left" style="padding-bottom: 0;">
                <?= $data['text'] ?>
                <h2></h2>
            </div>
        </div>
    <?php endif; ?>
</div>
