<!DOCTYPE html>
<?php
$colors = [
    'г. Екатеринбург' => 'midnight-blue',
    'г. В. Пышма' => 'green', //17,7
    'г. Первоуральск' => 'wisteria', //44,2 nephritis
    'г. Ревда' => 'pumpkin', //47,1 emerald
    'р.п. Белоярский' => 'teal', //53,5
    'г. Полевской' => 'peter-river', //53,6
    'г. В.Серги' => 'blue', //98,5
    'г. К-Уральский' => 'pomegra', //102,7
    'г. Н. Тагил' => 'belize-hole', //139,5
    'г. Камышлов' => 'purple', //144,6
    'г. В. Салда' => 'amethyst', //174,1
    'г. Кушва' => 'wisteria', //192,3
    'г. Красноуфимск' => 'magenta', //198,6
    'г. Ирбит' => 'clouds', //199,7 sun-flower
    'г. В. Тура' => 'concrete', //202,3 orange
    'г. Шадринск' => 'carrot', //227,7
    'г. Копейск' => 'pumpkin', //233,9
    'г. Туринск' => 'alizarin', //259,5
    'г. Краснотурьинск' => 'red', //382,6
]
?>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Конкурс «Лучший студент среднего профессионального образования»</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" type="text/css" href="/libs/metro-bootstrap/css/metro-bootstrap.min.css">
    <link rel="stylesheet" href="/libs/metro-bootstrap/styles/font-awesome.min.css">
    <link rel="stylesheet" href="/libs/slick/slick.css">
</head>
<body>

    <div class="btn-group" style="width: 100%">
        <div id="left" class="btn btn-primary" style="width: 50%"><i class="fa fa-4x fa-chevron-left"></i></div>
        <div id="right" class="btn btn-primary" style="width: 50%"><i class="fa fa-4x fa-chevron-right"></i></div>
    </div>

    <div class="grid">
        <?php foreach ($users as $chunk): ?>
            <div style="padding: 0;margin: 0;">
                <?php foreach ($chunk as $user): ?>
                    <div class="tile tile-<?= $colors[$user['city']] ?> col-sm-6 col-xs-12">
                        <h1 style="font-size: 6em;"><?= $user['sum'] ?></h1>
                        <h1><?= implode('<br>', explode(' ', $user['fio'])) ?></h1>
                        <span class="tile-label"><?= $user['city'] ?></span>
                        <span class="badge">№<?= $user['n'] ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" src="/libs/metro-bootstrap/scripts/vendor/bootstrap.min.js"></script>
<script type="text/javascript" src="/libs/metro-bootstrap/scripts/metro-docs.js"></script>
<script src="/libs/slick/slick.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('.grid').slick({
            infinite: false,
            prevArrow: $('#left'),
            nextArrow: $('#right'),
        });
        $('.tile').first().focus()
    });
</script>
</body>
</html>

<style>
    html,body {
        margin: 0;
        padding: 0;
        height:100%;
    }
    .grid {
        height: 100%;
    }
    .tile .badge {
        background: #f0f0f0;
        font-size: 3em;
        color: black;
        position: absolute;
        left: 0;
        top: 0;
    }

    .tile h1:nth-child(2) {
        font-size: 3em;
    }

    .tile .tile-label {
        font-size: 24px;
        left: 0;
        width: 100%;
    }

    .tile .tile-text {
        margin: 0 !important;
        font-size: 16px;
    }

    .tile:hover .tile-text {
        display: block;
    }

    /*col-sm-6 col-md-4 col-lg-3*/
    .grid .row {
        background-color: transparent;
        border: 0;
        height: 50px;
        padding-right: 0;

    }

    .grid .col-lg-3, .grid .col-sm-6 {
        min-height: 400px;
    }

    .col-sm-6 {
        width: 20%!important;
    }

    /*.grid .row .col-md-6 {*/
    /*    min-height: 300px;*/
    /*}*/
</style>
