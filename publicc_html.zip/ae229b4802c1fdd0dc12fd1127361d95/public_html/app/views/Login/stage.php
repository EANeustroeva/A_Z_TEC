<div class="container">
    <h1>СВОДНАЯ ТАБЛИЦА</h1>
    <table class="table table-striped table-hover table-bordered" style="font-size: 1.4em;">
        <thead>
        <tr>
            <th>№</th>
            <th>ФИО</th>
            <th class="text-center">Предв.</th>
            <th class="text-center">1 этап</th>
            <th class="text-center" style="width:130px">2 этап</th>
            <th style="width:130px"></th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($users as $id=>$user): ?>
            <tr>
                <td class="text-center"><?= $user['n'] ?></td>
                <td><?= $user['fio'] ?></td>
                <td class="text-center"><?= $user['pre'] ?></td>
                <td class="text-center"><?= $user['vote'] ?></td>
                <td class="text-center">
                    <div class="btn-group">
                        <div onclick="sub(<?=$id?>,this)" class="btn btn-danger">-</div>
                        <div class="btn btn-default"><?= $user['votes'] ?></div>
                        <div onclick="add(<?=$id?>,this)" class="btn btn-success">+</div>
                    </div>
                </td>
                <td>
                    <div onclick="fix(<?=$id?>,this)" class="btn btn-default" disabled>ЗАФИКСИРОВАТЬ</div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
    function add(id, el) {
        let votes = $(el).prev();
        if (votes.data('prev') === undefined) votes.data('prev', parseInt(votes.text()));
        let fix = $(el).parent().parent().next().find('.btn');
        votes.text(parseInt(votes.text())+1);
        fix.attr('disabled', false).addClass('btn-primary');
        if (votes.data('prev') === parseInt(votes.text())) fix.attr('disabled', true).removeClass('btn-primary');
    }

    function sub(id, el) {
        let votes = $(el).next();
        if (votes.text() <= 0) return;
        if (votes.data('prev') === undefined) votes.data('prev', parseInt(votes.text()));
        let fix = $(el).parent().parent().next().find('.btn');
        votes.text(parseInt(votes.text())-1);
        fix.attr('disabled', false).addClass('btn-primary')
        if (votes.data('prev') === parseInt(votes.text())) fix.attr('disabled', true).removeClass('btn-primary');
    }

    function fix(id, el) {
        let votes = $(el).parent().prev().find('.btn-default');
        $.ajax('?id='+id+'&m='+parseInt(votes.text())).done(function( data ) {
            if (data === '1') {
                $(el).attr('disabled', true).removeClass('btn-primary');
                votes.data('prev', parseInt(votes.text()));
            }
        });
    }
</script>