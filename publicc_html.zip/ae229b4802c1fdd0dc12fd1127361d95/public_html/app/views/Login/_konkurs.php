<h3>Конкурс «Лучший студент среднего профессионального образования»</h3>
<?php if (!empty($_SESSION['info_msg'])):?>
    <div class="alert alert-success fade in" role="alert">
        <?= array_shift($_SESSION['info_msg']) ?>
        <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>
    </div>
<?php endif; ?>

<?php if (count($_SESSION['k_poll_voted']) < count($users)):?>
<div class="panel panel-default">
    <div class="panel-heading">
		<h4>I этап</h4>
    </div>
    <div class="panel-body">
        <?php if (empty($_GET['c'])): ?>
            <p>Выберите участника:</p>
        <div class="row">
            <?php foreach ($users as $user):?>
                <?php if (in_array($user['fio'], $_SESSION['k_poll_voted'])) continue; ?>
                <div class="col-xs-6 col-sm-4 col-md-3">
                    <a class="btn btn-default form-control text-uppercase" style="margin-bottom: 5px;" href="?c=<?= $user['fio'] ?>">
                        <?= $user['fio'] ?>
                    </a>
                </div>
            <?php endforeach;?>
        </div>
        <?php else: ?>
            <a href="?">Вернуться к выбору участника</a>
            <h1>Выбран участник: <?= $_GET['c'] ?></h1>
            <hr>
            <h4>Как вы оцениваете выступление:</h4>
            <?php for ($i=0; $i<10; $i++): ?>
                <a class="btn btn-default" href="?c=<?= $_GET['c'] ?>&m=<?= $i+1 ?>"><?= $i+1 ?></a>
            <?php endfor; ?>
        <?php endif; ?>
        <div class="clearfix"></div>
    </div>
</div>
<?php elseif (count($_SESSION['k_poll_voted2']) < count($users)): ?>
<div class="panel panel-default">
    <div class="panel-heading">
        <h4>II этап</h4>
    </div>
    <div class="panel-body">
        <?php if (empty($_GET['c'])): ?>
            <p>Выберите участника:</p>
            <div class="row">
                <?php foreach ($users as $user):?>
                    <?php if (in_array($user['fio'], $_SESSION['k_poll_voted2'])) continue; ?>
                    <div class="col-xs-6 col-sm-4 col-md-3">
                        <a class="btn btn-default form-control text-uppercase" style="margin-bottom: 5px;" href="?c=<?= $user['fio'] ?>">
                            <?= $user['fio'] ?>
                        </a>
                    </div>
                <?php endforeach;?>
            </div>
        <?php else: ?>
            <a href="?">Вернуться к выбору участника</a>
            <h1>Выбран участник: <?= $_GET['c'] ?></h1>
            <hr>
            <h4>Как вы оцениваете выступление:</h4>
            <a class="btn btn-default" href="?c=<?= $_GET['c'] ?>&n=0">Нет</a>
            <a class="btn btn-default" href="?c=<?= $_GET['c'] ?>&n=1">Да</a>

        <?php endif; ?>
        <div class="clearfix"></div>
    </div>
</div>
<?php else:?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h4>Итоги голосования</h4>
        </div>
        <div class="panel-body">
            <h1>Подводится итог...</h1>
            <hr>
            <div class="clearfix"></div>
        </div>
    </div>
<?php endif; ?>