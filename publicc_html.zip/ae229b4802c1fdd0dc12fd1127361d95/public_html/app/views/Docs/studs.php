<div class="row">
    <div class="col-sm-8">
        <h5>Направление: <?= isset($plan['napr']) ? $plan['napr'] . ' ('. $plan['napr_n'] . ')' : 'Не найдено'?></h5>
        <h5>Профиль:     <?= isset($plan['dop']) ? $plan['dop'] : 'Не найдено'?></h5>
        <h4>Предмет:     <?= $_GET['disc'] ?></h4>
    </div>
<!--    --><?php //if (isset($plan['lektor'])): ?>
    <div class="col-sm-4">
        <form action="<?= BASE_URL ?>tasks/view?disc=<?= $_GET['disc'] ?>" method="post" style="display: inline" class="pull-right">
            <input type="hidden" name="id" value="0">
            <span class="btn btn-success">
                <span class="glyphicon glyphicon-eye-open"></span>&nbsp;Загрузить работу</span>
        </form>
    </div>
<!--    --><?php //endif; ?>
</div>


<?php
    if (empty($docs) && empty($rpd) && empty($fos)): echo '<div class="panel panel-default"><div class="panel-body"><h3 class="text-center" style="margin-bottom: 20px;">Документы по выбранному предмету не найдены</h3></div></div>';
else: ?>
<table class="table table-responsive table-bordered table-striped">

    <tbody>
        <?php if (!empty($rpd)): ?>
        <tr>
            <th>РПД:</th>
            <td colspan="2">
                <a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $rpd['fname']) . '&c=' . urlencode($rpd['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $rpd['ftitle'] ?></a>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($fos)): ?>
        <tr>
            <th>ФОС:</th>
            <td colspan="2">
                <a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $fos['fname']) . '&c=' . urlencode($fos['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $fos['ftitle'] ?></a>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($docs)): ?>
        <tr class="info"><th colspan="3">Задания:</th></tr>
        <tr>
            <th>Файл</th>
            <th>Комментарий</th>
            <th>Действие</th>
        </tr>
    <?php foreach ($docs as $i => $task): ?>
        <tr>
            <td><a class="list-group-item" style="padding: 0"
               href="<?= BASE_URL . 'download?f=' . base64_encode('../ino/' . $task['fname']) . '&c=' . urlencode($task['ftitle']) ?>"><i
                        class="glyphicon glyphicon-open-file"></i> <?= $task['ftitle'] ?></a></td>
            <td><?php
                if (!empty($task['descr'])) echo '<span tabindex="0" data-html="true" data-toggle="popover"
                      data-content="'. htmlspecialchars($task['descr']) .'" class="btn btn-xs btn-primary" style="display: inline-block"><i class="glyphicon glyphicon-comment"></i></span>';
//                mb_strimwidth($task['descr'], 0, 10, '..');
                ?></td>
            <td>
                <?php if (!empty($task['taskfile'])): ?>
                <?php endif; ?>
                <form action="<?= BASE_URL ?>tasks/view?disc=<?= $_GET['disc'] ?>" method="post" style="display: inline">
                    <input type="hidden" name="id" value="<?= $task['id'] ?>">
                    <span type="submit" class="btn btn-success btn-xs">
                        <span class="glyphicon glyphicon-eye-open"></span>&nbsp;<span
                                class="hidden-xs">Загрузить ответ</span></span>
                </form>
            </td>
        </tr>

    <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
<?php endif; ?>

<?php if ($_GET['disc'] && isset($plan['lektor'])): ?>
<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">Диалог с преподавателем <?= isset($plan['lektor']) ? "({$plan['lektor']})" : '' ?></div>
            <div class="panel-body">
                <div class="container-chat" style="min-height: 100px;
    max-height: 600px;">
                    <ul class="list-unstyled">
                        <p class="text-center">Нет сообщений</p>
                    </ul>
                </div>
            </div>
            <div class="panel-footer">
                <form action="<?= BASE_URL ?>users/dialog" method="post" class="input-group">
                    <input type="text" name="msg" class="form-control" autocomplete="off" autofocus required>
                    <input type="hidden" name="usr_name"
                           value="<?= $plan['lektor'] ?>">
                    <input type="hidden" name="usr_id" value="<?= $plan['user_id'] ?>">
                    <span class="input-group-btn">
                    <span class="btn btn-default" ><i class="glyphicon glyphicon-pencil"></i></span>
                </span>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<style>
    .list-group-item {
        word-break: break-word;
    }
</style>

<script>
    var popOverSettings = {
    placement: 'left',
    container: 'body',
    trigger: 'focus',
    html: true,
    selector: '[data-toggle=popover]',
    content: function () {
        return $('#popover-content').html();
    }
};

$('body').popover(popOverSettings);
</script>
