<form action="/docs/incdocs" method="post">
    <div class="panel panel-default">
        <div class="panel-body">
            <h4></h4>
            <div class="form-group">
            <select style="margin: 0 15px" name="course" id="">
                <option <?= (isset($_POST['course']) && $_POST['course'] == 0) ? 'selected' : '' ?> value="0">2018г</option>
                <option <?= (isset($_POST['course']) && $_POST['course'] == 1) ? 'selected' : '' ?> value="1">2017г</option>
                <option <?= (isset($_POST['course']) && $_POST['course'] == 2) ? 'selected' : '' ?> value="2">2016г</option>
                <option <?= (isset($_POST['course']) && $_POST['course'] == 3) ? 'selected' : '' ?> value="3">2015г</option>
                <option <?= (isset($_POST['course']) && $_POST['course'] == 4) ? 'selected' : '' ?> value="4">2014г</option>
            </select>
            <select style="margin: 0 15px" name="sem" id="">
                <option <?= (isset($_POST['sem']) && $_POST['sem'] == 1) ? 'selected' : '' ?> value="1">1 семестр</option>
                <option <?= (isset($_POST['sem']) && $_POST['sem'] == 2) ? 'selected' : '' ?> value="2">2 семестр</option>
                <option <?= (isset($_POST['sem']) && $_POST['sem'] == 3) ? 'selected' : '' ?> value="3">3 семестр</option>
                <option <?= (isset($_POST['sem']) && $_POST['sem'] == 4) ? 'selected' : '' ?> value="4">4 семестр</option>
                <option <?= (isset($_POST['sem']) && $_POST['sem'] == 5) ? 'selected' : '' ?> value="5">5 семестр</option>
                <option <?= (isset($_POST['sem']) && $_POST['sem'] == 6) ? 'selected' : '' ?> value="6">6 семестр</option>
                <option <?= (isset($_POST['sem']) && $_POST['sem'] == 7) ? 'selected' : '' ?> value="7">7 семестр</option>
                <option <?= (isset($_POST['sem']) && $_POST['sem'] == 8) ? 'selected' : '' ?> value="8">8 семестр</option>
                <option <?= (isset($_POST['sem']) && $_POST['sem'] == 9) ? 'selected' : '' ?> value="8">9 семестр</option>
            </select>
            <button class="btn btn-warning">Получить группы без документов</button>
            <div class="checkbox pull-right" style="padding-right: 15px;">
                <label><input type="checkbox" name="print" value="1">Версия для печати</label>
            </div>
            </div>
            <!--<div class="form-group">
                <input type="checkbox" value="1" name="print" placeholder="Версия для печати">
                <label for="print">Версия для печати</label>
            </div>-->
        </div>
    </div>

</form>
<form action="/docs/genLogin" method="post" target="_blank">
    <div class="panel panel-default">
        <div class="panel-body">
            <div class=""></div>
            <h4></h4>
            <div class="col-xs-12">
                <div class="form-group">
                    <select class="selectpicker" data-size="8" name="course" id="course">
                        <option value="0">2018</option>
                        <option value="1">2017</option>
                        <option value="2">2016</option>
                        <option value="3">2015</option>
                        <option value="4">2014</option>
                    </select>
                    <select  class="selectpicker" data-size="8" data-live-search="true" name="class" id="class"></select>
                    <button class="btn btn-default pull-right">Генерировать список логинов</button>

                </div>
            </div>
        </div>
    </div>

</form>

<!--<form action="/docs/genekz" method="post" target="_blank">
    <div class="panel panel-default">
        <div class="panel-body">
            <div class=""></div>
            <h4></h4>
            <div class="col-xs-12">
                <div class="form-group">
                    <select  class="selectpicker" data-size="8" data-live-search="true" name="class" id="class2">
                        <?php /*foreach ($classes as $y => $group): */?>
                            <optgroup label="<?/*= $y */?> год поступления">
                                <?php /*foreach ($group as $k => $class): */?>
                                <option><?/*= $class */?></option>
                                <?php /*endforeach; */?>
                            </optgroup>
                        <?php /*endforeach; */?>
                    </select>
                    <select  class="selectpicker" data-size="8" data-live-search="true" name="disc" id="disc"></select>
                    <button class="btn btn-default pull-right">Генерировать ведомость</button>

                </div>
            </div>
        </div>
    </div>

</form>
-->

<h4></h4>
<?php if (!empty($docs)): ?>

    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Группа</th>
            <th>РПД</th>
            <th>ФОС</th>
            <th>Задания</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($docs as $k => $item): ?>
            <tr>
                <td><?= $k ?></td>
                <td class="text-left"><?php foreach ($item as $key => $value) { if (isset($value[1])) echo "<li>{$key}</li>"; } ?></td>
                <td class="text-left"><?php foreach ($item as $key => $value) { if (isset($value[2])) echo "<li>{$key}</li>"; } ?></td>
                <td class="text-left"><?php foreach ($item as $key => $value) { if (isset($value[0])) echo "<li>{$key}</li>"; } ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

<?php endif; ?>

<script>
    $(document).ready(function () {
        get_list();
        $('#course').on('changed.bs.select', function (e) {
            get_list();
        });

    });

    $('#class2').on('changed.bs.select', function (e) {
        $.ajax({
            url: base+'docs/getdiscs',
            type: 'post',
            data: {'class': $(this).val()},
            success: function (res) {
                $('#disc')
                    .html(res)
                    .selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    function get_list() {
        $.ajax({
            url: base+'profile/getListFilter',
            type: 'post',
            data: {'course': $('#course').val()},
            success: function (res) {
                $('#class')
                    .html(res)
                    .selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }
</script>
