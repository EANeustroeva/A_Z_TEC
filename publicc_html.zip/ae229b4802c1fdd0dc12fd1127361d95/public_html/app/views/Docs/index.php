    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">Загрузить</h4>
          </div>
          <div class="modal-body">
              <div class="form-group">
                <label for="recipient-name" class="control-label">Файл:</label>
                <input type="file" id="file" required>
              </div>
              <div class="form-group">
                <label for="recipient-name" class="control-label">Тип файла:</label>
                  <select class="selectpicker form-control" id="ftype2">
                      <option value="1">РПД</option>
                      <option value="2">ФОС</option>
                      <option value="0">Доп. файл</option>
                  </select>
              </div>
              <div class="form-group">
                <label for="message-text" class="control-label">Комментарий:</label>
                <textarea class="form-control" id="comment"></textarea>
              </div>
          </div>
          <div class="modal-footer">
              <input id="disc_name" type="hidden" value="">
            <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
            <button type="button" id="save" class="btn btn-success">Сохранить</button>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel2">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel2">Редактировать файл</h4>
          </div>
          <div class="modal-body">
              <div class="form-group">
                <label for="recipient-name" class="control-label">Скачать файл:</label>
                  <span id="filename"></span>
                  <small id="changed" style="color: #bebebe"></small>
              </div>
              <div class="form-group">
                <label for="recipient-name" class="control-label">Тип файла:</label>
                  <select class="selectpicker form-control" id="ftype">
                      <option value="1">РПД</option>
                      <option value="2">ОС</option>
                      <option value="0">Доп. файл</option>
                  </select>
              </div>
              <div class="form-group">
                <label for="message-text" class="control-label">Комментарий:</label>
                <textarea class="form-control" id="comment2"></textarea>
              </div>
          </div>
          <div class="modal-footer" style="text-align: left">
              <input id="file_id" type="hidden" value="">
              <button type="button" id="save2" class="btn btn-success">Сохранить</button>
              <button type="button" id="deletedoc" class="btn btn-danger">Удалить</button>
              <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
          </div>
        </div>
      </div>
    </div>
<!--<div class="panel panel-default">
    <div class="panel-body">
        <div class="form-group">
            <input class="form-control" type="text" name="descr" placeholder="Коментарий учителя">
        </div>
        <input type="file" name="file" required>
    </div>
</div>-->
<!--<div class="alert alert-success" role="alert"><span class="badge" style="background-color: #5cb85c;margin-right: -5px">New!</span>&nbsp;&nbsp;&nbsp;Внимание! Добавлен просмотр документов со стороны студента, для этого нужно просто кликнуть на предмет в списке, откроется новое окно.<a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a></div>-->
<div class="info"></div>
<div class="panel">
    <div class="panel-footer">
        <div class="row">
            <div class="col-xs-4">
                <div class="form-group" style="margin: 0;">
                    <select class="selectpicker form-control" id="disc" title="Предметы" name="discs[]"
                           multiple data-live-search="true" data-actions-box="true"></select>
                </div>
            </div>
            <div class="col-xs-4">
                <div class="form-group" style="margin: 0;">
                    <select class="selectpicker form-control" id="class2" title="Группа"></select>
                </div>
            </div>
            <div class="col-xs-4">
                <div class="form-group" style="margin: 0;">
                    <span id="dub" class="btn btn-warning">Копировать в группу</span>
                </div>
            </div>

        </div>
    </div>
</div>
<div class="panel panel-default">
    <div class="panel-body">
        <div class="row">
            <div class="col-xs-4">
                <div class="form-group" style="margin: 0;">
                    <select required class="selectpicker form-control" name="course" id="course" title="*Год поступления">
                        <option selected value="0">2018</option>
                        <option value="1">2017</option>
                        <option value="2">2016</option>
                        <option value="3">2015</option>
                        <option value="4">2014</option>
<!--                                <option value="5">5 курс</option>-->
                    </select>
                </div>
            </div>
            <div class="col-xs-4">
                <div class="form-group" style="margin: 0;">
                    <select required class="selectpicker form-control" name="sem" id="sem" title="*Семестр">
                        <option selected value="1">1 семестр</option>
                        <option value="2">2 семестр</option>
                        <option value="3">3 семестр</option>
                        <option value="4">4 семестр</option>
                        <option value="5">5 семестр</option>
                        <option value="6">6 семестр</option>
                        <option value="7">7 семестр</option>
                        <option value="8">8 семестр</option>
                        <option value="9">9 семестр</option>
                    </select>
                </div>
            </div>
            <div class="col-xs-4">
                <div class="form-group" style="margin: 0;">
                    <select required class="selectpicker form-control" name="class[]" id="class" title="*Группа"
                            data-live-search="true" data-actions-box="true" data-multipleSeparator="|" data-size="10">
                    </select>
                </div>
            </div>

        </div>
    </div>
</div>

    <div id="table">
        <div class="panel panel-default">
            <div class="panel-body text-center">
                Выберите группу
            </div>
        </div>
    </div>




<style>
    .panel-body { padding: 15px; }
    div.tooltip-inner {
        max-width: inherit;
        text-align: center;/*
        -webkit-border-radius: 0px;
        -moz-border-radius: 0px;
        border-radius: 0px;
        margin-bottom: 6px;
        background-color: #505050;*/
        font-size: 16px;
    }
</style>
<script src="<?= BASE_URL?>js/filter.js?r=4"></script>
<script>
    $(document).ready(function () {
        get_list();
    });

    $(document.body).on('click', '.label' ,function(event) {
        var button = $(this);
        var id = button.data('id');
        get_file(id);
         $('#exampleModal2').modal('show');
    });

    $('#exampleModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var recipient = button.data('whatever');
      var doctype = button.data('doctype');
      if (doctype == 'РПД') $('#ftype2').val(1).selectpicker('refresh');
      else if (doctype == 'ФОС') $('#ftype2').val(2).selectpicker('refresh');
      else $('#ftype2').val(0).selectpicker('refresh');
      var modal = $(this);
      modal.find('.modal-title').text('Загрузить ' + doctype + ' по предмету: ' + recipient);
      modal.find('.modal-body input').val('');
      modal.find('.modal-body textarea').val('');
      $('#disc_name').val(recipient);
    });

    $('#save').click(function () {
        var fd = new FormData();
        fd.append('descr', $('#comment').val());
        fd.append('disc', $('#disc_name').val());
        fd.append('course', $('#course').val());
        fd.append('class', $('#class').val());
        fd.append('sem', $('#sem').val());
        fd.append('ftype', $('#ftype2').val());
        fd.append('file', $('#file')[0].files[0]);
        $.ajax({
            type: 'post',
            url: base + 'docs/uploaduch',
            data: fd,
            processData: false,
            contentType: false,
            dataType: "json",
            success: function (res) {
                update_table();
                $('#exampleModal').modal('hide');

            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    $('#save2').click(function () {
        $.ajax({
            url: base + 'docs/savedoc',
            type: 'get',
            data: {
                id: $('#file_id').val(),
                descr: $('#comment2').val(),
                type: $('#ftype').val()
            },
            success: function (res) {
                update_table();
                $('#exampleModal2').modal('hide');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    $('#dub').click(function () {
        $.ajax({
            url: base + 'docs/dub',
            type: 'post',
            data: {
                class: $('#class').val(),
                class2: $('#class2').val(),
                discs: $('#disc').val(),
                sem: $('#sem').val()
            },
            success: function (res) {
                if (res)
                $('.info').html('<div class="alert alert-success" role="alert">Успешно скопировано<a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a></div>');
                else $('.info').html('<div class="alert alert-danger" role="alert">Не выбраны предметы/группа<a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a></div>');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    $('#deletedoc').click(function () {
        $.ajax({
            url: base + 'docs/deletedoc',
            type: 'get',
            data: {
                id: $('#file_id').val(),
            },
            success: function (res) {
                update_table();
                $('#exampleModal2').modal('hide');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    function get_file(id) {
        $.ajax({
            url: base + 'docs/getFileById',
            type: 'get',
            data: {'id': id},
            success: function (res) {
                res = JSON.parse(res);
                $('#filename').html(res.link);
                $('#changed').html(res['changed']);
                $('#comment2').val(res.descr);
                $('#file_id').val(res.id);
                $('#ftype').val(res.type).selectpicker('refresh');

                // $('#table').html(res);
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function update_table() {
         $.ajax({
            url: 'getListDisc',
            type: 'get',
            data: {'class': $('#class').val(),'sem': $('#sem').val()},
            success: function (res) {
                $('#table').html(res.res);
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    $('body').tooltip({
        selector: '[data-toggle=tooltip]'
    });
</script>