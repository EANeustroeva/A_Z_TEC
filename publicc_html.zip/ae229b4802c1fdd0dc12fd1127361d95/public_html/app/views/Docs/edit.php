<form action="<?= BASE_URL ?>docs/uploaduch" method="post" enctype="multipart/form-data">

<div class="col-sm-4">
    <div class="panel panel-success">
        <div class="panel-body">
            <!--<div class="form-group">
                <select class="selectpicker form-control" id="asgmt" title="Назначение">
                    <option selected value="1">Группа</option>
                    <option value="2">Курс</option>
                </select>
            </div>-->
            <?php if ($cur_user->access == 1 || $cur_user->access == 3): ?>
            <div class="form-group">
                <select required class="selectpicker form-control" name="course" id="course" title="*Год поступления">
                    <option value="0" selected>2018</option>
                    <option value="1">2017</option>
                    <option value="2">2016</option>
                    <option value="3">2015</option>
                    <option value="4">2014</option>
                    <option value="5">2013</option>
                </select>
            </div>

            <div class="form-group">
                <select required class="selectpicker form-control" name="sem" id="sem" title="*Семестр">
                    <option selected value="1">1 семестр</option>
                    <option value="2">2 семестр</option>
                </select>
            </div>
            <?php endif; ?>

            <div class="form-group">
                <select required class="selectpicker form-control" name="class[]" id="class" title="*Группа"
                        data-live-search="true" data-actions-box="true" data-multipleSeparator="|" multiple>
                </select>
            </div>

            <div class="form-group">
                <select required class="selectpicker form-control" name="disc" id="disc" title="*Предмет" data-live-search="true">
                </select>
            </div>
            <button class="btn btn-success" type="submit">Сохранить</button>
        </div>
    </div>
</div>
<div class="col-sm-8">
    <div class="panel panel-default">
        <div class="panel-body">
            <div class="form-group">
                <input class="form-control" type="text" name="descr" placeholder="Коментарий учителя">
            </div>
            <input type="file" name="file" required>
        </div>
    </div>
</div>

</form>
<style>
    .panel-body { padding: 15px; }
</style>
<script src="<?= BASE_URL?>js/filter.js"></script>
<script>
    $(document).ready(function () {
        get_list();
    })
</script>