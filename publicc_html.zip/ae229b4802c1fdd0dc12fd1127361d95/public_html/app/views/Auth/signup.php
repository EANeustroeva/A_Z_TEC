
<form class="form-signin" action="signup" method="post">
    <h2 class="form-signin-heading">Регистрация</h2>
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php echo array_shift($errors); ?>
        </div>
    <?php endif; ?>
    <div class="form-group">
        <input type="text" name="firstname" value="<?php echo @$data['firstname'] ?>" id="firstname" class="form-control" placeholder="Имя" required="required" autofocus/>

        <input type="text" name="lastname" value="<?php echo @$data['lastname'] ?>" id="lastname" class="form-control" placeholder="Фамилия" required="required"/>
    </div>

    <input type="email" name="email" value="<?php echo @$data['email'] ?>" class="form-control" placeholder="Email адрес" required >
    <input type="text" name="login" value="<?php echo @$data['login'] ?>" class="form-control" placeholder="Логин" required>
    <input type="password" name="password" value="<?php echo @$data['password'] ?>" class="form-control" placeholder="Пароль" required>

    <button class="btn btn-lg btn-primary btn-block" name="do_signup" type="submit">Зарегистрироваться</button>

    <h5>Назад, к <a href="<?= BASE_URL ?>">авторизации</a></h5>
</form>
