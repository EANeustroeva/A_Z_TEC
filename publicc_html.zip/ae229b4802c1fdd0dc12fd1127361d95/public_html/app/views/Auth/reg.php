<div class="row">
    <div class="col-sm-8 col-sm-offset-2">
        <form class="form-horizontal" method="POST">
            <div class="form-group">
                <label class="col-xs-4 control-label">Enter your login: </label>
                <div class="col-xs-8">
                    <input class="form-control" type="text" name="login">
                </div>
            </div>
            <div class="form-group">
                <label class="col-xs-4 control-label">Enter your old password: </label>
                <div class="col-xs-8">
                    <input class="form-control" type="password" name="oldpass">
                </div>
            </div>
            <div class="form-group">
                <label class="col-xs-4 control-label">Enter your new password: </label>
                <div class="col-xs-8">
                    <input class="form-control" type="password" name="newpass1">
                </div>
            </div>
            <div class="form-group">
                <label class="col-xs-4 control-label">Retype your new password: </label>
                <div class="col-xs-8">
                    <input class="form-control" type="password" name="newpass2">
                </div>
            </div>
            <input class="btn btn-default" type="submit" value="Отправить" name="submitMe">
        </form>
    </div>
</div>

<?php
if(isset($_POST['submitMe']))
{
    $username=$_POST['login'];
    $oldpassword=$_POST['oldpass'];
    $newpassword=$_POST['newpass1'];
    $newpassword2=$_POST['newpass2'];
    print"Hello, $username!\n";


    ldap_set_option(NULL, LDAP_OPT_DEBUG_LEVEL, 7);
    $ldapconn = ldap_connect('ldaps://my.domain.com/',636);
    ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($ldapconn, LDAP_OPT_REFERRALS, 0);
    $ldapuser="domain\admuser";
    $ldappwd="admpwd";

    // search for user
    ldap_bind($ldapconn, $ldapuser, $ldappwd);

    $res_id = ldap_search( $ldapconn, "DC=my,DC=domain,DC=com", "sAMAccountName=$username");
    if ($res_id) {
        $entry_id = ldap_first_entry($ldapconn, $res_id);
        if($entry_id){
            $user_dn = ldap_get_dn($ldapconn, $entry_id);
            if ($user_dn) {
                $ldapbind = ldap_bind($ldapconn, $user_dn, $oldpassword);
                // check if the old password allows a successfull login
                if($ldapbind) {
                    if(strcmp($newpassword, $newpassword2)==0){

                        // create the unicode password
                        $newpassword = "\"" . $newpassword . "\"";
                        $newPass = mb_convert_encoding($newpassword, "UTF-16LE");

                        //rebind as admin to change the password
                        ldap_bind($ldapconn, $ldapuser, $ldappwd);

                        $pwdarr = array('unicodePwd' => $newPass);
                        print "<p class='error'>$user_dn</p>\n";
                        if(ldap_modify ($ldapconn, $user_dn, $pwdarr)) {
                            print "<p class='success'>Change password succeded.</p>\n";
                        } else {
                            print "<p class='error'>Change password failed.</p>\n";
                        }
                    }else{
                        print "<p class='error'>New password must be entered the same way twice.</p>\n";
                    }
                }else{
                    print "<p class='error'>Wrong user name or password.</p>\n";
                }
            } else {
                print "<p class='error'>Couldn't load user data.</p>\n";
            }
        } else {
            print "<p class='error'>Couldn't find user data.</p>\n";
        }
    } else {
        print "<p class='error'>Username was not found.</p>\n";
    }
    if(ldap_error($ldapconn)!="Success"){
        print "<p class='error'>LDAP Error:<br />\n";
        var_dump(ldap_error($ldapconn));
        print "</p>\n";
    }
    @ldap_close($ldapconn);
}
?>