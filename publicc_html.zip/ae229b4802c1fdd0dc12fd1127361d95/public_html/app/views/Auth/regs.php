<div id='outerdiv'>
<iframe src="https://portfolio.usue.ru/reg/uu/" id='innerIframe' scrolling=no></iframe>
</div>

<style>
#outerdiv
{
    width:756px;
    height: 500px;
    overflow:hidden;
    position:relative;
}

#innerIframe
{
    position: absolute;
    top: -156px;
    left: -184px;
    width: 1280px;
    height: 1200px;
}
</style>