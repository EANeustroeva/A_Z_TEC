<h2>Регистрации на ino-online.usue.ru/5fevr</h2>
<table class="table table-hover table-bordered table-striped">
    <thead>
    <tr>
        <th>ФИО</th>
        <th>Учебное заведение</th>
        <th>Email</th>
        <th>Контакты</th>
        <th>Дата регистрации</th>
        <th>Действие</th>
    </tr>
    </thead>
    <tbody>
<?php foreach ($data as $item): ?>
<tr>
    <td><?= $item['name'] ?></td>
    <td><?= $item['uchzav'] ?></td>
    <td><?= $item['email'] ?></td>
    <td><?= $item['contact'] ?></td>
    <td><?= date("d.m.Y H:i",strtotime($item['created'])) ?></td>
    <td><a href="/eventregs/delete?id=<?= $item['id'] ?>" class="btn btn-danger btn-xs">удалить</a></td>
</tr>
<?php endforeach; ?>
    </tbody>
</table>