<?php if ($uid == $my_id && $plan2): ?>
    <div class="row">
        <div class="col-sm-12">
            <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                <thead>
                <tr>
                    <th style="width: 30%;">Предмет</th>
                    <th style="width: 30%;">Преподаватель</th>
<!--                    <th style="width: 25%;">Оценки</th>-->
<!--                    <th style="width: 15%;">Итоговая</th>-->
                </tr>
                </thead>
                <tbody>
                <form action="<?= BASE_URL ?>tasks" method="get" target="_blank">
                    <?php foreach ($plan2 as $item): ?>
                        <tr<?php echo ($item['total_marks']=='')?' class=danger':'' ?>>
                            <td class="text-left"><button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>"><?= $item['disc'] ?></button></td>
                            <td class="text-left"><a href="<?= BASE_URL ?>?id=<?= $item['user_id'] ?>" target="_blank"><?= @$item['lektor'] ?></a></td>
<!--                            <td class="text-left">--><?//= $item['marks'] ?><!--</td>-->
<!--                            <td class="text-left">--><?//= $item['total_marks'] ?><!--</td>-->
                        </tr>
                    <?php endforeach; ?>
                </form>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>