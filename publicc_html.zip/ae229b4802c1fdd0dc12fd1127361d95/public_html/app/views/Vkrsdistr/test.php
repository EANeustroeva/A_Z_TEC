<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="exampleModalLabel">Добавить предмет</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="recipient-name" class="control-label">Предмет:</label>
                    <select class="selectpicker form-control" id="prepod" data-live-search="true">
                        <option selected value="">Ничего не выбрано</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                <button type="button" id="save_prepod" class="btn btn-success">Сохранить</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel2">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="exampleModalLabel2">Выбрать преподавателя</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label class="control-label">Преподаватель:</label>
                    <select class="selectpicker form-control" id="prepod2" data-live-search="true"></select>
                </div>
                <div class="form-group">
                    <label class="control-label">Статус:</label>
                    <select class="selectpicker form-control" id="status3">
                        <option selected value="0">Лектор</option>
                        <option value="1">Промежуточный контроль</option>
                        <option value="2">Руководитель курсовой</option>
                        <option value="3">Проверяющий контрольной</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="stud_id">
                <input type="hidden" id="predm">
                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                <button type="button" id="save_prepod2" class="btn btn-success">Сохранить</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel3">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="exampleModalLabel3">Выбрать преподавателя</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label class="control-label">Преподаватель:</label>
                    <select class="selectpicker form-control" id="prepod3" data-live-search="true">
                        <option selected value="">Ничего не выбрано</option>
                        <?= $prepod ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="stud_id3">
                <input type="hidden" id="predm3">
                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                <button type="button" id="save_prepod3" class="btn btn-success">Сохранить</button>
            </div>
        </div>
    </div>
</div>

<div id="info"></div>
<?php if ($cur_user->access == 1 || $cur_user->login == 'plutomi'): ?>
<ul class="nav nav-tabs nav-justified">
    <li><a data-toggle="tab" href="#discs-tab">Предметы</a></li>
    <li class="active"><a data-toggle="tab" href="#curs-tab">Распределение</a></li>
    <li><a data-toggle="tab" href="#instr-tab">Инструкция</a></li>
</ul>
<?php endif; ?>

<?php if ($cur_user->access == 1 || $cur_user->login == 'plutomi'): ?>
<div class="tab-content">
    <div id="discs-tab" class="tab-pane fade">
        <h3> </h3>
        <fieldset>
            <legend>Выбор предмета</legend>

            <div class="col-xs-6">
                <div class="form-group">
                    <label for="" class="col-xs-6">Семестр</label>
                    <div class="col-xs-6">
                        <select name="" id="sem" class="selectpicker form-control">
                            <option value="1">1 семестр</option>
                            <option value="2">2 семестр</option>
                            <option value="3">3 семестр</option>
                            <option value="4">4 семестр</option>
                            <option value="5">5 семестр</option>
                            <option value="6">6 семестр</option>
                            <option value="7">7 семестр</option>
                            <option value="8">8 семестр</option>
                            <option value="9">9 семестр</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-xs-6">Год зачисления</label>
                    <div class="col-xs-6">
                        <select name="" id="course" class="selectpicker form-control">
                            <option value="0">2018</option>
                            <option value="1">2017</option>
                            <option value="2">2016</option>
                            <option value="3">2015</option>
                            <option value="4">2014</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-xs-6">Группа</label>
                    <div class="col-xs-6">
                        <select name="" id="class" class="selectpicker form-control" data-live-search="true">
                            <option disabled selected value="">Не выбрано</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-xs-6">
                <fieldset>
                    <legend>Пул предметов</legend>
                    <div class="well" style="max-height: 350px; overflow: auto;">
                        <ul id="discs" class="list-group checked-list-box">Выберите группу</ul>
                    </div>
                    <h3></h3>
                    <div data-toggle="modal" data-target="#exampleModal" class="btn btn-primary form-control">Добавить</div>
                </fieldset>
                <h3></h3>
                <a class="btn btn-success form-control" href="/vkrsdistr/upload"><i class="glyphicon glyphicon-upload"></i> Загрузить из файла</a>
            </div>
        </fieldset>
        <h3></h3>

      <fieldset>
            <legend style="width: 215px;">Настройка графика проведения</legend>

            <table class="table table-bordered" id="graphic">

          </table>
        </fieldset>
        <h3></h3>

    </div>
    <div id="curs-tab" class="tab-pane fade in active">
        <h3> </h3>
        <div class="row">
            <div class="col-xs-6">
                <fieldset>
                    <legend>Выбор предмета</legend>
                    <div class="col-xs-12">
                        <div class="form-group">
                            <label for="" class="col-xs-6">Семестр</label>
                            <div class="col-xs-6">
                                <select name="" id="sem4" class="selectpicker form-control">
                                    <option value="1">1 семестр</option>
                                    <option value="2">2 семестр</option>
                                    <option value="3">3 семестр</option>
                                    <option value="4">4 семестр</option>
                                    <option value="5">5 семестр</option>
                                    <option value="6">6 семестр</option>
                                    <option value="7">7 семестр</option>
                                    <option value="8">8 семестр</option>
                                    <option value="9">9 семестр</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="col-xs-6">Год зачисления</label>
                            <div class="col-xs-6">
                                <select name="" id="course4" class="selectpicker form-control">
                                    <option value="0">2018</option>
                                    <option value="1">2017</option>
                                    <option value="2">2016</option>
                                    <option value="3">2015</option>
                                    <option value="4">2014</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="col-xs-6">Группа</label>
                            <div class="col-xs-6">
                                <select name="" id="class4" class="selectpicker form-control" data-live-search="true">
                                    <option disabled selected value="">Не выбрано</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="col-xs-6">Предмет</label>
                            <div class="col-xs-6">
                                <select name="" id="discs4" class="selectpicker form-control" data-live-search="true">
                                    <option disabled selected value="">Не выбрано</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </div>
            <div class="col-xs-6">
<!--                <fieldset>-->
<!--                    <legend style="width: 150px;">Пул преподавателей</legend>-->
<!--                    <div class="well well-sm" style="height: 100px; overflow-y: auto;">-->
<!--                        <ul class="list-group userlist">-->
<!--                            Не выбрано преподавателей-->
<!--                        </ul>-->
<!--                    </div>-->
<!--                </fieldset>-->
                <h4> </h4>
                <div class="form-group">
                    <div id="print2" class="btn btn-default form-control">Печать</div>
                </div>
                <div class="form-group">
                    <div id="getfile" class="btn btn-success form-control"><i class="glyphicon glyphicon-download"></i> Получить файл распределения</div>
                </div>
                <div class="form-group">
                    <div id="getplan" class="btn btn-default form-control"><i class="glyphicon glyphicon-download"></i> Получить шаблон для распределения <span class="badge pull-right" style="display:none;background-color: #5cb85c;margin-right: -5px">New!</span></div>
                </div>
            </div>
        </div>
        <h3></h3>

        <table id="table4" class="table table-bordered table-condenced">
            <thead>
                <tr>
                    <th><input type="checkbox" name="select_all" value="1" id="example-select-all2"></th>
                    <th>№</th>
                    <th>ФИО Студента</th>
                    <th>Группа</th>
                    <th>Предмет</th>
                    <th>ФИО Преподавателя</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <div id="instr-tab" class="tab-pane fade">
        <h3>Порядок действий в распределении</h3>
        Данный раздел настраивается аналогично разделу "Распределение нагрузки", только в более упрощенном варианте.
        Есть 2 способа обновления/добавления предметов для распределения и назначения руководителей к обучающемуся.
        <h4>1-й способ (ручной)</h4>
        <b>Добавление предметов к группе</b> происходит в первой вкладке данного раздела "Предметы". Необходимо выбрать семестр и нужную группу для распределения,
        затем в правой части окна, в пуле предметов отобразятся уже привязанные предметы, если пул пустой, то необходимо нажать кнопку "Добавить" и во всплывающем окне
        выбрать предмет, подлежащий данному распределению, и нажать "Сохранить". Предмет должен отобразится в пуле, что является индикатором успешного выбора.
        <br><b>Назначение руководителей</b> происходит во вкладке "Распределение", которая открывается при первой загрузке данного раздела.
        По аналогии с распределением нагрузки, здесь необходимо выбрать семестр, группу и предмет (если предметов несколько), снизу загрузится таблица с информацией
        о выбранной группе. <br>Назначение преподавателя происходит при нажатии на <i class="btn btn-primary btn-xs glyphicon glyphicon-pencil"></i> в правой части таблицы напротив нужного студента, появится всплывающее окно,
        содержащее весь список преподавателей системы, необходимо выбрать нужного преподавателя (присутствует поиск по фио) и нажать "Сохранить".
        <br>Если же требуется назначить одного и того же преподавателя для нескольких студентов,
        то необходимо отметить галочки напротив каждого студента и нажать на <i class="btn btn-primary btn-xs glyphicon glyphicon-pencil"></i> напротив любого студента.
        Назначение произойдет только для выбранных.
        <hr>
        <h4>2-й способ (через подготовленный файл, расширения xls)</h4>
        Файл импорта позволяет назначить сразу много предметов/руководителей. Необходимо скачать <a href="/faqres/import.xls" target="_blank">образец файла</a>.
        <br>Первую строчку файла необходимо оставить, заполнять нужно только данные по распределению.
        <br>Для <b>добавления предметов к группе</b>, две последние колонки в файле можно опустить, т.е. указать семестр,
        группу и предмет.
        <br>Для <b>назначение руководителей</b> необходимо помимо предыдущего требования (указание семестра, группы и предмета) указать ФИО студента и ФИО руководителя
        точно такими же как в системе ino-online.ru без ошибок.
        <br>Для того, чтобы загрузить файл в систему, необходимо в первой вкладке "Предметы" или здесь нажать кнопку <a class="btn btn-success" href="/vkrsdistr/upload"><i class="glyphicon glyphicon-upload"></i> Загрузить из файла</a>
        <br>
        Проверить работу файла можно выбрав соответствующие фильтры во всех вкладках.
    </div>
</div>
<?php endif; ?>

<style>
    table.dataTable { border-collapse: collapse!important;}
    .table > tbody > tr > td {
        border-top: 1px solid #ddd;!important;
    }

    .table > tbody > tr > td:nth-child(1) {
        border-right: 1px solid #ddd;!important;
    }

    /*.dataTables_paginate { display: none}*/
    .panel-body { padding: 15px; }
    .state-icon {
        left: -5px;
    }
    .well .list-group {
        margin-bottom: 0px;
    }
    .list-group-item {
        padding: 1px 15px;
    }
    fieldset .form-group {
        margin-bottom: 15px;
        display: flex;
        /*display: -webkit-box;*/
    }
    fieldset
    {
        border: 1px solid #ddd !important;
        margin: 0;
        min-width: 0;
        padding: 10px;
        position: relative;
        border-radius:4px;
        /*background-color:#f5f5f5;*/
        padding-left:10px!important;
    }

    legend
    {
        font-size:14px;
        font-weight:bold;
        margin-bottom: 0px;
        width: 120px;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 5px 5px 5px 10px;
        background-color: #ffffff;
    }
</style>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/select/1.2.5/css/select.dataTables.min.css">

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script src="/js/sweetalert2.all.min.js"></script>
<script src="/js/moment.js"></script>
<script>
    $(document).ready(function () {
        $('#graphic').on('click','.btn', function () {
            let dates = [];
            $('#graphic input').each(function(){dates.push($(this).val())});
             $.ajax({
                url: '/vkrsdistr/saveClassDates',
                type: 'post',
                data: {
                    sem: $('#sem').val(),
                    class: $('#class').val(),
                    dates: dates
                },
                success: function (res) {
                    if (res !== '0')
                      Swal({
                          title: "Успешно сохранено!",
                          timer: 1500,
                          type: 'success'
                      })
                },
                error: function (e) {
                    console.log(e);
                }
            });
        });

        $('#print').click(function () {
            var user = $('#users3').val();
            var classs = $('#class3').val();
            var disc = $('#discs3').val();

           window.open(
              '/vkrsdistr/getTasks?user='+user +'&class='+classs +'&disc='+disc +'&sem='+sem +'&print=1',
              '_blank'
            );
        });
        $('#print2').click(function () {
            var classs = $('#class4').val();
            var disc = $('#discs4').val();
            var sem = $('#sem4').val();
            window.open('/vkrsdistr/getTasksCurs?class='+classs +'&disc='+disc +'&sem='+sem + '&print=1', '_blank');
        });
        $('#getfile').click(function () {
            var classs = $('#class4').val();
            var disc = $('#discs4').val();
            var sem = $('#sem4').val();
            window.open('/vkrsdistr/getTasksCurs?class='+classs +'&disc='+disc +'&sem='+sem + '&getfile=1', '_blank');
        });
        $('#getplan').click(function () {
            var classs = $('#class4').val();
            var disc = $('#discs4').val();
            var sem = $('#sem4').val();
            var course = $('#course4').val();
            window.open('/plandistr?class='+classs +'&disc='+disc+'&course='+course +'&sem='+sem, '_blank');
        });
        get_list(0);
        get_list2();

        var table4 = $('#table4').DataTable( {
            "ajax": {
                "url": base + 'vkrsdistr/getTasksCurs',
                "data": function ( d ) {
                    if ($('#class4').val()) d.class = $('#class4').val();
                    if ($('#discs4').val()) d.disc = $('#discs4').val();
                    d.sem = $('#sem4').val();
                }
            },
            "order": [],
            "paging": false,
            // "pageLength": 10,
            "searching": false,
            "lengthChange": false,
            "info":     false,
            "sDom": '<"row view-filter"<"col-sm-12"<"pull-left"l>p<"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"i>>>',
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            },
            columnDefs: [
                { 'targets': 0, 'searchable': false, 'orderable': false, 'className': 'dt-body-center', 'render': function (data, type, full, meta){
                    return '<input type="checkbox" name="id[]" value="' + $('<div/>').text(data).html() + '">';
                } },
                { "bSortable": false, "aTargets": [6] },
                { "sWidth": "300px", "aTargets": [4] }
            ],
            select: {
                style:    'os',
                selector: 'td:first-child'
            },
        } );

        $('#course, #course4').on('changed.bs.select', function (e) {
            get_list($(this).val());
            var c = $(this).val()*2-1;
            $('#course, #course4').val($(this).val()).selectpicker('refresh');
        });
        $('#sem').on('changed.bs.select', function (e) { update_disc_(); update_disc(); });
        $('#class').on('changed.bs.select', function (e) { update_disc_(); update_disc(); });
        $('#sem4').on('changed.bs.select', function (e) { update_disc2(); });
        $('#class4').on('changed.bs.select', function (e) { update_disc2(); });
        $('#discs4').on('changed.bs.select', function (e) { table4.ajax.reload(); });

        $('#save_class').on('click', function() {
            $.ajax({
                url: base + 'vkrsdistr/saveClass',
                type: 'post',
                data: {
                    discs: $('#selected_discs').val(),
                    class: $('#class').val(),
                },
                success: function (res) {
                    // update_disc();
                    $('#info').html('<div class="alert alert-success fade in" role="alert">\
                        Успешно сохранено!\
                        <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>\
                    </div>').show().delay(3000).fadeOut();
                },
                error: function (e) {
                    console.log(e);
                }
            });
        });
        $('#save_prepod').on('click', function() {
            $.ajax({
                url: base + 'vkrsdistr/saveAccesss',
                type: 'post',
                data: {
                    class: $('#class').val(),
                    sem: $('#sem').val(),
                    disc: $('#prepod').val()
                },
                success: function (res) {
                    update_disc_();
                    update_disc();
                    $('#exampleModal').modal('hide');
                    $('#info').html('<div class="alert alert-success fade in" role="alert">\
                        Успешно сохранено!\
                        <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>\
                    </div>').show().delay(3000).fadeOut();
                },
                error: function (e) {
                    console.log(e);
                }
            });
        });
        $('#save_prepod2').click(function () {
            $.ajax({
                url: base + 'vkrsdistr/savePrepod',
                type: 'post',
                data: {
                    stud_id: $('#stud_id').val(),
                    predm: $('#predm').val(),
                    sem: $('#sem3').val(),
                    prepod: $('#prepod2').val(),
                    status: $('#status3').val(),
                    selected: table3.$('input[type="checkbox"]:checked')
                        .map(function() {return this.value;}).get()
                },
                success: function (res) {
                    $('#exampleModal2').modal('hide');
                    $('#info').html('<div class="alert alert-success fade in" role="alert">\
                        Успешно сохранено!\
                        <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>\
                    </div>').show().delay(3000).fadeOut();
                    table3.ajax.reload();
                },
                error: function (e) { console.log(e); }
            })
        });
        $('#save_prepod3').click(function () {
            $.ajax({
                url: base + 'vkrsdistr/savePrepodCurs',
                type: 'post',
                data: {
                    stud_id: $('#stud_id3').val(),
                    predm: $('#predm3').val(),
                    prepod: $('#prepod3').val(),
                    sem: $('#sem4').val(),
                    class: $('#class4').val(),
                    selected: table4.$('input[type="checkbox"]:checked')
                        .map(function() {return this.value;}).get()
                },
                success: function (res) {
                    $('#exampleModal3').modal('hide');
                    $('#info').html('<div class="alert alert-success fade in" role="alert">\
                        Успешно сохранено!\
                        <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>\
                    </div>').show().delay(3000).fadeOut();
                    table4.ajax.reload();
                },
                error: function (e) { console.log(e); }
            })
        });

        $('body').on('click','.del', function () {
            $.ajax({
                url: base + 'vkrsdistr/delDisc',
                type: 'post',
                data: {
                    class: $('#class').val(),
                    sem: $('#sem').val(),
                    disc: $(this).data('id')
                },
                success: function (res) {
                    update_disc_(); update_disc();
                },
                error: function (e) {
                    console.log(e);
                }
            });
        });

//         $('#exampleModal').on('show.bs.modal', function (event) {
//             var button = $(event.relatedTarget);
//             var userid = button.data('userid');
//             var disc = button.data('predmet');
//             var modal = $(this);
//             modal.find('.modal-title').text('Добавить преподавателя');
//             // modal.find('.modal-title').text('Выбрать преподавателя по предмету: ' + disc);
// //            modal.find('.modal-body input').val('');
// //            modal.find('.modal-body textarea').val('');
// //             $('#stud_id').val(userid);
// //             $('#predm').val(disc);
//             $('#prepod').val('').selectpicker('refresh');
//         });
        $('#exampleModal2').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var userid = button.data('userid');
            var disc = button.data('predmet');
            var modal = $(this);
            modal.find('.modal-title').text('Выбрать преподавателя по предмету: ' + disc);
//            modal.find('.modal-body input').val('');
//            modal.find('.modal-body textarea').val('');
            $('#stud_id').val(userid);
            $('#predm').val(disc);
            $('#prepod').val('').selectpicker('refresh');
        });
        $('#exampleModal3').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var userid = button.data('userid');
            var disc = button.data('predmet');
            var modal = $(this);
            modal.find('.modal-title').text('Выбрать преподавателя по предмету: ' + disc);
//            modal.find('.modal-body input').val('');
//            modal.find('.modal-body textarea').val('');
            $('#stud_id3').val(userid);
            $('#predm3').val(disc);
            $('#prepod3').val('').selectpicker('refresh');
        });

        $('#example-select-all2').on('click', function(){
            var rows = table4.rows({ 'search': 'applied' }).nodes();
            $('input[type="checkbox"]', rows).prop('checked', this.checked);
        });
        $('#table4 tbody').on('change', 'input[type="checkbox"]', function(){
            if(!this.checked){
                var el = $('#example-select-all2').get(0);
                if(el && el.checked && ('indeterminate' in el)){ el.indeterminate = true; }
            }
        });

        function update_disc2() {
            $.ajax({
                url: '/vkrsdistr/getVkrDisc',
                type: 'get',
                data: {'class': $('#class4').val(), 'sem': $('#sem4').val() },
                success: function (res) {
                    var data = JSON.parse(res);
                    var e = '';
                    // if (data.count > 1) {
                    //     e = '<option disabled selected value="">Не выбрано</option>';
                    // }
                    $('#discs4')
                        .html(e + data.res).selectpicker('refresh')
                        .val(data.sel).selectpicker('refresh');
                    table4.ajax.reload();
                    update_title();
                },
                error: function () {
                    console.log('Error!');
                }
            });
        }

        function update_disc() {
            $.ajax({
                url: '/vkrsdistr/getListDisc',
                type: 'get',
                data: {'class': $('#class').val(),'sem': $('#sem').val()},
                success: function (res) {
                    $('#discs').html(res.res);
                    $('#graphic').html(res.res2)
                },
                error: function () {
                    console.log('Error!');
                }
            });
        }
        function update_disc_() {
            $.ajax({
                url: '/vkrsdistr/getListDiscs',
                type: 'post',
                data: {'class': $('#class').val(),'sem': $('#sem').val()},
                success: function (res) {
                    $('#prepod').html('<option disabled selected value="">Не выбрано</option>' + res).selectpicker('refresh');
                },
                error: function () {
                    console.log('Error!');
                }
            });
        }

        function update_title() { $('title').text([ 'Распределение курсовых', $('#discs4').val(), $('#class4').val(), $('#sem4').val()+' семестр' ].join(' | ')) }
    });

    function update_disc_access(discs = false) {
        $.ajax({
            url: '/vkrsdistr/getVkrDisc',
            type: 'get',
            data: {'class': $('#class2').val()},
            success: function (res) {
                var disc = $('#discs2');
                disc.html(res);
                if (discs) disc.val(discs);
                disc.selectpicker('refresh')
            },
            error: function () {
                console.log('Error!');
            }
        });
    }
    function update_disc_access2() {
        $.ajax({
            url: '/vkrsdistr/getVkrDiscB',
            type: 'get',
            data: {class: $('#class3').val(), user: $('#users3').val(), sem: $('#sem3').val() },
            success: function (res) {
                $('#discs3').html('<option disabled selected value="">Не выбрано</option>' + res).selectpicker('refresh')
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function load_info_access() {
        $.ajax({
            url: '/vkrsdistr/getVkrInfo',
            type: 'get',
            data: {user: $('#users2').val()},
            success: function (res) {
                $('#class2').val(res.class).selectpicker('refresh');
                update_disc_access(res.disc);
            },
            error: function () {
                console.log('Error!');
            }
        });
    }
    function load_info_access2() {
        $.ajax({
            url: '/vkrsdistr/getVkrInfoB',
            type: 'get',
            data: {},
            success: function (res) {
                $('.userlist').html(res.users);
                $('#prepod2').html('<option selected value="">Не выбрано</option>' + res.prep).selectpicker('refresh');
                $('#class3').html(res.class).selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function get_list(course) {
        $.ajax({
            url: 'getList',
            type: 'get',
            data: {'course': course},
            success: function (res) {
                $('#class, #class3, #class4').html('<option disabled selected value="">Не выбрано</option>' + res).selectpicker('refresh');
            },
            error: function () {
                $('#class, #class3, #class4').html('<option disabled selected value="">Не выбрано</option>').selectpicker('refresh');
                console.log('Error!');
            }
        });
    }
    function get_list2() {
        $.ajax({
            url: 'getList',
            type: 'get',
            data: {'course': ''},
            success: function (res) {
                $('#class2').html(res).selectpicker('refresh');
            },
            error: function () {
                $('#class2').html(res).selectpicker('refresh');
                console.log('Error!');
            }
        });
    }
</script>