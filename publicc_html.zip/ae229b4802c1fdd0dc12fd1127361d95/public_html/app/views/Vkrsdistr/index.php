<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="exampleModalLabel">Выбрать преподавателя</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="recipient-name" class="control-label">Преподаватель:</label>
                    <select class="selectpicker form-control" id="prepod" data-live-search="true">
                        <option selected value="">Ничего не выбрано</option>
                        <?= $prepod ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <input id="stud_id" type="hidden" value="">
                <input id="predm" type="hidden" value="">
                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                <button type="button" id="save_prepod" class="btn btn-success">Сохранить</button>
            </div>
        </div>
    </div>
</div>
<span id="info"></span>
<div class="panel">
    <div class="panel-footer">
        <div class="row">
            <div class="col-xs-4">
                <div class="form-group">
                    <select class="selectpicker form-control" id="discs_vkr" title="Предметы" name="discs[]"
                            multiple data-live-search="true" data-actions-box="true"></select>
                </div>
            </div>
            <div class="col-xs-4">
                <div class="form-group">
                    <span id="save_class" class="btn btn-warning">Сохранить</span>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-6">
        <label for="">Предмет:</label>
        <select class="selectpicker form-control" id="disc" title="Предмет"></select>
    </div>
    <div class="col-sm-6">
        <label for="">Студент:</label>
        <select class="selectpicker form-control" id="student" title="Студент"></select>
    </div>
</div>
<hr>

<table class="table table-striped table-hover table-bordered">
    <thead>
    <tr>
        <th>Студент</th>
        <th>Предмет</th>
        <th>Преподаватель</th>
    </tr>
    </thead>
    <tbody>

    </tbody>
</table>

<style>
    .panel-body { padding: 15px; }
</style>
<script src="<?= BASE_URL?>js/filter.js?r=4"></script>
<script>
    $(document).ready(function () {
        get_list();

        $('#save_class').click(function () {
            $.ajax({
                url: base + 'vkrdistr/saveClass',
                type: 'post',
                data: {
                    discs: $('#discs_vkr').val(),
                    class: $('#class').val(),
                    sem: $('#sem').val()
                },
                success: function (res) {
                    update_disc();
                    $('#info').html('<div class="alert alert-success fade in" role="alert">\
                        Успешно сохранено!\
                        <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>\
                    </div>');
                },
                error: function (e) { console.log(e); }
            })
        });

        $('#save_prepod').click(function () {
            $.ajax({
                url: base + 'vkrdistr/savePrepod',
                type: 'post',
                data: {
                    stud_id: $('#stud_id').val(),
                    predm: $('#predm').val(),
                    sem: $('#sem').val(),
                    prepod: $('#prepod').val()
                },
                success: function (res) {
                    update_table();
                    $('#info').html('<div class="alert alert-success fade in" role="alert">\
                        Успешно сохранено!\
                        <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>\
                    </div>');
                    $('#exampleModal').modal('hide');
                },
                error: function (e) { console.log(e); }
            })
        });

        $('#student').on('changed.bs.select', function (e) {
            // table.search( $(this).val() ).draw();
            update_table();
        });
        $('#disc').on('changed.bs.select', function (e) {
            update_table();
        });

        $('#sem').on('changed.bs.select', function (e) {
             update_disc();
            update_table();
        });

        $('#class').on('changed.bs.select', function (e) { update_disc(); get_users(); });

        $('#exampleModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var userid = button.data('userid');
            var disc = button.data('predmet');
            var modal = $(this);
            modal.find('.modal-title').text('Выбрать преподавателя по предмету: ' + disc);
//            modal.find('.modal-body input').val('');
//            modal.find('.modal-body textarea').val('');
            $('#stud_id').val(userid);
            $('#predm').val(disc);
            $('#prepod').val('').selectpicker('refresh');
        });

        function update_table() {
            $.ajax({
                url: base + 'vkrdistr/getTasks',
                type: 'get',
                data: {
                    user: $('#student').val(),
                    class: $('#class').val(),
                    sem: $('#sem').val(),
                    disc: $('#disc').val()
                },
                success: function (res) {
                    $('.table tbody')
                        .html(res);
                },
                error: function () {
                    console.log('Error!');
                }
            });
        }

        function update_disc() {
            $.ajax({
                url: base + 'vkrdistr/getClass',
                type: 'post',
                data: {'class': $('#class').val(),'sem': $('#sem').val()},
                success: function (res) {
                    var unsel = '<option selected value="">Ничего не выбрано</option>';
                    $('#disc').html(unsel + res).selectpicker('refresh');
                },
                error: function () {
                    console.log('Error!');
                }
            });
        }

        function get_users() {
            $.ajax({
                url: base+'profile/getUserList',
                type: 'get',
                data: {'class': $('#class').val()},
                success: function (res) {
                    var unsel = '<option selected value="">Ничего не выбрано</option>';
                    $('#student').html(unsel + res).selectpicker('refresh');
                    update_table();
                },
                error: function () {
                    console.log('Error!');
                }
            });
        }
    });
</script>