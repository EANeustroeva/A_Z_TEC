<div id="info"></div>

<ul class="nav nav-tabs nav-justified">
    <li class="active"><a data-toggle="tab" href="#discs-tab">Предметы</a></li>
    <li><a data-toggle="tab" href="#users-tab">Ответственные</a></li>
    <li><a data-toggle="tab" href="#distr-tab">Распределение</a></li>
</ul>

<div class="tab-content">
    <div id="discs-tab" class="tab-pane fade in active">
        <h3> </h3>
        <fieldset>
            <legend>Выбор предмета</legend>

            <div class="col-xs-6">
                <div class="form-group">
                    <label for="" class="col-xs-6">Год зачисления</label>
                    <div class="col-xs-6">
                        <select name="" id="course" class="selectpicker form-control">
                            <option value="1">2017</option>
                            <option value="2">2016</option>
                            <option value="3">2015</option>
                            <option value="4">2014</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-xs-6">Семестр</label>
                    <div class="col-xs-6">
                        <select name="" id="sem" class="selectpicker form-control">
                            <option value="1">1 семестр</option>
                            <option value="2">2 семестр</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-xs-6">Направление</label>
                    <div class="col-xs-6">
                        <select name="" id="napr" class="selectpicker form-control">
                            <option disabled selected value="">Не выбрано</option>
                        <?php foreach ($napr_list as $k => $item): ?>
                            <option value="<?= $k ?>"><?= $item ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-xs-6">Группа</label>
                    <div class="col-xs-6">
                        <select name="" id="class" class="selectpicker form-control" data-live-search="true">
                            <option disabled selected value="">Не выбрано</option>
                        </select>
                    </div>
                </div>
            </div>
            <fieldset class="col-xs-6">
                <legend>Пул предметов</legend>
                <div class="well" style="max-height: 350px; overflow: auto;">
                    <ul id="discs" class="list-group checked-list-box">Выберите группу</ul>
                    <input type="hidden" id="selected_discs" value="">
                </div>
                <h3></h3>
                <span id="save_class" class="btn btn-success form-control" style="display: none;">Сохранить</span>
            </fieldset>
        </fieldset>
        <h3></h3>

        <table id="table1" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ФИО Студента</th>
                    <th>Группа</th>
                    <th>Предмет</th>
                    <th>Ответственный</th>
                    <th>ФИО Преподавателя</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
    <div id="users-tab" class="tab-pane fade">
        <h3> </h3>

        <fieldset>
            <legend style="width: 150px;">Выбор Пользователя</legend>

            <div class="col-xs-12">
                <div class="form-group">
                    <label for="" class="col-xs-6">Пользователь</label>
                    <div class="col-xs-6">
                        <select name="" id="users2" class="selectpicker form-control" data-live-search="true">
                            <option disabled selected value="">Не выбрано</option>
                            <?= $users ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-xs-6">Направление</label>
                    <div class="col-xs-6">
                        <select name="" id="napr2" multiple data-live-search="true" data-actions-box="true"
                                data-multipleSeparator="|" class="selectpicker form-control">
                        <?php foreach ($napr_list as $k => $item): ?>
                            <option value="<?= $k ?>"><?= $item ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-xs-6">Группа</label>
                    <div class="col-xs-6">
                        <select name="" id="class2" multiple data-live-search="true" data-actions-box="true"
                                data-multipleSeparator="|" class="selectpicker form-control">
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-xs-6">Предмет</label>
                    <div class="col-xs-6">
                        <select name="" id="discs2" multiple data-live-search="true" data-actions-box="true"
                                data-multipleSeparator="|" class="selectpicker form-control">
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div id="save_access" class="btn btn-success">Сохранить</div>
                </div>
            </div>

        </fieldset>
        <h3></h3>

        <table id="table2" class="table table-bordered table-condenced">
            <thead>
                <tr>
                    <th>ФИО Ответственного</th>
                    <th>Направление</th>
                    <th>Группа</th>
                    <th>Предмет</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
    <div id="distr-tab" class="tab-pane fade">
        <h3> </h3>
        <div class="row">
            <div class="col-xs-5">
                <fieldset>
                    <legend>Выбор предмета</legend>

                    <div class="col-xs-12">
                        <div class="form-group">
                            <label for="" class="col-xs-6">Год зачисления</label>
                            <div class="col-xs-6">
                                <select name="" id="course3" class="selectpicker form-control">
                                    <option value="1">2017</option>
                                    <option value="2">2016</option>
                                    <option value="3">2015</option>
                                    <option value="4">2014</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="col-xs-6">Семестр</label>
                            <div class="col-xs-6">
                                <select name="" id="sem3" class="selectpicker form-control">
                                    <option value="1">1 семестр</option>
                                    <option value="2">2 семестр</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="col-xs-6">Направление</label>
                            <div class="col-xs-6">
                                <select name="" id="napr3" class="selectpicker form-control">
                                    <option disabled selected value="">Не выбрано</option>
                                    <?php foreach ($napr_list as $k => $item): ?>
                                        <option value="<?= $k ?>"><?= $item ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="col-xs-6">Группа</label>
                            <div class="col-xs-6">
                                <select name="" id="class3" class="selectpicker form-control" data-live-search="true">
                                    <option disabled selected value="">Не выбрано</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="col-xs-6">Предмет</label>
                            <div class="col-xs-6">
                                <select name="" id="discs3" class="selectpicker form-control" data-live-search="true">
                                    <option disabled selected value="">Не выбрано</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </div>
            <div class="col-xs-7">
                <fieldset>
                    <legend style="width: 150px;">Пул преподавателей</legend>
                    <div class="well well-sm" style="height: 100px; overflow-y: auto;">
                        <ul class="list-group userlist">
                            <?php for ($i=0;$i<8; $i++): ?>
                                <a class="btn-xs list-group-item col-xs-6 col-md-4">
                                    <span class="del" value="132" style="cursor:pointer;float:right;"> ×</span>
                                    <span>Иванов</span>
                                </a>
                            <?php endfor; ?>
                        </ul>
                    </div>
                    <div class="btn btn-success form-control">Добавить</div>
                </fieldset>
            </div>
        </div>
        <h3></h3>

        <!--<table id="example" class="table table-bordered table-condenced">
            <thead>
                <tr>
                    <th></th>
                    <th>ФИО Студента</th>
                    <th>Группа</th>
                    <th>Предмет</th>
                    <th>Ответственный</th>
                    <th>ФИО Преподавателя</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
            <?php /*for ($i=0;$i<8; $i++): */?>
            <tr>
                <td></td>
                <td>Суркова Дарья Александровна</td>
                <td>ГПЮ-17-1</td>
                <td>Математика</td>
                <td>Иванов Иван Иванович</td>
                <td>Иванов Иван Иванович</td>
                <td>Лектор</td>
            </tr>
            <?php /*endfor; */?>
            </tbody>
        </table>-->
    </div>
</div>

<style>
    table.dataTable { border-collapse: collapse!important;}
    .table > tbody > tr > td {
        border-top: 1px solid #ddd;!important;
    }

    .table > tbody > tr > td:nth-child(1) {
        border-right: 1px solid #ddd;!important;
    }

    /*.dataTables_paginate { display: none}*/
    .panel-body { padding: 15px; }
    .state-icon {
        left: -5px;
    }
    .well .list-group {
        margin-bottom: 0px;
    }
    .list-group-item {
        padding: 1px 15px;
    }
    fieldset .form-group {
        margin-bottom: 15px;
        /*display: -webkit-box;*/
    }
    fieldset
    {
        border: 1px solid #ddd !important;
        margin: 0;
        min-width: 0;
        padding: 10px;
        position: relative;
        border-radius:4px;
        /*background-color:#f5f5f5;*/
        padding-left:10px!important;
    }

    legend
    {
        font-size:14px;
        font-weight:bold;
        margin-bottom: 0px;
        width: 120px;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 5px 5px 5px 10px;
        background-color: #ffffff;
    }
</style>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/select/1.2.5/css/select.dataTables.min.css">

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).ready(function () {
        get_list(1);
        get_list2();

        var table1 = $('#table1').DataTable({
            "ajax": {
                "url": base + 'vkrdistr/getVkrTasks',
                "data": function ( d ) {
                    if ($('#class').val())
                    d.class = $('#class').val();
                    d.sem = $('#sem').val();
                }
            },
            "order": [],
            "pageLength": 10,
            "searching": false,
            "lengthChange": false,
            "info":     false,
            "sDom": '<"row view-filter"<"col-sm-12"<"pull-left"l>p<"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"i>>>',
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            }
        });
        var table2 = $('#table2').DataTable({
            "ajax": {
                "url": base + 'vkrdistr/getVkrAccessTable',
                "data": function ( d ) {
                    if ($('#class2').val())
                        d.class = $('#class2').val();
                }
            },
            "order": [],
            "pageLength": 10,
            "searching": false,
            "lengthChange": false,
            "info":     false,
            "sDom": '<"row view-filter"<"col-sm-12"<"pull-left"l>p<"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"i>>>',
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
            }
        });
        $('#example').DataTable( {
            "searching": false,
            "lengthChange": false,
            "info":     false,
            columnDefs: [ {
                orderable: false,
                className: 'select-checkbox',
                targets:   0
            } ],
            select: {
                style:    'os',
                selector: 'td:first-child'
            },
            order: [[ 1, 'asc' ]]
        } );

        $('#course, #course3').on('changed.bs.select', function (e) {
            get_list($(this).val());
            var c = $(this).val()*2-1;
            $('#course, #course3').val($(this).val()).selectpicker('refresh');
            $('#sem, #sem3').html('<option value="'+c+'">'+c+' семестр</option>\
                            <option value="'+(c+1)+'">'+(c+1)+' семестр</option>').selectpicker('refresh');
        });

        $('#sem').on('changed.bs.select', function (e) {
            $.ajax({
                url: '/vkrdistr/getListDisc',
                type: 'get',
                data: {'class': $('#class').val(),'sem': $('#sem').val()},
                success: function (res) {
                    $('#discs, #discs2, #discs3').html(res.res).selectpicker('refresh');
                },
                error: function () {
                    console.log('Error!');
                }
            });
            table1.ajax.reload();
        });

        $('#class').on('changed.bs.select', function (e) { update_disc(); table1.ajax.reload();});
        $('#class2').on('changed.bs.select', function (e) { update_disc_access(); });
        $('#class3').on('changed.bs.select', function (e) { update_disc_access2(); });

        $('#users2').on('changed.bs.select', function (e) {
            load_info_access();
        });

        $('#save_class').on('click', function() {
            $.ajax({
                url: base + 'vkrdistr/saveClass',
                type: 'post',
                data: {
                    discs: $('#selected_discs').val(),
                    class: $('#class').val(),
                    sem: $('#sem').val()
                },
                success: function (res) {
                    // update_disc();
                    $('#info').html('<div class="alert alert-success fade in" role="alert">\
                        Успешно сохранено!\
                        <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>\
                    </div>').show().delay(3000).fadeOut();
                },
                error: function (e) {
                    console.log(e);
                }
            });
        });
        $('#save_access').on('click', function() {
            $.ajax({
                url: base + 'vkrdistr/saveAccess',
                type: 'post',
                data: {
                    user: $('#users2').val(),
                    napr: $('#napr2').val(),
                    discs: $('#discs2').val(),
                    class: $('#class2').val()
                },
                success: function (res) {
                    table2.ajax.reload();
                    // update_disc();
                    $('#info').html('<div class="alert alert-success fade in" role="alert">\
                        Успешно сохранено!\
                        <a type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</a>\
                    </div>').show().delay(3000).fadeOut();
                },
                error: function (e) {
                    console.log(e);
                }
            });
        });
    });

    function render_checkboxes() {
        $('.list-group.checked-list-box .list-group-item').each(function () {

            // Settings
            var $widget = $(this),
                $checkbox = $('<input type="checkbox" class="hidden" />'),
                color = ($widget.data('color') ? $widget.data('color') : "primary"),
                style = ($widget.data('style') == "button" ? "btn-" : "list-group-item-"),
                settings = {
                    on: {
                        icon: 'glyphicon glyphicon-check'
                    },
                    off: {
                        icon: 'glyphicon glyphicon-unchecked'
                    }
                };

            $widget.css('cursor', 'pointer')
            $widget.append($checkbox);

            // Event Handlers
            $widget.on('click', function () {
                $checkbox.prop('checked', !$checkbox.is(':checked'));
                $checkbox.triggerHandler('change');
                updateDisplay();
            });
            $checkbox.on('change', function () {
                updateDisplay();
            });


            // Actions
            function updateDisplay() {
                var isChecked = $checkbox.is(':checked');

                // Set the button's state
                $widget.data('state', (isChecked) ? "on" : "off");

                // Set the button's icon
                $widget.find('.state-icon')
                    .removeClass()
                    .addClass('state-icon ' + settings[$widget.data('state')].icon);

                // Update the button's color
                if (isChecked) {
                    $widget.addClass(style + color + ' active');
                } else {
                    $widget.removeClass(style + color + ' active');
                }

                var checkedItems = {}, counter = 0;
                $("#discs li.active").each(function(idx, li) {
                    checkedItems[$(li).data('value')] = $(li).data('value');
                    counter++;
                });
                $('#selected_discs').val(JSON.stringify(Object.keys(checkedItems)));
            }

            // Initialization
            function init() {

                if ($widget.data('checked') == true) {
                    $checkbox.prop('checked', !$checkbox.is(':checked'));
                }

                updateDisplay();

                // Inject the icon if applicable
                if ($widget.find('.state-icon').length == 0) {
                    $widget.prepend('<span class="state-icon ' + settings[$widget.data('state')].icon + '"></span>');
                }
            }
            init();
        });
    }

    function update_disc() {
        $.ajax({
            url: '/vkrdistr/getListDisc',
            type: 'get',
            data: {'class': $('#class').val(),'sem': $('#sem').val()},
            success: function (res) {
                $('#discs').html(res.res);
                render_checkboxes();
                $('#save_class').show();
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function update_disc_access(discs = false) {
        $.ajax({
            url: '/vkrdistr/getVkrDisc',
            type: 'get',
            data: {'class': $('#class2').val()},
            success: function (res) {
                var disc = $('#discs2');
                disc.html(res);
                if (discs) disc.val(discs);
                disc.selectpicker('refresh')
            },
            error: function () {
                console.log('Error!');
            }
        });
    }
    function update_disc_access2() {
        $.ajax({
            url: '/vkrdistr/getVkrDisc',
            type: 'get',
            data: {'class': $('#class3').val()},
            success: function (res) {
                $('#discs3').html('<option disabled selected value="">Не выбрано</option>' + res).selectpicker('refresh')
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function load_info_access() {
        $.ajax({
            url: '/vkrdistr/getVkrInfo',
            type: 'get',
            data: {user: $('#users2').val()},
            success: function (res) {
                $('#napr2').val(res.napr).selectpicker('refresh');
                $('#class2').val(res.class).selectpicker('refresh');
                update_disc_access(res.disc);
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    function get_list(course) {
        $.ajax({
            url: 'getList',
            type: 'get',
            data: {'course': course},
            success: function (res) {
                $('#class, #class3').html('<option disabled selected value="">Не выбрано</option>' + res).selectpicker('refresh');
            },
            error: function () {
                $('#class, #class3').html('<option disabled selected value="">Не выбрано</option>').selectpicker('refresh');
                console.log('Error!');
            }
        });
    }
    function get_list2() {
        $.ajax({
            url: 'getList',
            type: 'get',
            data: {'course': ''},
            success: function (res) {
                $('#class2').html(res).selectpicker('refresh');
            },
            error: function () {
                $('#class2').html(res).selectpicker('refresh');
                console.log('Error!');
            }
        });
    }

    function update_table() {
        $.ajax({
            url: base + 'vkrdistr/getVkrTasks',
            type: 'get',
            data: {
                class: $('#class').val(),
                sem: $('#sem').val(),
                disc: $('#disc').val()
            },
            success: function (res) {
                // $('#table1 tbody').html(res);
                // table1.fnDraw();
            },
            error: function () {
                console.log('Error!');
            }
        });
    }
</script>