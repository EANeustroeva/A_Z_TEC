<div id="info"></div>

<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#addremove">Профили</a></li>
    <li><a data-toggle="tab" href="#gr_pred">Предмет->Группа</a></li>
    <li><a data-toggle="tab" href="#prep_pred">Предмет->Преподаватель</a></li>
    <li><a data-toggle="tab" href="#prep_gr">Группа->Сотрудник</a></li>
</ul>

<div class="tab-content">
    <div id="addremove" class="tab-pane fade in active">
        <div class="panel panel-primary">
            <div class="panel-heading clearfix">
                <h4 class="pull-left">Просмотр профилей</h4>
                <a href="" id="useroplata" class="pull-right" target="_blank" style="margin-left: 15px;"></a>&nbsp;
                <a href="" id="userlink" class="pull-right" target="_blank" style="margin-left: 15px;"></a>&nbsp;
                <a href="" id="userlogin" class="pull-right" style="margin-left: 15px;" target="_blank"></a>&nbsp;
                <a href="" id="userlinkraspr" class="pull-right" target="_blank"></a>&nbsp;
            </div>
            <div class="panel-body form-horizontal">
                <h4></h4>
                <!--                <form class="form-signin" action="signup" method="post">-->
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <?php echo array_shift($errors); ?>
                    </div>
                <?php endif; ?>
                <div class="col-sm-12">

<!--                    <div class="btn-group btn-group-justified">-->
                        <!--                        <div id="useredit" class="btn btn-default">Редактировать</div>-->
<!--                        <div id="useradd" class="btn btn-default">Создать</div>-->
<!--                        <div id="userdel" class="btn btn-danger">Удалить</div>-->
<!--                    </div>-->
                    <div class="row">
                        <div class="col-sm-8">
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <select class="selectpicker form-control" id="user" title="Пользователь"
                                            data-size="8" data-live-search="true">
                                        <?php foreach ($prepod as $item): ?>
                                            <option value="<?= $item['id'] ?>"><?= $item['name'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <select class="selectpicker form-control" id="useraccess" title="Тип пользователя">
                                        <option value="3">Преподаватель</option>
                                        <option selected value="4">Студент</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8">
                            <div class="form-group">
                                <label class="col-sm-3 control-label">ФИО:</label>
                                <div class="col-sm-9">
                                    <input type="text" name="name" value="" id="name" class="form-control"
                                           placeholder="Иванов Иван Иванович"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Телефон:</label>
                                <div class="col-sm-9">
                                    <input type="text" id="phone" value="" class="form-control" placeholder="Телефон">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Email:</label>
                                <div class="col-sm-9">
                                    <input type="email" id="email" value="" class="form-control"
                                           placeholder="Email адрес">
                                </div>
                            </div>
                            <div class="form-group" data-access="4">
                                <label class="col-sm-3 control-label">Группа:</label>
                                <div class="col-sm-6">
                                    <input type="text" readonly id="class" value="" class="form-control disabled"
                                           placeholder="Группа" disabled>
                                </div>
                            </div>
                            <div class="form-group" data-access="3">
                                <label class="col-sm-3  control-label">Должность:</label>
                                <div class="col-sm-6">
                                    <input type="text" id="dolg" value="" class="form-control" placeholder="Должность">
                                </div>
                                <div class="col-sm-3">
                                    <input type="text" id="obozdolg" value="" class="form-control" placeholder="Коротко">
                                </div>
                            </div>
                            <div class="form-group" data-access="3">
                                <label class="col-sm-3 control-label">Уч. звание:</label>
                                <div class="col-sm-4"><input type="text" id="uhzvan" value="" class="form-control" placeholder="Уч. звание"></div>
                                <label class="col-sm-2 control-label">Уч. степень:</label>
                                <div class="col-sm-3"><input type="text" id="uhstep" value="" class="form-control" placeholder="Уч. степень"></div>
                            </div>
                            <hr style="border-top: 1px solid #337ab7;margin-top: 15px; margin-bottom: 15px;">
                            <div class="form-group" data-access="4">
                                <label class="col-sm-3  control-label">Паспорт:</label>
                                <div class="col-sm-3">
                                    <input type="text" id="pas_s" value="" class="form-control"
                                           placeholder="Серия">
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" id="pas_n" value="" class="form-control"
                                           placeholder="Номер">
                                </div>
                            </div>
<!--                            <div class="form-group">-->
<!--                                <label class="col-sm-3 control-label">Логин:</label>-->
<!--                                <div class="col-sm-9">-->
<!--                                    <input type="text" id="login" value="" class="form-control" placeholder="Логин"-->
<!--                                           required>-->
<!--                                </div>-->
<!--                            </div>-->
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Логин&nbsp;AD:</label>
                                <div class="col-sm-9">
                                    <input id="loginad" class="form-control" placeholder="Логин&nbsp;AD">
                                </div>
                            </div>
                            <div class="form-group" data-access="4">
                                <label class="col-sm-3 control-label">Пароль AD:</label>
                                <div class="col-sm-9">
                                    <input type="text" id="password-ad" value="" class="form-control"
                                           placeholder="Заполнить для изменения пароля (от 5 символов)">
                                </div>
                            </div>
<!--                            <div class="form-group">-->
<!--                                <label class="col-sm-2 control-label">Пароль:</label>-->
<!--                                <div class="col-sm-10">-->
<!--                                    <input type="text" id="password" value="" class="form-control"-->
<!--                                           placeholder="Пароль">-->
<!--                                </div>-->
<!--                            </div>-->
                        </div>
                        <div class="col-sm-4 ">

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <select class="selectpicker form-control" id="usercourse" title="Год поступления">
                                        <option value="0">2018</option>
                                        <option value="1">2017</option>
                                        <option value="2">2016</option>
                                        <option value="3">2015</option>
                                        <option value="4">2014</option>
                                        <option value="5">2013</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="selectpicker form-control" id="userclass" title="Группа"
                                          data-live-search="true"  disabled></select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <div class="avatar">
                                        <img class="img-thumbnail" id="avatar" style="max-height: 195px;"
                                             src="<?= BASE_URL ?>assets/images/thumbs/no-image.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-8">
                            <div class="btn-group btn-group">
                                <div class="btn btn-default" id="get-ad-login">Получить информацию с AD</div>
                                <div class="btn btn-danger" id="set-password" data-access="4">Задать новый пароль</div>
                                <div class="btn btn-default" id="prev-user"><<</div>
                                <div class="btn btn-default" id="next-user">>></div>
                            </div>
                            <div class="form-group"></div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <div class="col-xs-12">
                                    <div class="btn btn-success form-control" id="ad-save">Сохранить</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="ad-info-tree"></div>
    </div>
    <div id="gr_pred" class="tab-pane fade">
        <div class="panel panel-primary">
            <div class="panel-heading ">
                <h4>Просмотр предметов у групп</h4>
            </div>
            <div class="panel-body">
                <h4></h4>
                <!--    <form action="profile/adduserpred" method="post">-->
                <div class="col-sm-12">
                    <div class="row">
                        <div class="col-sm-6">
                            <select class="selectpicker form-control prepod" id="grds_class" title="Группа"
                                    data-live-search="true">
                                <?php foreach ($class as $item): ?>
                                    <option><?= $item ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-sm-6">
                            <select class="selectpicker form-control" id="grds_sem" title="Семестр">
                                <option selected value="1">1 семестр</option>
                                <option value="2">2 семестр</option>
                                <option value="3">3 семестр</option>
                                <option value="4">4 семестр</option>
                                <option value="5">5 семестр</option>
                                <option value="6">6 семестр</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <h5>Список предметов:</h5>
                        <div class="well well-sm" style="height: 400px; overflow-y: auto;">
                            <ul class="list-group userlist"></ul>
                        </div>
                    </div>
                </div>
                <!--<div class="col-sm-6">
                    <div class="form-group">
                        <label for="toadd">Доступные предметы:</label>
                        <select style="width: 100%;min-height: 400px" name="toadd[]" class="toadd"
                                title="Доступные предметы"
                                data-live-search="true" multiple>
                            <?php /*foreach ($predmet as $k => $item): */?>
                                <option value="<?/*= $item */?>"><?/*= $k */?></option>
                            <?php /*endforeach; */?>
                        </select>
                        <div class="btn btn-success adduspr">Добавить</div>
                    </div>
                </div>-->

                <!--    </form>-->
            </div>

        </div>
    </div>
    <div id="prep_pred" class="tab-pane fade">
        <div class="panel panel-primary">
            <div class="panel-heading ">
                <h4>Назначение предметов преподавателю</h4>
            </div>
            <div class="panel-body">
                <h4></h4>
                <!--    <form action="profile/adduserpred" method="post">-->
                <div class="col-sm-6">
                    <div class="form-group">
                        <select class="selectpicker prepod" name="prepod" title="Преподаватель" data-live-search="true">
                            <?php foreach ($prepod as $item): ?>
                                <option value="<?= $item['id'] ?>"><?= $item['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <h5>Список предметов:</h5>
                        <div class="well well-sm" style="height: 400px; overflow-y: auto;">
                            <ul class="list-group userlist"></ul>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="toadd">Доступные предметы:</label>
                        <select style="width: 100%;min-height: 400px" name="toadd[]" class="toadd"
                                title="Доступные предметы"
                                data-live-search="true" multiple>
                            <?php foreach ($predmet as $k => $item): ?>
                                <option value="<?= $item ?>"><?= $k ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="btn btn-success adduspr">Добавить</div>
                    </div>
                </div>

                <!--    </form>-->
            </div>

        </div>
    </div>
    <div id="prep_gr" class="tab-pane fade">
        <div class="panel panel-primary">
            <div class="panel-heading ">
                <h4>Просмотр групп у сотрудника</h4>
            </div>
            <div class="panel-body">
                <h4></h4>
                <!--    <form action="profile/adduserpred" method="post">-->
                <div class="col-sm-9">
                    <div class="row">
                        <div class="col-sm-6">
                            <select class="selectpicker prepod form-control" id="prep_user" title="Методист"
                                    data-live-search="true">
                                <?php foreach ($metodist as $item): ?>
                                    <option value="<?= $item['id'] ?>"><?= $item['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-sm-6">
                            <select class="selectpicker form-control" id="grpr_type" title="Тип сотрудника">
                                <option selected value="0">Методисты</option>
<!--                                <option value="1">Преподаватели</option>-->
                            </select>
                        </div>
                    </div>


                    <div class="form-group">
                        <h5>Список групп:</h5>
                        <div class="well well-sm" style="height: 400px; overflow-y: auto;">
                            <ul class="list-group userlist"></ul>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label for="toadd">Доступные Группы:</label>
                        <select style="width: 100%;min-height: 400px" name="toadd[]" class="toadd"
                                title="Доступные Группы"
                                data-live-search="true" multiple>
                            <?php foreach ($class as $item): ?>
                                <option><?= $item ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="btn btn-success adduspr">Добавить</div>
                    </div>
                </div>

                <!--    </form>-->
            </div>

        </div>
    </div>

</div>

<style>
    /*    #prep_gr .list-group-item {
            width: 33.33%;
            display: inline-block;
        }*/
    #gr_pred .list-group-item {
        padding: 5px 10px;
    }
    .uu-success{
        color: #009917 !important;
        border: 1px dashed #009917;
        padding: 7px 20px;
        margin-top: 4px;
        display: inline-block;
    }
    .block * {
        font-size: 14px;
        font-family: Noto;
        color: #333;
    }
    .uu-success span{
        color: #009917 !important;
    }
    .block b, .block strong {
        color: #006699;
    }

</style>

<script src="<?= BASE_URL ?>js/manager.js?r=<?= rand(0, 100) ?>"></script>