<div class="panel panel-default">
    <div class="panel-heading">Управление оплатой</div>
    <div class="panel-body">
        <div class="col-sm-12">
            <h4></h4>
            <form class="form-inline" method="post" action="<?= BASE_URL ?>users/changepay">
                <div class="form-group">
                    <p class="form-control-static">Установить статус оплаты для всех студентов:&nbsp;</p>
                </div>
                <div class="form-group">
                    <select class="selectpicker form-control" name="status" title="Статус">
                        <option value="-1">Не оплачено</option>
                        <option value="1">Оплачено</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-default">Сменить</button>
            </form>
            <h4></h4>
        </div>
    </div>
</div>
<table class="table table-striped table-hover table-bordered table-responsive ">
    <thead>
    <tr>
        <th>ФИО</th>
        <th>Группа</th>
        <th>Логин</th>
        <th>Пароль</th>
        <th>Оплата</th>
    </tr>
    </thead>
    <tbody>
        <div class="alert alert-warning">
            Выберите группу из списка слева
        </div>
    </tbody>
</table>
<style>
    td:nth-child(1),td:nth-child(2) {
        text-align: left;
    }
</style>
<script>
    $('#course').on('changed.bs.select', function (e) {
        $.ajax({
            url: 'getList',
            type: 'get',
            data: {'course': $('#course').val()},
            success: function (res) {
                $('#class')
                    .html(res)
                    .selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    });
    $('#class').on('changed.bs.select', function (e) {
        $.ajax({
            url: 'acc',
            type: 'get',
            data: {'class': $('#class').val()},
            success: function (res) {
                $('.alert').remove();
                $('.table tbody')
                    .html(res)
            },
            error: function () {
                console.log('Error!');
            }
        });
    });
</script>