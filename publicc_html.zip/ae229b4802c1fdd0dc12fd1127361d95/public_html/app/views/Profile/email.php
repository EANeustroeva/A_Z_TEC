<label for="">Заголовок</label>
<input  class="form-control" type="text" value="<?= $subject ?>" disabled>
<br>
<label for="">Сообщение</label>
<textarea class="form-control" rows="10" disabled><?= $message ?></textarea>