<div class="col-sm-12">
    <div class="bs">
            <div class="row">
                <div class="col-sm-3" style="text-align:center;">
                    <?php // dd($user->avatar) ?>
                    <img id="id_avatar" class="img-responsive" width="100" height="100"
                         src="<?= BASE_URL . 'assets/images/thumbs/no-image.jpg' ?>"/>
                </div>
                <div class="col-sm-6" style="padding-top:5px;">
                    <h4 style="margin:0px;">
                        <div class="text-center"><?php echo $user->firstname . ' ' . $user->lastname . ' ' . $user->surname; ?>

                        </div>
                    </h4>
                    <hr>
                    <div class="row">
                        <div class="col-sm-3">
                            <p style="color:#999;">Email:</p>
                        </div>
                        <div class="col-sm-9">
                            <p><?php echo @$user->email; ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <p style="color:#999;">Телефон:</p>
                        </div>
                        <div class="col-sm-9">
                            <p><?php echo @$user->phone; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                <span style="margin-bottom:5px;"
                      class="pull-right btn btn-xs btn-<?php echo $user->online == 1 ? 'success' : 'danger'; ?>"
                      id="current_status"><?php echo $user->online == 1 ? 'Online' : 'Offline'; ?></span>
                    <a href="<?= BASE_URL . 'edit' ?>">
                        <?php if ($my_id): ?>
                        <?php if ($uid == $my_id): ?>
                        <button type="button" class="btn btn-primary" style="width:100%;">
                            <?php echo 'Редактировать'; ?>
                        </button>
                    </a>
                    <?php endif; ?>

                    <?php if ($uid !== $my_id): ?>
                        <?php if (!$live_friend): ?>
                            <!--form action="users/addFriend" method="post">
                                <button href="" class="btn btn-warning" style="width: 100%;">Добавить</button>
                                <input type="hidden" name="usr_id" value="">
                            </form-->
                        <?php endif; ?>
                        <?php if ($live_friend): ?>
                            <form action="users/delFriend" method="post">
                                <button href="" class="btn btn-danger" style="width: 100%;">Удалить</button>
                                <input type="hidden" name="usr_id" value="<?= $uid ?>">
                            </form>
                        <?php endif; ?>
                        <form action="users/dialog" method="post">
                            <button href="" class="btn btn-primary" style="margin: 5px 0 0;width: 100%;">Написать
                            </button>
                            <input type="hidden" name="usr_id" value="<?= $uid ?>">
                        </form>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if (!$my_id): ?>
                        <a href="/<?php echo $link[3]; ?>">
                            <button type="button" class="btn btn-primary"
                                    style="width:100%;"><?php echo $lang[137]; ?></button>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    <div class="row">
        <div class="col-sm-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="users">Студенты</a>
                </div>
                <div class="panel-body" style="padding-top:10px;">
                    <?php echo $friends_body; ?>
                </div>
            </div>
        </div>
        <div class="col-sm-8">

        </div>
    </div>
</div>