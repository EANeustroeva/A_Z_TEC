<div class="col-sm-12">
    <div class="bs" style="position: relative;">
        <span style="position:absolute;top:10px;right:10px;z-index: 2"
              class="pull-right btn-xs btn-<?php echo $user->online == 1 ? 'success' : 'danger'; ?>"
              id="current_status"><?php echo $user->online == 1 ? 'Online' : 'Offline'; ?></span>
        <div class="row">
            <div class="col-xs-12 col-sm-4" style="text-align:center;">
                <img id="id_avatar" class="img-responsive" height="100"
                     src="<?= $user['avatar'] ?>"/>
            </div>
            <div class="col-xs-12 col-sm-8" style="padding-top:5px;">
                <div class="row">
                    <h4 class="text-center" style="margin:0px;"><?php
                        echo $user->firstname . ' ' . $user->lastname . ' ' . $user->surname;
                        ?></h4>
                </div>
                <hr>
                <div class="row">
                    <div class="col-xs-3">
                        <p style="color:#999;">Телефон:</p>
                        <p style="color:#999;">Email:</p>
                    </div>
                    <div class="col-xs-9 col-sm-5 col-md-5">
                        <p><?= isset($user->phone) ? $user->phone : 'Не указан' ?></p>
                        <p><?= isset($user->email) ? $user->email : 'Не указан' ?></p>
                    </div>
                    <div class="col-sm-4 col-md-4">
                        <?php if ($my_id): ?>
                            <?php if ($uid == $my_id): ?>
                                <a href="<?= BASE_URL . 'edit' ?>" class="btn btn-primary" style="width: 100%;">Изменить</a>
                            <?php endif; ?>
                            <?php if ($uid !== $my_id): ?>
                                <?php if (!$live_friend): ?>
                                    <!--form action="users/addFriend" method="post">
                                        <button href="" class="btn btn-warning btn-xs" style="width: 100%;">Добавить
                                        </button>
                                        <input type="hidden" name="usr_id" value="">
                                    </form-->
                                <?php endif; ?>
                                <?php if ($live_friend): ?>
                                    <form action="users/delFriend" method="post">
                                        <button href="" class="btn btn-danger btn-xs" style="width: 100%;">Удалить
                                        </button>
                                        <input type="hidden" name="usr_id" value="<?= $uid ?>">
                                    </form>
                                <?php endif; ?>

                                <button type="button" class="btn btn-primary" style="margin: 5px 0 0;width: 100%;"
                                        data-toggle="modal" data-target="#myModal<?= $user['id'] ?>">Написать
                                </button>
                                <div id="myModal<?= $user['id'] ?>" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Написать</h4>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?= BASE_URL ?>users/dialog" method="post">
                                                    <div class="form-group">
                                                        <div class="well well-sm"><?= $user['firstname'] . ' ' . $user['lastname'] . ' ' . $user['surname'] ?></div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="msg">Сообщение:</label>
                                                        <textarea class="form-control" name="msg" id="msg" rows="3"
                                                                  required></textarea>
                                                    </div>
                                                    <input type="hidden" name="usr_name"
                                                           value="<?= $user['firstname'] . ' ' . $user['lastname'] . ' ' . $user['surname'] ?>">
                                                    <input type="hidden" name="usr_id" value="<?= $user['id'] ?>">

                                                    <div class="form-group">
                                                        <button class="btn btn-primary btn-block" type="submit">
                                                            Отправить
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if (!$my_id): ?>
                            <a href="/<?php echo $link[3]; ?>">
                                <button type="button" class="btn btn-primary"
                                        style="width:100%;"><?php echo $lang[137]; ?></button>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div>
        <?php if ($uid == $my_id && $cur_user->is_student): ?>
            <div class="alert alert-info" role="alert">Пожалуйста, проверьте актуальность Email и телефона, в случае
                несоответствия, перейдите в <a href="<?= BASE_URL ?>edit" class="alert-link"> настройки</a>.
                <a type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <?php if ($user->pay_status): ?>
                <div class="alert alert-success" role="alert">
                    <b>Оплата прошла! </b>Справка вызов была отправлена вам <b><?= $user->email ?></b>.
                    <a type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
            <?php else: ?>
                <div class="alert alert-warning" role="alert">
                    <b>Нет оплаты! </b>Справка вызов вам не отправлена т.к. у вас задолженность по оплате.
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php if ($user->is_student): ?>
        <div class="panel panel-default">
            <div class="panel-heading">Сведения об успеваемости</div>
            <div class="panel-body">
                <table class="table table-condensed table-bordered">
                    <thead>
                    <tr>
                        <th>Предмет/Преподаватель</th>
                        <th>к/р</th>
                        <th>курсовая</th>
                        <th>домашняя</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php for ($i=0; $i<3; $i++):
                        $m = ['сдано','не сдано','оценка'];
                        $number = mt_rand(0, count($m) - 1); ?>
                        <tr>
                            <td>Название работы<br>
                                <a href="<?= BASE_URL ?>?id=354">Оксана Александровна Кандакова</a></td>
                            <td><?= $m[$number] ?><br>
                                <?= date('d-m-Y', mktime(0,0,0,rand(1,31),rand(1,12),2016)) ?>
                            </td>
                            <td><?= $m[$number] ?><br>
                                <?= date('d-m-Y', mktime(0,0,0,rand(1,31),rand(1,12),2017)) ?>
                            </td>
                            <td><?= $m[$number] ?><br>
                                <?= date('d-m-Y', mktime(0,0,0,rand(1,31),rand(1,12),2017)) ?>
                            </td>
                        </tr>
                    <?php endfor; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-sm-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="users">Студенты</a>
                </div>
                <div class="panel-body" style="padding-top:10px;">
                    <?php echo $friends_body; ?>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <?php if ($user->is_student): ?>
                <div class="panel panel-default">
                    <div class="panel-heading">Информация</div>
                    <div class="panel-body">
                        <div class="col-sm-12">
                            <h6><b>Учебные данные:</b></h6>
                            <hr>
                            <div class="row">
                                <div class="col-xs-6">
                                    <p style="color:#999;">Группа:</p>
                                </div>
                                <div class="col-xs-6">
                                    <p><?php echo @$user->class; ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-6">
                                    <p style="color:#999;">Курс:</p>
                                </div>
                                <div class="col-xs-6">
                                    <p><?php echo @$user->course; ?></p>
                                </div>
                            </div>
                            <?php if ($uid == $my_id || !$cur_user->is_student): ?>
                                <div class="row">
                                    <div class="col-xs-6">
                                        <p style="color:#999;">№ Зачетки:</p>
                                    </div>
                                    <div class="col-xs-6">
                                        <p><?php echo @$user->credit_book; ?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-6">
                                        <p style="color:#999;">Статус оплаты:</p>
                                    </div>
                                    <div class="col-xs-6">
                                        <i class="glyphicon glyphicon-<?= $cur_user->pay_status ? 'ok' : 'remove' ?>"></i>
                                        <?= $cur_user->pay_status ? ' Оплачено' : ' Нет оплаты' ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-12">
                            <h6><b>Персональные данные:</b></h6>
                            <hr>
                        </div>
                        <div class="col-sm-12">
                            <h6><b>Образование:</b></h6>
                            <hr>
                        </div>

                        <div class="col-sm-12">
                            <h6><b>Карьера:</b></h6>
                            <hr>
                        </div>
                        <div class="col-sm-12">
                            <h6><b>Доп. информация:</b></h6>
                            <hr>
                            <div class="row">
                                <div class="col-xs-6">
                                    <p style="color:#999;">День рождения:</p>
                                </div>
                                <div class="col-xs-6">
                                    <p></p>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-xs-6">
                                    <p style="color:#999;">Skype:</p>
                                </div>
                                <div class="col-xs-6">
                                    <p></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="panel panel-default">
                    <div class="panel-heading">Информация преподавателя</div>
                    <div class="panel-body">
                        <h4></h4>
                        <p style="text-align:center; margin-bottom:20px;">Информация отсутствует</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>