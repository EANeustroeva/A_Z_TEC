<div class="col-sm-12">
    <div class="row" style="display: none;">
        <?php if ($uid == $my_id && $cur_user->access == 4): ?>
            <div class="alert alert-info" role="alert">Пожалуйста, проверьте актуальность Email и телефона, в случае
                несоответствия, перейдите в <a href="<?= BASE_URL ?>edit" class="alert-link"> настройки</a>.
                <a type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <?php if ($user->pay_status): ?>
                <div class="alert alert-success" role="alert">
                    <b>Оплата прошла! </b>Справка вызов была отправлена вам <b><?= $user->email ?></b>.
                    <a type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
            <?php else: ?>
                <div class="alert alert-warning" role="alert">
                    <b>Нет оплаты! </b>Справка вызов вам не отправлена т.к. у вас задолженность по оплате.
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <!--    <div class="bs">-->
    <div class="row">
        <div class="col-xs-12 col-sm-4 col-md-3">
            <div class="row">
                <div class="bs">
                    <img id="id_avatar" class="img-responsive" src="<?= $user['avatar'] ?>"/>
                    <span style="font-size:12px; color:#777;text-align: center;width: 100%;display: block;"><?php
                     switch ($user['access']) {
                        case 5: echo 'Участник'; break;
                        case 4: echo "Студент"; break;
                        case 3: echo "Преподаватель"; break;
                        case 2: echo "Методист"; break;
                         }
                     ?></span>
                    <?php if ($my_id): ?>
                        <?php if ($uid == $my_id): ?>
                            <!--                            <a type="button" class="btn btn-default" style="width: 100%;margin: 5px 0;"-->
                            <!--                               onclick="upload_avatar();" >Добавить фото-->
                            <!--                            </a>-->
                            <div id="id_modal_avatar" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"
                                                    style="font-size:18px;">&times;</button>

                                                <h4 class="modal-title" id="myModalLabel">Загрузите новое фото</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <div id="id_preload_ava" class="col-md-3"
                                                     style="text-align:center; padding-bottom:20px;"></div>
                                                <div class="col-sm-9" id="id_upload_ava"></div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-primary" data-dismiss="modal"
                                                    onClick="del_avatar();">Удалить фото
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--                            <a href="--><? //= BASE_URL . 'edit' ?><!--" class="btn btn-primary" style="width: 100%;">Изменить</a>-->
                        <?php endif; ?>
                        <?php if ($uid !== $my_id): ?>
                            <?php if (!$live_friend): ?>
                                <!--form action="users/addFriend" method="post">
                                    <button href="" class="btn btn-warning btn-xs" style="margin-top: 5px;width: 100%;">
                                        Добавить
                                    </button>
                                    <input type="hidden" name="usr_id" value="">
                                </form-->
                            <?php endif; ?>
                            <?php if ($live_friend): ?>
                                <form action="users/delFriend" method="post">
                                    <button href="" class="btn btn-danger btn-xs" style="width: 100%;">Удалить
                                    </button>
                                    <input type="hidden" name="usr_id" value="<?= $uid ?>">
                                </form>
                            <?php endif; ?>

                            <button type="button" class="btn btn-primary" style="margin: 5px 0 0;width: 100%;"
                                    data-toggle="modal" data-target="#myModal<?= $user['id'] ?>">Написать
                            </button>
                            <div id="myModal<?= $user['id'] ?>" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close"
                                                    data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Написать</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?= BASE_URL ?>users/dialog" method="post">
                                                <div class="form-group">
                                                    <div class="well well-sm"><?= $user['name'] ?></div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="msg">Сообщение:</label>
                                                    <textarea class="form-control" name="msg" id="msg" rows="3"
                                                              required></textarea>
                                                </div>
                                                <input type="hidden" name="usr_name"
                                                       value="<?= $user['name'] ?>">
                                                <input type="hidden" name="usr_id" value="<?= $user['id'] ?>">

                                                <div class="form-group">
                                                    <button class="btn btn-primary btn-block" type="submit">
                                                        Отправить
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if (!$my_id): ?>
                        <a href="/<?php echo $link[3]; ?>">
                            <button type="button" class="btn btn-primary"
                                    style="width:100%;"><?php echo $lang[137]; ?></button>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-8 col-md-9">
            <div class="bs" style="margin-right: -15px">
                <span style="position:absolute;top:10px;right:10px;z-index: 2"
                      class="pull-right btn-xs btn-<?php echo $user->online == 1 ? 'success' : 'danger'; ?>"
                      id="current_status"><?php echo $user->online == 1 ? 'Online' : 'Offline'; ?></span>
                <div class="row">
                    <div class="col-sm-12">
                        <h4 style="margin: 0;"><?php
                            echo $user->name;
                            ?></h4>

                        <hr>
                    </div>
                    <?php if ($uid == $my_id || $cur_user->access < 4): ?>
                    <div class="col-sm-12">
                        <div class="row">
                            <div class="col-xs-5">
                                <p style="color:#999;">Телефон:</p>
                                <p style="color:#999;">Email:</p>
                            </div>
                            <div class="col-xs-7">
                                <p><?= $user->phone ?: 'Не указан' ?></p>
                                <p><?= $user->email ?: 'Не указан' ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if ($user->access == 4): ?>
                        <div class="col-sm-12">
                            <h6><b>Учебные данные:</b></h6>
                            <hr>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Группа:</p>
                                </div>
                                <div class="col-xs-7">
                                    <p><?php echo @$user->class; ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Курс:</p>
                                </div>
                                <div class="col-xs-7">
                                    <p><?php echo @$user->course; ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Семестр:</p>
                                </div>
                                <div class="col-xs-7">
                                    <p><?php echo @$user->sem; ?></p>
                                </div>
                            </div>
                            <?php if ($uid == $my_id || $cur_user->access != 4): ?>
<!--                                <div class="row">-->
<!--                                    <div class="col-xs-5">-->
<!--                                        <p style="color:#999;">№ Зачетки:</p>-->
<!--                                    </div>-->
<!--                                    <div class="col-xs-7">-->
<!--                                        <p>--><?php //echo @$user->credit_book; ?><!--</p>-->
<!--                                    </div>-->
<!--                                </div>-->
                                <?php if (is_null($cur_user->fl) && strpos($cur_user->class, '-18')): ?>
                                    <hr>
                                    <small>Выберите один из предложенных изучаемых языков и нажмите сохранить. Это необходимо для прохождения теста по иностранному языку. (выбрать язык можно всего один раз)</small>
                                <div class="row">
                                    <form action="/profile/selfl" method="post">
                                        <div class="col-xs-7">
                                            <select name="fl" id="" class="form-control">
                                                <option value="7">Английский</option>
                                                <option value="8">Немецкий</option>
                                                <option value="9">Французский</option>
                                            </select>
                                        </div>
                                        <div class="col-xs-5">
                                            <button class="btn btn-success form-control">Сохранить</button>
                                        </div>
                                    </form>
                                </div>
                                    <hr>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-xs-5">
                                        <p style="color:#999;">Статус оплаты:</p>
                                    </div>
                                    <?php if (!is_null($cur_user->master_pay)): ?>
                                        <?php if ($cur_user->master_pay): ?>
                                            <?php if (!is_null($cur_user->pay_status)&&intval($cur_user->pay_status)>0): ?>
                                                <div class="col-xs-7"><i class="glyphicon glyphicon-ok"></i>Оплачено</div>
                                            <?php else: ?>
                                                <div class="col-xs-7 btn-warning">Доступ возобновлен</div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <div class="col-xs-7 btn-danger">Заблокировано менеджером</div>
                                        <?php endif; ?>
                                    <?php else: ?>
<!--                                        --><?php //if (is_null($cur_user->pay_status)): ?>
<!--                                            <div class="col-xs-7 btn-warning">?</div>-->
<!--                                        --><?php //elseif (intval($cur_user->pay_status)>0): ?>
                                        <?php if (is_null($cur_user->pay_status) || intval($cur_user->pay_status)>= 0): ?>
                                            <div class="col-xs-7 btn-success"><i class="glyphicon glyphicon-ok"></i>Оплачено</div>
                                        <?php else: ?>
                                            <div class="col-xs-7 btn-danger">Долг: <?= $dolg_pay ?>р.</div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div id="dopinfa" style="display: none">
                            <div class="col-sm-12">
                                <h6><b>Персональные данные:</b></h6>
                                <hr>
                                <div class="row">
                                    <div class="col-xs-5">
                                        <p style="color:#999;">Пол:</p>
                                    </div>
                                    <div class="col-xs-7">
                                        <p><?= @$user->sex ?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-5">
                                        <p style="color:#999;">День рождения:</p>
                                    </div>
                                    <div class="col-xs-7">
                                        <p><?= @$user->birthday ?></p>
                                    </div>
                                </div>
                               <!-- <?php /*if ($uid == $my_id): */?>
                                    <div class="row">
                                        <div class="col-xs-5">
                                            <p style="color:#999;">Адрес:</p>
                                        </div>
                                        <div class="col-xs-7">
                                            <p><?/*= @$user->address */?></p>
                                        </div>
                                    </div>
                                --><?php /*endif; */?>
                            </div>
                            <div class="col-sm-12">
                            <h6><b>Образование:</b></h6>
                            <hr>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Специальность:</p>
                                </div>
                                <div class="col-xs-7">
                                    <p><?= @$user->start_obr_spec ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Форма обучения:</p>
                                </div>
                                <div class="col-xs-7">
                                    <p><?= @$user->forma_obuch ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Иностранный язык:</p>
                                </div>
                                <div class="col-xs-7">
                                    <p><?php
                                        if (is_null($user->fl)) echo $user->foreign_language ?: 'Не указан';
                                        else {
                                            switch ($user->fl) {
                                                case 7: echo 'Английский'; break;
                                                case 8: echo 'Немецкий'; break;
                                                case 9: echo 'Французский'; break;
                                            }
                                        }
                                    ?></p>
                                </div>
                            </div>
                            <?php if ($user->napr_post): ?>
                                <div class="row">
                                    <div class="col-xs-5">
                                        <p style="color:#999;">Направление:</p>
                                    </div>
                                    <div class="col-xs-7">
                                        <p><?= @$user->napr_post ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Срок обучения:</p>
                                </div>
                                <div class="col-xs-7">
                                    <p><?= @$user->srok_obuch ?></p>
                                </div>
                            </div>
                        </div>
                        </div>
                        <div class="col-sm-12">
                            <button id="dopinfatoggle" class="form-control">Дополнительная информация</button>
                        </div>
                    <?php elseif (in_array($user->access,[2,3])): ?>
                        <div class="col-sm-12">
                            <h6><b>Информация преподавателя:</b></h6>
                            <hr>

                            <?php
                                $wt = json_decode($user->workdate, 1);
                                $wtt = json_decode($user->workdatetime, 1);
                                $wt_str = '';
                            if (count($wt)):
                                foreach ($wt as $k=>$item) $wt_str .="{$item}: ".(!empty($wtt)?"с {$wtt[$k][0]} по {$wtt[$k][1]}":'')."<br>";
                                ?>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Даты консультаций:</p>
                                </div>
                                <div class="col-xs-7">
                                    <p><?= $wt_str ?></p>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php
                                $wt = json_decode($user->worktime, 1);
                                $wt_str  = (!empty($wt['from'][1]) || !empty($wt['to'][1])) ? "Пн: c {$wt['from'][1]} по {$wt['to'][1]} <br>" : '';
                                $wt_str .= (!empty($wt['from'][2]) || !empty($wt['to'][2])) ? "Вт: c {$wt['from'][2]} по {$wt['to'][2]} <br>" : '';
                                $wt_str .= (!empty($wt['from'][3]) || !empty($wt['to'][3])) ? "Ср: c {$wt['from'][3]} по {$wt['to'][3]} <br>" : '';
                                $wt_str .= (!empty($wt['from'][4]) || !empty($wt['to'][4])) ? "Чт: c {$wt['from'][4]} по {$wt['to'][4]} <br>" : '';
                                $wt_str .= (!empty($wt['from'][5]) || !empty($wt['to'][5])) ? "Пт: c {$wt['from'][5]} по {$wt['to'][5]} <br>" : '';
                                $wt_str .= (!empty($wt['from'][6]) || !empty($wt['to'][6])) ? "Сб: c {$wt['from'][6]} по {$wt['to'][6]} <br>" : '';
                                $wt_str .= (!empty($wt['from'][7]) || !empty($wt['to'][7])) ? "Вс: c {$wt['from'][7]} по {$wt['to'][7]}" : '';
                            if (count($wt)): ?>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Часы консультаций:</p>
                                </div>
                                <div class="col-xs-7">
                                    <p><?= $wt_str ?></p>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Аудитория:</p>
                                </div>
                                <div class="col-xs-7">
                                   <p><?= @$user->komnata ?></p>
                                </div>
                            </div>
                            <hr>
                            <?php if ($cur_user->access != 2): ?>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Кафедра:</p>
                                </div>
                                <div class="col-xs-7">
                                   <p><?= @$user->podr ?> <?= $user->obozpodr ? "({$user->obozpodr})" : '' ?></p>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Должность:</p>
                                </div>
                                <div class="col-xs-7">
                                   <p><?= @$user->dolg ?></p>
                                </div>
                            </div>
                            <?php if ($user->uhstep): ?>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Ученая степень:</p>
                                </div>
                                <div class="col-xs-7">
                                   <p><?= @$user->uhstep ?></p>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if ($user->uhzvan): ?>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Ученое звание:</p>
                                </div>
                                <div class="col-xs-7">
                                   <p><?= @$user->uhzvan ?></p>
                                </div>
                            </div>
                            <?php endif; ?>
                            <hr>
                            <!--<div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">Пол:</p>
                                </div>
                                <div class="col-xs-7">
                                    <p><?/*= @$user->sex */?></p>
                                </div>
                            </div>-->
                            <!--<div class="row">
                                <div class="col-xs-5">
                                    <p style="color:#999;">День рождения:</p>
                                </div>
                                <div class="col-xs-7">
                                    <?php /*$b = explode("-", @$user->birthday) */?>
                                    <p><?/*= $b[2] . '.' . $b[1] . '.' . $b[0] */?></p>
                                </div>
                            </div>-->
                            <?php /*if ($uid == $my_id): */?><!--
                                <div class="row">
                                    <div class="col-xs-5">
                                        <p style="color:#999;">Адрес:</p>
                                    </div>
                                    <div class="col-xs-7">
                                        <p><?/*= @$user->address */?></p>
                                    </div>
                                </div>
                            --><?php /*endif; */?>
                        </div>
                        <div class="col-sm-12">
                            <h6><b>Список групп:</b></h6>
                            <hr>
                            <?php if (!empty($list)): ?>

                                <?php foreach ($list as $k=>$i): ?>

                                <div class="row">
                                    <div class="col-xs-12">
                                        <p style="color:#999;"><?= $k ?>:</p>
                                    </div>
                                    <div class="col-xs-12">
                                        <?php echo '<p> ';
                                        foreach ($i as $item) {
                                            if ($cur_user->access != 4)
                                                echo '<a class="btn btn-xs btn-default" style="margin: 0px 2px 2px 0;" href="' . BASE_URL . 'im/converse?class='. $item .'">'.$item.'</a>';
                                            else
                                                echo '<span class="btn btn-xs btn-default" style="margin: 0px 2px 2px 0;">'. $item .'</span>';
                                        }
                                        echo '</p>';
                                        ?>
                                    </div>
                                </div>

                                <?php endforeach; ?>

                            <?php endif; ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (/*$cur_user->access == 5*/ in_array($cur_user->id,[12805,16639])): ?>
                <h4>Получить сертификат за участие можно по ссылке:</h4>
                <a class="btn btn-success btn-lg" target="_blank" href="/counter/cert?c=<?= base64_encode($cur_user->name); ?>">Скачать</a>
            <?php endif; ?>

            <?php if (!empty($events)): ?>

                <?php foreach ($events as $event):?>
                    <h4><?= $event['title'] ?> <small><?= $event['id'] ?></small></h4>
                    <?php $i=1; ?>
                    <?php foreach (explode(',',$event['cert']) as $item): ?>
                        <a style="display: block" href="/activity/show?f=<?= $item ?>" target="_blank"><i class="glyphicon glyphicon-open-file"></i>
                            Просмотр сертификата <?= $i++ ?>
                        </a>
                    <?php endforeach; ?>
                    <hr>
                <?php endforeach; ?>

            <?php endif; ?>
        </div>
    </div>
    <!--    </div>-->
</div>

<?php
//if ($cur_user->access == 4 && $uid == $my_id && !empty($plan))
//foreach ($plan as $k => $item) {
//    if (!count($item['total_marks'])) unset($plan[$k]);

//}

if (!empty($plans)) {
  $plans = array_filter($plans, function ($v){
    return $v['total_marks'] == '';
  });
}
?>
<?php if ($user->access == 4 && /*$uid == $my_id && */!empty($plans)): ?>
<div class="row">
    <div class="col-sm-12">
        <h4 class="text-center"><b>ДОЛГИ</b></h4>
        <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
            <thead>
            <tr>
                <th style="width: 10%;">Семестр</th>
                <th>Предмет</th>
                <th>Руководитель</th>
                <th>Сдать до</th>
<!--                <th style="width: 15%;">Оценка</th>-->
            </tr>
            </thead>
            <tbody>
            <?php foreach ($plans as $item): ?>
                <tr>
                    <td><?= $item['semestr'] ?></td>
                    <td class="text-left">
                        <?php if ($uid == $my_id): ?>
                        <form action="<?= BASE_URL ?>tasks" method="post" target="_blank">
                            <input type="hidden" name="s" value="<?= $item['semestr'] ?>">
                            <input type="hidden" name="dolg" value="1">
                            <button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>"><?= $item['disc'] ?></button>
                        </form>
                        <?php else: echo $item['disc']; endif; ?>
                    </td>
                    <td class="text-left"><?= @$item['lektor'] ?></td>
<!--                    <td class="text-left"><a href="--><?//= BASE_URL ?><!--?id=--><?//= $item['user_id'] ?><!--" target="_blank">--><?//= @$item['lektor'] ?><!--</a></td>-->
                    <td></td>
<!--                    <td>--><?//= @explode('|',@$classsem['ks'])[$item['semestr']-1] ?><!--</td>-->
<!--                    <td class="text-left">--><?//= $item['marks'] ?><!--</td>-->
                 </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php if ($user->access == 4  && /*$uid == $my_id && */count($port)): ?>
<div class="row">
    <div class="col-sm-12">
        <div id="port-discs" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner" role="listbox">
                <?php
                $lastEl = current(array_values(array_slice($port, -1))[0])['sem'];
                foreach ($port as $sem=>$plan2): ?>

                <?php
                    $krs = array_values(array_filter($plan2, function ($v) { return $v['parse'][2] == 0 && $v['parse'][3] != 0; }));
//                    if (isset($_GET['qwe']) && $sem==3) dd($krs);
                    $aud = array_values(array_filter($plan2, function ($v) { return $v['parse'][2] == 0 && $v['parse'][3] == 0; }));
                    $curs_cur= !empty($curs) ? array_values(array_filter($curs, function ($v) use ($sem) { return $v['sem'] == $sem; })):[];
                ?>

                <div class="item<?= $sem == $lastEl?' active':'' ?>">
                    <h3 class="text-center">Предметы на <?= $sem ?> семестр</h3>

                    <?php if (count($krs)): ?>
                    <h4 class="text-center">Контрольные работы</h4>
                    <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                        <thead>
                        <tr>
                            <th style="width: 30%;">Предмет</th>
                            <th style="width: 30%;">Преподаватель</th>
                            <th style="width: 25%;">Оценки</th>
                            <th style="width: 15%;">Итоговая</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($krs as $item): ?>
                            <tr<?php echo ($item['total_marks']=='')?' class=danger':'' ?>>
                                <td class="text-left">
                                    <?php if ($uid == $my_id): ?>
                                    <form action="<?= $item['disc']=='Выпускная квалификационная работа'?'/vkrtasks':'/tasks' ?>" method="post" target="_blank">
                                        <input type="hidden" name="s" value="<?=$sem ?>">
                                        <?= $item['dolg']?'<input type="hidden" name="dolg" value="1">':'' ?>
                                        <button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>">
                                            <?= $item['disc'] ?>
                                            <?php if (@$item['has_video']): ?>
                                                <i class='glyphicon glyphicon-film'></i>
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                    <?php else: echo $item['disc']; endif; ?>
                                </td>
<!--                                <td class="text-left"><a href="--><?//= BASE_URL ?><!--?id=--><?//= $item['user_id'] ?><!--" target="_blank">--><?//= @$item['lektor'] ?><!--</a></td>-->
                                <td class="text-left"><?= @$item['lektor'] ?></td>
                                <td class="text-left"><?= $item['marks'] ?></td>
                                <td class="text-left"><?= $item['total_marks'] ?></td>
                             </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>

                    <?php if (!empty($curs) && count($curs_cur)): ?>
                    <h4 class="text-center">Курсовые работы</h4>
                    <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                        <thead>
                        <tr>
    <!--                        <th style="width: 10%;">Семестр</th>-->
                            <th style="width: 35%;">Предмет</th>
                            <th style="width: 40%;">Руководитель</th>
                            <th style="width: 15%;">Оценка</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($curs_cur as $item): ?>
                            <?php if (empty($item['sem'])) continue; ?>
                            <tr>
    <!--                            <td>--><?//= $item['sem'] ?><!--</td>-->
                                <td class="text-left">
                                    <?php if ($uid == $my_id): ?>
                                    <form action="<?= BASE_URL ?>curstasks" method="post" target="_blank">
                                        <input type="hidden" name="sem" value="<?= $item['sem'] ?>">
                                        <button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>"><?= $item['disc'] ?></button>
                                    </form>
                                    <?php else: echo $item['disc']; endif; ?>
                                </td>
                                <td class="text-left"><?= $item['lektor'] ?></td>
                                <td class="text-left"><?= $item['marks'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>

                    <?php if (count($aud)): ?>
                    <h4 class="text-center">Дополнительные учебные материалы</h4>
                    <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                        <thead>
                        <tr>
                            <th style="width: 30%;">Предмет</th>
                            <th style="width: 30%;">Преподаватель</th>
                            <th style="width: 25%;">Оценки</th>
                            <th style="width: 15%;">Итоговая</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($aud as $item): ?>
                            <tr<?php echo ($item['total_marks']=='')?' class=danger':'' ?>>
                                <td class="text-left">
                                    <?php if ($uid == $my_id): ?>
                                        <?php if (in_array($item['disc'],['Выпускная квалификационная работа','Подготовка и защита выпускной квалификационной работы','Подготовка и защита ВКР','Государственный экзамен'])):?>
                                            <a href="https://portfolio.usue.ru/" target="_blank"><?= $item['disc'] ?></a>
                                        <?php else:?>
                                        <form action="<?= $item['disc']=='Выпускная квалификационная работа'?'/vkrtasks':'/tasks' ?>" method="post" target="_blank">
                                            <input type="hidden" name="s" value="<?=$sem ?>">
                                            <?= $item['dolg']?'<input type="hidden" name="dolg" value="1">':'' ?>
                                            <button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>">
                                                <?= $item['disc'] ?>
                                                <?= @$item['has_video'] ? "<i class='glyphicon glyphicon-film'></i>" : '' ?>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?= $item['disc']; ?>
                                    <?php endif; ?>
                                </td>
<!--                                <td class="text-left">--><?//= $item['disc'] ?><!-- --><?php //if (@$item['has_video']) echo "<i class='glyphicon glyphicon-film'></i>"?><!--</td>-->
<!--                                <td class="text-left"><a href="--><?//= BASE_URL ?><!--?id=--><?//= $item['user_id'] ?><!--" target="_blank">--><?//= @$item['lektor'] ?><!--</a></td>-->
                                <td class="text-left"><?= @$item['lektor'] ?></td>
                                <td class="text-left"><?= $item['marks'] ?></td>
                                <td class="text-left"><?= $item['total_marks'] ?></td>
                             </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>

                    <?php if (!empty($dists) && count($dist_cur)): ?>
                        <h4 class="text-center">Курсовые работы</h4>
                        <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                            <thead>
                            <tr>
                                <!--                        <th style="width: 10%;">Семестр</th>-->
                                <th style="width: 35%;">Предмет</th>
                                <th style="width: 40%;">Руководитель</th>
                                <th style="width: 15%;">Оценка</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($dist_cur as $item): ?>
                                <?php if (empty($item['sem'])) continue; ?>
                                <tr>
                                    <!--                            <td>--><?//= $item['sem'] ?><!--</td>-->
                                    <td class="text-left">
                                        <?php if ($uid == $my_id): ?>
                                            <form action="<?= BASE_URL ?>curstasks" method="post" target="_blank">
                                                <input type="hidden" name="sem" value="<?= $item['sem'] ?>">
                                                <button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>"><?= $item['disc'] ?></button>
                                            </form>
                                        <?php else: echo $item['disc']; endif; ?>
                                    </td>
                                    <td class="text-left"><?= $item['lektor'] ?></td>
                                    <td class="text-left"><?= $item['marks'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        <!-- Controls -->
            <div class="full-width-navigation">
                <a class="left carousel-control" href="#port-discs" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#port-discs" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (false && $cur_user->access == 4 && $uid == $my_id): ?>
    <div class="row">
        <div class="col-sm-12">
            <h4 class="text-center">Курсовые работы</h4>
            <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                <thead>
                <tr>
                    <th style="width: 10%;">Семестр</th>
                    <th style="width: 35%;">Предмет</th>
                    <th style="width: 40%;">Руководитель</th>
                    <th style="width: 15%;">Оценка</th>
                </tr>
                </thead>
                <tbody>
                <?php if (!$curs): ?>
                    <tr><td colspan="4" style="padding: 10px 20px;">Ожидается распределение</td></tr>
                <?php else: ?>
                    <?php foreach ($curs as $item): ?>
                    <?php if (empty($item['sem'])) continue; ?>
                    <tr>
                        <td><?= $item['sem'] ?></td>
                        <td class="text-left">
                            <form action="<?= BASE_URL ?>curstasks" method="post" target="_blank">
                                <input type="hidden" name="sem" value="<?= $item['sem'] ?>">
                                <button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>"><?= $item['disc'] ?></button>
                            </form>
                        </td>
                        <td class="text-left"><?= $item['lektor'] ?></td>
                        <td class="text-left"><?= $item['marks'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<?php if (!empty($vkr) && $vkr): ?>
    <div class="row">
        <div class="col-sm-12">
            <h4 class="text-center">Выпускная квалификационная работа</h4>
            <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                <thead>
                <tr>
                    <th style="width: 10%;">Семестр</th>
                    <th style="width: 35%;">Предмет</th>
                    <th style="width: 40%;">Руководитель</th>
                    <th style="width: 15%;">Оценка</th>
                </tr>
                </thead>
                <tbody>
                <?php if (!$vkr): ?>
                    <tr><td colspan="4" style="padding: 10px 20px;">Ожидается распределение</td></tr>
                <?php else: ?>
                    <?php foreach ($vkr as $item): ?>
                    <tr>
                        <td><?= $item['sem'] ?></td>
                        <td class="text-left">
                            <a href="https://portfolio.usue.ru/" target="_blank"><?= $item['disc'] ?></a>
                            <!--<form action="<?/*= BASE_URL */?>vkrtasks" method="post" target="_blank">
                                <input type="hidden" name="sem" value="<?/*= $item['sem'] */?>">
                                <button class="btn-link text-left" name="disc" value="<?/*= $item['disc'] */?>"><?/*= $item['disc'] */?></button>
                            </form>-->
                        </td>
                        <td class="text-left"><?= $item['lektor'] ?></td>
                        <td class="text-left"><?= $item['marks'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
<?php if (!empty($pract) && $pract): ?>
    <div class="row">
        <div class="col-sm-12">
            <h4 class="text-center">Практика</h4>
            <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                <thead>
                <tr>
                    <th style="width: 10%;">Семестр</th>
                    <th style="width: 35%;">Предмет</th>
                    <th style="width: 40%;">Руководитель</th>
                    <th style="width: 15%;">Оценка</th>
                </tr>
                </thead>
                <tbody>
                <?php if (!$pract): ?>
                    <tr><td colspan="4" style="padding: 10px 20px;">Ожидается распределение</td></tr>
                <?php else: ?>
                    <?php foreach ($pract as $item): ?>
                    <tr>
                        <td><?= $item['sem'] ?></td>
                        <td class="text-left">
                            <form action="<?= BASE_URL ?>practtasks" method="post" target="_blank">
                                <input type="hidden" name="sem" value="<?= $item['sem'] ?>">
                                <button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>"><?= $item['disc'] ?></button>
                            </form>
                        </td>
                        <td class="text-left"><?= $item['lektor'] ?></td>
                        <td class="text-left"><?= $item['marks'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<?php if (!empty($dists) && $dists): ?>
    <div class="row">
        <div class="col-sm-12">
            <h4 class="text-center">Дистанционные задания</h4>
            <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                <thead>
                <tr>
                    <th style="width: 10%;">Семестр</th>
                    <th style="width: 35%;">Предмет</th>
                    <th style="width: 40%;">Руководитель</th>
                </tr>
                </thead>
                <tbody>
                <?php if (!$dists): ?>
                    <tr><td colspan="4" style="padding: 10px 20px;">Ожидается распределение</td></tr>
                <?php else: ?>
                    <?php foreach ($dists as $item): ?>
                        <tr>
                            <td><?= $item['sem'] ?></td>
                            <td class="text-left">
                                <form action="<?= BASE_URL ?>disttasks" method="post" target="_blank">
                                    <input type="hidden" name="sem" value="<?= $item['sem'] ?>">
                                    <button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>"><?= $item['disc'] ?></button>
                                </form>
                            </td>
                            <td class="text-left"><?= $item['lektor'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>


<script>
    var uid = <?php echo $uid; ?>;
    var my_id = <?php if ($my_id) {
        echo $my_id;
    } else {
        echo 0;
    } ?>;

    $(document).ready(function () {
       $('#dopinfatoggle').click(function () {
           if ($('#dopinfa').is(':hidden'))
               $('#dopinfa').fadeIn(1000);
           else
               $('#dopinfa').fadeOut(1000);
       });
    });
</script>

<?php if ($user->access == 4  && /*$uid == $my_id && */count($port)): ?>
    <script>
        $(document).ready(function () {
            $(".carousel").carousel({ interval: false });
            $(function () {
                $('[data-toggle="popover"]').popover()
            })
        });
    </script>
    <style>
        h3 {text-transform:uppercase; font-weight:700        }
        .carousel-control { color: #f60; opacity: .8 }
        .carousel-control:focus, .carousel-control:hover { color: #f60; opacity: 1 }
        .carousel-control.right, .carousel-control.left{ background:none;}
        .btn-capsul {border-radius:30px;}
        .full-width-navigation { position: absolute;  width: 100%; top:30px;}
        .full-width-navigation .carousel-control .glyphicon-chevron-right {right:10%}
        .full-width-navigation .carousel-control .glyphicon-chevron-left {left:10%}
        .small-width-navigation {bottom: 34%; position: absolute; width: 5%;}
        .social-links span {width:40px; height:40px; border:1px solid #fff; color:#fff; border-radius:50%; text-align:center; line-height:40px; margin: 20px 10px;}
        .banner-01 {background: #CCCCCC; float: left; width: 100%;  padding: 30px 0; margin-bottom:50px; position:relative;}
        .banner-02 {background: #fff; float: left; width: 100%;  padding: 30px 0; margin-bottom:50px; position:relative; min-height:400px }
        .banner-02 .carousel-inner {min-height:250px }
        .banner-03 {background: #CCCCCC; float: left; width: 100%;  padding: 30px 0; margin-bottom:50px; position:relative; min-height:400px }
        .banner-03 .carousel-inner {min-height:350px }
        .banner-04 {background: #fff; float: left; width: 100%;  padding: 30px 0; margin-bottom:50px; position:relative; min-height:400px }
        .banner-04 p {font-size:16px; line-height:30px;}
        .banner-04 .glyphicon {color:#E8117F}
        .banner-04 .content-sec {margin-top:30px;}
        .banner-04 .carousel-inner {min-height:400px }

        .action-sec{width:100%; float:left; background:#222}
        .action-box{float:left; width:100%; text-align:center;}
        .action-box h2{color:#fff; font-size:20px;}

    </style>
<?php endif; ?>
