<!--<div class="col-sm-3">
    <div class="row">
        <ul id="myTab" class="list-group">
            <a class="list-group-item" href="#basic" data-toggle="tab">Основная</a>
            <a class="list-group-item" href="#school" data-toggle="tab">Учебные</a>
            <a class="list-group-item" href="#personal" data-toggle="tab">Персональные</a>
            <a class="list-group-item" href="#edu" data-toggle="tab">Образование</a>
            <a class="list-group-item" href="#carier" data-toggle="tab">Карьера</a>
            <a class="list-group-item" href="#add" data-toggle="tab">Дополнительно</a>
        </ul>
    </div>
</div>-->
<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="#basic">Основные</a></li>
    <?php if ($user->access != 5): ?>
        <li><a data-toggle="tab" href="#noty">Уведомления</a></li>
    <?php endif; ?>
</ul>
<div id="myTabContent" class="tab-content">
    <div class="tab-pane fade in active" id="basic">
        <form action="profile/save" method="post" class="form-horizontal">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-sm-4"><h4>Общие настройки</h4></div>
                    <div class="col-sm-8">
                        <?php if ($user->access != 1): ?>
                        <div class="form-group">
                            <label class="control-label col-sm-8" for="phone">Пол:</label>
                            <div class="col-sm-4">
                                <select name="sex" class="selectpicker form-control">
                                    <option value="">Не выбрано</option>
                                    <option <?= ($user->sex == 'М') ? 'selected' : '' ?> value="М">Мужской</option>
                                    <option <?= ($user->sex == 'Ж') ? 'selected' : '' ?> value="Ж">Женский</option>
                                </select>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <div class="col-xs-12">
                        <h1></h1>
                    <?php if ($user->access == 1): ?>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <label style="font-size: 1.5em;" class="control-label" for="email">Текст на странице авторизации:</label>
                                <textarea class="form-control" name="email" id="" rows="5"><?= @$user->email ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <label style="font-size: 1.5em;" class="control-label" for="email">Текст на странице тестов:</label>
                                <textarea class="form-control" name="config" id="" rows="5"><?= @$config ?></textarea>
                            </div>
                        </div>
                        <div class="form-group" style="display: none">
                            <div class="col-xs-12">
                                <label style="font-size: 1.5em;" class="control-label" for="email">Email для копий писем методисту:</label>
                                <input class="form-control" name="config_metodist_email" value="<?= @$config_metodist_email ?>">
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="form-group">
                            <label class="control-label col-sm-4" for="email">Email:<small class="form-element-helptext">
                                <div class="text-muted text-danger">(Виден только менеджеру)</div></small></label>
                            <div class="col-sm-8">
                                <input type="email" class="form-control" name="email" placeholder="Введите email" value="<?= @$user->email ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-4" for="email">Мобильный телефон:<small class="form-element-helptext">
                                <div class="text-muted text-danger">(Виден только менеджеру)</div></small></label>
                            <div class="col-sm-8">
                                <input type="tel" class="form-control mphone" name="mphone" placeholder="Введите мобильный телефон" value="<?= @$user->mphone ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-4" for="phone">Телефон:</label>
                            <div class="col-sm-8">
                                <input type="tel" class="form-control" name="phone" placeholder="Введите рабочий телефон" value="<?= @$user->phone ?>">
                            </div>
                        </div>
                    <?php endif; ?>
                        <?php if ($user->access == 3): ?>
                        <div class="form-group">
                            <label class="control-label col-sm-4" for="phone">Аудитория:</label>
                            <div class="col-sm-8">
                                <input type="tel" class="form-control" name="komnata" placeholder="Укажите аудиторию" value="<?= @$user->komnata ?>">
                            </div>
                        </div>

                        <ul class="nav nav-tabs nav-justified">
                          <li class="active"><a data-toggle="tab" href="#date-cons">Даты консультаций</a></li>
                          <li><a data-toggle="tab" href="#time-cons">Часы консультаций</a></li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane fade in active" id="date-cons">
                                <h3> </h3>
                                <div class="form-group">
                                    <table id="my-table2" class="table table-bordered tabledit-form">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>С</th>
                                                <th>По</th>
                                                <th width="135"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php for ($i=0; $i<count(@$workdate); $i++): ?>
                                            <tr data-id="<?= $i ?>">
                                                <td>
                                                    <div class="input-group date">
                                                        <input autocomplete="off" type="text" class="datepicker form-control" name="workdate[]" value="<?= $workdate[$i] ?>">
                                                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                                    </div>
                                                </td>
                                                <td><input class="form-control" name="wt_from[]" value="<?= @$workdatetime[$i][0] ?>" type="text"></td>
                                                <td><input class="form-control" name="wt_to[]"   value="<?= @$workdatetime[$i][1] ?>" type="text"></td>
                                                <td>
                                                    <div class="del-workdate label label-danger" style="font-size: 1em;cursor: pointer;">&nbsp;Удалить дату...</div>
                                                </td>
                                            </tr>
                                            <?php endfor; ?>
                                        </tbody>
                                    </table>
                                    <span style="margin-left: 1em;" href="/profile/addworkdate" class="add-workdate btn btn-success">
                                        <i class="glyphicon glyphicon-plus-sign"></i>&nbsp;Добавить дату...</span>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="time-cons">
                                <h3> </h3>
                                <div class="form-group">
                                    <table id="my-table" class="table table-bordered tabledit-form">
                                            <thead>
                                                <tr>
                                                    <th></th>
                                                    <th>С</th>
                                                    <th>По</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr><td width="1">Пн</td>
                                                    <td><input autocomplete="off" class="form-control" name="w_from_1" value="<?= @$worktime['from'][1] ?>" type="text"></td>
                                                    <td><input autocomplete="off" class="form-control" name="w_to_1"   value="<?= @$worktime['to'][1] ?>" type="text"></td></tr>
                                                <tr><td width="1">Вт</td>
                                                    <td><input autocomplete="off" class="form-control" name="w_from_2" value="<?= @$worktime['from'][2] ?>" type="text"></td>
                                                    <td><input autocomplete="off" class="form-control" name="w_to_2"   value="<?= @$worktime['to'][2] ?>" type="text"></td></tr>
                                                <tr><td width="1">Ср</td>
                                                    <td><input autocomplete="off" class="form-control" name="w_from_3" value="<?= @$worktime['from'][3] ?>" type="text"></td>
                                                    <td><input autocomplete="off" class="form-control" name="w_to_3"   value="<?= @$worktime['to'][3] ?>" type="text"></td></tr>
                                                <tr><td width="1">Чт</td>
                                                    <td><input autocomplete="off" class="form-control" name="w_from_4" value="<?= @$worktime['from'][4] ?>" type="text"></td>
                                                    <td><input autocomplete="off" class="form-control" name="w_to_4"   value="<?= @$worktime['to'][4] ?>" type="text"></td></tr>
                                                <tr><td width="1">Пт</td>
                                                    <td><input autocomplete="off" class="form-control" name="w_from_5" value="<?= @$worktime['from'][5] ?>" type="text"></td>
                                                    <td><input autocomplete="off" class="form-control" name="w_to_5"   value="<?= @$worktime['to'][5] ?>" type="text"></td></tr>
                                                <tr><td width="1">Сб</td>
                                                    <td><input autocomplete="off" class="form-control" name="w_from_6" value="<?= @$worktime['from'][6] ?>" type="text"></td>
                                                    <td><input autocomplete="off" class="form-control" name="w_to_6"   value="<?= @$worktime['to'][6] ?>" type="text"></td></tr>
                                                <tr><td width="1">Вс</td>
                                                    <td><input autocomplete="off" class="form-control" name="w_from_7" value="<?= @$worktime['from'][7] ?>" type="text"></td>
                                                    <td><input autocomplete="off" class="form-control" name="w_to_7"   value="<?= @$worktime['to'][7] ?>" type="text"></td></tr>
                                            </tbody>
                                        </table>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <input type="hidden" name="name" value="basic">

                </div>
            </div>
            <div class="panel-footer">
                <button type="submit" class="btn btn-success pull-right">Сохранить</button>
                <div class="clearfix"></div>
            </div>
        </div>
        </form>
    </div>
    <?php if ($user->access != 5): ?>
    <div class="tab-pane fade" id="noty">
        <form action="profile/save" method="post" class="form-horizontal">
        <div class="panel panel-default">
            <div class="panel-heading">Настройка уведомлений</div>
            <div class="panel-body">
                <div class="col-xs-12">
                <?php if ($user->access == 1): ?>
                    <div class="row">
                        <div class="alert alert-warning" role="alert">
                            Доступные переменные во всех письмах и заголовках:<br>
                            <b>%email%</b> - <i>Email получателя письма</i><br>
                            <b>%date%</b> - <i>Текущая дата в формате (день.месяц.Год)</i><br>
                            <b>%time%</b> - <i>Текущее время в формате (Часы:минуты:секунды)</i><br>
                            <b>%fio%</b> - <i>ФИО получателя</i><br>
                        </div>
                    </div>
                    <?php foreach ($list as $k => $item): ?>

                        <?php //if (in_array($k,['metodist','metodist1','metodist2'])) continue; ?>
                    <ul class="list-group">
                        <li class="list-group-item" style="<?= in_array($k,['metodist','metodist1','metodist2']) ? 'display:none' :'' ?>">
                            <div class="row">
                                <div class="col-xs-12">
                                    <b style="font-size: 1.5em;"><?= $item ?></b>
                                    <small><a href="/profile/email?alias=<?= $k ?>" target="_blank"> (пример сообщения)</a></small>
                                    <div class="material-switch pull-right">
                                        Статус уведомления&nbsp;
                                        <input id="<?= $k ?>" name="noty[<?= $k ?>]" type="checkbox" data-toggle="collapse" data-target="#noty-<?= $k ?>"
                                            <?= (isset($noty) && in_array($k,$noty)) ? 'checked' : ''  ?> />
                                        <label for="<?= $k ?>" class="label-success"></label>
                                    </div>
                                </div>
                            </div>
                            <div id="noty-<?= $k ?>" class="collapse<?= (isset($noty) && in_array($k,$noty)) ? ' in' : ''  ?>">
                                <?php if (in_array($k, ['worksend','worknew','workmark','metodist','metodist1','metodist2'])): ?>
                                <div class="row">
                                    <div class="alert alert-warning" role="alert">
                                        Доступные переменные в текущем письме и заголовке:<br>
                                        <?php if (in_array($k, ['worksend','worknew','workmark'])): ?>
                                            <b>%predmet%</b> - <i>Предмет</i>
                                        <?php endif; ?>
                                        <?php if ($k=='workmark'): ?>
                                            <br><b>%ocenka%</b> - <i>Оценка</i>
                                        <?php endif; ?>
                                        <?php if ($k=='worknew'): ?>
                                            <br><b>%fio_stud%</b> - <i>ФИО студента</i>
                                            <br><b>%gruppa%</b> - <i>Группа студента</i>
                                        <?php endif; ?>
                                        <?php if (in_array($k, ['metodist','metodist1','metodist2'])): ?>
                                            <br><b>%fio_stud%</b> - <i>ФИО студента</i>
                                            <br><b>%gruppa%</b> - <i>Группа студента</i>
                                            <br><b>%akadem_from%</b> - <i>Дата начала академ.отпуска в формате (день.месяц.Год)</i>
                                            <br><b>%akadem_to%</b> - <i>Дата окончания академ.отпуска в формате (день.месяц.Год)</i>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div class="clearfix"></div>
                                <label for="">Заголовок письма:</label>
                                <input class="form-control" type="text" name="header[<?= $k ?>]" value="<?= $noty_list[$k]['header'] ?>"><br>
                                <label for="">Сообщение:</label>
                                <textarea class="form-control editor1" name="message[<?= $k ?>]" id="" rows="10"><?= $noty_list[$k]['message'] ?></textarea>
                            </div>
                        </li>
                    </ul>
                    <?php endforeach; ?>
                <?php else: ?>
                    <?php foreach ($list as $k => $item): ?>
                    <?php if (($user->access == 3 && !in_array($k,['auth','worknew']))
                            || ($user->access == 4 && $k == 'worknew')) continue ?>
                    <ul class="list-group">
                        <li class="list-group-item"><?= $item ?><?= !in_array($k,$admin_noty) ? ' <br><code>отключено администратором</code>' : '' ?>
                            <div class="material-switch pull-right">
                                <input id="<?= $k ?>" name="noty[<?= $k ?>]" type="checkbox"
                                    <?= (isset($noty) && in_array($k,$noty)) ? 'checked' : ''  ?> />
                                <label for="<?= $k ?>" class="label-success"></label>
                            </div>
                        </li>
                    </ul>
                    <?php endforeach; ?>
                <?php endif; ?>
                </div>
            </div>
            <div class="panel-footer">
                <input type="hidden" name="name" value="noty">
                <button type="submit" class="btn btn-success pull-right">Сохранить</button>
                <div class="clearfix"></div>
            </div>
        </div>
        </form>
    </div>
    <div class="tab-pane fade" id="school">
        <div class="panel panel-default">
            <div class="panel-heading">Учебные данные</div>
            <div class="panel-body">
                <form action="profile/save" method="post" class="form-horizontal">
                    <h1></h1>
                    <?php $i=0;
                    foreach ($school as $k => $v): ?>
                        <div class="form-group">
                            <label class="control-label col-sm-3"><?= $k ?></label>
                            <div class="col-sm-8">
                                <input name="<?= $i++ ?>" type="text" class="form-control" placeholder="" value="<?= @$v ?>">
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <input type="hidden" name="name" value="school">
                    <div class="form-group">
                        <div class="col-sm-offset-5 col-sm-2">
                            <button type="submit" class="btn btn-default">Сохранить</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="tab-pane fade" id="personal">
        <div class="panel panel-default">
            <div class="panel-heading">Персональные данные</div>
            <div class="panel-body">
                <form class="form-horizontal">
                    <h1></h1>
                    <div class="form-group">
                        <label class="control-label col-sm-2 col-sm-offset-1" for="email">test:</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="test" placeholder="test">
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <div class="tab-pane fade" id="edu">
        <div class="panel panel-default">
            <div class="panel-heading">Образование</div>
            <div class="panel-body">
                <form class="form-horizontal">
                    <h1></h1>
                    <div class="form-group">
                        <label class="control-label col-sm-2 col-sm-offset-1" for="email">test:</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="test" placeholder="test">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="tab-pane fade" id="carier">
        <div class="panel panel-default">
            <div class="panel-heading">Карьера</div>
            <div class="panel-body">
                <form class="form-horizontal">
                    <h1></h1>
                    <div class="form-group">
                        <label class="control-label col-sm-2 col-sm-offset-1" for="email">test:</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="test" placeholder="test">
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <div class="tab-pane fade" id="add">
        <div class="panel panel-default">
            <div class="panel-heading">Доп. информация</div>
            <div class="panel-body">
                <form class="form-horizontal">
                    <h1></h1>
                    <div class="form-group">
                        <label class="control-label col-sm-2 col-sm-offset-1" for="email">test:</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="test" placeholder="test">
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<div id="mod" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body"></div>
            <div class="modal-footer">
                <a href="#" class="btn btn-default" data-dismiss="modal">Закрыть</a>
            </div>
        </div>
    </div>
</div>
<?php /*<!--<script src="/js/jquery.tabledit.min.js"></script>-->*/ ?>
<script src="/js/plug/jquery.inputmask.bundle.min.js"></script>
<script src="/js/moment.js"></script>
<script src="/js/plug/bootstrap-datetimepicker.js"></script>
<link rel="stylesheet" type="text/css" href="/js/plug/bootstrap-datetimepicker.css">

<script language="JavaScript" type="text/javascript">
    $('[name="wt_from[]"]').datetimepicker({locale: 'ru',format: 'HH:mm'});
    $('[name="wt_to[]"]').datetimepicker({locale: 'ru',format: 'HH:mm'});
    $('#my-table input').datetimepicker({locale: 'ru',format: 'HH:mm'});
</script>
<script>
    $(document).ready(function () {
        $('.datepicker').datepicker({
            language: 'ru',
            format: 'dd.mm.yyyy',
            todayHighlight: true,
            autoclose: true
        });
        $('.mphone').inputmask("+7(999)999-99-99");
    });

    $('body').on('click','.add-workdate', function () {
       let tr = $('#my-table2 tbody');
       let aaa = tr.append('<tr><td><div class="input-group date"><input autocomplete="off" type="text" class="datepicker form-control" name="workdate[]" value=""><span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span></div></td><td><input class="form-control" name="wt_from[]" value="" type="text"></td><td><input class="form-control" name="wt_to[]" value="" type="text"></td><td><div class="del-workdate label label-danger" style="font-size:1em;cursor: pointer">&nbsp;Удалить дату...</div></td></tr>');
       aaa.find('.datepicker').datepicker({
            language: 'ru',
            format: 'dd.mm.yyyy',
            todayHighlight: true,
            autoclose: true
       });
       aaa.find('[name="wt_from[]"]').datetimepicker({locale: 'ru',format: 'HH:mm'});
       aaa.find('[name="wt_to[]"]').datetimepicker({locale: 'ru',format: 'HH:mm'});
    });

    $('body').on('click','.del-workdate', function () {
        $(this).parent().parent().remove();
    })


    // $('#my-table').Tabledit({
    //     editButton: false,
    //     removeButton: false,
    //     columns: {
    //       identifier: [0, 'id'],
    //       editable: [[1, 'from'], [2, 'to']]
    //     },
    //     buttons: {}
    // });
</script>

<style>
    .material-switch > input[type="checkbox"] {
    display: none;
}

.material-switch > label {
    cursor: pointer;
    height: 0px;
    position: relative;
    width: 40px;
}

.material-switch > label::before {
    background: rgb(0, 0, 0);
    box-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);
    border-radius: 8px;
    content: '';
    height: 16px;
    margin-top: -8px;
    position:absolute;
    opacity: 0.3;
    transition: all 0.4s ease-in-out;
    width: 40px;
}
.material-switch > label::after {
    background: rgb(255, 255, 255);
    border-radius: 16px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    content: '';
    height: 24px;
    left: -4px;
    margin-top: -8px;
    position: absolute;
    top: -4px;
    transition: all 0.3s ease-in-out;
    width: 24px;
}
.material-switch > input[type="checkbox"]:checked + label::before {
    background: inherit;
    opacity: 0.5;
}
.material-switch > input[type="checkbox"]:checked + label::after {
    background: inherit;
    left: 20px;
}
</style>

<script>
    // $('.collapse').on('show.bs.collapse', function (e) {
    //     let id = $(this).attr('id');
    //     console.log(id);
    //     $('[data-target="#'+id+'"').find(.material-switch)
    // });
    // $('body').on('change','.material-switch', function () {
    	// el = $(this).parent().parent().data('target');
    	// console.log(el);
    	// $(el).collapse('show')
    	// $('.collapse')
        // .on('show.bs.collapse', function (e) { e.preventDefault(); })
        // .on('hide.bs.collapse', function (e) { e.preventDefault(); })
    // })
    // $('.collapse').on('show.bs.collapse', function () {
    // 	 $('.material-switch')
    // })
    // $('body').on('click','.collapse', function (e) {
    // 	let $self = $(this);
    //     $self.find('.material-switch').change(function () {
    //     	e.preventDefault();
    //         $self.collapse('toggle')
	//     })
    // })
</script>