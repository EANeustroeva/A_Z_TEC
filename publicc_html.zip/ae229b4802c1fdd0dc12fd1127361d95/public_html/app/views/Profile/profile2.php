<div id="carousel-example-01" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner" role="listbox">
        <?php foreach ($port as $sem=>$plan2): ?>
        <div class="item<?= $sem == $cur_user->sem?' active':'' ?>">
            <h4 class="text-center">Предметы на <?= $sem ?> семестр</h4>
            <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                <thead>
                <tr>
                    <th style="width: 30%;">Предмет</th>
                    <th style="width: 30%;">Преподаватель</th>
                    <th style="width: 25%;">Оценки</th>
                    <th style="width: 15%;">Итоговая</th>
                </tr>
                </thead>
                <tbody>
                <form action="<?= BASE_URL ?>tasks" method="get" target="_blank">
                <input type="hidden" name="s" value="<?=$sem ?>">
                <?php foreach ($plan2 as $item): ?>
                    <tr<?php echo ($item['total_marks']=='')?' class=danger':'' ?>>
                        <td class="text-left">
                            <button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>"><?= $item['disc'] ?> <?php if (@$item['has_video']) echo "<i class='glyphicon glyphicon-film'></i>"?></button>
                        </td>
                        <td class="text-left"><a href="<?= BASE_URL ?>?id=<?= $item['user_id'] ?>" target="_blank"><?= @$item['lektor'] ?></a></td>
                        <td class="text-left"><?= $item['marks'] ?></td>
                        <td class="text-left"><?= $item['total_marks'] ?></td>
                     </tr>
                <?php endforeach; ?>
                </form>
                </tbody>
            </table>
        </div>
        <?php endforeach; ?>
    </div>
<!-- Controls -->
</div>
<div class="full-width-navigation">
    <a class="left carousel-control" href="#carousel-example-01" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#carousel-example-01" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>


<script>
    $(".carousel").carousel({
        interval: false
    });
</script>
<style>
    h1 {text-transform:uppercase; font-weight:700        }
        .carousel-control.right, .carousel-control.left{ background:none;}
        .btn-capsul {border-radius:30px;}
        .full-width-navigation { position: absolute;  width: 100%; top:10px;}
        .full-width-navigation .carousel-control .glyphicon-chevron-right {right:10%}
        .full-width-navigation .carousel-control .glyphicon-chevron-left {left:10%}
        .small-width-navigation {bottom: 34%; position: absolute; width: 5%;}
        .social-links span {width:40px; height:40px; border:1px solid #fff; color:#fff; border-radius:50%; text-align:center; line-height:40px; margin: 20px 10px;}
        .banner-01 {background: #CCCCCC; float: left; width: 100%;  padding: 30px 0; margin-bottom:50px; position:relative;}
        .banner-02 {background: #fff; float: left; width: 100%;  padding: 30px 0; margin-bottom:50px; position:relative; min-height:400px }
        .banner-02 .carousel-inner {min-height:250px }
        .banner-03 {background: #CCCCCC; float: left; width: 100%;  padding: 30px 0; margin-bottom:50px; position:relative; min-height:400px }
        .banner-03 .carousel-inner {min-height:350px }
        .banner-04 {background: #fff; float: left; width: 100%;  padding: 30px 0; margin-bottom:50px; position:relative; min-height:400px }
        .banner-04 p {font-size:16px; line-height:30px;}
        .banner-04 .glyphicon {color:#E8117F}
        .banner-04 .content-sec {margin-top:30px;}
        .banner-04 .carousel-inner {min-height:400px }

.action-sec{width:100%; float:left; background:#222}
.action-box{float:left; width:100%; text-align:center;}
.action-box h2{color:#fff; font-size:20px;}

</style>

    <div class="row">
<div class="col-sm-12">
    <h4>Предметы на <?= $cur_user->sem ?> семестр</h4>
    <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
        <thead>
        <tr>
            <th style="width: 30%;">Предмет</th>
            <th style="width: 30%;">Преподаватель</th>
            <th style="width: 25%;">Оценки</th>
            <th style="width: 15%;">Итоговая</th>
        </tr>
        </thead>
        <tbody>
        <form action="<?= BASE_URL ?>tasks" method="get" target="_blank">
        <input type="hidden" name="s" value="<?=$cur_user->sem ?>">
        <?php foreach ($plan2 as $item): ?>
            <tr<?php echo ($item['total_marks']=='')?' class=danger':'' ?>>
                <td class="text-left">
                    <button class="btn-link text-left" name="disc" value="<?= $item['disc'] ?>"><?= $item['disc'] ?> <?php if ($item['has_video']) echo "<i class='glyphicon glyphicon-film'></i>"?></button>
                </td>
                <td class="text-left"><a href="<?= BASE_URL ?>?id=<?= $item['user_id'] ?>" target="_blank"><?= @$item['lektor'] ?></a></td>
                <td class="text-left"><?= $item['marks'] ?></td>
                <td class="text-left"><?= $item['total_marks'] ?></td>
             </tr>
        <?php endforeach; ?>
        </form>
        </tbody>
    </table>
</div>
    </div>