<a href="/works//edit" class="btn btn-primary">Новая вакансия</a>
<a href="/works?view" class="btn btn-warning" target="_blank">Просмотреть со стороны студента</a>
<?php if (!isset($_GET['deleted'])): ?>
<a href="/works?deleted" class="btn btn-link pull-right">Просмотреть удаленные вакансии</a>
<?php else: ?>
<a href="/works" class="btn btn-success pull-right">Вернуться к обычному просмотру</a>
<?php endif; ?>
<!--<a href="/works/report" class="btn btn-warning">Полный отчет</a>-->
<!--<a href="/works/print" target="_blank" class="btn btn-warning">Печать полного отчета</a>-->
<hr>
<table class="table table-striped table-hover table-bordered table-responsive">
    <thead>
        <tr>
<!--            <th>№</th>-->
<!--            <th>Курсы</th>-->
<!--            <th>Направления</th>-->
<!--            <th>Группы</th>-->
<!--            <th>Студенты</th>-->
            <th>Создан</th>
            <th>Работодатель</th>
            <th>Зарплата</th>
            <th>Заголовок</th>
            <th>Действие</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($q as $item): ?>
        <tr class="<?= !$item['enabled'] ? 'warning' : '' ?>">
<!--            <td>--><?//= $item['id'] ?><!--</td>-->
<!--            --><?php //$ss = json_decode($item['course'],1); foreach ($ss as &$i) $i = $i+1;?>
<!--            <td>--><?//=implode(', ',$ss)?><!--</td>-->
<!--            <td>--><?//=implode(', ',array_intersect_key($napr_list,array_flip(json_decode($item['napr'],1))))?><!--</td>-->
<!--            <td>--><?//=implode(', ',json_decode($item['class'],1))?><!--</td>-->
<!--            <td>--><?//=implode(', ',json_decode($item['users'],1))?><!--</td>-->
            <td width="120"><?=date("d.m.Y H:i",strtotime($item['created']))?></td>
            <td class="text-left"><?=$item['employer']?></td>
            <td width="150"><?=$item['price']?></td>
            <td class="text-left"><?=$item['header']?></td>
            <td>
                <a href="/works/edit?id=<?= $item['id'] ?>" class="btn btn-primary btn-xs" style="margin-bottom: 5px;" title="Редактировать"><i class="glyphicon glyphicon-pencil"></i></a>
                <?php if (isset($_GET['deleted'])): ?>
                <form class="restore" action="/works/restore" style="display:inline-block;" method="post">
                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                    <button class="btn btn-warning btn-xs" style="margin-bottom: 5px;" title="Восстановить"><i class="glyphicon glyphicon-repeat"></i></button>
                </form>
                <?php else: ?>
                <form class="delete" action="/works/delete" style="display:inline-block;" method="post">
                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                    <button class="btn btn-danger btn-xs" style="margin-bottom: 5px;" title="Удалить"><i class="glyphicon glyphicon-remove"></i></button>
                </form>
                <?php endif; ?>
<!--                <a href="/works/report?id=--><?//= $item['id'] ?><!--" class="btn btn-warning btn-xs" style="width: 100%;margin-bottom: 5px;">Отчет</a>-->
<!--                <a href="/works/print?id=--><?//= $item['id'] ?><!--" target="_blank" class="btn btn-warning btn-xs" style="width: 100%;margin-bottom: 5px;">Печать</a>-->
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/select/1.2.5/css/select.dataTables.min.css">

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script src="/js/sweetalert2.all.min.js"></script>
<script src="/js/moment.js"></script>
<script>
    table = $('table2').DataTable({
        stateSave: true,
        // "info":     false,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
        }
    });

    $('body').on('click','.delete', function (e) {
        let form = $(this);
        e.preventDefault();
        Swal.fire({
          title: 'Вы уверены?',
          text: "Вы точно хотите удалить вакансию!",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Да',
          cancelButtonText: 'Нет'
        }).then((result) => {
          if (result.value) {
            form.submit();
          }
        })
    });


</script>