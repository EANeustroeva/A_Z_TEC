<?php if (!isset($_GET['favorites'])): ?>
<h3 class="pull-left" style="margin-top: 0;">Список вакансий</h3>
<i style="font-size: 1.2em;" class="pull-right"><a class="btn btn-link" style="color: #f60" href="/works?<?= isset($_GET['view'])?'view&':'' ?>favorites"><i class="glyphicon glyphicon-star"></i> Избранное</a> <?php if (!empty($count)): ?>Новых вакансий: <strong id="count"><?= $count ?></strong><?php endif; ?></i>
<?php else: ?>
<h3 class="pull-left" style="margin-top: 0;">Список избранных вакансий</h3>
<i style="font-size: 1.2em;" class="pull-right"><a class="btn btn-link" style="color: #f60" href="/works<?= isset($_GET['view'])?'?view':'' ?>">Назад</a></i>
<?php endif; ?>
<div class="clearfix"></div>
<hr>
<br>
<?php if (empty($q)): ?>
<p><i>Список пуст</i></p>
<?php else: ?>
    <?php foreach ($q as $item): ?>
    <div data-id="<?= $item['id'] ?>" class="panel panel-primary">
        <div class="panel-heading">
            <a class="title" data-id="<?= $item['id'] ?>" href="#collapse<?= $item['id'] ?>" data-toggle="collapse" style="font-size: 1.1em; color: white;">
                <?php if (count($int_good)&&in_array($item['id'],$int_good)): ?>
                    <span class="" style="color: #f60"><i class="glyphicon glyphicon-star" title="В избранном"></i></span>
                <?php endif; ?>
                <b style="border-bottom: 1px dashed #fff"><?=$item['header']?></b>
                <?php if (count($ids) && !in_array($item['id'], $ids) || !count($ids)): ?>
                &nbsp;<span class="new label label-warning">новая</span>
                <?php endif; ?>
            </a>
            <span class="label label-danger pull-right" style="font-size: 1.1em;"><?= !empty($item['price']) ? $item['price'] : 'договорная' ?></span>
        </div>
        <div class="panel-body">
            <div class="col-xs-12">
                <h4> </h4>
                <div class="row">
                    <div class="col-xs-6">
                        <p>Работодатель: <b><?= !empty($item['employer']) ? $item['employer'] : '-' ?></b></p>
                        <p>Телефон: <b><?= !empty($item['phone']) ? $item['phone'] : '-' ?></b></p>
                    </div>
                    <div class="col-xs-6"><p>Адрес: <b><?= !empty($item['address']) ? $item['address'] : '-' ?></b></p></div>
                </div>

                <div class="collapse" id="collapse<?= $item['id'] ?>">
                    <div class="well"><?= $item['msg'] ?></div>
                </div>
                <div>
                    <span class="pull-left">
                        <?php if (count($ids) && !in_array($item['id'], $ids) || !count($ids)): ?>
                            <span data-id="<?= $item['id'] ?>" class="watched btn btn-link pull-left" style="color: green"><i class="glyphicon glyphicon-ok"></i> Ознакомлен</span>
                        <?php endif; ?>
                        <?php if (count($int_good) && !in_array($item['id'], $int_good) || !count($int_good)): ?>
                            <span data-int="1" data-id="<?= $item['id'] ?>" class="interested btn btn-link pull-left" style="color: #f60"><i class="glyphicon glyphicon-star-empty"></i> В избранное</span>
        <!--                    <span data-int="0" data-id="--><?//= $item['id'] ?><!--" class="interested btn btn-danger">Не нравится</span>-->
                        <?php endif; ?>
                    </span>
                    <?php if (!empty($item['date_end'])): ?>
                        <i class="pull-right">Действительна до: <?=date("d.m.Y",strtotime($item['date_end']))?></i>
                    <?php else: ?>
                        <i class="pull-right">Добавлено: <?=date("d.m.Y H:i",strtotime($item['created']))?></i>
                    <?php endif; ?>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<script src="/js/sweetalert2.all.min.js"></script>
<script src="/js/moment.js"></script>
<script>
    $(document).ready(function () {

    });

    // $('.title').click(function () {
    //     let id = $(this).data('id');
    //     let self = $(this);
    //     let count = $('#count').text();
    //     $.ajax({
    //         url: '/works/confirm',
    //         data: {id: id},
    //         success: function (res) {
    //             if (res === 'ok') {
    //                 self.find('.new').fadeOut(1000);
    //                 $('#count').text(count-1);
    //             }
    //         },
    //         error: function () {
    //             console.log('error')
    //         }
    //     })
    // });

    $('.watched').click(function () {
        let id = $(this).data('id');
        let n = $('.title[data-id='+id+']');
        let self = $(this);
        let count = $('#count').text();
        $.ajax({
            url: '/works/confirm',
            data: {id: id},
            success: function (res) {
                if (res === 'ok') {
                    n.find('.new').fadeOut(1000);
                    self.fadeOut(1000)
                    $('#count').text(count-1);
                }
            },
            error: function () {
                console.log('error')
            }
        })
    });

    $('.interested').click(function () {
        let id = $(this).data('id');
        let int = $(this).data('int');
        let self = $(this);
        $.ajax({
            url: '/works/confirmi',
            data: {id: id,int: int},
            success: function (res) {
                $('#collapse'+id+' .interested').fadeOut(1000);
                if (res === 'ok') {
                    $('.panel[data-id="'+id+'"]').removeClass('panel-primary').addClass('panel-success');
                    Swal.fire('Отлично!', 'Вакансия добавлена в список желаемых!', 'success')
                    self.parent().fadeOut(1000)
                } else {
                    $('.panel[data-id="'+id+'"]').fadeOut(1000);
                    Swal.fire('', 'Вакансия скрыта', 'error')
                }
            },
            error: function () {
                console.log('error')
            }
        })
    })
</script>
<style>
    .panel-success>.panel-heading { background-color: green; }
</style>