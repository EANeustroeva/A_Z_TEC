<a href="/noty" class="btn btn-default">Назад</a>
<?php if ($q): ?>
    <h3>Номер вакансии: <?= $_GET['id'] ?><br>Заголовок: <?= $q->header ?></h3>
<?php endif; ?>
<hr>
<table class="table table-striped table-hover table-bordered table-responsive">
    <thead>
        <tr>
            <th>Студент</th>
            <th>Группа</th>
            <th>Профиль</th>
            <th>Направление</th>
            <?php if (!isset($_GET['id'])): ?>
                <th title="Номер уведомления">№</th>
            <?php endif; ?>
            <th>Ознакомлен</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($nys as $item): ?>
    <?php if (!empty($_GET['id']) && $item['noty_id']!=$_GET['id']) continue ?>
        <tr>
            <td><?=$users[$item['user_id']]['name']?></td>
            <td><?=$users[$item['user_id']]['class']?></td>
            <td><?=$users[$item['user_id']]['profile']?></td>
            <td><?=$users[$item['user_id']]['napr_post']?></td>
            <?php if (!isset($_GET['id'])): ?>
                <td><?=$item['noty_id']?>
            <?php endif; ?>
            <td><?=date("d.m.Y H:i",strtotime($item['created']))?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/select/1.2.5/css/select.dataTables.min.css">

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script>
    table = $('table').DataTable({
        stateSave: true,
        // "info":     false,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Russian.json"
        }
    });
</script>