<div id="mod" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <a href="#" class="btn btn-success" data-dismiss="modal">Ознакомлен</a>
      </div>
    </div>

  </div>
</div>
<form action="<?= BASE_URL ?>works/save" method="post" class="form-horizontal">
<div class="panel panel-default">
    <div class="panel-heading">
        Редактирование вакансии
        <div class="checkbox pull-right" style="padding: 0;line-height: 1;">
            <label><input type="checkbox" name="enabled" <?= $q['enabled']==1||is_null($q['enabled'])?'checked':'' ?>>Активно</label>
        </div>
        <div class="input-group date pull-right" style="width: 150px; margin-right: 1em;">
            <input type="text" class="datepicker form-control" name="date_end" value="<?= $q['date_end']?date("d.m.Y",strtotime($q['date_end'])):''; ?>" style="height: 26px;">
            <span class="input-group-addon" style="font-size: 10px;"><i class="glyphicon glyphicon-calendar"></i></span>
        </div>
        <span class="pull-right" style="margin-right: 1em;">Срок действия:</span>
    </div>
    <div class="panel-body">
         <div class="col-sm-12">
            <h4></h4>
            <div class="col-xs-6">
                <div class="form-group">
                    <label for="" class="col-xs-6">Направление</label>
                    <div class="col-xs-6">
                        <select name="napr[]" id="napr" class="selectpicker form-control" multiple>
                        <?php foreach ($napr_list as $k => $item): ?>
                            <?php $s = ''; if (isset($q) && !empty($q['napr'])) {
                                $s = in_array($k,json_decode($q['napr'],1)) ? ' selected' : '';
                            } ?>
                            <option <?= $s ?> value="<?= $k ?>"><?= $item ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-xs-6">Год зачисления</label>
                    <div class="col-xs-6">
                        <?php $arr = @json_decode($q['course'],1) ?>
                        <select name="course[]" id="course" class="selectpicker form-control" multiple>
                            <option <?=in_array(0,$arr)?'selected ':''?>value="0">2018</option>
                            <option <?=in_array(1,$arr)?'selected ':''?>value="1">2017</option>
                            <option <?=in_array(2,$arr)?'selected ':''?>value="2">2016</option>
                            <option <?=in_array(3,$arr)?'selected ':''?>value="3">2015</option>
                            <option <?=in_array(4,$arr)?'selected ':''?>value="4">2014</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-xs-6">
                 <div class="form-group">
                    <label for="" class="col-xs-6">Группа</label>
                    <div class="col-xs-6">
                        <select  class="selectpicker form-control" name="class[]" id="class" title="Группа" multiple
                                data-live-search="true" data-actions-box="true" data-size="10">
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-xs-6">Студент</label>
                    <div class="col-xs-6">
                        <select  class="selectpicker form-control" name="users[]" id="users" title="Студент" multiple
                                data-live-search="true" data-actions-box="true" data-size="10">
                        </select>
                    </div>
                </div>
            </div>
             <div class="clearfix"></div>
            <hr class="form-group">
            <div class="col-xs-12">
                <div class="row">
                    <div class="col-xs-6">
                        <div class="form-group">
                            <label class="col-xs-4">Зарплата</label>
                            <div class="col-xs-8">
                                <input type="text" class="form-control" name="price" value="<?= @$q['price'] ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-6">
                        <div class="form-group">
                            <label class="col-xs-4">Телефон</label>
                            <div class="col-xs-8">
                                <input type="text" class="form-control" id="phone" name="phone" value="<?= @$q['phone'] ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-4">Работодатель</label>
                    <div class="col-xs-8">
                        <input type="text" class="form-control" name="employer" value="<?= @$q['employer'] ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-4">Адрес</label>
                    <div class="col-xs-8">
                        <input type="text" class="form-control" name="address" value="<?= @$q['address'] ?>">
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
             <hr class="form-group">
            <div class="col-xs-12">
                <div class="form-group">
                    <label for="msgd">Заголовок:</label>
                    <input type="text" class="form-control" name="header"  value="<?= @$q['header'] ?>">
                </div>
                <div class="form-group">
                    <label for="msgd">Сообщение:</label>
                    <textarea class="form-control" id="editor1" name="msg" rows="10" ><?= @$q['msg'] ?></textarea>
                </div>
            </div>
         </div>
    </div>
    <div class="panel-footer">
        <input type="hidden" name="id" value="<?= @$_GET['id'] ?>">
            <button type="submit" class="btn btn-success">Сохранить</button>
            <a href="/works" class="btn btn-default">Назад</a>
            <a href="#" data-toggle="modal" data-target="#mod" class="btn btn-warning pull-right">Показать</a>
    </div>
</div>
</form>

<script type="text/javascript" src="/js/tinymce/tinymce.min.js?apiKey=skjd0gy9vnw43ubn4q52n9w7bv6hskiw9yfchm9pdi30nfum"></script>
<script src="/js/plug/jquery.inputmask.bundle.min.js"></script>
<!-- TinyMCE -->
<script>
tinymce.init({
    selector: '#editor1',
    language:"ru",
    height: 400
});
</script>
<!-- /TinyMCE -->
<script>
    $('#mod').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var modal = $(this);
        modal.find('.modal-title').text($('[name=header]').val());
        modal.find('.modal-body').html($('[name=msg]').val());
    });
    function get_classes() {
        $.ajax({
            url: '/works/getclasslist',
            type: 'post',
            data: {'course': $('#course').val()},
            success: function (res) {
                $('#class').html(res).selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }
    function get_studs() {
        $.ajax({
            url: '/works/getstudlist',
            type: 'post',
            data: {'class': $('#class').val()},
            success: function (res) {
                $('#users').html(res).selectpicker('refresh');
            },
            error: function () {
                console.log('Error!');
            }
        });
    }

    $('#course').on('changed.bs.select', function (e) { get_classes() });
    $('#class').on('changed.bs.select', function (e) { get_studs() });

    $(document).ready(function() {
        let selected = <?=@$q['class'] ?: '""'?>;
        $.ajax({
            url: '/works/getclasslist',
            type: 'post',
            data: {'course': $('#course').val()},
            success: function (res) {
                $('#class').html(res).val(selected).selectpicker('refresh');
                selected = <?=@$q['users'] ?: '""'?>;
                $.ajax({
                    url: '/works/getstudlist',
                    type: 'post',
                    data: {'class': $('#class').val()},
                    success: function (res) {
                        $('#users').html(res).val(selected).selectpicker('refresh');
                    },
                    error: function () {
                        console.log('Error!');
                    }
                });
            },
            error: function () {
                console.log('Error!');
            }
        });

        $('.datepicker').datepicker({
            language: 'ru',
            format: 'dd.mm.yyyy',
            todayHighlight: true,
            autoclose: true
        });
        $('#phone').inputmask("+7(999)999-99-99");
    });
</script>