<div class="panel panel-default">
    <div class="panel-body">
        <div class="row">
            <div class="col-xs-3">
                <div class="form-group" style="margin: 0;">
                    <select required class="selectpicker form-control" name="course" id="course" title="*Год поступления">
                        <option selected value="0">2018</option>
                        <option value="1">2017</option>
                        <option value="2">2016</option>
                        <option value="3">2015</option>
                        <option value="4">2014</option>
                        <!--                                <option value="5">5 курс</option>-->
                    </select>
                </div>
            </div>
            <div class="col-xs-3">
                <div class="form-group" style="margin: 0;">
                    <select required class="selectpicker form-control" name="sem" id="sem" title="*Семестр">
                        <option selected value="1">1 семестр</option>
                        <option value="2">2 семестр</option>
                        <option value="3">3 семестр</option>
                        <option value="4">4 семестр</option>
                        <option value="5">5 семестр</option>
                        <option value="6">6 семестр</option>
                        <option value="7">7 семестр</option>
                        <option value="8">8 семестр</option>
                        <option value="9">9 семестр</option>
                    </select>
                </div>
            </div>
            <div class="col-xs-3">
                <div class="form-group" style="margin: 0;">
                    <select name="" id="napr" class="selectpicker form-control" title="Направление">
                        <option value="">Не выбрано</option>
                        <?php foreach ($napr_list as $k => $item): ?>
                            <option value="<?= $k ?>"><?= $item ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="col-xs-3">
                <div class="form-group" style="margin: 0;">
                    <select required class="selectpicker form-control" name="class[]" id="class" title="*Группа"
                            data-live-search="true" data-actions-box="true" data-multipleSeparator="|" data-size="10">
                    </select>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="table">
    <div class="panel panel-default">
        <div class="panel-body text-center">
            Выберите группу
        </div>
    </div>
</div>

<!--<form action="--><?//= BASE_URL ?><!--tasks" method="get" target="_blank">-->
<div class="panel-group" id="accordion">
    <?php foreach ($port as $i => $sem): ?>
        <?php if (empty($sem)) continue ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?= $i ?>"><?= $i ?> семестр</a>
                </h4>
            </div>
            <div id="collapse<?= $i ?>" class="panel-collapse collapse in">
                <div class="panel-body">
                    <div class="row">
                        <table class="table table-condensed table-bordered table-striped table-hover table-responsive">
                            <thead>
                            <tr>
                                <th>Предмет</th>
                                <th>Итого</th>
                                <th>Лек.</th>
                                <th>Прак.</th>
                                <th>Лаб.</th>
                                <th>Экз.</th>
                                <th>Зач.</th>
                                <th>Кур.</th>
                                <th>Атт.</th>
                                <th>Контр.</th>
                                <th>Преподаватель</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($sem as $item): ?>
                                <tr>
                                    <td class="text-left">
                                        <?= $item['disc'] ?>
                                        <!--                                            <button class="btn-link text-left" name="disc" value="--><?//= $item['disc'] ?><!--">--><?//= $item['disc'] ?><!--</button>-->
                                    </td>
                                    <?php $parse = explode('|',$item["s$i"]) ?>
                                    <?php foreach ($parse as &$it)
                                        if ($it==0) $it='';?>

                                    <td><?= (int)$parse[5]+(int)$parse[7] ?></td>
                                    <td><?= $parse[5] //л ?></td>
                                    <td><?= $parse[7] //пр ?></td>
                                    <td><?= $parse[6] //лб ?></td>
                                    <td><?= ($parse[0])?'экз':'' //экз ?></td>
                                    <td><?= ($parse[1]>0)?'зач':(($parse[1]<0)?'диф.зач':"") //зач ?></td>
                                    <td><?= $parse[2] //кур ?></td>
                                    <td><?php switch ($parse[4]) { case 1: echo 'экз'; break; case 2: echo 'зач'; break; case 15: echo 'диф.зач'; break; default: echo $parse[4];} //a?></td>
                                    <td><?= ($parse[3]>0)?'к.р':(($parse[3]<0)?'дом.к.р':"") //к ?></td>

                                    <!--                                        <td class="text-right"><a href="--><?//= BASE_URL ?><!--?id=--><?//= $item['user_id'] ?><!--">--><?//= $item['lektor'] ?><!--</a></td>-->
                                    <td class="text-right">
                                        <!--                                            <a target="_blank" href="--><?//= BASE_URL ?><!--?id=--><?//= $item['user_id'] ?><!--">-->
                                        <?php
                                        if ($item['lektor']) {
                                            $name = explode(" ",$item['lektor']);
                                            $teacher = $name[0] . '&nbsp;' . mb_substr($name[1],0,1,"UTF-8") . '.' . mb_substr($name[2],0,1,"UTF-8") . '.';
                                            echo $teacher;
                                        }
                                        ?>
                                        <!--                                            </a>-->
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<!--</form>-->

<style>
    #accordion .area { border-left: 4px solid #f38787; }
    #accordion .equipamento { border-left: 4px solid #65c465; }
    #accordion .ponto { border-left: 4px solid #98b3fa; }
    #accordion .collapse.in { overflow: visible; }
    #accordion .panel-body { padding: 15px; }
    .panel-group .panel+.panel { margin-top: 0px; }
    #accordion .panel-default>.panel-heading { background-color: transparent; }
</style>
<style>
    .panel-body { padding: 15px; }
    div.tooltip-inner {
        max-width: inherit;
        text-align: center;/*
        -webkit-border-radius: 0px;
        -moz-border-radius: 0px;
        border-radius: 0px;
        margin-bottom: 6px;
        background-color: #505050;*/
        font-size: 16px;
    }
</style>

<script>
    $('body').tooltip({ selector: '[data-toggle=tooltip]' });

    $('#course').on('changed.bs.select', function (e) { get_list(); });
    $('#napr').on('changed.bs.select', function (e) { get_list(); });

    $('#class').on('changed.bs.select', function (e) {
        let cl = $(this).val();
        $.ajax({
            url: '/planview/getPlan',
            type: 'get',
            // data: {'class': 'ТЕСТ-18','sem': 1},
            data: {'class': cl,'sem': $('#sem').val()},
            success: function (res) {
                $('#table').html(res.res);
            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    $('#sem').on('changed.bs.select', function (e) {
        $.ajax({
            url: '/planview/getPlan',
            type: 'get',
            data: {'class': $('#class').val(),'sem': $('#sem').val()},
            success: function (res) {
                $('#table').html(res.res);
            },
            error: function () {
                console.log('Error!');
            }
        });
    });

    function get_list() {
        $.ajax({
            url: 'getList',
            type: 'get',
            data: {'course': $('#course').val(), napr: $('#napr').val()},
            success: function (res) {
                $('#class').html(res).selectpicker('refresh');
            },
            error: function () {
                $('#class').html('').selectpicker('refresh');
                console.log('Error!');
            }
        });
    }
</script>