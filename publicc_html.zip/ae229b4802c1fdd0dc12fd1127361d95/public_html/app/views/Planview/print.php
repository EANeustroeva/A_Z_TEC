<?= $html ?>

<style>
    h3,h4 {
        margin: 0;
    }

    table {
        border-collapse: collapse;
        margin-top: 1em;
        margin-bottom: 1em;
    }

    table, th, td {
        border: 1px solid black;
    }
</style>