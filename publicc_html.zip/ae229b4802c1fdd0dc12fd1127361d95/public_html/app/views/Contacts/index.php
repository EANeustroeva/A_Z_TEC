<div class="visible-xs clearfix title-name">
    <h4 class="text-capitalize pull-left"><?= $s_user['firstname'] ?> <?= $s_user['lastname'] ?> <?= $s_user['surname'] ?></h4>
    <h5 class="pull-right">
        <span class="btn btn-xs btn-<?php echo $s_user->online == 1 ? 'success' : 'danger'; ?>"
              id="current_status"><?php echo $s_user->online == 1 ? 'Online' : 'Offline'; ?></span>
    </h5>
</div>

<div class="row">
    <div class="col-sm-3">
        <div class="row">
            <div class="col-xs-5 col-sm-12">
                <img src="http://www.girardatlarge.com/wp-content/uploads/2013/05/gravatar-60-grey.jpg"
                     class="img-responsive" alt="Generic thumbnail">

                <?php if ($cur_user['id'] != $s_user['id']) { ?>
                    <?php $sel = false;
                    foreach ($users as $usr) {
                        if ($s_user['id'] == $usr['id']) {
                            $sel = true;
                            break;
                        };
                    } ?>
                    <form action="users/dialog" method="post">
                        <button href="" class="btn btn-primary" style="margin: 5px 0 0;width: 100%;">Написать
                        </button>
                        <input type="hidden" name="usr_id" value="<?= $s_user['id'] ?>">
                    </form>
                    <?php if (!$sel) { ?>
                        <form action="users/addFriend" method="post">
                            <button href="" class="btn btn-warning" style="margin: 5px 0 0;width: 100%;">Добавить
                            </button>
                            <input type="hidden" name="usr_id" value="<?= $s_user['id'] ?>">
                        </form>
                    <?php } else { ?>
                        <form action="users/delFriend" method="post">
                            <button href="" class="btn btn-danger" style="margin: 5px 0 10px;width: 100%;">Удалить
                            </button>
                            <input type="hidden" name="usr_id" value="<?= $s_user['id'] ?>">
                        </form>
                    <?php } ?>
                <?php } ?>

            </div>

            <div class="col-xs-7 col-sm-12">
                <div class="panel-group" id="accordion2">
                    <!-- 1 панель -->
                    <div class="panel panel-default">
                        <!-- Заголовок 1 панели -->
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion2" href="#collapse_1">Студенты</a>
                            </h4>
                        </div>
                        <div id="collapse_1" class="panel-collapse collapse in">
                            <!-- Содержимое 1 панели -->
                            <div class="panel-body">
                                <div class="list-group">
                                    <?php foreach ($users as $user) {
                                        if ($user['is_student'] == 0) continue;
                                        if ($user['id'] != $cur_user['id']) { ?>
                                            <a href="?id=<?= $user['id'] ?>" data-toggle="popover"
                                               class="list-group-item <?= $user['selected'] ? 'selected' : '' ?>">
                                                <div class="contact-wrap">
                                                    <input type="hidden" value="<?php echo $user['id']; ?>"
                                                           name="user_id"/>
                                                    <span class="contact-name"><span
                                                                style="display: table-cell;vertical-align: middle;"
                                                                class="user_status">
            <?php $status = $user['online'] == 1 ? 'is-online' : 'is-offline'; ?>
                                                            <span class="user-status <?php echo $status; ?>"></span>
            <small class="user-name"><?php echo ucwords($user['firstname'] . ' ' . mb_strimwidth($user['lastname'], 0, 2, '.')); ?></small>

        </span>

        </span>
                                                </div>
                                            </a>
                                        <?php }
                                    } ?>


                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 2 панель -->
                    <div class="panel panel-default">
                        <!-- Заголовок 2 панели -->
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion2" href="#collapse_2">Сотрудники</a>
                            </h4>
                        </div>
                        <div id="collapse_2" class="panel-collapse collapse in">
                            <!-- Содержимое 2 панели -->
                            <!--                --><? //= dump($class) ?>
                            <div class="panel-body">
                                <div class="list-group">
                                    <?php foreach ($users as $user) {
                                        if ($user['is_student'] == 1) continue;
                                        if ($user['id'] != $cur_user['id']) { ?>
                                            <a href="?id=<?= $user['id'] ?>" data-toggle="popover"
                                               class="list-group-item <?= $user['selected'] ? 'selected' : '' ?>">
                                                <div class="contact-wrap">
                                                    <input type="hidden" value="<?php echo $user['id']; ?>"
                                                           name="user_id"/>
                                                    <span class="contact-name"><span
                                                                style="display: table-cell;vertical-align: middle;"
                                                                class="user_status">
            <?php $status = $user['online'] == 1 ? 'is-online' : 'is-offline'; ?>
                                                            <span class="user-status <?php echo $status; ?>"></span>
            <small class="user-name"><?php echo ucwords($user['firstname'] . ' ' . mb_strimwidth($user['lastname'], 0, 2, '.')); ?></small>

        </span>

        </span>
                                                </div>
                                            </a>
                                        <?php }
                                    } ?>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="hidden-xs clearfix title-name">
            <h4 class="text-capitalize pull-left"><?= $s_user['firstname'] ?> <?= $s_user['lastname'] ?> <?= $s_user['surname'] ?></h4>
            <h5 class="pull-right">
        <span class="btn btn-xs btn-<?php echo $s_user->online == 1 ? 'success' : 'danger'; ?>"
              id="current_status"><?php echo $s_user->online == 1 ? 'Online' : 'Offline'; ?></span>
            </h5>
        </div>

        <div class="bg-warning" style="padding: 10px; margin-bottom: 15px;">
            <p><strong>Контактные данные</strong></p>
            <ul class="list-unstyled">
                <li>Телефон: <?= $s_user['phone'] ?></li>
                <li>E-mail: <?= $s_user['email'] ?></li>
            </ul>
        </div>

        <div class="panel-group " id="accordion">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Учебные данные</a>
                    </h4>
                </div>
                <div id="collapse1" class="panel-collapse collapse in">
                    <div class="/*panel-body*/">
                        <table class="table table-hover" style="margin-bottom: 0;">
                            <!-- <tbody> -->
                            <tr>
                                <td>Группа</td>
                                <td><?= $s_user->class ?></td>
                            </tr>
                            <tr>
                                <td>Курс</td>
                                <td><?= $s_user->course ?></td>
                            </tr>
                            <?php if ($s_user['id'] == $cur_user['id']): ?>
                                <tr>
                                    <td>№ Зачетки</td>
                                    <td><?= $s_user->credit_book ?></td>
                                </tr>

                                <tr>
                                    <td>Статус оплаты</td>
                                    <td>
                                        <i class="glyphicon glyphicon-<?= $s_user->pay_status ? 'ok' : 'remove' ?>"></i><?= $s_user->pay_status ? ' Оплачено' : ' Нет оплаты' ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            <!-- </tbody> -->
                        </table>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Персональные данные</a>
                    </h4>
                </div>
                <div id="collapse2" class="panel-collapse collapse">
                    <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                        minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                        commodo consequat.
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Образование</a>
                    </h4>
                </div>
                <div id="collapse3" class="panel-collapse collapse">
                    <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                        minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                        commodo consequat.
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">Карьера</a>
                    </h4>
                </div>
                <div id="collapse4" class="panel-collapse collapse">
                    <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                        minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                        commodo consequat.
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">Доп. информация</a>
                    </h4>
                </div>
                <div id="collapse5" class="panel-collapse collapse">
                    <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                        minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                        commodo consequat.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>