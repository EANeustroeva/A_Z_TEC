<?php


namespace app\models;


use vendor\core\base\Model;

class Doc extends Model {

    public $list;

    public function __construct() {
        $this->list = [];
    }

    public function getList($user_id, $type = 0) {
        $this->list = \R::findAll('files', "user_id=? AND type=?", [$user_id, $type]);
        if (!$this->list) return false;
        $count = 0;
        foreach ($this->list as $l) {
            $count += intval($l['fsize']);
        }
        foreach ($this->list as &$l) {
            $l['name'] = $l['ftitle'];
            $l['real'] = $l['fname'];
            $l['date'] = $l['fdata'];
            $l['size'] = number_format($l['fsize'], 0, '.', '').' Кб';
            $l['type'] = $l['fext'];
        }
//        $this->list['full_size'] = floor($count * 100 / 1024 / 1024);
        /*
        if ($handle = opendir($dir)) {
//            echo "Дескриптор каталога: $handle\n";
//            echo "Файлы:\n";
*/
            /* Именно этот способ чтения элементов каталога является правильным. */
 /*           while (false !== ($file = readdir($handle))) {
                if ($file == '.' || $file == '..' || is_dir($dir.'/'.$file)) continue;
                $name = pathinfo($file)['filename'];
//                debug(pathinfo($file));
//                dd($file['filename']);
                $date = time(); /date("d F", filectime($dir.'/'.$file)) .
                    '<span class="hidden-xs">'.date(" H:i:s", filectime($dir.'/'.$file)).'</span>';///F d Y H:i:s.
                $size = round( (filesize($dir.'/'.$file)/1024) ,2) . ' Кб';
                $type = pathinfo($file)['extension'];//substr(strrchr($file, '.'), 1);
                array_push($this->list, [
                    'name'=>$name, 'date'=>$date, 'size'=>$size, 'type'=>$type
                ]);
            }
//            dump($this->list);

            closedir($handle);
        }
        */
//        usort($this->list, function ($a,$b) {
//            return strnatcasecmp($a['date'], $b['date']);
//        });
        return $this->list;
    }

    public function getListDir($dir='') {
        if ($handle = opendir($dir)) {
//            echo "Дескриптор каталога: $handle\n";
//            echo "Файлы:\n";
            $name = [];
            /* Именно этот способ чтения элементов каталога является правильным. */
            while (false !== ($file = readdir($handle))) {
                if ($file == '.' || $file == '..' || is_dir($dir.'/'.$file)) continue;
                $name[] = pathinfo($file)['basename'];
//                debug(pathinfo($file));
//                dd($file['filename']);

            }

            usort($name, function ($a,$b) {
                return strnatcasecmp($a, $b);
            });
//            dd($name);
            closedir($handle);
            return $name;
        }
    }

}