<?php


namespace app\models;


use vendor\core\base\Model;

class Lastmsg extends Model {

    public function update_lastSeen($user = 0) {
        $last_msg = \R::getRow("SELECT m.* FROM messages m, userdialog u WHERE 
          m.dialog_id=u.userdialog AND u.user_id=? ORDER BY msg_time DESC", [$user]);
//        dd($last_msg);
        $msg = !empty($last_msg) ? $last_msg['id'] : 0;

        $record = $this->get_by('user_id', $user);
//        dd($record);
        $details = [
            'user_id' => $user,
            'message_id' => $msg
        ];
        if (empty($record)) {
            $this->insert($details);
        } else {
            $msg = \R::load('lastseen', $record->id);
            $msg->import($details);
            \R::store($msg);
//            $this->update($record->id, $details);
        }
    }

    public function get_by($user_id) {
        return \R::findOne('lastseen', 'user_id = ?', [$user_id]);
    }

    public function insert($data=[]) {
        $message = \R::dispense('lastseen');
        $message ->import($data);
        \R::store($message);
    }
}