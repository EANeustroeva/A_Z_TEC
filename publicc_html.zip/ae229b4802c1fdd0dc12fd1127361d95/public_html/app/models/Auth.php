<?php


namespace app\models;


use vendor\core\base\Model;

class Auth extends Model {

}