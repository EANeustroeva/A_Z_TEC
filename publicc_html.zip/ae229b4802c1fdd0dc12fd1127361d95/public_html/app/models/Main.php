<?php

namespace app\models;

/**
 * Description of Main
 *
 */
class Main extends \fw\core\base\Model{
    
    public $table = 'posts';
    public $pk = 'id';
    
}
