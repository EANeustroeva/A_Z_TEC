<?php
//267

namespace app\models;


use vendor\core\base\Model;

class Message extends Model {

    public function conversation($dialog_id, $limit = 5) {
        $messages = \R::getAll("SELECT * FROM messages WHERE dialog_id=? ORDER BY id DESC LIMIT ?",[$dialog_id, $limit]);
        //$this->db->where('to', $user)->where('from', $chatbuddy)->update('messages', array('is_read' => '1'));
        foreach ($messages as $k=>$message) $messages[$k]['message'] = htmlentities($messages[$k]['message']);
        return $messages;
    }

    public function conversation_len($dialog_id) {
        $messages = count(\R::getAll("SELECT * FROM messages WHERE dialog_id=? ORDER BY id DESC",[$dialog_id]));
        //$this->db->where('to', $user)->where('from', $chatbuddy)->update('messages', array('is_read' => '1'));
        return $messages;
    }

    public function thread_len($user, $chatbuddy) {
        $messages = count(\R::getAll("SELECT * FROM messages WHERE user_id=? AND dialog_id=? OR user_id=? AND dialog_id=? ORDER BY id DESC", [
            $user,
            $chatbuddy,
            $chatbuddy,
            $user
        ]));
        return $messages;
    }

    public function latest_message($user, $last_seen) {
        $message = \R::getRow("SELECT * FROM messages WHERE dialog_id IN (SELECT dialog_id FROM userdialog WHERE user_id=?) AND user_id != ? AND id > ? ORDER BY msg_time DESC",[$user, $user, $last_seen]);
        if (count($message) > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function new_messages($user, $last_seen) {
//        $messages = \R::getAll("SELECT * FROM messages WHERE dialog_id IN (SELECT dialog_id FROM userdialog WHERE user_id=?) AND user_id != ? AND id > ? ORDER BY msg_time ASC ",[$user, $user, $last_seen]);
        $messages = \R::getAssoc("SELECT m.*, u.user_id, u.dialog_id FROM messages m, userdialog u WHERE
            m.dialog_id=u.dialog_id AND u.user_id=? AND m.user_id != ? AND m.id > ? ORDER BY m.msg_time ASC ",[$user, $user, $last_seen]);
//        dd($messages);
        return $messages;
    }

    public function unread($user) {
        $class = addcslashes(json_encode( $user['class']),'\\');
        $q = $user->is_student ? "AND (d.course IS NULL OR d.course=?) AND (d.class IS NULL OR d.class LIKE ?)" : 'AND d.user_id=?';
        $p = $user->is_student ? [$user['id'],$user['id'], $user['id'],$user['id'],
                                    $user['course'], "%$class%"]: [$user['id'],$user['id'], $user['id'],$user['id'],$user['id']];
        $messages = \R::getAssoc("SELECT d.*, u.user_id, u.dialog_id FROM dialogs d LEFT OUTER JOIN userdialog u ON d.id=u.dialog_id WHERE 
            d.is_read=0 AND d.msg_from!=? AND (
            ( d.public=0 AND (d.name=? OR d.user_id=?) ) OR 
            ( d.public=1 AND u.user_id=?) OR
            ( d.public=2 $q ) ) ORDER BY d.updated DESC", $p);
//         ORDER BY msg_time DESC
//        dd($messages);
        return $messages;
    }

    public function mark_read($id) {
//        $id = $_GET['id'];//$this->input->post('id');
       // \R::fancyDebug(true);
       $message = \R::load('messages',$id);
       $dialog = \R::load('dialogs', $message->dialog_id);
       // dd($message);
       $message->is_read = '1';
       $dialog->is_read = '1';
       \R::store($message);
       \R::store($dialog);

//        $this->db->where('id', $id)->update('messages', array('is_read' => '1'));
    }

    public function unread_per_user($id, $dialog_id) {
        return count(\R::findAll('messages', "dialog_id=? AND user_id!=? AND is_read=0",
            [$dialog_id, $id]));
    }

    public function get_last_message($dialog) {
//        $message = \R::getAll("SELECT * FROM messages WHERE ");
//        $message =  \R::getRow("SELECT message FROM messages WHERE user_id=? AND dialog_id=? ORDER BY msg_time DESC LIMIT 1",[$key, $sender]);
        $message = \R::getRow("SELECT message,msg_time,user_id,is_read FROM messages WHERE dialog_id=? ORDER BY msg_time DESC", [$dialog]);
        return $message;
    }

    public function get($id) {
        return \R::findOne('messages', 'id = ?', [$id]);
    }

//'user_id' => $logged_user,
//'dialog_id' => $buddy,
//'message' => $message,
    public function insert($data=[]) {
        $message = \R::dispense('messages');
        $message->import($data);
        $message->message = $message->message; //$this->filter_bazar($message->message);
        \R::store($message);

        $dialog = \R::load('dialogs',$message->dialog_id);
        $dialog->msg_from = $message->user_id;
        $dialog->updated = \R::isoDateTime();
        $dialog->msg = $message->message;//$this->filter_bazar($message->message);
        $dialog->is_read = '0';
        \R::store($dialog);
    }

    public function getDialogs($user) {
//        \R::fancyDebug(true);
        $class = addcslashes(json_encode( $user['class']),'\\');
        $q = $user->access == 4 ? "AND (d.course IS NULL OR d.course=?) AND (d.class IS NULL OR d.class LIKE ?)" : "AND d.user_id=?";
        $p = $user->access == 4 ? [$user['id'], $user['id'], $user['id'], $user['course'], "%$class%"] : [$user['id'], $user['id'], $user['id'], $user['id']];
//        $p = [$user['id'], $user['id']];
		// $p = [$user['id'], $user['id']];
        $dialogs = \R::getAll("SELECT DISTINCT d.* FROM dialogs d LEFT OUTER JOIN userdialog u ON d.id=u.dialog_id WHERE
            ( d.public=0 AND (d.name=? OR d.user_id=?) OR ( d.public=1 AND u.user_id=? and date(updated)>'2019-10-20') OR ( d.public=2 and date(updated)>'2019-10-20' $q )) ORDER BY d.updated DESC ", $p);

        /*	OR ( d.public=1 AND u.user_id=?) OR ( d.public=2 $q )

        */

//        dd($dialogs);
        return $dialogs;
    }

    public function getUserFromDialog($user, $dialog_id) {
//        $u = \R::getRow("SELECT user_id FROM userdialog WHERE dialog_id=? AND user_id!=?",[$dialog_id,$user]);
        $u = \R::getRow("SELECT name,user_id FROM dialogs WHERE id=?",[$dialog_id]);
//        $u = \R::getRow("SELECT name,user_id FROM dialogs WHERE id=? and user_id!=?",[$dialog_id, $user]);
        return $u['user_id'] == $user ? $u['name']:$u['user_id'];
    }

    public function create_dialog($id, $msg, $name=null, $public=0, $fac=null, $class=null, $course=null) {
        $dialogs = \R::dispense('dialogs');
        $dialogs->name = $name;
        $dialogs->public = $public;
        $dialogs->user_id = $id;
        $dialogs->msg_from = $id;
        $dialogs->msg = $msg; //$this->filter_bazar($msg);
        $dialogs->updated = \R::isoDateTime();
        if ($public==2) {
            $dialogs->fac = $fac;
            $dialogs->class = $class;
            $dialogs->course = $course;
        }
        \R::store($dialogs);
        if ($public==1) $this->add_user_to_dialog($id,$dialogs->id);
        $this->insert([
            'user_id' => $id,
            'dialog_id' => $dialogs->id,
            'message' => $msg,
        ]);
        return $dialogs->id;
    }

    public function add_user_to_dialog($user, $dialog) {
        $dlgusrs = \R::dispense('userdialog');
        $dlgusrs->user_id = $user;
        $dlgusrs->dialog_id = $dialog;
        \R::store($dlgusrs);
    }

    public function messages($id = null) {
        //get paginated new_messages
        $per_page = 5;
        $user = $_SESSION['logged_user']['id'];
        if (!empty($id)) $dialog_id = $id;
        else return null;//$dialog_id = isset($_GET['id']) ? $_GET['id'] : 0;//$this->input->post('user');
        $limit = isset($_POST['limit']) ? $_POST['limit'] : $per_page;
        $messages = array_reverse($this->conversation((int)$dialog_id, (int)$limit));

        $total = $this->thread_len($user, $dialog_id);

        $thread = array();
        foreach ($messages as $message) {
            $owner = \R::load('users', $message['user_id']);
            if ($message['user_id'] != $user && $message['is_read'] == '0') $this->mark_read($message['id']);
            $chat = ['msg' => $message['message'], 'status' => $message['is_read'], 'sender' => $message['user_id'],
                     'recipient' => $message['dialog_id'],
                     'avatar' => $owner->avatar = $owner->photo != '' ? BASE_URL .'order/'.$owner->photo: BASE_URL . 'assets/images/thumbs/no-image.jpg',
                     //                 'body' => parse_smileys($message->message, $this->smiley_url),
                     'body' => $message['message'],
                     'time' => date("M j, Y, g:i a", strtotime($message['msg_time'])),
                     'type' => $message['user_id'] == $user ? 'out' : 'in',
                     'name' => explode(' ', $owner->name)[1] ?: 'Вы'];
            array_push($thread, $chat);
        }

        $buddy_id = $this->getUserFromDialog($user, $dialog_id);

        $chatbuddy = \R::load('users', $buddy_id);
        $contact = ['name' => $chatbuddy->name,
                    'd_id' => $dialog_id,
                    'status' => $chatbuddy->online, 'id' => $chatbuddy->id, 'limit' => $limit + $per_page,
                    'more' => $total <= $limit ? false : true, 'scroll' => $limit > $per_page ? false : true,
                    'remaining' => $total - $limit];
        $response = ['success' => true, 'errors' => '', 'message' => '', 'buddy' => $contact, 'thread' => $thread];
        //add the header here
        // header('Content-Type: application/json');
        return json_encode($response);
    }

    public function filter_bazar($msg = '', $flag = true) {
        $bad = "6ля|6лядь|6лять|b3ъeб|cock|cunt|e6aль|ebal|eblan|eбaл|eбaть|eбyч|eбать|eбёт|eблантий|fuck|fucker|fucking|xyёв|xyй|xyя|xуе,xуй|xую|zaeb|zaebal|zaebali|zaebat|архипиздрит|ахуел|ахуеть|бздение|бздеть|бздех|бздецы|бздит|бздицы|бздло|бзднуть|бздун|бздунья|бздюха|бздюшка|бздюшко|бля|блябу|блябуду|бляд|бляди|блядина|блядище|блядки|блядовать|блядство|блядун|блядуны|блядунья|блядь|блядюга|блять|вафел|вафлёр|взъебка|взьебка|взьебывать|въеб|въебался|въебенн|въебусь|въебывать|выблядок|выблядыш|выеб|выебать|выебен|выебнулся|выебон|выебываться|выпердеть|высраться|выссаться|вьебен|гавно|гавнюк|гавнючка|гамно|гандон|гнид|гнида|гниды|говенка|говенный|говешка|говназия|говнецо|говнище|говно|говноед|говнолинк|говночист|говнюк|говнюха|говнядина|говняк|говняный|говнять|гондон|доебываться|долбоеб|долбоёб|долбоящер|дрисня|дрист|дристануть|дристать|дристун|дристуха|дрочелло|дрочена|дрочила|дрочилка|дрочистый|дрочить|дрочка|дрочун|е6ал|е6ут|еб твою мать|ёб твою мать|ёбaн|ёбaна|ебaть|ебyч|ебал|ебало|ебальник|ебан|ебанамать|ебанат|ебаная|ёбаная|ебанический|ебанный|ебанныйврот|ебаное|ебануть|ебануться|ёбаную|ебаный|ебанько|ебарь|ебат|ёбат|ебатория|ебать|ебать-копать|ебаться|ебашить|ебёна|ебет|ебёт|ебец|ебик|ебин|ебись|ебическая|ебки|ебла|еблан|ебливый|еблище|ебло|еблыст|ебля|ёбн|ебнуть|ебнуться|ебня|ебошить|ебская|ебский|ебтвоюмать|ебун|ебут|ебуч|ебуче|ебучее|ебучий|ебучим|ебущ|ебырь|елда|елдак|елдачить|жопа|жопу|заговнять|задрачивать|задристать|задрота|зае6|заё6|заеб|заёб|заеба|заебал|заебанец|заебастая|заебастый|заебать|заебаться|заебашить|заебистое|заёбистое|заебистые|заёбистые|заебистый|заёбистый|заебись|заебошить|ебош|заебываться|залуп|залупа|залупаться|залупить|залупиться|замудохаться|запиздячить|засерать|засерун|засеря|засирать|засрун|захуячить|заябестая|злоеб|злоебучая|злоебучее|злоебучий|ибанамат|ибонех|изговнять|изговняться|изъебнуться|ипать|ипаться|ипаццо|Какдвапальцаобоссать|конча|курва|курвятник|лох|лошарa|лошара|лошары|лошок|лярва|малафья|манда|мандавошек|мандавошка|мандавошки|мандей|мандень|мандеть|мандища|мандой|манду|мандюк|минет|минетчик|минетчица|млять|мокрощелка|мокрощёлка|мразь|мудak|мудaк|мудаг|мудак|муде|мудель|мудеть|муди|мудил|мудила|мудистый|мудня|мудоеб|мудозвон|мудоклюй|хер|нахуй|набздел|набздеть|наговнять|надристать|надрочить|наебать|наебет|наебнуть|наебнуться|наебывать|напиздел|напиздели|напиздело|напиздили|насрать|настопиздить|нахер|нахрен|нахуй|нахуйник|не ебет|неебёт|невротебучий|невъебенно|нехира|нехрен|Нехуй|нехуйственно|ниибацо|ниипацца|ниипаццо|ниипет|никуя|нихера|нихуя|обдристаться|обосранец|обосрать|обосцать|обосцаться|обсирать|объебос|обьебать обьебос|однохуйственно|опездал|опизде|опизденивающе|остоебенить|остопиздеть|отмудохать|отпиздить|отпиздячить|отпороть|отъебись|охуевательский|охуевать|охуевающий|охуел|охуенно|охуеньчик|охуеть|охуительно|охуительный|охуяньчик|охуячивать|охуячить|очкун|падла|падонки|падонок|паскуда|педерас|педик|педрик|педрила|педрилло|педрило|педрилы|пездень|пездит|пездишь|пездо|пездят|пердануть|пердеж|пердение|пердеть|пердильник|перднуть|пёрднуть|пердун|пердунец|пердунина|пердунья|пердуха|пердь|переёбок|пернуть|пёрнуть|пи3д|пи3де|пи3ду|пизд|пиzдец|пидар|пидр|пидарaс|пидарас|пидарасы|пидары|пидор|пидорасы|пидорка|пидорок|пидоры|пидрас|пизда|пиздануть|пиздануться|пиздарваньчик|пиздато|пиздатое|пиздатый|пизденка|пизденыш|пиздёныш|пиздеть|пиздец|пиздит|пиздить|пиздиться|пиздишь|пиздища|пиздище|пиздобол|пиздоболы|пиздобратия|пиздоватая|пиздоватый|пиздолиз|пиздонутые|пиздорванец|пиздорванка|пиздострадатель|пизду|пиздуй|пиздун|пиздунья|пизды|пиздюга|пиздюк|пиздюлина|пиздюля|пиздят|пиздячить|писбшки|писька|писькострадатель|писюн|писюшка|по хуй|по хую|подговнять|подонки|подонок|подъебнуть|подъебнуться|поебать|поебень|поёбываает|поскуда|посрать|потаскуха|потаскушка|похер|похерил|похерила|похерили|похеру|похрен|похрену|похуй|похуист|похуистка|похую|придурок|приебаться|припиздень|припизднутый|припиздюлина|пробзделся|проблядь|проеб|проебанка|проебать|промандеть|промудеть|пропизделся|пропиздеть|пропиздячить|раздолбай|разхуячить|разъеб|разъеба|разъебай|разъебать|распиздай|распиздеться|распиздяй|распиздяйство|распроеть|сволота|сволочь|сговнять|секель|серун|серька|сестроеб|сикель|сирать|сирывать|соси|спиздел|спиздеть|спиздил|спиздила|спиздили|спиздит|спиздить|срака|сраку|сраный|сранье|срать|срун|ссака|ссышь|стерва|страхопиздище|сука|суки|суходрочка|сучара|сучий|сучка|сучко|сучонок|сучье|сцание|сцать|сцука|сцуки|сцуконах|сцуль|сцыха|сцышь|съебаться|сыкун|трахае6|трахаеб|трахаёб|трахатель|ублюдок|уебать|уёбища|уебище|уёбище|уебищное|уёбищное|уебк|уебки|уёбки|уебок|уёбок|уёбыв|уебыв|уебу|урюк|усраться|ушлепок|х_у_я_р_а|хyё|хyй|хyйня|хамло|хер|херня|херовато|херовина|херовый|хитровыебанный|хитрожопый|хуeм|хуе|хуё|хуевато|хуёвенький|хуевина|хуево|хуевый|хуёвый|хуек|хуёк|хуел|хуем|хуенч|хуеныш|хуенький|хуеплет|хуеплёт|хуепромышленник|хуерик|хуерыло|хуесос|хуесоска|хуета|хуетень|хуею|хуи|хуй|хуйком|хуйло|хуйня|хуйрик|хуище|хуля|хую|хуюл|хуя|хуяк|хуякать|хуякнуть|хуяра|хуясе|хуячить|целка|чмо|чмошник|чмырь|шалава|шалавой|шараёбиться|шлюха|шлюхой|шлюшка|ябывает";
        $replace = ($flag) ? '<span style="color: #FF0000">[вырезано]</span>' : '_Нет_';
        return preg_replace("#{$bad}#si", $replace, mb_strtolower($msg));
    }

}