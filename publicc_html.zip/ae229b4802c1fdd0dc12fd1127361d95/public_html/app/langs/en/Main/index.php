<?php

return [
    'test' => 'Test value',
    'test2' => 'Test value 2',
    'read_more' => 'Read more',
];