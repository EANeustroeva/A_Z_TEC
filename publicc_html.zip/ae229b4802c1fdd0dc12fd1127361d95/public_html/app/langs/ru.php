<?php

return [
    'recent_posts' => 'Последние записи',
    'categories' => 'Категории',
];