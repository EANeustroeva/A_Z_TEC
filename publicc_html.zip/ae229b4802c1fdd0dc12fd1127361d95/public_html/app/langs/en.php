<?php

return [
    'recent_posts' => 'RECENT POSTS',
    'categories' => 'Categories',
];