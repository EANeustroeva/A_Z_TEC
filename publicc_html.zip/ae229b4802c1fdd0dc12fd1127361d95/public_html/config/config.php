<?php

$config = [
    'components' => [
        'cache' => 'fw\libs\Cache',
        'test' => 'fw\libs\Test',
    ],
];

return $config;