<?php

return [
    'dsn' => 'mysql:host=localhost;dbname=sanchozzz_fw;charset=utf8',
    'user' => 'sanchozzz_fw',
    'pass' => '3OqYJZ&Q',
];