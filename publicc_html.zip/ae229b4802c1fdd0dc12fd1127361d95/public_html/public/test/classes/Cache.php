<?php

namespace classes;

/**
 * Description of Cache
 *
 */
class Cache {
    //put your code here
}
