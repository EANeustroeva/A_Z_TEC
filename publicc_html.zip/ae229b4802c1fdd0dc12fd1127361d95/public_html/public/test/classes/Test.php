<?php

namespace classes;

/**
 * Description of Test
 *
 */
class Test {
    public function go(){
        echo 'Поехали!';
    }
}
