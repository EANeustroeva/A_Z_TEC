<?php

namespace classes;

/**
 * Description of Test2
 *
 */
class Test2 {
    
    public function hello(){
        echo 'Hello, world!';
    }
    
}
