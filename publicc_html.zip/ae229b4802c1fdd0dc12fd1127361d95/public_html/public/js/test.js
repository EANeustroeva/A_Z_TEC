$(function(){
//    alert($('#send').text());
});